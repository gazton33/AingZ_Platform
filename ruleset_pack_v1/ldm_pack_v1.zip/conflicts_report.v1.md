# Conflicts report v1 — 2025-08-31

- duplicate_groups: 5
- duplicate_files_extras: 48
- dedup_ratio: 0.020

## filename collisions (top)
- .gitkeep → 45 ocurrencias
