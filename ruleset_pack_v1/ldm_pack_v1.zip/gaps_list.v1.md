# Gaps list v1 — 2025-08-31

- Faltan ADRs formales (architecture decision records).
- Faltan checklists CHK explícitos.
- Faltan artefactos AUDT de auditoría.
- No se encontró carpeta dedicada ruleset/ con gobierno consolidado.
