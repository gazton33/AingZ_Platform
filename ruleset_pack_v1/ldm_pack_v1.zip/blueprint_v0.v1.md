# Blueprint v0 — Plataforma AingZ

## Decisiones
- Arquitectura hexagonal. Proveedor-agnóstico.
- RULESET_MAX rige. SPEC con overrides controlados.
## Componentes
- Ingesta LDM, matrices, ADRs futuros, pipelines CHK/VALD/AUDT.
## Operación
- Staging→Prod con CI de linting y validación de reglas.
