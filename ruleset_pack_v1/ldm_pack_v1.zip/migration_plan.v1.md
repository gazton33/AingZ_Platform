# Plan de Migración v1

1. Normalizar cabeceras YAML en *.md|*.yml y nombres con sufijos _v_*
2. Mapear a RULE,SPEC,ENV,PRC,WK,CHK,VALD,AUDT,RPT según matriz
3. Deduplicar por sha256 y por similitud de título ≥0.90
4. Purga de secretos (.env*, *secret*, *.pem) a metadatos
5. Consolidar gobierno en ruleset/ y congelar baselines V5
