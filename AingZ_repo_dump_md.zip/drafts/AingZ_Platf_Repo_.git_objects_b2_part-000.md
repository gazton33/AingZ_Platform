---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/b2
part_index: 0
files_included: 4
size_bytes_sum: 2447
created_at: 2025-08-31T21:08:15.629691+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/b2/4419cd040a7e0faaf91a3554f607bea958179d
meta: {size:824, lines:0, sha256:"5e530ac599df673c6a5a83c5bf9216cd6bc4e091332272fa8a9dec87826328ce", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b2/63308fb151ac64df85ce2a77c9f78481f381a4
meta: {size:561, lines:0, sha256:"b8087a398629eea56a0304d428109de27b1a14a53dc371bc79be2f83d4ba8826", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b2/78429392960f3812cd652c8053bedb9b8b9589
meta: {size:54, lines:0, sha256:"421353d452c5c930965ab43c3863f9738f81319eb8242249404bb3f2a94f1cd9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b2/b90ead715afba72e68ff60197e60683806390f
meta: {size:1008, lines:0, sha256:"1e3b8d143fd73d7494ebfd0ef8fec1767d2ebcae2dc7660a01fd1438c87946fe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

