---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/26
part_index: 0
files_included: 9
size_bytes_sum: 11412
created_at: 2025-08-31T21:08:15.569955+00:00
integrity:
  sha256_concat: 08e1d508dd89c75e28a74aeda70767e29aef257c8de97a52e9fb110ede0cef92
---

## AingZ_Platf_Repo/.git/objects/26/1e08562f4d1d22fe1af457525b3143333f2c86
meta: {size:637, lines:0, sha256:"161456ec882062bcd0153bad218e842d88c0b70496b29747a98c34fd5012f4a0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/26/3b17d9dd3b30d9309d45c28014738b9b03b11b
meta: {size:961, lines:0, sha256:"611fde450d51fbf947106e78c581a2b2528bfd2076e46aef2379364951e6dd93", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/26/770c19275733c25a558ade8bd34049c4b3c7b9
meta: {size:3410, lines:0, sha256:"08a55795059baa039bb8ac1513e96bdd839ddb2b82f188df5dbfb1831c2614a8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/26/7a506456c25574059bcb0aa92da9383eb48731
meta: {size:44, lines:0, sha256:"2d5bfee8f8675eaace84534e8ec1a5088cc3a7cb8abeabcd7e44f61523c4e7e8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/26/7bfac34f086f05afd783344063a8efdfb9015b
meta: {size:736, lines:0, sha256:"61a723eb5885aa9dbf8e42365fed6378e4634a9af7233f27522591cff013025f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/26/8b6aaf9f0df5a5d8b6f329cf746f2503a7bbf9
meta: {size:110, lines:0, sha256:"1dcea323dba9e9ff232abfb8f1dab0ecb288411b10b668d2345704a1d86a9eff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/26/9910cac86f0f2fc77e47dc0afb868dca57cd6d
meta: {size:5021, lines:0, sha256:"020d288f62f1e7da0c264dfff7835e733e7c768ec0bc7f9cf2c0f89e7236a231", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/26/be18940717090154d42d93a12a6d4ba1e40e41
meta: {size:421, lines:2, sha256:"a2a6439154756ff5f2216959a4054b4a95f3b480cc93ed282c376cb9acfa145c", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x¿n1©ý#¥IýÃêîÜêDtE
òùÖ³'¯½{÷Øñ4H<DP7ÉGÀ»aABA$7¶åï7þf¶Æmát~ü$IViJG)WfëÆÈÙzy¶X-ÓZ±Ékg9t³4Osæ­ç Ë ;d¡o"PªÛ[$gÚî^ËªÕðõÖûsÖ6*"/|ä'¬$ç=aÅÀÖ´Ø¶Cföb+~^NÌ¾hVNÏE~2Ô	°3&©Þ¿±>Î²4ì$i'J§0ÒÏÂàÀ·ÏÞßùð)p÷î#ÄoÙ BÖÖh,õíµÃ«ÙQdÀÓ.É5·×^Ç.õH:æÆ _ÊªrFyh$IØa4'éw^utFZ!Ì»ÆQÀtL(RXaÑéÈL²Î|õï_>ÂúQ{þC*\¼X,¡+8<¤þUöö=rÇ.m6^Ö¹64mÓØrX/Vâjö±Dö~$T
```

## AingZ_Platf_Repo/.git/objects/26/d34f4c863f61c0424011bfe4ddedf4f424ab0f
meta: {size:72, lines:0, sha256:"1ff72fdf5ab30558a5b1f857821bc1913b309bf47e26492747ac8b23746a6128", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

