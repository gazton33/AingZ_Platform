---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/b8
part_index: 0
files_included: 11
size_bytes_sum: 26025
created_at: 2025-08-31T21:08:15.629959+00:00
integrity:
  sha256_concat: 88c5df336c8bc4799a48cbd3570576b0763f857764cee213790e82b4b3ce62c4
---

## AingZ_Platf_Repo/.git/objects/b8/14848d3d68572502042b280cecd4b5ded8b4e3
meta: {size:907, lines:0, sha256:"86435a3e51e08e97e87afe92acc86a911d61049ec743650378e1dcf290e00b9f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b8/64289f616463da3b42020112620dec097993d4
meta: {size:17195, lines:0, sha256:"141e4083f3bfb60502dae55963cd7c69fca4b25ad7498101c35243c386a9bf71", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b8/6561e823f2c958a1f7401e65b88281f02bb7a4
meta: {size:1659, lines:0, sha256:"6c329d19e41a65671200bf18bb284857faf0275ce51772d07358b46587688a89", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b8/929dbf1d0353699ba1c3389c9020440da4c533
meta: {size:79, lines:0, sha256:"5c99ed75a030333e44a7dd36e47c57e812c9d0476be81a65e865d50246e81d73", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b8/9e457bb4cf72ced8d06d04da45da5b281ce0a9
meta: {size:80, lines:0, sha256:"71f49f75e8a1bfd935c5a8efb12d7e32f42dfe139d05a6654770f4112f06c2ad", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b8/b1a8ca55acb8dcdc5422db8267826b632fc723
meta: {size:82, lines:0, sha256:"4d7058f82754ad40ec7bb855af0a51e4789443e294597e0254039c3e33258fca", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b8/d43c67fbe2d88be31019fbe8fa503a7d200972
meta: {size:191, lines:0, sha256:"f39114d160e561872cde0c35a600375d7b32600d875ce8e4ac2086c54045849d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b8/d516e216479bd226765fd15270fe77c73da4f5
meta: {size:1608, lines:0, sha256:"d9badc94acafe78e3af887e19876044519fecb548c5df237d204f2b6c63dff93", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b8/d72ec86cc49ce7c3edcc855065c8b531e69826
meta: {size:161, lines:4, sha256:"d1d2edd987b2885cb9aa841ba7579a51aefadd755fe7f64f6d96bf9fd14b0c41", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎ[
Ã @Ñ~»
7ÐàÌøPJ·btL&1fõÍú{áÀuÛÖ.í­7f	
¼Edjg'ò@Ææ¤Æ&(aÅ;4Þ»tÑ¨uÌÞ¸)hm&O7Àé(ÂÑÚäÎ^w"ùÇ¥~¸½æ-¬eu{JpqFÞ)%®z-vþÂs_RÄõF!
```

## AingZ_Platf_Repo/.git/objects/b8/da1f829809b81a0eea992b2b3826daafb93a45
meta: {size:3263, lines:0, sha256:"add1029ccce5cd58d49451d320950e48ffd5b8bfe59e540a91624f345ba5db37", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b8/e0763dd356ab36dab08b906951e1edc2030342
meta: {size:800, lines:0, sha256:"d64d77856b98948fe461565759365dbaee5210fc6312758ce71e55cd51b6349e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

