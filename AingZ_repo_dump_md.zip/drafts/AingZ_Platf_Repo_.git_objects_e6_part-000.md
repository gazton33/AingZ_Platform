---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/e6
part_index: 0
files_included: 15
size_bytes_sum: 27095
created_at: 2025-08-31T21:08:15.650850+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/e6/0eb42ddd2ca5a83739edc95a74385ec8873f07
meta: {size:801, lines:0, sha256:"f1bf908c75977d2594f601541484aa1db2ef43c02192221a4951951e67792adb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/12ec3370cffd07764ea965003047e781ca64f5
meta: {size:845, lines:0, sha256:"73c457270b4885a958e788b08fe45df413c0e63e4eaa2b7f718d1fa59fa6b7d0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/18a457b45fcaa6461810fb3c8b9af3026313cf
meta: {size:1045, lines:0, sha256:"4001ded641e5a1bac3e89ce8093c2bd8548510ac1bed4b625507784e9937d751", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/236fbf81594f0f70be8c5dcc20f4f667650b83
meta: {size:802, lines:0, sha256:"77a170047e9a65614324b6dd08ec6a58a68ce82da97062fb3b76475ef5458bb3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/2b82865d6705e6c4297a42730778007f3d68ef
meta: {size:83, lines:0, sha256:"d3872de7f8eb4b6aa369abbae5a462ecb955a0f7b67735d3a4f75d6e169368d0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/2d6dc0b57823c13e2161ea6535eb805791dce0
meta: {size:892, lines:0, sha256:"517943920d649c357ba53aa343c64f5cb5e7fa45345480f416811289f4ef56f7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/495ba6fe25fcbb6217bb8711806f9e791274de
meta: {size:238, lines:0, sha256:"f9a3c59d7b644f765359f00516869342fdeedc5f7a3f07d4534c38f7cd7a2d34", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/80d3f19f1116d7a17dd846bef3d6cee19b7904
meta: {size:704, lines:0, sha256:"89dd70801af045db1904c4d7dc58715c075051813722d1df98694e2eca700699", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/9bed26081223e724efbce7106629ea95e93a81
meta: {size:163, lines:0, sha256:"49c01911fc7d22e28fa2c8cf053aedc53fa4475450a0dac07d2563427b034c57", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/9de29bb2d1d6434b8b29ae775ad8c2e48c5391
meta: {size:15, lines:0, sha256:"164c5fa8067facf1a43f09ce3d0e35ebf53a7f5723ecbf15a8667cfc53c26f6c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/a0a09e2fa9e18f17e93728edc19587ac08ba93
meta: {size:186, lines:0, sha256:"b18684c46be77be291c43e7d1eea11824941c69cf6fe7fe6ceee9fad337a4e52", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/a158fad9c8cf36391f1d2264aa85598380979f
meta: {size:350, lines:0, sha256:"ce8e8e860e106ffef40c0d3c2c16098516c4968d20ec4917bbffe9f061c45140", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/bf431c50bb403397622e7f1597ac111e2be794
meta: {size:905, lines:0, sha256:"53068534b40f4de6c4f5896e4eb8467fc095eb0ea7b4c80719ee7b9465674d82", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/e0605d1b66a9826189b2e43613943512e5c672
meta: {size:19879, lines:0, sha256:"b702435af50ecf6f67b315b2873c78b3548c4aba6c2ef57a07d4bb3401f4dbaf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e6/e96ae7fb6d0b5bc685616bc866fe8c1caee406
meta: {size:187, lines:0, sha256:"a9d863bfe11fac093ee0cc9aaa685786d0dff24f3cff86354ae6139045f33bd8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

