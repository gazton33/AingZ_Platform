---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/legacy
part_index: 0
files_included: 18
size_bytes_sum: 224892
created_at: 2025-08-31T21:08:15.531868+00:00
integrity:
  sha256_concat: ebe33bdcae4e150e74ffebf21a9f0acf42f1e6b8a471f7d6a48e4791720e0f48
---

## AingZ_Platf_Repo/legacy/aing_z_v_5_baselines_unificados_v_1.md
meta: {size:7339, lines:161, sha256:"e25345c6a0aa4a865d0c938da27bcb2de25c23705a8e65036049af2b247b3624", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: core/doc/workbench/AINGZ\_V5\_Baselines\_Unificados\_v1\_4\_locked.md code: ARB\_AST name: AINGZ\_V5\_Baselines\_Unificados version: v1.4 date: 2025-08-16 owner: AingZ\_Platform · QMS status: locked refs: baseline\_prev: core/doc/workbench/AINGZ\_V5\_Baselines\_Unificados\_v1\_3\_locked.md glosario\_final: main/data\_base/core\_actv/data/semantics/glossary/GLOS\_AINGZ\_V5\_FULL\_v1\_0.md sem\_ruleset: main/data\_base/core\_actv/data/semantics/ruleset/SEM\_RULESET\_AINGZ\_V5\_v0\_1.md chkp: main/data\_base/core\_actv/data/guides/planin/chkp/CHKP\_2025\_08\_16\_GLOSv1\_0.md valog: main/log/validation/VALOG\_GLOS\_AINGZ\_V5\_FULL\_2025\_08\_16.md triggers: [TRG\_AUDIT\_TL, TRG\_CONSOLIDATE\_TL] chg: [CHG-2025-08-16-001, CHG-2025-08-16-002, CHG-2025-08-16-003, CHG-2025-08-16-004] chk: CHK#baseline\_lock\_v1\_4 notes: "Snapshot **LOCKED**: árbol + assets + alias\_final en EN; alineado 1:1 a GLOS v1.0 (MAPX PASS)."

# AingZ V5 — **Baselines Unificados v1.4 (LOCKED)**

> **Objeto**: congelar el **árbol de directorios** y los **assets** con sus *alias\_final* como **fuente de verdad** para la Fase 2. Incluye **rename** y **altas** aprobadas en CHKP.

---

## 0) Principios de este baseline

- Naming técnico en **idioma nativo** (SDK/API/PL), con \`\` en español (ver SEMR).
- **MAPX** 1:1 entre Glosario v1.0 y este árbol (sin órfanos).
- Cambios respecto a v1.3 documentados en **CHG-001..004**.

---

## 1) Árbol de directorios (v1.4)

```text
main/
  data_base/
    core_actv/
      docs/
        audio/
        image/
        video/
        library/
        onboard/
      data/
        semantics/
          glossary/
          dicts/
          code_dict/
          trigger_dict/
          app_dict/
          prompt_dict/
          ingest_prompts/
          vocabulary/
          ruleset/                 # SEM_RULESET_AINGZ_V5_v0_1.md
        ai_learn/
          learning/
          evaluation/
          insights/
          fine_tuning/
          few_shot/
          relevance/
          training/
          feedback/
        develop/
          ruleset/
          config/
          setup/
          customization/
          specs/
          preferences/
          connectors/
          orchestrator/
        out_template/
          mtx/
            matrix/
            table/
            record_sheet/
            mapping/
            relation/
            validation/
            comparison/
          docs/                    # DOCS (nuevo)
          workspaces/              # WSPC (nuevo)
          platform_arch/           # PARCH (nuevo)
          ai_tools/                # ATOOL (nuevo)
        guides/
          planin/
            mpln/
            brainstorm_crtv/
          run_control/             # RCNT (nuevo: START/STOP/RESUME/ROLLBACK)
          pipeline/
        wf_playbooks/              # rename desde wf_template/ (WFPB)
      log/
        changelog/
        validation/
        qms/
```

> **Nota**: Las carpetas marcadas como **(nuevo)**/rename provienen de **CHG-002..004**.

---

## 2) Alias\_final (EN) por bucket — extracto

| Bucket/Path                                                   | Alias\_final (ejemplos)                                                                                          |
| ------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| docs/audio                                                    | audio\_notes, meetings, interviews, podcast, audio\_from\_video                                                  |
| docs/image                                                    | photos, images, graphics, schematics, diagrams, blueprints, exploded\_views                                      |
| docs/video                                                    | videos, youtube, animations, presentations                                                                       |
| docs/library                                                  | books, manuals, guides, articles, papers                                                                         |
| docs/onboard                                                  | notes, messages, observations                                                                                    |
| data/semantics/\*                                             | glossary, trigger\_dict, code\_dict, app\_dict, prompt\_dict, ingest\_prompts, vocabulary                        |
| data/ai\_learn/\*                                             | learning, evaluation, insights, fine\_tuning, few\_shot, relevance, training, feedback                           |
| data/develop/\*                                               | ruleset, config, setup, customization, specs, preferences, connectors, orchestrator                              |
| data/out\_template/mtx/\*                                     | matrix, table, record\_sheet, mapping, relation, validation, comparison                                          |
| data/out\_template/{docs,workspaces,platform\_arch,ai\_tools} | docs\_template, workspace\_template, platform\_arch\_template, ai\_tool\_template                                |
| guides/run\_control                                           | run\_control (START, STOP, RESUME, ROLLBACK)                                                                     |
| guides/pipeline/\*                                            | creator, relev, audit, consolidation, migration, update, cleanup, validation, test, literal\_work, report, clone |
| data/wf\_playbooks                                            | wf\_playbook                                                                                                     |
| log/{changelog,validation,qms}                                | change\_log, validation\_log, traceability, cross\_ref, versioning                                               |

---

## 3) Delta v1.3 → v1.4 (estructura)

```diff
- data/wf_template/
+ data/wf_playbooks/              # CHG-002
+ data/out_template/docs/         # CHG-003
+ data/out_template/workspaces/   # CHG-003
+ data/out_template/platform_arch/# CHG-003
+ data/out_template/ai_tools/     # CHG-003
+ guides/run_control/             # CHG-004
```

---

## 4) Garantías y alcance del baseline

- **Integridad MAPX**: validada en **VALOG 2025-08-16**.
- **Compatibilidad V2→V5**: deprecaciones consolidadas (`RWB/RWS`→`SPEC`; `wf_template`→`wf_playbooks`).
- **Owners**: ver propuesta en Glosario v1.0 §2A (asignar nombres propios antes de cambios de producción).

---

## 5) Checklist de cierre (LOCKED)

-

---

## 6) OutputTemplate (de este baseline)

```yaml
output_example:
  status: LOCKED
  id_asset: aingz_v5_baselines_unificados_v1_4
  generated_by: ai
  created_at: 2025-08-16T00:00:00-03:00
  params:
    - from: v1.3
    - chg: [002,003,004]
    - aligned_to: GLOS_AINGZ_V5_FULL_v1_0
  result:
    - tree: updated
    - alias_final: applied
    - mapx: pass
  log:
    - step1: apply_chg
    - step2: update_tree
    - step3: verify_mapx
    - step4: lock_baseline
```

```

## AingZ_Platf_Repo/legacy/aing_z_v_5_dir_tree_assets_v_1.md
meta: {size:12954, lines:247, sha256:"2f9b51ec0bb3060aeb6bda14f240ab7513b3ebf984601fdf70e4f38162ba9ab3", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: core/doc/workbench/AINGZ\_V5\_Baselines\_Unificados\_v1\_4\_visual\_plus\_functions.md code: ARB\_AST\_VIZ name: BaselineV1\_4\_VisualFunctions version: v1.4 date: 2025-08-16 owner: AingZ\_Platform · QMS status: locked (derived) refs: baseline\_locked: core/doc/workbench/AINGZ\_V5\_Baselines\_Unificados\_v1\_4\_locked.md baseline\_prev: core/doc/workbench/AINGZ\_V5\_Baselines\_Unificados\_v1\_3\_locked.md glosario\_final: main/data\_base/core\_actv/data/semantics/glossary/GLOS\_AINGZ\_V5\_FULL\_v1\_0.md sem\_ruleset: main/data\_base/core\_actv/data/semantics/ruleset/SEM\_RULESET\_AINGZ\_V5\_v0\_1.md legacy\_ref: /mnt/data/aingz\_v\_5\_baselines\_unificados\_dir\_tree\_assets\_v\_1.md chkp: main/data\_base/core\_actv/data/guides/planin/chkp/CHKP\_2025\_08\_16\_GLOSv1\_0.md triggers: [TRG\_AUDIT\_TL, TRG\_CONSOLIDATE\_TL] chg: [CHG-2025-08-16-002, CHG-2025-08-16-003, CHG-2025-08-16-004, CHG-2025-08-16-005] chk: CHK#baseline\_v1\_4\_visual\_functions notes: "Vista enriquecida: funciones por bucket, descripciones ampliadas por asset, compatibilidad **legacy (wf|workflow)** → **wf\_playbooks**."

# AingZ V5 — **Dir Tree + Assets v1.4** · Visual + Functions (Enriched)

> **Objetivo**: mejorar **visualización** y **detalle funcional** del árbol **v1.4 (LOCKED)**. Incluye **descripciones de función por bucket** y **especificaciones ampliadas de assets** alineadas al **Glosario v1.0** y al **SEMR (RwB)**.

---

## 0) Leyenda de lectura rápida

- **[BKT]** = *Bucket/Folder* principal (función operativa)
- **(Inputs → Outputs)** = flujo típico de información
- **Governance** = rol custodio + QA
- **Legacy** = alias/paths históricos compatibles

---

## 1) Visual del árbol con funciones (anotado)

```text
main/
  data_base/
    core_actv/
      docs/                 [BKT] Fuentes documentales (entrada humana/externa)
        audio/              grabaciones y notas de voz → (transcripts, insights)
        image/              imágenes/diagramas → (annotations, assets derivados)
        video/              videos/presentaciones → (transcripts, clips)
        library/            bibliografía/corpus → (citables, refs)
        onboard/            notas internas → (contexto, decisions log)
      data/                 [BKT] Datos de trabajo y conocimiento estructurado
        semantics/          autoridad semántica → (glosario, diccionarios)
        ai_learn/           aprendizaje/evaluación → (labels, evals, ft)
        develop/            configuración y reglas → (ruleset, specs, setup)
        out_template/       plantillas de salida (estructuras de resultados)
          mtx/              matrices/tablas comunes
          docs/             plantillas de documentos
          workspaces/       plantillas de espacios de trabajo
          platform_arch/    plantillas de arquitectura de plataforma
          ai_tools/         plantillas de herramientas/agents AI
        guides/             guías operativas → (planificación, pipeline, run)
          planin/           planeamiento (MPLN/BLP/BLN/PLN/RMAP/TSK/CHK/CHKP)
          run_control/      control de ejecución (START/STOP/RESUME/ROLLBACK)
          pipeline/         procedimientos de proceso (CRTR/RLEV/...)
        wf_playbooks/       playbooks (paso a paso) → generan assets
      log/                  [BKT] QMS y evidencia → (CHG/VALOG/TRC/XRF/VER)
        changelog/          cambios/versionado semántico
        validation/         resultados de QA y validaciones
        qms/                trazabilidad y referencias cruzadas
```

> **Compatibilidad (legacy)**: donde la documentación antigua referencia `` o ``, el destino **v1.4** es `data/wf_playbooks/`.

---

## 2) Función por bucket (tabla ampliada)

| Bucket/Path            | Función (qué es)                                                                  | Inputs típicos                    | Outputs típicos                            | Consumers  | Governance             |
| ---------------------- | --------------------------------------------------------------------------------- | --------------------------------- | ------------------------------------------ | ---------- | ---------------------- |
| `docs/*`               | Repositorio de **fuentes documentales** (entrada primaria)                        | audio, imágenes, videos, textos   | transcripts, annotations, refs             | AI/Analyst | Docs Owner + QA(CHK)   |
| `data/semantics/*`     | **Autoridad semántica** del proyecto                                              | LSWP, glosarios previos           | glosario, diccionarios, vocabulario        | All        | Semantic Owner + VALD  |
| `data/ai_learn/*`      | **Aprendizaje y evaluación** de modelos                                           | datasets, labels, prompts         | evals, ft artifacts, feedback              | AI/ML      | Learning Owner + EVAL  |
| `data/develop/*`       | **Reglas y configuración** de plataforma                                          | specs, configs, ruleset           | manifiestos, setup scripts                 | DevOps     | Dev Owner + RULE       |
| `data/out_template/*`  | **Plantillas de salida** para **resultados estructurados**                        | requirements, schema defs         | CSV/JSON/MD templates                      | All        | Templates Owner + VALD |
| `guides/planin/*`      | **Planeamiento** y dirección de trabajo                                           | objetivos, backlog                | MPLN, BLP, PLN, CHKP                       | PM/Arch    | Guides Owner           |
| `guides/run_control/*` | **Procedimientos de ejecución controlada**                                        | baseline\_locked, sem\_ruleset    | logs de run, checkpoints, restore evidence | PM/Ops     | Guides Owner + QMS     |
| `guides/pipeline/*`    | **Procedimientos técnicos** (crear, validar, migrar, limpiar, etc.)               | specs, playbooks                  | reportes, estados intermedios              | Dev/AI     | Guides Owner           |
| `wf_playbooks/*`       | **Instrucciones paso a paso** para generar **assets** con OutputTemplate embebido | fuentes, parámetros, herramientas | artefactos listos y evidencias             | AI/Dev     | Playbooks Owner + QA   |
| `log/*`                | **Calidad y conformidad (QMS)**                                                   | evidencias de QA, cambios         | CHG, VALOG, TRC, XRF, VER                  | All/QMS    | QMS Owner              |

---

## 3) Catálogo de assets — Especificaciones ampliadas

> **Formato** por asset: **Purpose** · **RequiredMeta** · **OptionalMeta** · **Formats** · **Lifecycle** · **Triggers**

### 3.1 `docs/*`

- **AUD · AudioDoc**\
  Purpose: fuente de audio para registro/ingest.\
  RequiredMeta: `title, date, source, speakers[]`\
  OptionalMeta: `language, duration, transcription_id`\
  Formats: `wav, mp3, m4a`\
  Lifecycle: ingest → transcribe → index → link a insights\
  Triggers: `TRG_CONSOLIDATE_TL`
- **IMG · ImageDoc**\
  Purpose: imagen/diagrama con descripción mínima y fuente.\
  RequiredMeta: `title, date, source`\
  OptionalMeta: `resolution, annotations[]`\
  Formats: `png, jpg, svg, pdf(page)`\
  Lifecycle: ingest → annotate → index\
  Triggers: `TRG_CONSOLIDATE_TL`
- **VID · VideoDoc**\
  Purpose: video/presentación; puede requerir transcripción.\
  RequiredMeta: `title, date, source`\
  OptionalMeta: `duration, transcription_id`\
  Formats: `mp4, mkv, webm`\
  Lifecycle: ingest → transcribe → clip/summary\
  Triggers: `TRG_CONSOLIDATE_TL`
- **LIB · LibraryRef**\
  Purpose: bibliografía/corpus externo citable.\
  RequiredMeta: `title, authors[], year, publisher|venue`\
  OptionalMeta: `doi|isbn, url`\
  Formats: `pdf, bib, md`\
  Lifecycle: ingest → cite → reference map\
  Triggers: `TRG_AUDIT_TL`
- **ONB · OnboardNotes**\
  Purpose: notas internas de onboarding.\
  RequiredMeta: `author, date`\
  OptionalMeta: `related_tasks[]`\
  Formats: `md, txt`\
  Lifecycle: capture → link → archive\
  Triggers: `TRG_CONSOLIDATE_TL`

### 3.2 `data/semantics/*`

- **GLOS · Glossary**\
  Purpose: autoridad semántica del proyecto.\
  RequiredMeta: `version, status, baseline_id`\
  OptionalMeta: `deprecations[], mapx_path`\
  Formats: `md, yaml`\
  Lifecycle: draft → valog → final → lock\
  Triggers: `TRG_AUDIT_TL`
- **DTRG · TriggerDict**\
  Purpose: diccionario de triggers + contrato/uso.\
  RequiredMeta: `trigger_id, contract`\
  Formats: `md, yaml`
- **DCD · CodeDict**\
  Purpose: catálogo de `CODE≤5` ↔ `Name`.\
  RequiredMeta: `code, name`\
  QA: unicidad/regex
- **DAPP · AppDict**\
  Purpose: apps/servicios internos.\
  RequiredMeta: `app_id, contract`
- **DPRM · PromptDict**\
  Purpose: prompts y campos parametrizables.\
  RequiredMeta: `prompt_id, input_schema`
- **IPRM · IngestPrompts**\
  Purpose: prompts de ingestión.\
  RequiredMeta: `pipeline_id, steps[]`
- **VCB · Vocabulary**\
  Purpose: vocabulario controlado.\
  RequiredMeta: `term, alias[]`
- **SEMR · SemRuleset**\
  Purpose: reglas RwB/semántica y operación.\
  RequiredMeta: `rules[], qa[]`

### 3.3 `data/ai_learn/*`

- **LEARN · Learning** — registros de aprendizaje (datasets, sesiones).
- **EVAL · Evaluation** — métricas, curvas, verdicts.
- **INSI · Insight** — hallazgos curados, decisiones.
- **FTUNE · FineTuning** — artefactos de ajuste fino.
- **FSHOT · FewShot** — conjuntos de ejemplos.
- **RLEV · Relevance** — labels/señales de relevancia.
- **TRN · Training** — datasets de entrenamiento.
- **FDBK · Feedback** — feedback interno/externo.

> **Meta común (AI Learn)**: `dataset_id|exp_id, model, split, metrics{}`; Formats: `jsonl, parquet, csv, md`.

### 3.4 `data/develop/*`

- **RULE · Ruleset** — normativa técnica (naming, contratos).
- **CFG · Configuration** — parámetros por entorno (YAML).
- **SETUP · SetupGuide** — guía de preparación.
- **CSTM · Customization** — ajustes/adaptaciones.
- **SPEC · Specs** — especificaciones funcionales/técnicas.
- **PREF · Preferences** — overrides no críticos.
- **CNCTR · Connectors** — integración a servicios externos.
- **ORCH · Orchestrator** — definiciones del orquestador/flow.

### 3.5 `data/out_template/*`

- **MTX sub-bucket**: `MTR, TBL, RSHT, MAPX, RELN, VALD, VRS`\
  Spec común: `schema_fields[], export{csv,json,yaml,md}, example_file`.
- **DOCS/WSPC/PARCH/ATOOL** (nuevos): ver esquemas en Glosario v1.0 §1.6;\
  Propósito: empaquetar resultados repetibles con **front‑matter** estándar.

### 3.6 `guides/*`

- **PLANIN** (`MPLN, BLP, BLN, PLN, RMAP, TSK, CHK, CHKP, FDBK, VALD, OBJU`)\
  Purpose: dirección, planeamiento y checkpoints.
- **RUN CONTROL** (`RCNT`)\
  Purpose: control seguro de ejecución; sub‑entradas **START/STOP/RESUME/ROLLBACK**;\
  Evidencias: `rcnt_*.log, rcnt_state.chk, rcnt_restore.evd`.
- **PIPELINE** (`CRTR, RLEV, AUDT, CNSL, MIGR, UPDT, CLNP, VALD, TST, LITW, RPT, CLON`)\
  Purpose: procedimientos técnicos por etapa.

### 3.7 `wf_playbooks/*`

- **WFPB · WorkflowPlaybook**\
  Purpose: guías paso a paso para generar un **asset**;\
  RequiredMeta: `inputs[], tools[], preconditions[]`;\
  Output: asset + **OutputTemplate** embebido;\
  **Legacy**: `wf/` | `workflow/`.

### 3.8 `log/*`

- **CHG** — cambios/publicación de versiones.
- **BIT** — bitácora extendida.
- **ADT** — evidencias de auditoría.
- **VALOG** — resultados de QA/tests.
- **TRC** — trazabilidad cruzada.
- **XRF** — referencias cruzadas.
- **VER** — versioning del sistema.

---

## 4) Compatibilidad y mapeo **legacy** → **v1.4**

| Legacy (antiguo)      | v1.4 (actual)             | Tipo    | Nota de migración                       |
| --------------------- | ------------------------- | ------- | --------------------------------------- |
| `wf/`, `workflow/`    | `data/wf_playbooks/`      | rename  | Actualizar crossrefs en docs y scripts  |
| `PIPE (script)`       | `guides/pipeline/*`       | norma   | Preferir `CRTR/UPDT/CLNP/...` por etapa |
| `RWB/RWS` (semántica) | `SPEC` (en develop/specs) | replace | Mantener como alias histórico en GLOS   |

> **CHG-2025-08-16-005 (propuesto)**: Documentar formalmente la compatibilidad `wf|workflow` → `wf_playbooks`.

---

## 5) Checklist de afinamiento (visual + funciones)

-

---

## OutputTemplate (de este documento)

```yaml
output_example:
  status: OK
  id_asset: baseline_v1_4_visual_functions
  generated_by: ai
  created_at: 2025-08-16T00:00:00-03:00
  params:
    - baseline_locked: AINGZ_V5_Baselines_Unificados_v1_4_locked.md
    - enrich: [bucket_functions, asset_specs, legacy_map]
  result:
    - tables: [bucket_functions, asset_catalog]
    - actions: [crossref_sweep, out_template_concrete_schemas]
  log:
    - step1: analyze_baseline
    - step2: enrich_specs
    - step3: publish_visual
```

```

## AingZ_Platf_Repo/legacy/aing_z_v_5_dir_tree_v_1.md
meta: {size:4153, lines:99, sha256:"84176fc53d380199b44be65924a4e7e52c588c1f56b23391e3d7b45850c44eb4", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: core/doc/workbench/AINGZ\_V5\_Baselines\_Unificados\_v1\_4\_ascii\_tree.md code: ARB\_AST\_ASC name: BaselineV1\_4\_AsciiTree version: v1.4 date: 2025-08-16 owner: AingZ\_Platform · QMS status: locked (derived) refs: source\_visual: core/doc/workbench/AINGZ\_V5\_Baselines\_Unificados\_v1\_4\_visual\_plus\_functions.md baseline\_locked: core/doc/workbench/AINGZ\_V5\_Baselines\_Unificados\_v1\_4\_locked.md glosario\_final: main/data\_base/core\_actv/data/semantics/glossary/GLOS\_AINGZ\_V5\_FULL\_v1\_0.md notes: "Árbol con **líneas ASCII** (├── │ └──) para no perder niveles. Sin anotaciones extensas; sólo nombres canónicos."

# AingZ V5 — Dir Tree v1.4 (ASCII Lines)

**Leyenda:** `├──` rama intermedia · `└──` última rama · `│` continuidad de nivel

```text
AingZ_Platform
├── main
│   ├── data_base
│   │   ├── core_actv
│   │   │   ├── docs
│   │   │   │   ├── audio
│   │   │   │   ├── image
│   │   │   │   ├── video
│   │   │   │   ├── library
│   │   │   │   └── onboard
│   │   │   ├── data
│   │   │   │   ├── semantics
│   │   │   │   │   ├── glossary
│   │   │   │   │   ├── dicts
│   │   │   │   │   ├── code_dict
│   │   │   │   │   ├── trigger_dict
│   │   │   │   │   ├── app_dict
│   │   │   │   │   ├── prompt_dict
│   │   │   │   │   ├── ingest_prompts
│   │   │   │   │   ├── vocabulary
│   │   │   │   │   └── ruleset
│   │   │   │   ├── ai_learn
│   │   │   │   │   ├── learning
│   │   │   │   │   ├── evaluation
│   │   │   │   │   ├── insights
│   │   │   │   │   ├── fine_tuning
│   │   │   │   │   ├── few_shot
│   │   │   │   │   ├── relevance
│   │   │   │   │   ├── training
│   │   │   │   │   └── feedback
│   │   │   │   ├── develop
│   │   │   │   │   ├── ruleset
│   │   │   │   │   ├── config
│   │   │   │   │   ├── setup
│   │   │   │   │   ├── customization
│   │   │   │   │   ├── specs
│   │   │   │   │   ├── preferences
│   │   │   │   │   ├── connectors
│   │   │   │   │   └── orchestrator
│   │   │   │   ├── out_template
│   │   │   │   │   ├── mtx
│   │   │   │   │   │   ├── matrix
│   │   │   │   │   │   ├── table
│   │   │   │   │   │   ├── record_sheet
│   │   │   │   │   │   ├── mapping
│   │   │   │   │   │   ├── relation
│   │   │   │   │   │   ├── validation
│   │   │   │   │   │   └── comparison
│   │   │   │   │   ├── docs
│   │   │   │   │   ├── workspaces
│   │   │   │   │   ├── platform_arch
│   │   │   │   │   └── ai_tools
│   │   │   │   └── guides
│   │   │   │       ├── planin
│   │   │   │       │   ├── mpln
│   │   │   │       │   └── brainstorm_crtv
│   │   │   │       ├── run_control
│   │   │   │       └── pipeline
│   │   │   ├── wf_playbooks
│   │   │   └── kns_ctx_vivo
│   │   ├── core_dev
│   │   └── core_arch_platform
├── log
│   ├── changelog
│   ├── validation
│   └── qms
├── .github
├── packages
├── ruleset
└── scripts
```

---

## OutputTemplate

```yaml
output_example:
  status: OK
  id_asset: baseline_v1_4_ascii_tree
  generated_by: ai
  created_at: 2025-08-16T00:00:00-03:00
  params:
    - source_visual: AINGZ_V5_Baselines_Unificados_v1_4_visual_plus_functions.md
  result:
    - tree: ascii_lines
  log:
    - step1: render
```

```

## AingZ_Platf_Repo/legacy/aing_z_v_5_glosario_full_v_1_0_final_mapx_v_1.md
meta: {size:23915, lines:251, sha256:"cc830e30ca1a7e992f0e7da3d869fc51961fdc246471a6a2a3750049b05a2e0d", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: main/data\_base/core\_actv/data/semantics/glossary/GLOS\_AINGZ\_V5\_FULL\_v1\_0.md code: GLOS name: AingzV5GlossaryFull version: v1.0 date: 2025-08-16 owner: AingZ\_Platform · RwB status: final refs: baseline\_id: BL-2025-08-15-ARB+AST-v1.3 sem\_ruleset: main/data\_base/core\_actv/data/semantics/ruleset/SEM\_RULESET\_AINGZ\_V5\_v0\_1.md roadmap: core/doc/workbench/ROADMAP\_GLOS\_FULL\_V5\_FASE2.md valog: main/log/validation/VALOG\_GLOS\_AINGZ\_V5\_FULL\_2025\_08\_16.md triggers: [TRG\_CONSOLIDATE\_TL, TRG\_AUDIT\_TL] chg: [CHG-2025-08-16-001, CHG-2025-08-16-002, CHG-2025-08-16-003, CHG-2025-08-16-004] chk: CHK#glos\_v5\_full\_v1\_0 notes: "Promoción desde v0.9 a **v1.0 (FINAL)** tras VALM/VALD PASS. Naming técnico en idioma nativo; `Name/Contract` en español."

# AingZ V5 — **Glosario FULL v1.0 (FINAL)** + **MAPX v1.0**

> **Ámbito**: consolidación completa de entidades/items/datos de glosarios y diccionarios previos, **alineada 1:1** al Árbol/Assets del baseline **v1.3 (LOCKED)**. Reglas SEMR aplicadas. Evidencia en **VALOG 2025‑08‑16**.

---

## 0) Reglas mínimas (extracto SEMR)

- `CODE` ≤5 (SCREAMING\_SNAKE); `Name` en PascalCase.
- `Contract` ≤120 chars; garantías/uso, no implementación.
- **Idioma nativo** para términos técnicos/alias (EN); `Name/Contract` en español.
- **MAPX** 1:1 (sin órfanos) contra paths del árbol.
- Deprecaciones con `Deprecated:true` + `ReplacedBy` + rationale.

---

## 1) Glosario FULL — Tablas

### 1.1 Buckets: `docs/*`

| CODE | Name         | AliasFinal                                                                  | Contract (≤120)                                            | Notas |
| ---- | ------------ | --------------------------------------------------------------------------- | ---------------------------------------------------------- | ----- |
| AUD  | AudioDoc     | audio\_notes, meetings, interviews, podcast, audio\_from\_video             | Activo de audio para registro o ingest; metadatos básicos  | —     |
| IMG  | ImageDoc     | photos, images, graphics, schematics, diagrams, blueprints, exploded\_views | Imagen/diagrama con descripción mínima y fuente            | —     |
| VID  | VideoDoc     | videos, youtube, animations, presentations                                  | Video o presentación grabada; puede requerir transcripción | —     |
| LIB  | LibraryRef   | books, manuals, guides, articles, papers                                    | Referencia bibliográfica/corpus externo; citable           | —     |
| ONB  | OnboardNotes | notes, messages, observations                                               | Notas internas de onboarding y observaciones               | —     |

### 1.2 Datos semánticos: `data/semantics/*`

| CODE | Name          | AliasFinal      | Contract (≤120)                           | Notas          |
| ---- | ------------- | --------------- | ----------------------------------------- | -------------- |
| GLOS | Glossary      | glossary        | Autoridad semántica del proyecto          | Este documento |
| DTRG | TriggerDict   | trigger\_dict   | Diccionario de triggers con contrato/uso  | —              |
| DCD  | CodeDict      | code\_dict      | Diccionario de códigos (CODE≤5) y nombres | —              |
| DAPP | AppDict       | app\_dict       | Diccionario de apps/servicios internos    | —              |
| DPRM | PromptDict    | prompt\_dict    | Catálogo de prompts y campos              | —              |
| IPRM | IngestPrompts | ingest\_prompts | Paquete de prompts de ingestión           | —              |
| VCB  | Vocabulary    | vocabulary      | Vocabulario controlado (términos/alias)   | —              |
| SEMR | SemRuleset    | sem\_ruleset    | Normas de semántica y operación RwB       | Referencia     |

### 1.3 Aprendizaje IA: `data/ai_learn/*`

| CODE  | Name       | AliasFinal   | Contract (≤120)                    | Notas |
| ----- | ---------- | ------------ | ---------------------------------- | ----- |
| LEARN | Learning   | learning     | Material/registro de aprendizaje   | —     |
| EVAL  | Evaluation | evaluation   | Evaluaciones y métricas de outputs | —     |
| INSI  | Insight    | insights     | Hallazgos/insights curados         | —     |
| FTUNE | FineTuning | fine\_tuning | Activos de ajuste fino             | —     |
| FSHOT | FewShot    | few\_shot    | Conjuntos de ejemplos few-shot     | —     |
| RLEV  | Relevance  | relevance    | Señales/labels de relevancia       | —     |
| TRN   | Training   | training     | Datos de entrenamiento             | —     |
| FDBK  | Feedback   | feedback     | Devoluciones internas/externas     | —     |

### 1.4 Desarrollo: `data/develop/*`

| CODE  | Name          | AliasFinal    | Contract (≤120)                       | Notas            |
| ----- | ------------- | ------------- | ------------------------------------- | ---------------- |
| RULE  | Ruleset       | ruleset       | Normativa técnica del proyecto        | Naming/contratos |
| CFG   | Configuration | config        | Parámetros declarativos por entorno   | YAML             |
| SETUP | SetupGuide    | setup         | Guía de preparación del entorno       | —                |
| CSTM  | Customization | customization | Ajustes/adaptaciones del sistema      | —                |
| SPEC  | Specs         | specs         | Especificaciones funcionales/técnicas | —                |
| PREF  | Preferences   | preferences   | Preferencias/overrides no críticas    | —                |
| CNCTR | Connectors    | connectors    | Conectores a servicios externos       | —                |
| ORCH  | Orchestrator  | orchestrator  | Definiciones del orquestador/flow     | —                |

### 1.5 Plantillas de salida: `data/out_template/mtx/*`

| CODE | Name             | AliasFinal    | Contract (≤120)                      | Notas |
| ---- | ---------------- | ------------- | ------------------------------------ | ----- |
| MTR  | Matrix           | matrix        | Estructura tabular (export CSV/JSON) | —     |
| TBL  | TableSimple      | table         | Tabla simple sin fórmulas            | —     |
| RSHT | RecordSheet      | record\_sheet | Ficha/registro de un ítem            | —     |
| MAPX | MappingMatrix    | mapping       | Mapeo uni/bidireccional              | —     |
| RELN | RelationMatrix   | relation      | Relaciones y cardinalidades          | —     |
| VALD | ValidationMatrix | validation    | Reglas y criterios de QA             | —     |
| VRS  | VersusMatrix     | comparison    | Comparativas con pesos/criterios     | —     |

### 1.6 Plantillas de salida (NUEVOS): `data/out_template/{docs,workspaces,platform_arch,ai_tools}`

| CODE  | Name                 | AliasFinal               | Contract (≤120)                                        | Notas                                     |
| ----- | -------------------- | ------------------------ | ------------------------------------------------------ | ----------------------------------------- |
| DOCS  | DocsTemplate         | docs\_template           | Plantilla para documentos de entrega (MD/PDF/HTML).    | Front‑matter estándar + secciones básicas |
| WSPC  | WorkspaceTemplate    | workspace\_template      | Plantilla de workspace para edición/colaboración.      | Estructura de carpetas + README           |
| PARCH | PlatformArchTemplate | platform\_arch\_template | Plantilla de artefactos de arquitectura de plataforma. | Incluye blueprint y ADR/ADR‑0001          |
| ATOOL | AiToolTemplate       | ai\_tool\_template       | Plantilla para assets de herramientas/agents AI.       | Inputs/Outputs/Contracts                  |

### 1.7 Guías — Planeamiento: `data/guides/planin/*`

| CODE | Name            | AliasFinal        | Contract (≤120)                    | Notas |
| ---- | --------------- | ----------------- | ---------------------------------- | ----- |
| MPLN | MasterPlan      | master\_plan      | Objetivos macro/KPIs/alcances      | —     |
| BLP  | Blueprint       | blueprint         | Topología, límites, decisiones     | —     |
| BLN  | Baseline        | baseline          | Snapshot de referencia (congelado) | —     |
| PLN  | Plan            | plans             | Entregables/cronograma/recursos    | —     |
| RMAP | Roadmap         | roadmaps          | Hitos, dependencias, fechas        | —     |
| TSK  | Task            | tasks             | Acción atómica con I/O y done      | —     |
| CHK  | Checklist       | checklists        | Controles de cumplimiento          | —     |
| CHKP | Checkpoint      | checkpoints       | Congela estado y evidencia         | —     |
| FDBK | Feedback        | feedback          | Retroalimentación accionable       | —     |
| VALD | Validation      | validation        | Validación técnica/funcional       | —     |
| OBJU | ObjectiveUpdate | objective\_update | Actualización de objetivos         | —     |

### 1.8 Guías — Brainstorm creativo: `data/guides/planin/brainstorm_crtv/*`

| CODE  | Name           | AliasFinal       | Contract (≤120)                   | Notas |
| ----- | -------------- | ---------------- | --------------------------------- | ----- |
| BRAIN | Brainstorm     | brainstorm       | Tormenta de ideas (no vinculante) | —     |
| INSI  | Insight        | insights         | Hallazgos (ver 1.3)               | —     |
| IDEA  | IdeaDraft      | ideas, drafts    | Ideas en elaboración              | —     |
| NOTE  | Note           | notes            | Notas simples                     | —     |
| NCHK  | NodeCheckpoint | node\_checkpoint | Nodo de control/estado            | —     |
| NCHG  | NodeChanges    | node\_changes    | Cambios en nodo/flujo             | —     |
| SNAP  | Snapshots      | snapshots        | Capturas de estado o UI           | —     |

### 1.9 Run Control: `data/guides/run_control/*`

| CODE | Name       | AliasFinal   | Contract (≤120)                                   | SubEntries                    |
| ---- | ---------- | ------------ | ------------------------------------------------- | ----------------------------- |
| RCNT | RunControl | run\_control | Procedimientos operativos de ejecución controlada | START, STOP, RESUME, ROLLBACK |

#### 1.9.1 RCNT — SubEntries (definición mínima)

| Entry    | Propósito                                 | Preconditions                           | Outputs (Artefactos)                  |
| -------- | ----------------------------------------- | --------------------------------------- | ------------------------------------- |
| START    | Inicializar ejecución controlada del run  | baseline\_locked, sem\_ruleset\_applied | rcnt\_start.log, rcnt\_context.json   |
| STOP     | Detener ejecución y persistir estado      | run\_in\_progress                       | rcnt\_stop.log, rcnt\_state.chk       |
| RESUME   | Retomar ejecución desde último checkpoint | chkp\_available                         | rcnt\_resume.log, rcnt\_delta.rpt     |
| ROLLBACK | Revertir al último estado válido (CHKP)   | chkp\_valid, vald\_pass                 | rcnt\_rollback.log, rcnt\_restore.evd |

> Nota: `RunControl` solo define **procedimiento** y **evidencia**; no implementa lógica de negocio.

### 1.10 Pipeline: `data/guides/pipeline/*`

| CODE | Name          | AliasFinal    | Contract (≤120)                  | Notas |
| ---- | ------------- | ------------- | -------------------------------- | ----- |
| CRTR | Creator       | creator       | Generación de activos/paquetes   | —     |
| RLEV | Relevance     | relev         | Selección/curado por relevancia  | —     |
| AUDT | Audit         | auditoria     | Auditoría de procesos/artefactos | —     |
| CNSL | Consolidation | consolidado   | Consolidación de fuentes/estados | —     |
| MIGR | Migration     | migracion     | Migración y compatibilidad       | —     |
| UPDT | Update        | update        | Actualizaciones controladas      | —     |
| CLNP | Cleanup       | cleanup       | Limpieza de estados/archivos     | —     |
| VALD | Validation    | validation    | QA (ver 1.5/1.7)                 | —     |
| TST  | Test          | test          | Pruebas de componente/flujo      | —     |
| LITW | LiteralWork   | literal\_work | Barrido literal del 100%         | —     |
| RPT  | Report        | report        | Informe sintetizado y KPIs       | —     |
| CLON | Clone         | clone         | Replicación de estructuras       | —     |

### 1.11 WF Playbooks (renombrado de `wf_template/`): `data/wf_playbooks/*`

| CODE | Name             | AliasFinal   | Contract (≤120)                                                                  | Notas             |
| ---- | ---------------- | ------------ | -------------------------------------------------------------------------------- | ----------------- |
| WFPB | WorkflowPlaybook | wf\_playbook | Instrucciones paso a paso para generar un asset; incluye OutputTemplate embebido | Ex `wf_template/` |

### 1.12 Logs & QMS: `main/log/*`

| CODE  | Name          | AliasFinal      | Contract (≤120)                  | Notas |
| ----- | ------------- | --------------- | -------------------------------- | ----- |
| CHG   | Changelog     | change\_log     | Historial semántico de cambios   | —     |
| BIT   | Logbook       | logbook         | Bitácora extendida               | —     |
| ADT   | AuditLog      | audit\_log      | Evidencia de auditoría           | —     |
| VALOG | ValidationLog | validation\_log | Resultados de QA/tests           | —     |
| TRC   | Trace         | traceability    | Trazabilidad cruzada             | —     |
| XRF   | CrossRef      | cross\_ref      | Referencias cruzadas (ID/alias)  | —     |
| VER   | Versioning    | versioning      | Control de versiones del sistema | —     |

---

## 2) MAPX v1.0 — Glosario ↔ Árbol/Assets

> **Formato**: `Path (Árbol)` · **Assets (fuente)** · *AliasFinal* → `CODE/Name`

| Path (Árbol)                                                    | Assets (fuente)                                                                                                           | AliasFinal                                                                                                                  | CODE/Name                                                     |
| --------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------- |
| main/data\_base/core\_actv/docs/audio/                          | notas\_de\_voz, reuniones, entrevistas, podcast, audio\_de\_video                                                         | audio\_notes, meetings, interviews, podcast, audio\_from\_video                                                             | **AUD/AudioDoc**                                              |
| main/data\_base/core\_actv/docs/image/                          | fotos, imagenes, graficos, esquemas, diagramas, planos, explosiones                                                       | photos, images, graphics, schematics, diagrams, blueprints, exploded\_views                                                 | **IMG/ImageDoc**                                              |
| main/data\_base/core\_actv/docs/video/                          | videos, youtube, animaciones, presentaciones                                                                              | videos, youtube, animations, presentations                                                                                  | **VID/VideoDoc**                                              |
| main/data\_base/core\_actv/docs/library/                        | libros, manuales, guias, articulos, papers                                                                                | books, manuals, guides, articles, papers                                                                                    | **LIB/LibraryRef**                                            |
| main/data\_base/core\_actv/docs/onboard/                        | notas, mensajes, observaciones                                                                                            | notes, messages, observations                                                                                               | **ONB/OnboardNotes**                                          |
| main/data\_base/core\_actv/data/semantics/                      | glossary, dict\_trigger, dict\_code, dict\_app, dict\_prompt, ing\_prompt, vocabulary                                     | glossary, trigger\_dict, code\_dict, app\_dict, prompt\_dict, ingest\_prompts, vocabulary                                   | **GLOS/DTRG/DCD/DAPP/DPRM/IPRM/VCB/SEMR**                     |
| main/data\_base/core\_actv/data/ai\_learn/                      | learn, eval, insi, tune, shot, rel, trn, feedback                                                                         | learning, evaluation, insights, fine\_tuning, few\_shot, relevance, training, feedback                                      | **LEARN/EVAL/INSI/FTUNE/FSHOT/RLEV/TRN/FDBK**                 |
| main/data\_base/core\_actv/data/develop/                        | ruleset, config, setup, custom, spec, preference, conectors, orquestador                                                   | ruleset, config, setup, customization, specs, preferences, connectors, orchestrator                                         | **RULE/CFG/SETUP/CSTM/SPEC/PREF/CNCTR/ORCH**                  |
| main/data\_base/core\_actv/data/out\_template/mtx/              | matrix, tabla, ficha, mapping, relation, validation, versus                                                               | matrix, table, record\_sheet, mapping, relation, validation, comparison                                                     | **MTR/TBL/RSHT/MAPX/RELN/VALD/VRS**                           |
| main/data\_base/core\_actv/data/out\_template/docs/             | docs\_template                                                                                                            | docs\_template                                                                                                              | **DOCS/DocsTemplate**                                         |
| main/data\_base/core\_actv/data/out\_template/workspaces/       | workspace\_template                                                                                                       | workspace\_template                                                                                                         | **WSPC/WorkspaceTemplate**                                    |
| main/data\_base/core\_actv/data/out\_template/platform\_arch/   | platform\_arch\_template                                                                                                  | platform\_arch\_template                                                                                                    | **PARCH/PlatformArchTemplate**                                |
| main/data\_base/core\_actv/data/out\_template/ai\_tools/        | ai\_tool\_template                                                                                                        | ai\_tool\_template                                                                                                          | **ATOOL/AiToolTemplate**                                      |
| main/data\_base/core\_actv/data/guides/planin/mpln/             | mplan, blueprint, baseline, /plans, /roadmaps, /task, /checklist, /checkpoint, /feedback, /validacion, /update\_objective | master\_plan, blueprint, baseline, plans, roadmaps, tasks, checklists, checkpoints, feedback, validation, objective\_update | **MPLN/BLP/BLN/PLN/RMAP/TSK/CHK/CHKP/FDBK/VALD/OBJU**         |
| main/data\_base/core\_actv/data/guides/planin/brainstorm\_crtv/ | brainstorm, insights, ideas, draft, notas, nodo(chkpnt), nodo\_changes, snapshots                                         | brainstorm, insights, ideas, drafts, notes, node\_checkpoint, node\_changes, snapshots                                      | **BRAIN/INSI/IDEA/NOTE/NCHK/NCHG/SNAP**                       |
| main/data\_base/core\_actv/data/guides/run\_control/            | start, stop, resume, rollback                                                                                             | run\_control                                                                                                                | **RCNT/RunControl**                                           |
| main/data\_base/core\_actv/data/guides/pipeline/                | creator, relev, auditoria, consolidado, migracion, update, cleanup, validation, test, literal\_work, report, clone        | creator, relevance, audit, consolidation, migration, update, cleanup, validation, test, literal\_work, report, clone        | **CRTR/RLEV/AUDT/CNSL/MIGR/UPDT/CLNP/VALD/TST/LITW/RPT/CLON** |
| main/data\_base/core\_actv/data/wf\_playbooks/                  | wf\_playbook                                                                                                              | wf\_playbook                                                                                                                | **WFPB/WorkflowPlaybook**                                     |
| main/log/changelog/                                             | changelog, logbook, auditlog, validationlog                                                                               | change\_log, logbook, audit\_log, validation\_log                                                                           | **CHG/BIT/ADT/VALOG**                                         |
| main/log/qms/                                                   | trace, crossref, version                                                                                                  | traceability, cross\_ref, versioning                                                                                        | **TRC/XRF/VER**                                               |

---

## 3) Deprecaciones y compatibilidad (V2→V5)

- `RWB`/`RWS` (v2) **→** `SPEC` (V5); conservar en `Aliases` como histórico.
- `wf_template/` **→** `wf_playbooks/` (renombrado; mantener redirect en CHG hasta v1.4).
- `VALD` (matrix) vs `VALOG` (log) — separar responsabilidades.

---

## 4) QA — Resumen VALOG 2025‑08‑16

- `CODE≤5/SCREAMING_SNAKE` — **PASS**
- `Contract≤120` — **PASS**
- `Idioma nativo (técnicos)` — **PASS**
- `MAPX 1:1` — **PASS**
- `Deprecaciones formales` — **PASS**

---

## 5) Próximos pasos

-

---

## OutputTemplate (de este artefacto)

```yaml
output_example:
  status: FINAL
  id_asset: glos_aingz_v5_full_v1_0
  generated_by: ai
  created_at: 2025-08-16T00:00:00-03:00
  params:
    - baseline_id: BL-2025-08-15-ARB+AST-v1.3
    - sem_ruleset: SEM_RULESET_AINGZ_V5_v0_1
    - references: [VALOG_GLOS_AINGZ_V5_FULL_2025_08_16.md]
  result:
    - glossary_entries: 90+
    - mapping_rows: 22
    - qa_status: PASS
  log:
    - step1: consolidate
    - step2: normalize
    - step3: mapx_build
    - step4: valm_vald_pass
    - step5: promote_final
```

```

## AingZ_Platf_Repo/legacy/aing_z_v_5_glosario_mapeo_gaps_fase_2_draft.md
meta: {size:22052, lines:228, sha256:"fe8231e6d8a356fde45c745e9e1292df23631d5c8b234201c7c0663b18e810d6", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: main/data\_base/core\_actv/data/semantics/glossary/GLOS\_AINGZ\_V5\_Draft\_v0\_1.md code: GLOS name: AingzV5GlossaryDraft version: v0.1 date: 2025-08-15 owner: AingZ\_Platform · RwB status: draft xrf: baseline: BL-2025-08-15-ARB+AST-v1.3 tree\_ref: main/data\_base/core\_actv/\*\* assets\_ref: main/log/\*\* triggers: [TRG\_CONSOLIDATE\_TL] chg: CHG#glosario\_v5\_fase2 chk: CHK#glosario\_v5\_fase2 notes: "Construido SOLO con el ctx\_package del baseline LOCKED."

# AingZ V5 — **Glosario (Draft)** + **Mapeo** + **Gaps**

> **Ámbito:** normalización de nombres/códigos y alineación con Árbol/Assets del **Baseline v1.3 (LOCKED)**. El esqueleto de la nueva arquitectura se preparará **después** de cerrar el glosario.

---

## 0) Reglas mínimas de nomenclatura (aplican a este glosario)

- **CODE** ≤ 5 caracteres, `SCREAMING_SNAKE`.
- **Name** en **PascalCase**.
- **Contract** (≤120 chars) describe **qué garantiza**; no detalla implementación.
- **AliasFinal** = alias normalizado en inglés (según baseline) cuando aplique.
- **Uniquidad**: `CODE` único en este documento.

> **Estado:** draft (se cerrará en V1 tras validar con Árbol/Assets y QMS).

---

## 1) Glosario V5 — Draft (tablas con alias finales)

### 1.1 Buckets: `docs/*`

| CODE | Name         | AliasFinal                                                                  | Contract (≤120)                                            | Ejemplo de uso           |
| ---- | ------------ | --------------------------------------------------------------------------- | ---------------------------------------------------------- | ------------------------ |
| AUD  | AudioDoc     | audio\_notes, meetings, interviews, podcast, audio\_from\_video             | Activo de audio para registro o ingest; metadatos básicos  | notas\_de\_voz/reuniones |
| IMG  | ImageDoc     | photos, images, graphics, schematics, diagrams, blueprints, exploded\_views | Imagen/diagrama con descripción mínima y fuente            | planos/diagramas         |
| VID  | VideoDoc     | videos, youtube, animations, presentations                                  | Video o presentación grabada; puede requerir transcripción | presentaciones           |
| LIB  | LibraryRef   | books, manuals, guides, articles, papers                                    | Referencia bibliográfica/corpus externo; citable           | manuales/papers          |
| ONB  | OnboardNotes | notes, messages, observations                                               | Notas internas de onboarding y observaciones               | notas/mensajes           |

### 1.2 Datos semánticos: `data/semantics/*`

| CODE | Name          | AliasFinal      | Contract (≤120)                           | Notas          |
| ---- | ------------- | --------------- | ----------------------------------------- | -------------- |
| GLOS | Glossary      | glossary        | Autoridad semántica del proyecto          | Este documento |
| DTRG | TriggerDict   | trigger\_dict   | Diccionario de triggers con contrato/uso  | —              |
| DCD  | CodeDict      | code\_dict      | Diccionario de códigos (CODE≤5) y nombres | —              |
| DAPP | AppDict       | app\_dict       | Diccionario de apps/servicios internos    | —              |
| DPRM | PromptDict    | prompt\_dict    | Catálogo de prompts y campos              | —              |
| IPRM | IngestPrompts | ingest\_prompts | Paquete de prompts de ingestión           | —              |
| VCB  | Vocabulary    | vocabulary      | Vocabulario controlado (términos/alias)   | —              |

### 1.3 Aprendizaje IA: `data/ai_learn/*`

| CODE  | Name       | AliasFinal   | Contract (≤120)                     | Notas |
| ----- | ---------- | ------------ | ----------------------------------- | ----- |
| LEARN | Learning   | learning     | Material/registro de aprendizaje    | —     |
| EVAL  | Evaluation | evaluation   | Evaluaciones y métricas de outputs  | —     |
| INSI  | Insight    | insights     | Hallazgos/insights curados          | —     |
| FTUNE | FineTuning | fine\_tuning | Activos de ajuste fino              | —     |
| FSHOT | FewShot    | few\_shot    | Conjuntos de ejemplos de *few-shot* | —     |
| RLEV  | Relevance  | relevance    | Señales/labels de relevancia        | —     |
| TRN   | Training   | training     | Datos de entrenamiento              | —     |
| FDBK  | Feedback   | feedback     | Devoluciones internas/externas      | —     |

### 1.4 Desarrollo: `data/develop/*`

| CODE  | Name          | AliasFinal    | Contract (≤120)                       | Notas            |
| ----- | ------------- | ------------- | ------------------------------------- | ---------------- |
| RULE  | Ruleset       | ruleset       | Normativa técnica del proyecto        | Naming/contratos |
| CFG   | Configuration | config        | Parámetros declarativos por entorno   | YAML             |
| SETUP | SetupGuide    | setup         | Guía de preparación del entorno       | —                |
| CSTM  | Customization | customization | Ajustes/adaptaciones del sistema      | —                |
| SPEC  | Specs         | specs         | Especificaciones funcionales/técnicas | —                |
| PREF  | Preferences   | preferences   | Preferencias/overrides no críticas    | —                |
| CNCTR | Connectors    | connectors    | Conectores a servicios externos       | —                |
| ORCH  | Orchestrator  | orchestrator  | Definiciones del orquestador/flow     | —                |

### 1.5 Plantillas de salida: `data/out_template/mtx/*`

| CODE | Name             | AliasFinal    | Contract (≤120)                      | Notas |
| ---- | ---------------- | ------------- | ------------------------------------ | ----- |
| MTR  | Matrix           | matrix        | Estructura tabular (export CSV/JSON) | —     |
| TBL  | TableSimple      | table         | Tabla simple sin fórmulas            | —     |
| RSHT | RecordSheet      | record\_sheet | Ficha/registro de un ítem            | —     |
| MAPX | MappingMatrix    | mapping       | Mapeo uni/bidireccional              | —     |
| RELN | RelationMatrix   | relation      | Relaciones y cardinalidades          | —     |
| VALD | ValidationMatrix | validation    | Reglas y criterios de QA             | —     |
| VRS  | VersusMatrix     | comparison    | Comparativas con pesos/criterios     | —     |

> **Pendientes de este bucket:** `out_template/{docs, workspaces, platform_arch, ai_tools}` → definir modelos de documento/plantilla.

### 1.6 Guías — Planeamiento: `data/guides/planin/*`

| CODE | Name            | AliasFinal        | Contract (≤120)                    | Notas |
| ---- | --------------- | ----------------- | ---------------------------------- | ----- |
| MPLN | MasterPlan      | master\_plan      | Objetivos macro/KPIs/alcances      | —     |
| BLP  | Blueprint       | blueprint         | Topología, límites, decisiones     | —     |
| BLN  | Baseline        | baseline          | Snapshot de referencia (congelado) | —     |
| PLN  | Plan            | plans             | Entregables/cronograma/recursos    | —     |
| RMAP | Roadmap         | roadmaps          | Hitos, dependencias, fechas        | —     |
| TSK  | Task            | tasks             | Acción atómica con I/O y done      | —     |
| CHK  | Checklist       | checklists        | Controles de cumplimiento          | —     |
| CHKP | Checkpoint      | checkpoints       | Congela estado y evidencia         | —     |
| FDBK | Feedback        | feedback          | Retroalimentación accionable       | —     |
| VALD | Validation      | validation        | Validación técnica/funcional       | —     |
| OBJU | ObjectiveUpdate | objective\_update | Actualización de objetivos         | —     |

### 1.7 Guías — Brainstorm creativo: `data/guides/planin/brainstorm_crtv/*`

| CODE  | Name           | AliasFinal       | Contract (≤120)                   | Notas |
| ----- | -------------- | ---------------- | --------------------------------- | ----- |
| BRAIN | Brainstorm     | brainstorm       | Tormenta de ideas (no vinculante) | —     |
| INSI  | Insight        | insights         | Hallazgos (ver 1.3)               | —     |
| IDEA  | IdeaDraft      | ideas, drafts    | Ideas en elaboración              | —     |
| NOTE  | Note           | notes            | Notas simples                     | —     |
| NCHK  | NodeCheckpoint | node\_checkpoint | Nodo de control/estado            | —     |
| NCHG  | NodeChanges    | node\_changes    | Cambios en nodo/flujo             | —     |
| SNAP  | Snapshots      | snapshots        | Capturas de estado o UI           | —     |

### 1.8 Guías — Pipeline y Run Control

| CODE | Name          | AliasFinal    | Contract (≤120)                        | Notas       |
| ---- | ------------- | ------------- | -------------------------------------- | ----------- |
| RCNT | RunControl    | (pendiente)   | Procedimientos operativos de ejecución | **Definir** |
| CRTR | Creator       | creator       | Generación de activos/paquetes         | —           |
| RLEV | Relevance     | relev         | Selección/curado por relevancia        | —           |
| AUDT | Audit         | auditoria     | Auditoría de procesos/artefactos       | —           |
| CNSL | Consolidation | consolidado   | Consolidación de fuentes/estados       | —           |
| MIGR | Migration     | migracion     | Migración y compatibilidad             | —           |
| UPDT | Update        | update        | Actualizaciones controladas            | —           |
| CLNP | Cleanup       | cleanup       | Limpieza de estados/archivos           | —           |
| VALD | Validation    | validation    | QA (ver 1.5/1.6)                       | —           |
| TST  | Test          | test          | Pruebas de componente/flujo            | —           |
| LITW | LiteralWork   | literal\_work | Barrido literal del 100%               | —           |
| RPT  | Report        | report        | Informe sintetizado y KPIs             | —           |
| CLON | Clone         | clone         | Replicación de estructuras             | —           |

### 1.9 Logs & QMS: `main/log/*`

| CODE  | Name          | AliasFinal      | Contract (≤120)                  | Notas |
| ----- | ------------- | --------------- | -------------------------------- | ----- |
| CHG   | Changelog     | change\_log     | Historial semántico de cambios   | —     |
| BIT   | Logbook       | logbook         | Bitácora extendida               | —     |
| ADT   | AuditLog      | audit\_log      | Evidencia de auditoría           | —     |
| VALOG | ValidationLog | validation\_log | Resultados de QA/tests           | —     |
| TRC   | Trace         | traceability    | Trazabilidad cruzada             | —     |
| XRF   | CrossRef      | cross\_ref      | Referencias cruzadas (ID/alias)  | —     |
| VER   | Versioning    | versioning      | Control de versiones del sistema | —     |

---

## 2) Matriz MAPX — Glosario ↔ Árbol/Assets (baseline‑aligned)

> **Formato**: `Path (Árbol)` · **Assets (fuente)** · *AliasFinal* → `CODE/Name`

| Path (Árbol)                                                    | Assets (fuente)                                                                                                           | AliasFinal                                                                                                                  | CODE/Name                                                     |
| --------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------- |
| main/data\_base/core\_actv/docs/audio/                          | notas\_de\_voz, reuniones, entrevistas, podcast, audio\_de\_video                                                         | audio\_notes, meetings, interviews, podcast, audio\_from\_video                                                             | **AUD/AudioDoc**                                              |
| main/data\_base/core\_actv/docs/image/                          | fotos, imagenes, graficos, esquemas, diagramas, planos, explosiones                                                       | photos, images, graphics, schematics, diagrams, blueprints, exploded\_views                                                 | **IMG/ImageDoc**                                              |
| main/data\_base/core\_actv/docs/video/                          | videos, youtube, animaciones, presentaciones                                                                              | videos, youtube, animations, presentations                                                                                  | **VID/VideoDoc**                                              |
| main/data\_base/core\_actv/docs/library/                        | libros, manuales, guias, articulos, papers                                                                                | books, manuals, guides, articles, papers                                                                                    | **LIB/LibraryRef**                                            |
| main/data\_base/core\_actv/docs/onboard/                        | notas, mensajes, observaciones                                                                                            | notes, messages, observations                                                                                               | **ONB/OnboardNotes**                                          |
| main/data\_base/core\_actv/data/semantics/                      | glossary, dict\_trigger, dict\_code, dict\_app, dict\_prompt, ing\_prompt, vocabulary                                     | glossary, trigger\_dict, code\_dict, app\_dict, prompt\_dict, ingest\_prompts, vocabulary                                   | **GLOS/DTRG/DCD/DAPP/DPRM/IPRM/VCB**                          |
| main/data\_base/core\_actv/data/ai\_learn/                      | learn, eval, insi, tune, shot, rel, trn, feedback                                                                         | learning, evaluation, insights, fine\_tuning, few\_shot, relevance, training, feedback                                      | **LEARN/EVAL/INSI/FTUNE/FSHOT/RLEV/TRN/FDBK**                 |
| main/data\_base/core\_actv/data/develop/                        | ruleset, config, setup, custom, spec, preference, conectors, orquestador                                                   | ruleset, config, setup, customization, specs, preferences, connectors, orchestrator                                         | **RULE/CFG/SETUP/CSTM/SPEC/PREF/CNCTR/ORCH**                  |
| main/data\_base/core\_actv/data/out\_template/mtx/              | matrix, tabla, ficha, mapping, relation, validation, versus                                                               | matrix, table, record\_sheet, mapping, relation, validation, comparison                                                     | **MTR/TBL/RSHT/MAPX/RELN/VALD/VRS**                           |
| main/data\_base/core\_actv/data/out\_template/docs/             | (pendiente)                                                                                                               | (pendiente)                                                                                                                 | **—**                                                         |
| main/data\_base/core\_actv/data/out\_template/workspaces/       | (pendiente)                                                                                                               | (pendiente)                                                                                                                 | **—**                                                         |
| main/data\_base/core\_actv/data/out\_template/platform\_arch/   | (pendiente)                                                                                                               | (pendiente)                                                                                                                 | **—**                                                         |
| main/data\_base/core\_actv/data/out\_template/ai\_tools/        | (pendiente)                                                                                                               | (pendiente)                                                                                                                 | **—**                                                         |
| main/data\_base/core\_actv/data/guides/planin/mpln/             | mplan, blueprint, baseline, /plans, /roadmaps, /task, /checklist, /checkpoint, /feedback, /validacion, /update\_objective | master\_plan, blueprint, baseline, plans, roadmaps, tasks, checklists, checkpoints, feedback, validation, objective\_update | **MPLN/BLP/BLN/PLN/RMAP/TSK/CHK/CHKP/FDBK/VALD/OBJU**         |
| main/data\_base/core\_actv/data/guides/planin/brainstorm\_crtv/ | brainstorm, insights, ideas, draft, notas, nodo(chkpnt), nodo\_changes, snapshots                                         | brainstorm, insights, ideas, drafts, notes, node\_checkpoint, node\_changes, snapshots                                      | **BRAIN/INSI/IDEA/DRAFT/NOTE/NCHK/NCHG/SNAP**                 |
| main/data\_base/core\_actv/data/guides/run\_control/            | (pendiente)                                                                                                               | (pendiente)                                                                                                                 | **RCNT/RunControl** (propuesto)                               |
| main/data\_base/core\_actv/data/guides/pipeline/                | creator, relev, auditoria, consolidado, migracion, update, cleanup, validation, test, literal\_work, report, clone        | creator, relevance, audit, consolidation, migration, update, cleanup, validation, test, literal\_work, report, clone        | **CRTR/RLEV/AUDT/CNSL/MIGR/UPDT/CLNP/VALD/TST/LITW/RPT/CLON** |
| main/log/changelog/                                             | changelog, logbook, auditlog, validationlog                                                                               | change\_log, logbook, audit\_log, validation\_log                                                                           | **CHG/BIT/ADT/VALOG**                                         |
| main/log/qms/                                                   | trace, crossref, version                                                                                                  | traceability, cross\_ref, versioning                                                                                        | **TRC/XRF/VER**                                               |

---

## 3) Gaps detectados + Decisiones pendientes (para la **Nueva Arquitectura**)

### 3.1 Gaps de cobertura (nomenclatura/plantillas)

- **out\_template/**: faltan modelos para `docs/`, `workspaces/`, `platform_arch/`, `ai_tools` → definir estructura mínima (front‑matter, campos, OutputTemplate) y códigos propuestos (`DOCS`, `WSPC`, `PARCH`, `ATOOL`).
- **guides/run\_control/**: sin definición. Proponer `RCNT` con sub‑entradas (`START`, `STOP`, `RESUME`, `ROLLBACK`).
- **node\_\*:** consolidar semántica `NCHK` y `NCHG` (scope, campos obligatorios).

### 3.2 Decisiones de normalización (naming/códigos)

- Adoptar **AliasFinal** en inglés **solo para nombres de assets**; mantener descriptores en español en `Name`/`Contract`.
- Códigos **reutilizables** en varios buckets (p.ej., `VALD`) **permitidos** si refieren al **mismo concepto**; si el uso difiere, crear variante (p.ej., `VALOG` para log de validación).
- Prefijar códigos de logs/QMS en `E*` si se requiere clasificación futura; por ahora mantener `CHG/ADT/TRC/XRF/VER`.

### 3.3 CrossRef y QMS

- Definir **tabla XRF** mínima entre Glosario ↔ Árbol (ID/CODE ↔ Path) para QMS; consolidar en `main/log/qms/`.
- Establecer **reglas de versión** para glosario (`v1.0` al cerrar), con **CHKP** por hito.

### 3.4 Esqueleto de la Nueva Arquitectura (bloqueado hasta cerrar glosario)

- **Propuesto (no ejecutar aún):** `src/aingz/{domain,adapters,orchestration,memory,eval,telemetry}` con contratos por **Puertos** y **tests de sustitución**; `ops/configs/**` y `core/doc/**` instanciados desde plantillas.
- **Prereq:** Cerrar códigos y alias de este glosario; publicar **MAPX** final; definir `RCNT`.

---

## 4) Próximos pasos (checklist de cierre de Fase 2)

-

---

## OutputTemplate (de este artefacto)

```yaml
output_example:
  status: DRAFT
  id_asset: glos_aingz_v5_draft_v0_1
  generated_by: ai
  created_at: 2025-08-15T00:00:00-03:00
  params:
    - baseline_id: BL-2025-08-15-ARB+AST-v1.3
    - coverage: [docs, semantics, ai_learn, develop, out_template.mtx, guides.planin, guides.pipeline, log.qms]
  result:
    - glossary_entries: 70+
    - mapping_rows: 18
    - gaps: [out_template_docs, out_template_workspaces, out_template_platform_arch, out_template_ai_tools, run_control]
  log:
    - step1: extract_assets_from_baseline
    - step2: normalize_alias_and_codes
    - step3: build_mapx
    - step4: list_gaps_and_pending_decisions
```

```

## AingZ_Platf_Repo/legacy/aing_z_v_5_roadmap_glosario_full_barrido_adjuntos_fase_2.md
meta: {size:9094, lines:161, sha256:"6716f17561231e14daa5fc7c7696c699c6d26938f16228dacf67f194e799f007", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: core/doc/workbench/ROADMAP\_GLOS\_FULL\_V5\_FASE2.md code: RMAP name: RoadmapGlosarioFullV5 version: v0.1 date: 2025-08-15 owner: AingZ\_Platform · RwB status: draft refs: baseline\_id: BL-2025-08-15-ARB+AST-v1.3 ctx\_package: true sources: - glos\_code\_semantics\_v\_5\_main.md (V5 MAIN en uso) - rw\_b\_glosario\_code\_v\_2\_20250729.md (histórico v2) - rw\_b\_diccionario\_code\_triggers\_v\_2\_20250729.md (histórico v2) - readme\_core\_kns\_glossary\_rw\_b\_v\_3\_2.md (README KNS) - readme\_core\_data\_dicts\_rw\_b\_v\_3\_2.md (README DICTS) - aingz\_v\_5\_baselines\_unificados\_dir\_tree\_assets\_v\_1.md (ARB+AST v1.3 LOCKED) triggers: [TRG\_CONSOLIDATE\_TL, TRG\_AUDIT\_TL] chg: CHG#fase2\_glosario\_full\_v5 chk: CHK#fase2\_glosario\_full\_v5

# Roadmap — Glosario Full V5 + Actualización Dir Tree/Assets (Fase 2)

> Objetivo: **consolidar y validar un Glosario Full V5** (sin omitir conceptos) **alineado 1:1** con el **Árbol/Assets** del baseline **v1.3 (LOCKED)**; publicar **MAPX** Glosario↔Árbol y **congelar baseline** actualizado.

---

## 1) Alcance y criterios de éxito

**Incluye:**

- Integración de **todas** las entidades/items/data de glosarios y diccionarios adjuntos.
- Normalización de **CODE ≤5**, `Name` PascalCase, `AliasFinal` (EN) y `Contract` ≤120.
- **MAPX** bidireccional Glosario↔Árbol/Assets.
- Checklist de modificaciones para **actualizar** `aingz_v_5_baselines_unificados_dir_tree_assets`.

**Éxito (DoD):**

- `GLOS_V5_FULL v1.0` (FINAL) + `MAPX v1.0` publicados.
- `CHKP` emitido; `BL-2025-08-15-ARB+AST-v1.3` → `v1.4` (**WIP**) actualizado y luego `v1.4` (**LOCKED**).

---

## 2) Roadmap por fases (WBS + entregables + criterios)

### F0 • Preparación (Día 0)

- **Tareas**: levantar baseline y fuentes; fijar reglas de naming; armar tablero de seguimiento y matrices.
- **Entregables**: este **Roadmap** + plantilla **VALM** de QA + **LSWP** para barrido.
- **Criterios**: fuentes inventariadas; owners asignados.

### F1 • Barrido LSWP 100% y Consolidación (Día 0–1)

- **Tareas**:
  1. **LSWP** (Literal Sweep) 100% de archivos adjuntos (glosarios+diccionarios+baseline).
  2. Tabla **DELTA**: V2↔V5 MAIN (códigos, secciones, conflictos, deprecaciones).
  3. Resolver **nomenclatura** y **alias** según baseline; marcar **gaps**.
- **Entregables**: **LSWP.md**, **DELTA\_V2\_V5.mtr**, **GAPS.mtr**.
- **Criterios**: cobertura 100%; conflictos clasificados (blocker/major/minor).

### F2 • Draft integrado (Día 1–2)

- **Tareas**:
  1. Generar **GLOS\_V5\_FULL\_draft.md** (secciones A–J + buckets/paths del árbol).
  2. Completar **AliasFinal** y **Contracts** homogéneos.
  3. Diseñar **MAPX v0.9** (Glosario↔Árbol/Assets).
- **Entregables**: **Glosario Full v0.9**, **MAPX v0.9**.
- **Criterios**: 0 códigos duplicados; `Contract` ≤120; validación sintáctica.

### F3 • QA + Validación cruzada (Día 2)

- **Tareas**: ejecutar **VALD/VALOG**; probar integridad de `MAPX`; check semántico con `TRIGGERS v2`.
- **Entregables**: **VALM**, **VALOG**, **RPT QA**.
- **Criterios**: 100% pass en reglas; sin conflictos con `CODE_TRIGGERS`.

### F4 • Freeze y publicación (Día 2–3)

- **Tareas**: promover **Glosario v1.0 (FINAL)**; publicar **MAPX v1.0**; emitir **CHKP** y actualizar **Dir Tree/Assets** a `v1.4`.
- **Entregables**: **GLOS\_V5\_FINAL v1.0**, **MAPX v1.0**, **CHKP-2025-08-XX**, **ARB+AST v1.4 LOCKED**.
- **Criterios**: checklist completo; ADR/CHG actualizados.

---

## 3) Plan de QA (VALD/VALM) y reglas (SOLID‑Gate)

- **DIP/Hexagonal**: glosario desacoplado de rutas; `AliasFinal` sólo para activos de árbol.
- **ISP**: tablas con ≤8 columnas; `Contract` preciso.
- **SRP**: una responsabilidad/concepto por fila; deprecaciones explícitas.
- **OCP**: extensiones por `SPEC`/`RULE` sin tocar core.
- **LSP**: tests de sustitución para adaptadores de `TRIGGERS`/`CODES` (misma semántica).

**VALM (mínima)**

- Unicidad (`CODE`, `ID`), longitud y formato.
- Cobertura de buckets del árbol; `MAPX` 1:1 sin órfanos.
- Compatibilidad con **CODE\_TRIGGERS v2** (lookups vigentes) y **V5 MAIN**.

---

## 4) Checklist de modificaciones (para Generar/Validar Glosario Full + Actualizar Árbol)

1. **Normalizar AliasFinal** según baseline en: `docs/*`, `data/semantics/*`, `ai_learn/*`, `develop/*`, `guides/*`, `log/*`.
2. **Completar modelos** faltantes en `out_template/{docs,workspaces,platform_arch,ai_tools}` (propuestos: `DOCS`, `WSPC`, `PARCH`, `ATOOL`).
3. Definir `RCNT/RunControl` y sub‑entradas (`START`, `STOP`, `RESUME`, `ROLLBACK`).
4. Consolidar `NCHK` y `NCHG` (scope, campos obligatorios) en brainstorming.
5. Publicar **MAPX** y **XRF** mínimos en `main/log/qms/`.
6. Emitir **CHKP** y bump a `ARB+AST v1.4`.

---

## 5) Barrido LSWP 100% — Resumen y acciones

> Resultado del análisis literal de todos los adjuntos (tipo, foco, highlights, acciones):

| File                                                  | Tipo             | Foco                          | Highlights                                                                                                    | Acciones                                                                                  |
| ----------------------------------------------------- | ---------------- | ----------------------------- | ------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| glos\_code\_semantics\_v\_5\_main.md                  | Glosario V5 MAIN | Semántica V5 (A–J)            | `SPEC` como reemplazo de `RWB/RWS`; secciones **F**, **H**, **I** completas; feedback abierto en **E**, **F** | Adoptar `SPEC` (deprecación RWB/RWS); alinear con AliasFinal del árbol; incorporar `MAPX` |
| rw\_b\_glosario\_code\_v\_2\_20250729.md              | Glosario v2      | Vocabulario RwB histórico     | Contiene `RWB/RWS`, `WF_M`, `WK_P`, etc.                                                                      | Mapear V2→V5 (RWB/RWS→SPEC; WF\_M→WFM; WK\_P→WKP); mantener lookup en `TRIGGERS`          |
| rw\_b\_diccionario\_code\_triggers\_v\_2\_20250729.md | Diccionario      | Lookups por CODE/Prompt       | Tabla grande A–I con prompts/refs                                                                             | Validar que todos los CODE del Glosario V5 estén en este lookup o documentar sustitutos   |
| readme\_core\_kns\_glossary\_rw\_b\_v\_3\_2.md        | README           | Proceso y sincronización      | KNS/glossary se sincroniza desde `data/dicts/`                                                                | Mantener pipeline v3.2; actualizar crossrefs a V5                                         |
| readme\_core\_data\_dicts\_rw\_b\_v\_3\_2.md          | README           | Data/Dicts                    | Diccionarios vivos; sincronización con KNS                                                                    | Asegurar propagación V5→dicts                                                             |
| AINGZ\_V5\_Baselines\_Unificados\_v1\_3\_locked.md    | Baseline         | Árbol + Assets + Correcciones | AliasFinal EN; `out_template/*` y `run_control` pendientes                                                    | Usar como fuente para AliasFinal; completar pendientes y subir a v1.4                     |

**Conflictos/Decisiones**

- `RWB/RWS` (v2) **→** `SPEC` (V5). Mantener alias históricos en `Aliases` (no en `CODE`).
- `PIPE` (script) vs `Pipeline (estructura)` — usar `PIPE` para script y `PLINE`/`PIPEL` para estructura si aplica.
- Reutilización `VALD`: mismo concepto en QA/log — separar `VALD` (matrix) vs `VALOG` (log).

---

## 6) Matrices auxiliares (plantillas)

**6.1 DELTA\_V2\_V5.mtr (campos)**: `ID_v2, CODE_v2, Name_v2, CODE_v5, Name_v5, Estado{igual|rename|deprecate|nuevo}, Rationale`.

**6.2 MAPX\_GLOS\_TREE.csv (campos)**: `Path, Assets_fuente, AliasFinal, CODE, Name, Notas`.

**6.3 VALM\_GLOS.csv (campos)**: `Regla, Chequeo, Resultado, Evidencia`.

---

## 7) Riesgos y mitigaciones

- **Divergencia V2↔V5** → DELTA obligatorio + alias históricos.
- **Áreas pendientes del árbol** (`out_template/*`, `run_control`) → definir mínimos y validar en QA.
- **Lock‑in semántico** → reglas `RULE/SPEC` y `ADR` inicial documentan extensiones.

---

## 8) Milestones y fechas

- **M1 (Día 1)**: LSWP 100% + DELTA + GAPS.
- **M2 (Día 2)**: Glosario Full v0.9 + MAPX v0.9 + VALM pass.
- **M3 (Día 3)**: Glosario v1.0 (FINAL) + MAPX v1.0 + CHKP + Árbol v1.4 LOCKED.

---

## 9) OutputTemplate

```yaml
output_example:
  status: DRAFT
  id_asset: roadmap_glos_full_v5_fase2
  generated_by: ai
  created_at: 2025-08-15T00:00:00-03:00
  params:
    - phases: [F0,F1,F2,F3,F4]
    - qa: [VALM,VALD,VALOG]
  result:
    - deliverables: [GLOS_V5_FULL, MAPX, DELTA, LSWP, VALM, RPT_QA, CHKP]
  log:
    - step1: plan
    - step2: sweep
    - step3: integrate
    - step4: validate
    - step5: freeze
```

```

## AingZ_Platf_Repo/legacy/aing_z_v_5_semantic_ruleset_rw_b_mode_v_0.md
meta: {size:10140, lines:159, sha256:"3648a38780e9a4172d1add1087fa0e074ab83a80f5e02e2acb0ec088165ec7a3", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: main/data\_base/core\_actv/data/semantics/ruleset/SEM\_RULESET\_AINGZ\_V5\_v0\_1.md code: SEMR name: SemanticRulesetAingZV5 version: v0.1 date: 2025-08-15 owner: AingZ\_Platform · RwB status: draft xrf: baseline\_id: BL-2025-08-15-ARB+AST-v1.3 depends\_on: - glos\_code\_semantics\_v\_5\_main.md - rw\_b\_glosario\_code\_v\_2\_20250729.md - rw\_b\_diccionario\_code\_triggers\_v\_2\_20250729.md - readme\_core\_kns\_glossary\_rw\_b\_v\_3\_2.md - readme\_core\_data\_dicts\_rw\_b\_v\_3\_2.md triggers: [TRG\_CONSOLIDATE\_TL, TRG\_AUDIT\_TL] chg: CHG#sem\_ruleset\_v5 chk: CHK#sem\_ruleset\_v5 notes: "Reglas de semántica unificadas. Integra el espíritu **RwB (Raw\_Base)**: literalidad, no-omisión, enfoque genérico/universal."

# **Semantic Ruleset — AingZ V5 (RwB Mode)**

> **Propósito**: establecer normas de semántica y operación que aseguren **literalidad** (LSWP), **no omisión de información** por criterios subjetivos, y un **enfoque genérico/universal** del trabajo. Las reglas son **agnósticas de rutas** y se alinean al **Baseline Árbol/Assets v1.3** para los *alias\_final*.

---

## 0) Alcance y definiciones

- **RwB (Raw\_Base)**: modo operativo que **prioriza evidencia literal** y **neutralidad**; ninguna curaduría subjetiva puede eliminar datos.
- **Semántica**: conjunto de **códigos, nombres, contratos y alias** con unicidad y trazabilidad.
- **AliasFinal (EN)**: taxonomía normalizada para assets del árbol baseline.
- **MAPX**: matriz de mapeo Glosario↔Árbol/Assets.

---

## 1) Principios (obligatorios)

1. **Literalidad primero (LSWP)**: todo barrido y consolidación se hace por **evidencia textual 100%** antes de sintetizar.
2. **No‑omisión**: se preservan **todos** los ítems encontrados; las deprecaciones requieren **rationale** y **ReplacedBy**.
3. **Contrato sobre implementación**: cada término define **qué garantiza** y sus **límites observables** (≤120 chars).
4. **Unicidad**: `CODE` (≤5, SCREAMING\_SNAKE) y `ID` son únicos; `Name` en PascalCase.
5. **Agnosticismo**: sin rutas ni nombres de archivos en definiciones semánticas.
6. **Compatibilidad**: mapeos **V2→V5** conservan **alias históricos** como metadatos, no como `CODE` vigente.
7. **Interoperabilidad**: misma semántica para GPT‑5, Codex, API, GH Bot, VSC y Python.
8. **Auditabilidad**: cada cambio queda en `CHG`, validado por `VALD` y registrado en `VALOG`.
9. **AliasFinal/Idioma nativo**: usar el idioma **nativo** de la plataforma/SDK/API (usualmente inglés). En activos del árbol, respetar el *alias\_final* del baseline; `Name/Contract` en español.
10. **Separación de templates**: `out_template/*` aloja **templates de salida estructurados** para trabajos puntuales. El bucket `wf_template/` se **renombra** a `wf_playbooks/` (propuesto) y contendrá **workflows detallados paso a paso para la AI**, incluyendo en cada archivo su **OutputTemplate** específico. (Si se aprueba otro nombre, se actualiza por CHG.)
11. **Tono/Estilo GLOS V5**: el tono, taxonomía y forma de las definiciones siguen **GLOS\_Code\_Semantics\_V5\_MAIN** (neutral, técnico, imperativo; sin marketing).
12. **Prioridad de naming por plataforma**: ante ambigüedad, prevalece el naming nativo del lenguaje/plataforma/SDK objetivo (p.ej., Python/JS/CLI/YAML, GitHub Actions, VS Code, OpenAI API).

---

## 2) Reglas operativas (SEMR)

| Nº  | Regla            | Descripción                                                                                                                                                                                 | Evidencia/Artefactos         |
| --- | ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------- |
| R1  | **LSWP.100**     | Antes de decidir, ejecutar **Literal Sweep 100%** sobre todas las fuentes del scope.                                                                                                        | LSWP.md, RPT                 |
| R2  | **CODE.≤5**      | `CODE` máximo 5 chars, SCREAMING\_SNAKE; `Name` en PascalCase.                                                                                                                              | VALM (nomenclatura)          |
| R3  | **CONTR.120**    | `Contract` ≤120 chars, describe finalidad/garantías, no implementación.                                                                                                                     | VALM (contratos)             |
| R4  | **ALIAS.EN**     | En assets del árbol usar **AliasFinal EN** definidos en baseline; no inventar alias.                                                                                                        | MAPX, Baseline               |
| R5  | **MAPX.1:1**     | Mantener mapeo **1:1** Glosario↔Árbol; sin órfanos.                                                                                                                                         | MAPX.csv                     |
| R6  | **DEPREC.RB**    | Deprecaciones requieren `Deprecated:true` + `ReplacedBy` + **rationale**.                                                                                                                   | CHG, DELTA V2→V5             |
| R7  | **HIST.ALIAS**   | Alias históricos (`RWB`, `RWS`, etc.) se conservan como **Aliases** no vigentes.                                                                                                            | GLOS/Main                    |
| R8  | **VALD.QA**      | Ejecutar matrices de validación (`VALD`) y registrar resultados en `VALOG`.                                                                                                                 | VALD.mtx, VALOG              |
| R9  | **TRG.SYNC**     | Cambios en glosario **sincronizan** con `CODE_TRIGGERS` y `dicts` de datos.                                                                                                                 | Dicts/Triggers               |
| R10 | **XRF.MIN**      | Publicar **XRF mínima** (ID/CODE ↔ Path) para QMS.                                                                                                                                          | main/log/qms/XRF.mtx         |
| R11 | **RUNCTRL.DEF**  | Definir `RCNT` (RunControl) y sub‑entradas (`START/STOP/RESUME/ROLLBACK`) como prereq de pipeline.                                                                                          | guides/run\_control          |
| R12 | **TEMPL.MIN**    | Completar modelos mínimos `out_template/{docs,workspaces,platform_arch,ai_tools}`.                                                                                                          | out\_template/\*             |
| R13 | **LANG.NATIVE**  | Para `CODE`, `AliasFinal` y campos técnicos, usar términos nativos del lenguaje/plataforma objetivo; evitar traducciones que rompan convenciones.                                           | GLOS\_V5\_MAIN, SDK/API docs |
| R14 | **TONE.GLOSV5**  | Redactar definiciones según el tono/estructura de **GLOS\_Code\_Semantics\_V5\_MAIN**.                                                                                                      | GLOS\_V5\_MAIN               |
| R15 | **WF.PLAYBOOKS** | Renombrar `wf_template/` → `wf_playbooks/` (propuesto). Cada **playbook** define pasos, entradas/salidas, herramientas y **OutputTemplate** embebido para generar el asset bajo el ruleset. | wf\_playbooks/\*             |

---

## 3) Flujo RwB (resumen operativo)

1. **LSWP** de fuentes → 2. **DELTA V2→V5** (rename/deprec/new) → 3. **Draft integrado** (GLOS v0.9) → 4. **MAPX v0.9** → 5. **VALD/VALOG** → 6. **Freeze** (GLOS v1.0 + MAPX v1.0) → 7. **Actualizar Árbol/Assets** (v1.4 LOCKED).

---

## 4) Roles y ownership (mínimo)

- **Semantic Owner**: custodia del glosario (`GLOS`, `DCD`, `VCB`).
- **Triggers Owner**: custodia de `DTRG` (sincronización automática y revisiones).
- **Baseline Owner**: aplica alias y publica **CHKP**.

---

## 5) QA (VALM/VALD) — Checklist

-

---

## 6) Plantillas mínimas (apéndice)

### 6.1 Entrada de Glosario

```yaml
- CODE: VALD
  Name: Validation
  Contract: Verificar conformidad técnica; produce pass/fail + métricas.
  Aliases: [Validacion]
  Deprecated: false
  ReplacedBy: null
  PlatformNotes: {GPT5: "QA gates", PY: "unit/integration hooks"}
```

### 6.2 Fila MAPX

```yaml
- Path: main/data_base/core_actv/data/out_template/mtx/
  Assets: [matrix, table, record_sheet, mapping, relation, validation, comparison]
  AliasFinal: [matrix, table, record_sheet, mapping, relation, validation, comparison]
  MapTo: [MTR, TBL, RSHT, MAPX, RELN, VALD, VRS]
```

### 6.3 WF Playbook (propuesto)

```yaml
- CODE: WFPB
  Name: WorkflowPlaybook
  Contract: Instrucciones paso a paso para generar un asset bajo el ruleset; incluye OutputTemplate embebido.
  Inputs:
    - name: source_files
      type: list[path]
      required: true
    - name: params
      type: dict
      required: false
  Tools: [web.run, file_search, python, etc.]
  Preconditions: [baseline_locked, sem_ruleset_v5_applied]
  Steps:
    - id: s1
      do: LSWP.100 (leer fuentes)
      out: lswp_report
    - id: s2
      do: Normalizar (CODE≤5, Contract≤120, Lang.Native)
      out: draft_glossary
    - id: s3
      do: MAPX (1:1 Glosario↔Árbol)
      out: mapx_v0_9
  OutputTemplate:
    type: yaml
    schema:
      asset_id: str
      version: semver
      files: [paths]
      qa: {valm: pass|fail, vald: pass|fail}
```

---

## 7) OutputTemplate (del Ruleset)

```yaml
output_example:
  status: DRAFT
  id_asset: sem_ruleset_aingz_v5_v0_1
  generated_by: ai
  created_at: 2025-08-15T00:00:00-03:00
  params:
    - mode: RwB (Raw_Base)
    - alignment: baseline_alias_final
    - qa: [VALM, VALD, VALOG]
  result:
    - rules: 12
    - checklists: 8
    - templates: [glosario_item, mapx_row]
  log:
    - step1: lswp_sources
    - step2: unify_rules
    - step3: publish_semr
```

```

## AingZ_Platf_Repo/legacy/aingz_v_5_arbol_de_directorios_baseline_2025_08_15.md
meta: {size:1567, lines:70, sha256:"636a8829321b37f5fc67d6919b71a4ed6298148845defdae02da76ec52183f63", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
file: core/doc/workbench/AINGZ_V5_Directory_Tree_Baseline_2025-08-15.md
code: ARB_BASE
name: AingzV5DirectoryTreeBaseline
version: v1.0-baseline
date: 2025-08-15
owner: AingZ_Platform · RwB
status: baseline
notes: "Snapshot validado por el usuario. Usar como punto de restauración si aparecen inconsistencias futuras."
---

# AINGZ_V5 — Árbol de Directorios (Baseline)

**Baseline-ID:** BL-2025-08-15-ARB

```text
AingZ_Platform/
  main/
  .github/
  data_base/
    core_actv/
      docs/
        audio/
        image/
        video/
        library/
        onboard/
      data/
        semantics/
        ai_learn/
        develop/
        out_template/
        guides/
          planin/
            mpln/
            brainstorm_crtv/
          run_control/
          pipeline/
      kns_ctx_vivo/
      wf_template/
    core_dev/
    core_arch_platform/
  log/
    changelog/
    qms/
  packages/
  ruleset/
  scripts/
```

> **Estado**: *LOCKED (baseline)* — cualquier cambio futuro se hará en el canvas **Full · WIP** y, si es necesario, se podrá volver a esta versión.

---

## Cambios desde la última iteración
- `2025-08-15` — Se congela árbol como baseline validada por el usuario.

## Cómo usar este baseline
- Comparar futuras versiones contra **Baseline-ID** `BL-2025-08-15-ARB`.
- Si hay desvíos, restaurar desde este documento o copiar este bloque al **Full · WIP**.

```yaml
output_example:
  status: BASELINE_LOCKED
  id_asset: BL-2025-08-15-ARB
  created_at: 2025-08-15T00:00:00-03:00
  result:
    - baseline_ready: true
```

```

## AingZ_Platf_Repo/legacy/aingz_v_5_baselines_unificados_dir_tree_assets_v_1.md
meta: {size:9133, lines:145, sha256:"c506d9195ca11b6613e5f440290e1be46b2a912b7fa952fa5b8bbc6974ca8fe3", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: core/doc/workbench/AINGZ\_V5\_Baselines\_Unificados\_v1\_3\_locked.md

code: ARB+AST\_BASE name: AingzV5BaselinesUnificados version: v1.3 status: baseline\_locked date: 2025-08-15 owner: AingZ\_Platform · RwB notes: "Baseline final de Árbol + Assets. Vista de árbol mejorada. Incluye checklist aplicado, pendientes y ctx\_package. (Se mantiene separación out\_template/\* vs wf\_template/\*)"

**Baseline-ID:** BL-2025-08-15-ARB+AST-v1.3

---

# AINGZ V5 — Baselines Unificados (Directorio + Assets) — **LOCKED**

> Origen: snapshots Excalidraw + canvas previos. Esta versión consolida v1.1–v1.2, aplica correcciones de naming aprobadas (excepto unificación de templates), y queda como referencia estable para las próximas etapas.

---

## 1) Árbol de Directorios — **Vista Mejorada (Tree)**

```
AingZ_Platform/
├── main/
├── .github/
├── data_base/
│   ├── core_actv/
│   │   ├── docs/
│   │   │   ├── audio/            → [notas_de_voz, reuniones, entrevistas, podcast, audio_de_video]
│   │   │   ├── image/            → [fotos, imagenes, graficos, esquemas, diagramas, planos, explosiones]
│   │   │   ├── video/            → [videos, youtube, animaciones, presentaciones]
│   │   │   ├── library/          → [libros, manuales, guias, articulos, papers]
│   │   │   └── onboard/          → [notas, mensajes, observaciones]
│   │   ├── data/
│   │   │   ├── semantics/        → [glossary, dict_trigger, dict_code, dict_app, dict_prompt, ing_prompt, vocabulary]
│   │   │   ├── ai_learn/         → [learn, eval, insi, tune, shot, rel, trn, feedback]
│   │   │   ├── develop/          → [ruleset, config, setup, custom, spec, preference, conectors, orquestador]
│   │   │   ├── out_template/
│   │   │   │   ├── mtx/          → [matrix, tabla, ficha, mapping, relation, validation, versus]
│   │   │   │   ├── docs/         → [pendiente]
│   │   │   │   ├── workspaces/   → [pendiente]
│   │   │   │   ├── platform_arch/→ [pendiente]
│   │   │   │   └── ai_tools/     → [pendiente]
│   │   │   └── guides/
│   │   │       ├── planin/
│   │   │       │   ├── mpln/     → [mplan, blueprint, baseline, /plans, /roadmaps, /task, /checklist, /checkpoint, /feedback, /validacion, /update_objective]
│   │   │       │   └── brainstorm_crtv/ → [brainstorm, insights, ideas, draft, notas, nodo(chkpnt), nodo_changes, snapshots]
│   │   │       ├── run_control/  → [pendiente]
│   │   │       └── pipeline/     → [creator, relev, auditoria, consolidado, migracion, update, cleanup, validation, test, literal_work, report, clone]
│   │   ├── kns_ctx_vivo/
│   │   └── wf_template/
│   ├── core_dev/
│   └── core_arch_platform/
├── log/
│   ├── changelog/                → [changelog, logbook, auditlog, validationlog]
│   └── qms/                      → [trace, crossref, version]
├── packages/
├── ruleset/
└── scripts/
```

> Leyenda: cada carpeta final muestra entre corchetes **los assets relevados**. Donde figura "pendiente" no hubo lista explícita en Excalidraw.

---

## 2) **Assets Baseline Unificado** (por ruta final)

> Formato: `path_final` → **Assets (fuente)** · *alias\_final (corrección aplicada)*

- `main/data_base/core_actv/docs/audio/` → notas\_de\_voz, reuniones, entrevistas, podcast, audio\_de\_video · *audio\_notes, meetings, interviews, podcast, audio\_from\_video*
- `main/data_base/core_actv/docs/image/` → fotos, imagenes, graficos, esquemas, diagramas, planos, explosiones · *photos, images, graphics, schematics, diagrams, blueprints, exploded\_views*
- `main/data_base/core_actv/docs/video/` → videos, youtube, animaciones, presentaciones · *videos, youtube, animations, presentations*
- `main/data_base/core_actv/docs/library/` → libros, manuales, guias, articulos, papers · *books, manuals, guides, articles, papers*
- `main/data_base/core_actv/docs/onboard/` → notas, mensajes, observaciones · *notes, messages, observations*
- `main/data_base/core_actv/data/semantics/` → glossary, dict\_trigger, dict\_code, dict\_app, dict\_prompt, ing\_prompt, vocabulary · *glossary, trigger\_dict, code\_dict, app\_dict, prompt\_dict, ingest\_prompts, vocabulary*
- `main/data_base/core_actv/data/ai_learn/` → learn, eval, insi, tune, shot, rel, trn, feedback · *learning, evaluation, insights, fine\_tuning, few\_shot, relevance, training, feedback*
- `main/data_base/core_actv/data/develop/` → ruleset, config, setup, custom, spec, preference, conectors, orquestador · *ruleset, config, setup, customization, specs, preferences, connectors, orchestrator*
- `main/data_base/core_actv/data/out_template/mtx/` → matrix, tabla, ficha, mapping, relation, validation, versus · *matrix, table, record\_sheet, mapping, relation, validation, comparison*
- `main/data_base/core_actv/data/out_template/docs/` → **(pendiente)**
- `main/data_base/core_actv/data/out_template/workspaces/` → **(pendiente)**
- `main/data_base/core_actv/data/out_template/platform_arch/` → **(pendiente)**
- `main/data_base/core_actv/data/out_template/ai_tools/` → **(pendiente)**
- `main/data_base/core_actv/data/guides/planin/mpln/` → mplan, blueprint, baseline, /plans, /roadmaps, /task, /checklist, /checkpoint, /feedback, /validacion, /update\_objective · *master\_plan, blueprint, baseline, plans, roadmaps, tasks, checklists, checkpoints, feedback, validation, objective\_update*
- `main/data_base/core_actv/data/guides/planin/brainstorm_crtv/` → brainstorm, insights, ideas, draft, notas, nodo(chkpnt), nodo\_changes, snapshots · *brainstorm, insights, ideas, drafts, notes, node\_checkpoint, node\_changes, snapshots*
- `main/data_base/core_actv/data/guides/run_control/` → **(pendiente)**
- `main/data_base/core_actv/data/guides/pipeline/` → creator, relev, auditoria, consolidado, migracion, update, cleanup, validation, test, literal\_work, report, clone · *creator, relevance, audit, consolidation, migration, update, cleanup, validation, test, literal\_work, report, clone*
- `main/log/changelog/` → changelog, logbook, auditlog, validationlog · *change\_log, logbook, audit\_log, validation\_log*
- `main/log/qms/` → trace, crossref, version · *traceability, cross\_ref, versioning*

---

## 3) Correcciones de Naming **aplicadas en v1.3** (registro)

- docs/image/: `imagenes`→`images`, `graficos`→`graphics`, `esquemas`→`schematics`, `planos`→`blueprints`, `explosiones`→`exploded_views` ✅
- docs/video/: `presentaciones` (corrige `presentac`)→`presentations` ✅
- data/semantics/: `ing_prompt`→`ingest_prompts` ✅
- data/ai\_learn/: `insi`→`insights`, `rel`→`relevance`, `trn`→`training`, `tune`→`fine_tuning`, `shot`→`few_shot` ✅
- data/develop/: `ruleset`→`ruleset`, `custom`→`customization`, `spec`→`specs`, `preference`→`preferences`, `conectors`→`connectors`, `orquestador`→`orchestrator` ✅
- guides/planin/mpln/: `update_objective`→`objective_update`, `validacion`→`validation` ✅
- guides/planin/brainstorm\_crtv/: normaliza `nodo`→`node`, `nodo_changes`→`node_changes`, typo "Barinstorm"→`Brainstorm` ✅
- log/: `auditlog`→`audit_log`, `validationlog`→`validation_log` ✅
- qms/: `crossref`→`cross_ref` ✅

> **Explícito:** NO se unifican `out_template/*` y `wf_template/*`. (Se mantiene separación hasta nuevo diseño.)

---

## 4) Pendientes (para próxima iteración)

- Definir assets para: `out_template/{docs, workspaces, platform_arch, ai_tools}` y `guides/run_control`.
- Completar glosario alineado a alias\_final y códigos.
- Iniciar ER model, CrossRef y esqueleto de Pipeline (solo after glosario).

---

## 5) Checklist — Próxima etapa (Glosario + Nueva Arch)

-

---

## 6) ctx\_package — Snapshots del Hilo

```yaml
ctx_package:
  id: BL-2025-08-15-ARB+AST-v1.3
  date: 2025-08-15
  sources:
    - excalidraw_blocks: [docs/*, data/* (out_template, guides), log/*]
    - canvas_docs:
        - Aingz V5 — Árbol De Directorios (baseline · 2025-08-15)
        - Aingz V5 — Baselines Unificados (dir Tree + Assets) · V1 (v1.1–v1.2)
        - Aingz V5 — Baselines Unificados (dir Tree + Assets) · v1.3 (Locked)
  decisions:
    - Mantener separación entre out_template/* y wf_template/*.
    - Aplicar correcciones de naming listadas.
    - Marcar como pendiente lo no especificado en Excalidraw.
  next:
    - Consolidar Glosario v5 y alinear con árbol + assets.
    - Iniciar modelo ER, CrossRef y Pipeline esqueleto.
```

---

## Estado

**baseline\_locked** — Documento listo como referencia estable. Cualquier cambio se hará en una copia **WIP** derivada de esta versión.

```

## AingZ_Platf_Repo/legacy/core_data_mtx_mtx_arch_patterns_v_4.md
meta: {size:21539, lines:371, sha256:"18523bdf37671270fee0e8830db35955def8e08bf9b1c77b28c3fa094289f87f", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
file: core/data/mtx/MTX_Arch_Patterns_V4.md
code: MTRAP
name: ArchPatternsAssessment
version: v4.0
date: 2025-08-12
owner: RwB_Platform
status: active
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL, TRG_AUDIT_TL, TRG_AUDIT_LEGACY, TRG_PURGE_AI]
chg: CHG_main.md#arch_patterns_v4
chk: CHK_root.md#arch_patterns_v4
---

# Patrones de Arquitectura de Software — Snapshots + Matrices (V4)

> **Propósito**: entregar un **doc interno** genérico (sin naming de productos/organizaciones) con snapshots concisos de patrones, **matrices comparativas** (VRS) y un **WF de decisión** para seleccionar opciones para **infraestructura de agentes/IA en proyectos personales (1 dev)**.

## 1) Alcance y supuestos

- **Contexto**: desarrollo profesional **personal (1 dev)** con agentes/IA, pipelines de datos y automatizaciones; foco en simplicidad operativa, trazabilidad y costo bajo.
- **Plataforma**: ejecución en **un solo repositorio** con despliegue en **contenedores** y opción de VM; posibilidad de escalar a orquestadores más adelante.
- **No objetivos**: tiempo real estricto/ultra‑baja latencia, multi‑equipo, SLA 24x7 de misión crítica.
- **Criterios guía**: reproducibilidad, portabilidad, minimización de dependencias externas, auditoría de decisiones de IA, seguridad de credenciales.

### 1.1 Escenarios típicos (Agentes/IA)
- Agente único con **herramientas** (I/O a archivos, web, correo, APIs).
- **Orquestación de tareas** (jobs batch) y colas ligeras.
- **Memoria** del agente: episódica (conversación), semántica (embedding), factual (config/kb).
- **Evaluación** y registro de prompts, decisiones y resultados.

## 1.2 Principios SOLID (guía práctica para agentes/IA)

> **Objetivo**: reducir acoplamiento, aumentar cohesión y testabilidad. Aplicable a clases, módulos, servicios y adaptadores (puertos/herramientas) en proyectos personales con agentes/IA.

| Principio | Enunciado breve | Señales de violación | Heurísticos aplicables | Impacto en agentes/IA |
|---|---|---|---|---|
| **SRP** (Single Responsibility) | Una unidad debe tener **una sola razón de cambio**. | Módulos "multi‑propósito", *utils* gigantes, clases que hacen de todo. | Dividir por **caso de uso**; módulos orientados a dominio; separar *tooling* del core. | Menos deuda, pruebas más simples por función/herramienta.
| **OCP** (Open/Closed) | **Abierta a extensión, cerrada a modificación**. | *if/elif* por tipo, *feature flags* en core, tocar núcleo para agregar herramientas. | Patrones **Strategy/Factory**; cargar herramientas por **registro/config**; plugin‑like. | Añadir tool/modelo sin tocar el núcleo del agente.
| **LSP** (Liskov Substitution) | Subtipos deben **sustituir** sin romper contratos. | Adaptadores que cambian pre/post‑condiciones; *raise* inesperado. | **Contratos explícitos** (Protocol/ABC), **tests de sustitución** compartidos. | Intercambiar proveedor/LLM sin romper flujos.
| **ISP** (Interface Segregation) | Preferir **interfaces específicas** y pequeñas. | Interfaces gordas; métodos no usados. | **Interfaces por caso de uso**; < 5 métodos por puerto; herramientas minimalistas. | Agente con menú de herramientas mínimo y claro.
| **DIP** (Dependency Inversion) | Depender de **abstracciones**, no de concreciones. | Importar SDKs/HTTP client desde el dominio; acoplar a framework. | **Puertos/Adaptadores**, inyección de dependencias, *factories*. | Cambiar proveedor/DB sin tocar dominio.

**Reglas de arquitectura (tests sugeridos)**
- El **dominio** no puede importar **adaptadores** ni SDKs (DIP).
- Todo acceso a proveedor externo debe pasar por un **Puerto** (interface/Protocol) con **Adaptador**.
- **Interfaces pequeñas** por herramienta; evitar *god interfaces* (ISP).
- **Suite de sustitución**: cada adaptador debe pasar los **mismos tests** (LSP).
- Nuevas herramientas se agregan por **registro/config** sin modificar core (OCP).
- Módulos con **una responsabilidad** y *boundaries* claros (SRP).

**Plantillas (DIP/ISP en Python)**
```python
from typing import Protocol, runtime_checkable

@runtime_checkable
class LLMPort(Protocol):
    def complete(self, prompt: str, **kw) -> str: ...

@runtime_checkable
class ToolPort(Protocol):
    name: str
    def run(self, input: dict, ctx: dict) -> dict: ...

class OpenAIAdapter:
    def __init__(self, client):
        self._c = client
    def complete(self, prompt: str, **kw) -> str:
        # implementación concreta del proveedor
        return self._c.completions.create(prompt=prompt, **kw).text

class Agent:
    def __init__(self, llm: LLMPort, tools: list[ToolPort]):
        self.llm, self.tools = llm, {t.name: t for t in tools}
```

**Automatización de calidad**
- **import‑linter**: reglas de dependencia (DIP).
- **pytest**: *tests* de sustitución compartidos por adaptador (LSP).
- **ruff/pylint**: SRP/ISP por métricas de complejidad y tamaño.
- **mypy**: contratos de tipo para puertos/adaptadores.

---

## 2) Snapshots de patrones (1‑pagers)

Cada snapshot resume: **Contexto → Fuerzas → Trade‑offs → Antipatrones → Indicadores**.

### 2.1 Monolito Modular

- **Contexto**: un solo deploy, módulos bien definidos (contextos delimitados).
- **Fuerzas**: simplicidad operativa, transacciones ACID, latencia baja intra‑proceso.
- **Trade‑offs**: riesgo de erosión modular; ciclos de release acoplados.
- **Antipatrones**: *Big Ball of Mud*, capas anémicas.
- **Indicadores**: time‑to‑market inicial, % coupling entre módulos, cobertura de tests por módulo.

### 2.2 Hexagonal (Puertos y Adaptadores)

- **Contexto**: dominio aislado del I/O (DB, MQ, HTTP). Facilita tests y reemplazos.
- **Fuerzas**: desacople fuerte; testing por puertos; fácil mockeo de adaptadores.
- **Trade‑offs**: sobrecosto inicial de diseño; disciplina en boundaries.
- **Antipatrones**: lógica de dominio filtrada a adaptadores; puertos "dios".
- **Indicadores**: nº adaptadores por puerto, % dependencias dominio→infra (ideal 0%).

### 2.3 Arquitectura en Capas (Layered)

- **Contexto**: presentación ⇄ aplicación ⇄ dominio ⇄ datos.
- **Fuerzas**: familiaridad, separación de responsabilidades.
- **Trade‑offs**: riesgo de *pasamanos*; violaciones de capas; latencia por hops.
- **Antipatrones**: servicios anémicos que solo delegan repositorios.
- **Indicadores**: reglas de dependencia (solo hacia abajo) cumplidas.

### 2.4 Microservicios

- **Contexto**: servicios pequeños, independientes, *DB per service*.
- **Fuerzas**: escalado selectivo, independencia de release, equipos autónomos.
- **Trade‑offs**: complejidad operativa (network, observabilidad, consistencia); coste.
- **Antipatrones**: *microservicios en mini‑monolito*; *shared DB*.
- **Indicadores**: lead‑time por servicio, MTTR, tasa de cambios coordinados cross‑servicio.

### 2.5 Event‑Driven (EDA)

- **Contexto**: eventos como primera clase; *publish/subscribe*.
- **Fuerzas**: desacople temporal; resiliencia; extensibilidad.
- **Trade‑offs**: debugging/orden; *at‑least‑once* y deduplicación; semántica eventual.
- **Antipatrones**: *event soup* sin contratos; acoplamiento a payloads frágiles.
- **Indicadores**: lag de colas, % idempotencia efectiva, *dead letters*.

### 2.6 CQRS

- **Contexto**: separar modelos/paths de **lectura** y **escritura**.
- **Fuerzas**: escalado lecturas, proyecciones especializadas.
- **Trade‑offs**: sincronización y consistencia eventual; duplicación de modelos.
- **Antipatrones**: uso sin necesidad; agregar complejidad sin volúmenes de lectura altos.
- **Indicadores**: ratio R/W, latencia de proyección, frescura de vistas.

### 2.7 Event Sourcing

- **Contexto**: el estado es el *log* de eventos; *snapshots* periódicos.
- **Fuerzas**: auditoría perfecta; *time‑travel*; integridad histórica.
- **Trade‑offs**: complejidad de replays/migraciones; *versioning* de eventos.
- **Antipatrones**: usarlo para dominios CRUD simples.
- **Indicadores**: tiempo de *rebuild*, tamaño de log, tasa de *upcasters*.

### 2.8 Serverless (FaaS + servicios gestionados)

- **Contexto**: funciones efímeras y *managed services*.
- **Fuerzas**: coste OPEX por uso, escalado automático, zero‑ops parcial.
- **Trade‑offs**: *cold starts*, límites de ejecución, *vendor lock‑in*.
- **Antipatrones**: core de dominio con cadenas FaaS largas.
- **Indicadores**: p95 de arranque, coste/100k invocaciones, error rate por límite.

### 2.9 Modular Monolith → Strangler Fig (Evolución)

- **Contexto**: iniciar modular y extraer *seams* a servicios cuando maduran.
- **Fuerzas**: control del riesgo, inversiones incrementales.
- **Trade‑offs**: disciplina de boundaries, doble topología transitoria.
- **Indicadores**: nº seams candidatos; *blast radius* de cambios.

### 2.10 Micro‑Frontends (si aplica)

- **Contexto**: UI compuesta por *slices* independientes.
- **Nota**: evaluar solo si crece la UI multi‑equipo.

### 2.11 Orquestación en Grafo (Agentes)
- **Contexto**: flujo como **grafo/DAG** de nodos (agentes/herramientas) con control explícito de estado.
- **Fuerzas**: visualización clara, reintentos por nodo, trazabilidad de decisiones.
- **Trade‑offs**: diseño inicial del grafo; sobrecosto si el flujo es lineal simple.
- **Indicadores**: nº nodos/edges, tasa de reintentos por nodo, tiempo total por recorrido.

### 2.12 Agente Único con Registro de Herramientas
- **Contexto**: proceso único, **registro de herramientas** (adapters) que el agente invoca.
- **Fuerzas**: simplicidad y bajos costos; fácil de depurar.
- **Trade‑offs**: límites de escalado vertical; riesgo de *god‑agent*.
- **Indicadores**: nº herramientas, % llamadas externas exitosas, MTTR por fallo.

### 2.13 Memoria Híbrida del Agente
- **Contexto**: capas de memoria (episódica/semántica/factual) con políticas de retención.
- **Fuerzas**: mejor contexto y repetibilidad; control de privacidad.
- **Trade‑offs**: complejidad de sincronización y vencimientos.
- **Indicadores**: *hit rate* de recuperación, frescura de memoria, coste de almacenamiento.

---

## 3) Matrices comparativas (VRS)

### 3.1 Patrón × Criterios técnicos/operativos

| Patrón           | Complejidad Operativa | Escalabilidad   | Cohesión     | Acoplamiento               | Consistencia Datos  | Latencia   | Despliegue          | Observabilidad       | Coste          | Fit Equipo |
| ---------------- | --------------------- | --------------- | ------------ | -------------------------- | ------------------- | ---------- | ------------------- | -------------------- | -------------- | ---------- |
| Monolito Modular | **Baja**              | Media           | Alta         | Media‑Baja                 | **Fuerte (ACID)**   | **Baja**   | Simple              | Media                | **Bajo**       | **Alto**   |
| Hexagonal        | Baja‑Media            | Media           | **Muy alta** | **Baja**                   | Fuerte              | Baja       | Simple              | Alta                 | Bajo           | Alto       |
| Capas            | Baja                  | Media           | Media        | Media                      | Fuerte              | Media      | Simple              | Media                | Bajo           | Alto       |
| Microservicios   | **Alta**              | **Alta**        | Media        | **Baja (inter‑servicios)** | Eventual            | Media‑Alta | Complejo (K8s/mesh) | **Alta (necesaria)** | **Alto**       | Medio‑Alto |
| EDA              | Media                 | Alta            | Alta         | Baja temporal              | Eventual            | Media      | Medio               | Alta                 | Medio          | Medio      |
| CQRS             | Media                 | Alta (lecturas) | Alta         | Media                      | Eventual (lecturas) | Baja‑Media | Medio               | Media                | Medio          | Medio      |
| Event Sourcing   | Alta                  | Media           | Alta         | Media                      | **Fuerte (audit)**  | Media      | Medio‑Alto          | Alta                 | Medio‑Alto     | Medio      |
| Serverless       | Media                 | **Alta**        | N/A          | N/A                        | N/A                 | Variable   | Simple‑Medio        | Media                | **Bajo‑Medio** | Medio      |

> **Leyenda**: negrita = ventaja clara. "Fit Equipo" asume equipo pequeño‑mediano con fuerte disciplina de testing.

### 3.2 Requisitos (proyectos personales con agentes/IA) × Adecuación de patrón

| Requisito                                 | Monolito Modular | Hexagonal | Microservicios | EDA | CQRS | Event Sourcing | Serverless |
| ----------------------------------------- | ---------------- | --------- | -------------- | --- | ---- | -------------- | ---------- |
| Trazabilidad (auditoría/no‑loss)          | 3                | 5         | 4              | 4   | 4    | **5**          | 4          |
| Time‑to‑market inicial                    | **5**            | 4         | 2              | 3   | 3    | 2              | 4          |
| Evolución incremental sin *big‑bang*      | 4                | **5**     | 3              | 4   | 3    | 3              | 4          |
| Coste operativo inicial bajo              | **5**            | 4         | 2              | 3   | 3    | 2              | 4          |
| Procesos batch/orquestación               | 4                | 4         | 3              | 4   | 3    | 3              | **5**      |
| Dependencias externas variables           | 3                | **5**     | 4              | 4   | 3    | 3              | 4          |

> Escala 1‑5 (mejor=5). Basado en contexto actual (1 dev) y objetivos de simplicidad.

### 3.3 Riesgos clave × Mitigaciones

| Riesgo                | Patrón asociado    | Mitigación                                                              | Indicador/KPI                              |
| --------------------- | ------------------ | ----------------------------------------------------------------------- | ------------------------------------------ |
| Erosión modular       | Monolito Modular   | Reglas de dependencia + *module boundaries* + **tests de arquitectura** | % violaciones detectadas por *linter*      |
| Complejidad/operación | Microservicios/EDA | Observabilidad abierta, *service templates*, *platform repo*            | MTTR, SLIs (lat/err)                       |
| Pérdida de eventos    | EDA/CQRS/ES        | **Outbox**, idempotencia, *DLQ*, *sagas*                                | % reintentos, DLQ size                     |
| Vendor lock‑in        | Serverless         | Abstracción por puertos + *infra as code*                               | % funciones con adapters neutrales          |

### 3.4 Stack de agentes × Integración

| Componente              | Opción mínima (1 dev)           | Patrón de integración        | KPIs sugeridos                 |
|-------------------------|----------------------------------|------------------------------|-------------------------------|
| Orquestación de flujo   | Grafo simple en proceso          | Orquestación en Grafo        | tiempo por nodo, reintentos   |
| Llamadas a herramientas | Registro local de herramientas   | Puertos/Adaptadores          | tasa éxito, latencia por tool |
| Memoria                 | Archivos/BD ligera + índice      | Memoria Híbrida              | hit rate, frescura            |
| Persistencia            | BD relacional ACID               | Hexagonal + Repositorios     | p95 consultas, locks          |
| Mensajería              | Cola ligera/log local            | EDA                          | lag, DLQ                      |
| Evaluación              | Harness de pruebas + métricas    | CQRS (proyecciones de lectura)| frescura de vistas            |
| Observabilidad          | Tracing/métricas/logs básicos    | N/A                          | MTTR, cobertura de spans      |

### 3.5 Matriz SOLID × Patrones

| Patrón / Principio | SRP | OCP | LSP | ISP | DIP | Notas |
|---|---:|---:|---:|---:|---:|---|
| Monolito Modular | 4 | 4 | 4 | 4 | 3 | Requiere disciplina en límites para mantener SRP.
| Hexagonal | **5** | **5** | 4 | **5** | **5** | Puertos/Adaptadores refuerzan OCP/DIP/ISP.
| Capas | 4 | 3 | 3 | 4 | 3 | Riesgo de *pasamanos*; OCP mejora con factories.
| Microservicios | 5 (a nivel servicio) | 4 | 4 | 4 | 4 | Aumenta SRP, pero complejidad operativa.
| EDA | 4 | 4 | 4 | 4 | 4 | Contratos de eventos claros ayudan LSP/ISP.
| CQRS | 4 | 4 | 4 | 4 | 4 | Separación R/W apoya SRP.
| Event Sourcing | 4 | 3 | 4 | 3 | 4 | DIP crítico en *event store*.
| Serverless | 3 | 4 | 3 | 4 | 4 | Mantener puertos evita *lock‑in* proveedor.

> Escala 1‑5; **negrita** = ajuste sobresaliente.

## 4) Roadmap genérico para agentes/IA (equipo 1 dev)

**Estrategia recomendada**: **Monolito Modular + Hexagonal** como base → **EDA táctico** para integración y jobs → **CQRS limitado** donde lecturas escalen → **Event Sourcing solo** en módulos con auditoría fuerte (p.ej., cambios de reglas, decisiones automáticas) → **Serverless** para picos/batch.

### Fase 0 — Baseline (hoy)

- Modular Monolith repo‑first con **capas de dominio hexagonales** (puertos: DB, cola, HTTP, storage).
- **BD relacional ACID** (con soporte JSON) para estado fuerte. **Cache en memoria** con TTL para lecturas frecuentes.
- **Orquestación de jobs** en proceso/cola ligera + **patrón Outbox** para entrega confiable.
- **Telemetría abierta** (tracing/métricas/logs) + KPIs clave del §3.3.
- **CI/CD basado en repositorio** + contenedores.

### Fase 1 — Integración por eventos (3‑6 meses)

- Introducir **bus de mensajería** (cola o *log* distribuido) según throughput.
- **Publicar eventos de dominio** y proyecciones de lectura (mini‑CQRS donde aporte).
- Endurecer idempotencia y *DLQ*.

### Fase 2 — Extracción selectiva (6‑12 meses)

- Identificar *seams* con alta tasa de cambio o *scaling hotspots* → extraer microservicios.
- Plantillas de servicio, *API gateway* y *contract tests*.

### Fase 3 — Serverless táctico

- Funciones para tareas picos/batch (p.ej., análisis de corpus, generación de reportes).

---

## 5) WF — Selección y evaluación de patrón (WF\_APSEL)

**Objetivo**: aplicar un proceso repetible y auditable para elegir patrones por módulo.

**Inputs**: requisitos del módulo, KPIs objetivo, restricciones de operación, *fit* de equipo.

**Pasos**:

0. **SOLID**: validar reglas (DIP/ISP/SRP) y *tests* de sustitución (LSP); exigir extensión por config/registro (OCP).
1. **INGEST**: capturar requisitos → matriz 3.2 por módulo.
2. **SCORING**: puntuar patrones (1‑5) y calcular **Score Ajustado = (Adecuación × Peso requisito)**.
3. **RIESGOS**: evaluar tabla 3.3 y proponer mitigaciones.
4. **DECISIÓN**: seleccionar patrón/es y generar ADR.
5. **VALIDACIÓN**: definir KPIs (latencia, MTTR, % idempotencia, coste) y umbrales.
6. **CHECK**: correr *architecture tests* y QA de dependencias.
7. **CLOSE**: registrar en CHG/LESSONS + disparar **TRG\_CONSOLIDATE\_TL** y **TRG\_AUDIT\_TL**.

**Salidas**: ADR, matriz decisión, backlog de mitigaciones, KPIs y plan de implementación.

### Árbol de decisión (resumen)

```mermaid
flowchart TD
  A[¿Equipo pequeño/mediano?] -->|Sí| B{¿Necesitás auditoría fuerte?}
  A -->|No| MS[Microservicios] --> EDA
  B -->|Sí| ES[Event Sourcing+Snapshots en ese módulo] --> EDA
  B -->|No| C{¿Lecturas >> Escrituras?}
  C -->|Sí| CQ[MQ+CQRS de lectura]
  C -->|No| MM[Modular Monolith + Hexagonal]
  MM --> EDA
```

---

## 6) KPIs & Observabilidad (mínimos)
- **Disponibilidad** por módulo/servicio; **MTTR**; **latencia p95** rutas críticas.
- **Consistencia**: % mensajes re‑procesados; tamaño de DLQ.
- **Calidad**: cobertura tests de dominio; **tests de arquitectura** (dependencias).
- **Coste**: gasto mensual infra por módulo.
- **IA/Agentes**: *hit rate* de recuperación de memoria; % decisiones explicadas/logueadas; tasa de alucinaciones detectadas.

## 7) Referencias internas & ADR
- Plantilla ADR sugerida:

```yaml
adr:
  id: <consecutivo>
  title: <decision_breve>
  date: <YYYY-MM-DD>
  status: proposed|accepted|deprecated
  context: |
    <resumen del problema y fuerzas>
  decision: |
    <patrón/es elegidos y justificación>
  consequences: |
    <trade-offs y riesgos>
  kpis:
    - name: <kpi>
      target: <umbral>
```

- Este doc se cruza con ADRs por módulo (ruta sugerida: `core/doc/adr/ADR_<id>_<tema>.md`).
- Mantener **no‑loss**: cambios mayores deben registrarse en `ops/changelog.md` y `ops/lessons_learned.md`.

## OutputTemplate (obligatorio)

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: mtx_arch_patterns_v4
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
  params:
    - scope: core
    - audience: single_dev
    - principles: [SOLID]
    - patterns: [monolith_modular, hexagonal, layered, microservices, eda, cqrs, event_sourcing, serverless, graph_orchestration, agent_tools_registry, hybrid_memory]
  result:
    - decision_matrix_path: core/data/mtx/MTX_Arch_Patterns_V4.md
    - recommended_strategy: ModularMonolith+Hexagonal→EDA→CQRS(selectivo)
  log:
    - step0: solid_checks
    - step1: snapshots
    - step2: matrices
    - step3: wf_decision
---

```

## AingZ_Platf_Repo/legacy/core_wf_wf_arch_create_v_4.md
meta: {size:10726, lines:327, sha256:"f660fa952490bbb35898af42816f764dce6af59b6b0da249796667d9d881bd3f", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: core/wf/WF\_ARCH\_CREATE\_V4.md code: WFARC name: ArchCreateWorkflow version: v4.0 date: 2025-08-12 owner: AingZ\_Platform · RwB status: active xrf: blueprint: RwB\_Blueprint\_V4 mplan: RwB\_MasterPlan\_V4 glossary: CODE\_Glossary\_v2 dictionary: CODE\_Triggers\_v2 triggers: [TRG\_CONSOLIDATE\_TL, TRG\_AUDIT\_TL, TRG\_AUDIT\_LEGACY, TRG\_PURGE\_AI] chg: CHG\_main.md#wf\_arch\_create\_v4 chk: CHK\_root.md#wf\_arch\_create\_v4

# WF\_ARCH\_CREATE\_V4 — Workflow para crear una **Arquitectura Base** (agentes/IA, 1 dev)

> **Objetivo**: Instanciar una **arquitectura de software** coherente con la **MTX\_Arch\_Patterns\_V4** (patrones + SOLID) y con el **ruleset V4**. Produce el **paquete de archivos** (blueprint, masterplan, roadmap, ruleset, checklist, configs, setups) listo para versionar.

## 1) Alcance y premisas

- Entorno: proyecto personal (1 dev), agentes/IA, contenedores, CI/CD repo‑based.
- Criterios guía: **trazabilidad, reproducibilidad, bajo costo y simplicidad operativa**.
- Sin naming de productos/terceros; usar **puertos/adaptadores** y **interfaces pequeñas** (SOLID).

## 2) Entradas y salidas

**Inputs**

- MTX: `core/data/mtx/MTX_Arch_Patterns_V4.md` (criterios, matrices, SOLID).
- Requisitos del módulo/arquitectura (alcance, SLIs/SLOs, restricciones, prioridades).

**Outputs**

- Paquete de archivos **MVP** (sección §4) + **ADR** principal + checklist inicial.

## 3) Flujo (paso a paso)

```mermaid
flowchart TD
  A[Kickoff] --> B[Ingest: requisitos]
  B --> C[SOLID Gate: DIP/ISP/SRP & OCP por registro]
  C --> D[Scoring MTX: patrón/es candidatos]
  D --> E[ADR: decisión arquitectura]
  E --> F[Generar paquete archivos MVP]
  F --> G[Config & Setup base]
  G --> H[QA: tests arquitectura + checklist]
  H --> I[Commit + Triggers CHG/CHK]
```

**Detalle de pasos**

1. **Ingest**: capturar requisitos (tabla 3.2 de la MTX). Ponderar criterios.
2. **SOLID‑Gate (0‑fail)**: validar reglas de dependencia (DIP), interfaces pequeñas (ISP), una responsabilidad (SRP), extensión por registro (OCP) y tests de sustitución (LSP).
3. **Scoring**: aplicar matriz VRS → seleccionar patrón/es (p.ej., Monolito Modular + Hexagonal + EDA táctico).
4. **ADR**: registrar contexto, decisión, consecuencias y KPIs.
5. **Generación**: instanciar **paquete** (blueprint/mplan/roadmap/ruleset/checklist/configs/setups) con **metadatos V4**.
6. **Config & Setup**: completar parámetros de `configs` (puertos, secrets, storage, colas).
7. **QA**: ejecutar *tests de arquitectura* (import‑linter), contratos (pytest), tipado (mypy), lint (ruff/pylint).
8. **Commit**: versionar y disparar **TRG\_CONSOLIDATE\_TL** y **TRG\_AUDIT\_TL**.

## 4) **Paquete de archivos convencional (MVP)**

> **Destino**: rutas V4 canónicas. Los archivos incluyen **front‑matter** + **OutputTemplate** o secciones de control.

| Asset             | Ruta V4                                | Propósito                                              | CODE (≤5) |
| ----------------- | -------------------------------------- | ------------------------------------------------------ | --------- |
| **Blueprint**     | `core/doc/blueprint/BLP_<ARCH>_V4.md`  | Topología, límites, dependencias, decisiones clave     | `BLP`     |
| **Master Plan**   | `core/doc/mplan/MPLN_<ARCH>_V4.md`     | Objetivos, fases, riesgos, KPIs                        | `MPLN`    |
| **Roadmap**       | `core/doc/roadmap/RDM_<ARCH>_V4.md`    | Hitos, entregables, fechas, criterios de done          | `RDM`     |
| **RuleSet**       | `core/rules/RULES_<ARCH>_V4.md`        | Reglas de diseño (SOLID, puertos, contratos, naming)   | `RULES`   |
| **Checklist**     | `core/checklists/CHK_<ARCH>_V4.md`     | Controles de cumplimiento (pre/pos‑release)            | `CHK`     |
| **Configs**       | `ops/configs/CFG_<ARCH>_V4.yaml`       | Parámetros de despliegue, puertos, colas, storage, env | `CFG`     |
| **Setups**        | `ops/scripts/setup/SETUP_<ARCH>_V4.md` | Pasos de inicialización local/CI, seeds, fixtures      | `SETUP`   |
| **ADR principal** | `core/doc/adr/ADR_<id>_<ARCH>_V4.md`   | Decisión arquitectónica inicial                        | `ADR`     |

> `<ARCH>` es un alias corto del proyecto/arquitectura (p.ej., `CORE`, `AGNT`).

## 5) **Plantillas (draft) — contenido mínimo**

### 5.1 Blueprint

```markdown
---
file: core/doc/blueprint/BLP_<ARCH>_V4.md
code: BLP
name: <PascalCaseBlueprint>
version: v4.0
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#blp_<arch>
chk: CHK_root.md#blp_<arch>
---
# Blueprint <ARCH>
- **Patrones**: <Monolito Modular + Hexagonal + EDA>
- **Boundaries**: <módulos/contextos>
- **Dependencias externas**: <DB, cola, storage, API>
- **Contratos**: <puertos/interface + eventos>
- **Riesgos** & **mitigaciones**: <tabla>

---
# OutputTemplate (obligatorio)
output_example:
  status: DRAFT
  id_asset: blp_<arch>_v4
  generated_by: user
  created_at: <ISO8601>
  params:
    - patterns: [<...>]
  result:
    - modules: [<...>]
```

### 5.2 Master Plan

```markdown
---
file: core/doc/mplan/MPLN_<ARCH>_V4.md
code: MPLN
name: <PascalCaseMasterPlan>
version: v4.0
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: BLP_<ARCH>_V4
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#mplan_<arch>
chk: CHK_root.md#mplan_<arch>
---
# Master Plan <ARCH>
## Fases
- F0 Baseline → F1 Eventos → F2 Extracción → F3 Serverless
## KPIs
- p95 latencia, MTTR, % idempotencia, coste mensual
## Riesgos y planes
- <riesgo>: <mitigación>

---
# OutputTemplate (obligatorio)
output_example:
  status: DRAFT
  id_asset: mplan_<arch>_v4
  generated_by: user
  created_at: <ISO8601>
```

### 5.3 Roadmap

```markdown
---
file: core/doc/roadmap/RDM_<ARCH>_V4.md
code: RDM
name: <PascalCaseRoadmap>
version: v4.0
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: BLP_<ARCH>_V4
  mplan: MPLN_<ARCH>_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#rdm_<arch>
chk: CHK_root.md#rdm_<arch>
---
# Roadmap <ARCH>
- **Hitos**: <Q1/Q2/...>
- **Entregables**: <artefactos>
- **Criterios de done**: <listas>
```

### 5.4 RuleSet

```markdown
---
file: core/rules/RULES_<ARCH>_V4.md
code: RULES
name: <PascalCaseRuleset>
version: v4.0
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: BLP_<ARCH>_V4
  mplan: MPLN_<ARCH>_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_AUDIT_TL]
chg: CHG_main.md#rules_<arch>
chk: CHK_root.md#rules_<arch>
---
# RuleSet <ARCH>
- **SOLID**: SRP/OCP/LSP/ISP/DIP
- **Puertos/Adaptadores**: contratos mínimos, idempotencia
- **Eventos**: esquema/versionado, outbox, DLQ
- **Persistencia**: ACID + TTL cache
- **Naming**: CODE ≤5, PascalCaseName, rutas V4
```

### 5.5 Checklist

```markdown
---
file: core/checklists/CHK_<ARCH>_V4.md
code: CHK
name: <PascalCaseChecklist>
version: v4.0
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: BLP_<ARCH>_V4
  mplan: MPLN_<ARCH>_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_AUDIT_TL]
chg: CHG_main.md#chk_<arch>
chk: CHK_root.md#chk_<arch>
---
# Checklist <ARCH>
- [ ] DIP: dominio no importa adaptadores/SDK
- [ ] ISP: interfaces pequeñas (<5 métodos)
- [ ] LSP: tests de sustitución por adaptador
- [ ] OCP: registro de herramientas/puertos
- [ ] SRP: una responsabilidad por módulo
- [ ] Eventos: outbox + DLQ + idempotencia
- [ ] Observabilidad: traces/metrics/logs mínimos
- [ ] KPIs definidos y umbrales
```

### 5.6 Configs (YAML)

```yaml
# ops/configs/CFG_<ARCH>_V4.yaml
arch:
  name: <arch_name>
  patterns: [monolith_modular, hexagonal, eda]
  modules:
    - id: <mod_id>
      purpose: <texto>
      ports:
        db: <dsn>
        cache: <redis_url>
        queue: <queue_url>
        http: <base_url>
  events:
    bus: <none|queue|log>
    outbox: true
  telemetry:
    tracing: true
    metrics: true
  ci_cd:
    container: true
    pipelines: [build, test, lint]
```

### 5.7 Setups

```markdown
---
file: ops/scripts/setup/SETUP_<ARCH>_V4.md
code: SETUP
name: <PascalCaseSetup>
version: v4.0
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: BLP_<ARCH>_V4
  mplan: MPLN_<ARCH>_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#setup_<arch>
chk: CHK_root.md#setup_<arch>
---
# Setup <ARCH>
1) **Repo local**: clonar, crear `.env`, levantar contenedor.
2) **Pipelines**: ejecutar build/test/lint.
3) **Seeds/fixtures**: cargar datos mínimos.
4) **QA arquitectura**: correr import‑linter, mypy, pytest, ruff.
```

### 5.8 ADR principal

```markdown
---
file: core/doc/adr/ADR_<id>_<ARCH>_V4.md
code: ADR
name: <PascalCaseADR>
version: v4.0
date: <YYYY-MM-DD>
owner: <Owner>
status: proposed
xrf:
  blueprint: BLP_<ARCH>_V4
  mplan: MPLN_<ARCH>_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#adr_<arch>
chk: CHK_root.md#adr_<arch>
---
# ADR: Decisión Arquitectónica Inicial
<contexto>
<decisión>
<consecuencias>
<kpis>
```

---

## 6) Controles y crossref (compliance V4)

- **Regla de Máxima Jerarquía**: cada archivo con *front‑matter*, ruta exacta V4, **WF** y **OutputTemplate**.
- Triggers mínimos: **TRG\_CONSOLIDATE\_TL**, **TRG\_AUDIT\_TL**.
- Registrar **CHG/CHK/LESSONS** en commits relevantes.

---

## OutputTemplate (obligatorio)

# OutputTemplate (obligatorio)

output\_example: status: OK id\_asset: wf\_arch\_create\_v4 generated\_by: ai created\_at: 2025-08-12T00:00:00-03:00 params: - source\_mtx: core/data/mtx/MTX\_Arch\_Patterns\_V4.md - deliverables: [blueprint, masterplan, roadmap, ruleset, checklist, configs, setups, adr] result: - package\_root: \<repo\_root> - files: - core/doc/blueprint/BLP\_*V4.md - core/doc/mplan/MPLN**V4.md - core/doc/roadmap/RDM**V4.md - core/rules/RULES**V4.md - core/checklists/CHK**V4.md - ops/configs/CFG**V4.yaml - ops/scripts/setup/SETUP**V4.md - core/doc/adr/ADR*\_\_V4.md log: - step1: ingest - step2: solid\_gate - step3: scoring - step4: adr - step5: package - step6: qa - step7: commit

```

## AingZ_Platf_Repo/legacy/glos_code_semantics_v_5_main.md
meta: {size:19288, lines:423, sha256:"d44e204014a0ab505ea880a55a8f3c47e1d9789458ce61ca56684ddd7085ab19", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
file: GLOS_Code_Semantics_V5_MAIN.md
code: GLOS
name: CodeSemanticsV5
version: v5.0.0-rc2
date: 2025-08-12
owner: AingZ_Platform · RwB
status: working
ruleset: GLOS_V5_RULES_MIN
platforms:
  - GPT5
  - CODEX
  - OPENAI_API
  - GH_BOT
  - VSC
  - PY
  - APP
triggers:
  - TRG_AUDIT_TL
  - TRG_CONSOLIDATE_TL
chg: CHG#glosario_v5
chk: CHK#glosario_v5
note: Glosario V5 genérico, sin rutas. Sub-secciones listas para feedback iterativo.
---

# Glosario CODE — V5 (MAIN)
> **Axioma**: cero ambigüedades. **Contrato antes que implementación.** Sin acoplar a rutas ni a docs externos.
> **Enfoque de uso**: ChatGPT (GPT‑5 Thinking), Codex, OpenAI API, GitHub Bot, VS Code, Python, Apps (Win/Web/Android).

---

## 0) Ruleset mínimo (cabecera obligatoria)
- **Naming**: `CODE` ≤ 5 chars, **SCREAMING_SNAKE**; `Name` **PascalCase**.
- **Unicidad**: `CODE` e `ID` únicos en todo el glosario.
- **Contrato (≤120 chars)**: qué garantiza y cómo se usa; no describe implementación.
- **Compatibilidad**: especificidades por entorno en `PlatformNotes` (`{GPT5:..., PY:...}`) cuando aplique.
- **Deprecación**: `Deprecated: true` + `ReplacedBy` + nota breve.
- **Crossref**: sólo **genérica** (alias/tema), nunca rutas.

<div align="right"><em>Sub-sección de feedback</em> — <strong>0.RULESET</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] ¿Aumentar límite de contrato a 160 chars?
- [ ] ¿Agregar campo `Aliases` por entrada?
- [ ] ¿Fijar vocabulario permitido para `Status`?

</details>
</div>

---

## 1) Principios de semántica profesional
1. **Separación de responsabilidades**: cada término cubre un concepto **único** y atómico.
2. **Contratos claros**: entradas con I/O, efectos y límites **observables**.
3. **Interoperabilidad**: GPT‑5, Codex, API, GH Bot, VSC y Python comparten la misma semántica.
4. **Evolución controlada**: deprecaciones con reemplazos y **mapeo V2→V5**.
5. **Trazabilidad mínima**: `ID, CODE, Name, Contract, PlatformNotes`.

<div align="right"><em>Sub-sección de feedback</em> — <strong>1.PRINCIPIOS</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] ¿Agregar principio de **idempotencia** explícito en WF y scripts?
- [ ] ¿Agregar principio de **observabilidad** (métricas y logs) a nivel global?

</details>
</div>

---

## A. RULESET (principios y control)
| ID | CODE | Name | Definición | Contract (≤120) | Deprecated | ReplacedBy | PlatformNotes |
|---|---|---|---|---|---|---|---|
| A01 | RULE | Ruleset | Marco normativo semántico universal | Rige naming/contratos/validación del glosario | false | — | — |
| A02 | LITW | LiteralWork | Barrido literal 100% sin inferencia | Garantiza trazado textual objetivable | false | — | — |
| A03 | CFG | Configuration | Parámetros operativos declarativos | Define límites/defaults por entorno | false | — | {PY: args; API: headers} |
| A04 | PKG | Package | Unidad empaquetada (release/dataset) | Exporta versión inmutable y firmada | false | — | — |
| A05 | BLN | Baseline | Snapshot de referencia de QA | Punto de comparación invariante | false | — | — |
| A06 | SPEC | SpecificExtension | Extensión contextual de reglas | Debe declarar alcance y overrides | false | — | — |

<div align="right"><em>Sub-sección de feedback</em> — <strong>A.RULESET</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] Confirmar eliminación de `RWB/RWS` (neutralización de marca) → usar `SPEC`.
- [ ] ¿Agregar `POL` (Policy) o se infiere bajo `RULE`?

</details>
</div>

---

## B. IDENTIFICADORES (estructura lógica)
| ID | CODE | Name | Definición | Contract (≤120) | Deprecated | ReplacedBy | PlatformNotes |
|---|---|---|---|---|---|---|---|
| B01 | CTX | Context | Ámbito lógico de trabajo | Aglutina assets/estado con límites claros | false | — | — |
| B02 | LYR | Layer | Capa arquitectónica | Agrupa sin alterar semántica | false | — | — |
| B03 | DOM | Domain | Área funcional | Limita vocabulario y alcance | false | — | — |
| B04 | USC | UserScope | Alcance de privacidad/rol | Gobierna visibilidad/acciones | false | — | — |
| B05 | MOD | Module | Subsistema/microservicio | Interfaz estable y versionada | false | — | {PY: package; API: tag} |
| B06 | CAT | Category | Macro‑grupo funcional | Agrupa TSK/TRG afines | false | — | — |
| B07 | TSK | Task | Acción atómica | I/O definidos + código retorno | false | — | {PY: exit code} |
| B08 | TRG | Trigger | Disparador de acciones | Declarativo; sin ruta; ejecutable por agente | false | — | {GPT5: tool call} |
| B09 | VER | Version | Etiqueta SemVer | Mayor.Minor.Patch | false | — | — |
| B10 | STA | State | Estado (WIP/FINAL/ARCH) | Transiciones controladas | false | — | — |
| B11 | ID | Identifier | UID global | Inmutable por asset | false | — | — |
| B12 | TYP | Type | Tipo/formato | MIME/extensión | false | — | — |
| B13 | BK | Backup | Snapshot crítico | Restauración garantizada | false | — | — |
| B14 | ACTV | ActiveAsset | Activo vivo/actual | Elegible para ingest/uso | false | — | — |
| B15 | PURG | Purgatory | Área de obsoletos | No productivo; retención | false | — | — |
| B16 | DIFF | DiffAsset | Deltas entre versiones | Ayuda auditoría/rollback | false | — | — |
| B17 | TRG_AUDIT_TL | TriggerAuditTL | Disparador auditoría TL | Debe registrar evidencia | false | — | — |
| B18 | TRG_CONSOLIDATE_TL | TriggerConsolidateTL | Disparador consolidación TL | Ejecuta consolidación semántica | false | — | — |
| B19 | TRG_AUDIT_EXT_OFF | TriggerAuditExternalOfficial | Auditoría de assets externos | Evidencia formal | false | — | — |
| B20 | TRG_AUDIT_bk_temp | TriggerAuditBackup | Auditoría de respaldos | Abarca retención/restore | false | — | — |
| B21 | TRG_TRAIN_EXT_COM | TriggerTrainExternalCommunity | Entrenamiento comunidad externa | Curación de datos | false | — | — |
| B22 | TRG_AUDIT_LEGACY | TriggerAuditLegacy | Auditoría de archivos legacy | Plan de migración | false | — | — |
| B23 | TRG_PURGE_AI | TriggerPurgeAI | Purga de datos IA | Cumplimiento y minimización | false | — | — |

<div align="right"><em>Sub-sección de feedback</em> — <strong>B.IDENTIFICADORES</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] ¿Mantener TRG_* en B o mover a D (control)?
- [ ] ¿Agregar `OWNR` (Ownership) como meta‑identificador?

</details>
</div>

---

## C. INSTRUCCIONES & PROCEDIMIENTOS
| ID | CODE | Name | Definición | Contract (≤120) | Deprecated | ReplacedBy | PlatformNotes |
|---|---|---|---|---|---|---|---|
| C01 | INS | InstructionSet | Conjunto de directrices | Orienta conducta; no ejecuta | false | — | — |
| C02 | ENV | EnvInstruction | Instrucción por entorno | Ajustes por plataforma | false | — | {API: rate limits} |
| C03 | HIE | HierInstruction | Instrucción por jerarquía | Rol/capa‑específica | false | — | — |
| C04 | PRC | ProcInstruction | Procedimiento paso a paso | Ejecutable por humano/agente | false | — | {GPT5: steps} |
| C05 | WK | WorkflowKnowledge | Loop de aprendizaje/logging | Persistencia post‑run | false | — | — |
| C06 | WKP | WorkflowKnowledgeProject | Variante WK para onboarding | Inicialización asistida | false | — | — |

<div align="right"><em>Sub-sección de feedback</em> — <strong>C.INSTRUCCIONES</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] ¿Agregar `SOP` como alias de `PRC`?
- [ ] ¿Separar `ENV` (dev/prod) con taxonomía fija?

</details>
</div>

---

## D. WORKFLOW — Planeamiento, Desarrollo y Control (reorganizado)
**Jerarquía por objetivos**
- **N1 • Planeamiento estratégico**: `MPLN`, `WF`, `WFM`
- **N2 • Planificación operativa**: `PLN`, `RMAP`
- **N3 • Control de ejecución y calidad**: `CHK`, `VALD`, `TST`, `AUDT`, `LSWP`, `RPT`
- **N4 • Estado y evidencia**: `CHKP`

```mermaid
flowchart TB
  subgraph N1[Planeamiento estratégico]
    MPLN((MPLN)) --- WF((WF)) --- WFM((WFM))
  end
  subgraph N2[Planificación operativa]
    PLN((PLN)) --- RMAP((RMAP))
  end
  subgraph N3[Control de ejecución y calidad]
    CHK((CHK)) --- VALD((VALD)) --- TST((TST))
    AUDT((AUDT)) --- RPT((RPT)) --- LSWP((LSWP))
  end
  subgraph N4[Estado y evidencia]
    CHKP((CHKP))
  end
  MPLN --> PLN
  PLN --> CHK
  PLN --> RMAP
  CHK --> CHKP
  CHK --> VALD
  VALD --> TST
  AUDT --> RPT
  LSWP --> RPT
```

### D.1 N1 — Planeamiento estratégico
| CODE | Name | Objetivo | Contract | Relaciones | Crossref genérico |
|---|---|---|---|---|---|
| MPLN | MasterPlan | Definir objetivos macro/criterios de éxito | Fuente de verdad de objetivos y supuestos | parent: CTX; children: PLN | OBJETIVOS |
| WF | Workflow | Orquestar procesos para cumplir objetivos | Secuencia determinista sin efectos colaterales | peers: WFM | PROCESOS |
| WFM | WorkflowMacro | Encadenar múltiples WF coherentes | Preserva invariantes globales | parent: WF | PROCESOS |

### D.2 N2 — Planificación operativa
| CODE | Name | Objetivo | Contract | Relaciones | Crossref genérico |
|---|---|---|---|---|---|
| PLN | Plan | Convertir objetivos en entregables/cronograma | Tareas con dueño/fecha/criterios | parent: MPLN; peers: RMAP | OBJETIVOS, PROCESOS |
| RMAP | Roadmap | Ordenar hitos y dependencias | Visible, medible, revisable | parent: PLN | OBJETIVOS |

### D.3 N3 — Control de ejecución y calidad
| CODE | Name | Objetivo | Contract | Relaciones | Crossref genérico |
|---|---|---|---|---|---|
| CHK | Checklist | Validar requisitos/aceptación | Criterios observables y trazables | parent: PLN | CALIDAD |
| VALD | Validation | Verificar conformidad técnica | Pass/Fail + métricas | derives: CHK | CALIDAD |
| TST | Test | Probar componentes o flujos | Exit codes claros y datos de prueba | derives: VALD | CALIDAD |
| AUDT | Audit | Auditar proceso/resultados | Evidencias y hallazgos accionables | on: WF/PLN/RMAP/CHK | TRANSPARENCIA |
| LSWP | LiteralSweep | Barrer evidencia textual 100% | Registro literal sin inferencia | on: WF/PLN/RMAP/CHK | TRANSPARENCIA |
| RPT | Report | Consolidar resultados/estado | Síntesis, KPIs y decisiones | from: VALD/TST/AUDT/LSWP | COMUNICACION |

### D.4 N4 — Estado y evidencia
| CODE | Name | Objetivo | Contract | Relaciones | Crossref genérico |
|---|---|---|---|---|---|
| CHKP | Checkpoint | Congelar estado en un punto de control | Snapshot reproducible y fechado | from: CHK | EVIDENCIAS |

<div align="right"><em>Sub-sección de feedback</em> — <strong>D.WORKFLOW</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] ¿Mover triggers TRG_* a esta sección como "mecanismos de control"?
- [ ] ¿Agregar `RETRO` (Retrospective) como práctica de cierre?

</details>
</div>

---

## E. LOGS & TRAZABILIDAD
| ID | CODE | Name | Definición | Contract (≤120) | Deprecated | ReplacedBy | PlatformNotes |
|---|---|---|---|---|---|---|---|
| E01 | LOG | Log | Registro cronológico de eventos | Append‑only | false | — | — |
| E02 | BIT | Logbook | Bitácora extendida | Contexto narrativo y decisiones | false | — | — |
| E03 | CHG | Changelog | Historial de cambios | Semántico; auditable | false | — | — |
| E04 | TRC | Trace | Trazabilidad cruzada | IDs enlazados | false | — | — |
| E05 | XRF | CrossRef | Referencias cruzadas | Usar alias, nunca rutas | false | — | — |
| E06 | ADT | AuditLog | Log de auditoría | Pruebas + resultados | false | — | — |
| E07 | VALOG | ValidationLog | Log de QA/tests | Artefactos reproducibles | false | — | — |

<div align="right"><em>Sub-sección de feedback</em> — <strong>E.LOGS</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] ¿Estandarizar formato de IDs de log (prefijo por sección)?
- [ ] ¿Agregar severidades y categorías mínimas?

</details>
</div>

---

## F. DOCUMENTACIÓN & ASSETS
| ID | CODE | Name | Definición | Contract (≤120) | Deprecated | ReplacedBy | PlatformNotes |
|---|---|---|---|---|---|---|---|
| F01 | DOC | Documentation | Documento técnico base | Legible por humano/agente | false | — | — |
| F02 | RDM | Readme | README principal/local | Onboarding + contrato | false | — | — |
| F03 | RDM_H | ReadmeHuman | README visual/humano | Puede incluir gráficos | false | — | — |
| F04 | RDM_AI | ReadmeAI | Prompt set IA | Ingesta/validación por agente | false | — | {GPT5: system} |
| F05 | TXT | TextDoc | Documento textual | Plano, sin metadatos extra | false | — | — |
| F06 | IMG | ImageDoc | Imagen/diagrama | Fuente o export | false | — | — |
| F07 | VID | VideoDoc | Video demo | No fuente de verdad | false | — | — |
| F08 | AUD | AudioDoc | Nota de voz/audio | Transcripción opcional | false | — | — |
| F09 | LIB | LibraryRef | Referencia externa | Citable | false | — | — |
| F10 | PAP | Paper | Artículo científico | Citable | false | — | — |
| F11 | OWN | OwnDoc | Documento interno | Controlado | false | — | — |
| F12 | DRAFT | DraftDoc | Documento en edición | No estable | false | — | — |
| F13 | FINAL | FinalDoc | Documento aprobado | Congelado | false | — | — |
| F14 | NB | Notebook | Jupyter/Colab | Ejecutable | false | — | {PY: ipynb} |
| F15 | MD | Markdown | Documento MD base | Render estándar | false | — | — |
| F16 | TMP | Template | Plantilla reusable | Campos obligatorios | false | — | — |

<div align="right"><em>Sub-sección de feedback</em> — <strong>F.DOCS</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] ¿Agregar `SCHEMA` para contratos JSON/YAML?
- [ ] ¿Separar `RDM` por niveles (root/local)?

</details>
</div>

---

## G. SCRIPTS
| ID | CODE | Name | Definición | Contract (≤120) | Deprecated | ReplacedBy | PlatformNotes |
|---|---|---|---|---|---|---|---|
| G01 | SCR | Script | Ejecutable puntual | Side‑effects controlados | false | — | {PY: .py; SH: .sh} |
| G02 | PIPE | PipelineScript | ETL/flujo de datos | Idempotente | false | — | — |
| G03 | TSTSC | TestScript | Conjunto de tests | Retorna exit codes | false | — | — |
| G04 | INTG | IntegrationScript | Integración/CI/CD | Sin credenciales acopladas | false | — | — |
| G05 | PRCSC | ProcessingScript | Procesamiento batch | Entradas explícitas | false | — | — |
| G06 | CMD | CommandScript | Script de comandos | Portabilidad básica | false | — | — |

<div align="right"><em>Sub-sección de feedback</em> — <strong>G.SCRIPTS</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] ¿Agregar `SVC` para servicios/daemons largos?
- [ ] ¿Unificar resultado estándar: `{status:int, log:list}`?

</details>
</div>

---

## H. MATRICES
| ID | CODE | Name | Definición | Contract (≤120) | Deprecated | ReplacedBy | PlatformNotes |
|---|---|---|---|---|---|---|---|
| H01 | MTR | Matrix | DataFrame/tabla | Export CSV/JSON | false | — | — |
| H02 | MAPX | MappingMatrix | Tabla de correspondencias | Uni/bidireccional | false | — | — |
| H03 | REL | RelationMatrix | Correlaciones | Metodología explícita | false | — | — |
| H04 | INM | InputMatrix | Datos de entrada | Validación previa | false | — | — |
| H05 | OUTM | OutputMatrix | Resultados | Firma y checksum | false | — | — |
| H06 | VALM | ValidationMatrix | QA matrix | Reglas y métricas | false | — | — |
| H07 | VRS | VersusMatrix | Comparativa "versus" | Criterios trazables | false | — | — |
| H08 | TBL | TableSimple | Tabla simple | Sin fórmulas | false | — | — |

<div align="right"><em>Sub-sección de feedback</em> — <strong>H.MATRICES</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] ¿Agregar `DSGN` para matrices de diseño de pruebas?

</details>
</div>

---

## I. CONOCIMIENTO VIVO
| ID | CODE | Name | Definición | Contract (≤120) | Deprecated | ReplacedBy | PlatformNotes |
|---|---|---|---|---|---|---|---|
| I01 | KNS | Knowledge | Núcleo de saberes | Fuente de verdad | false | — | — |
| I02 | MEM | ContextMemory | Memoria contextual | Persistente por proyecto | false | — | — |
| I03 | NOTE | Note | Nota breve | No normativa | false | — | — |
| I04 | DTL | DetailNote | Nota técnica detallada | Puede referenciar ensayos | false | — | — |
| I05 | GLOS | Glossary | Este documento | Autoridad semántica | false | — | — |
| I06 | PREF | Preferences | Config personales | No obligatoria | false | — | — |
| I07 | LEARN | Learning | Registro de aprendizajes | Mejora continua | false | — | — |
| I08 | INSI | Insight | Hallazgo estratégico | Accionable | false | — | — |
| I09 | BRAIN | Brainstorm | Lluvia de ideas | No vinculante | false | — | — |
| I10 | IDEA | IdeaDraft | Idea en borrador | Evolutiva | false | — | — |
| I11 | KNX | KnowledgeExtract | Extracto aplicado | Usable por agentes | false | — | — |

<div align="right"><em>Sub-sección de feedback</em> — <strong>I.KNOWLEDGE</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] ¿Separar `INSI` por severidad/prioridad?
- [ ] ¿Agregar `DEC` (Decision) como artefacto explícito?

</details>
</div>

---

## J. Plataformas (compatibilidad mínima)
| Plataforma | Clave | Notas semánticas |
|---|---|---|
| ChatGPT · GPT‑5 Thinking | GPT5 | Tools/func‑calling; tags por CODE/TRG |
| ChatGPT · Codex | CODEX | Generación/edición de código |
| OpenAI API | OPENAI_API | `responses.tools`, `json_schema` |
| GitHub Bot | GH_BOT | Comentarios/labels con CODE/TRG |
| VS Code | VSC | Naming de archivos y módulos |
| Python | PY | Paquetes, exit codes, typing |
| Apps (Win/Web/Android) | APP | UI labels y acciones derivadas |

<div align="right"><em>Sub-sección de feedback</em> — <strong>J.PLATAFORMAS</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] ¿Agregar `CLI` como plataforma explícita?

</details>
</div>

---

## K. Mapeo V2→V5 (resumen)
> El mapeo V2→V5 completo se edita de forma interactiva en el canvas: **GLOS_V5_Mapping_Interactive.jsx** (export JSON/CSV).

**Cambios clave ya integrados en V5**
- `RWB` → **deprecado** y **mapeado** en `RULE` (neutralización de marca).
- `RWS` → **SPEC** (extensiones específicas neutrales).
- `WF_M` → **WFM** (sin separador).
- `WK_P` → **WKP** (sin separador).
- `J02 PIPE` (estructura) → **PLINE** (*PipelineStruct*) para evitar colisión con `G02 PIPE` (script).

<div align="right"><em>Sub-sección de feedback</em> — <strong>K.MAPEO</strong>

<details><summary>Propuestas / dudas</summary>

- [ ] ¿Agregar columna `Rationale` obligatoria en export?
- [ ] ¿Bloquear códigos con números (p.ej. `A1`)?

</details>
</div>

---

## Panel de feedback global (resumen)
- **Estado**: working (RC‑2).
- **Backlog de ajustes**: ver sub‑secciones de cada capítulo.
- **Fuente de propuestas**: UI interactiva de mapeo (canvas) + comentarios en este documento.

---

## OutputTemplate (obligatorio)
```yaml
output_example:
  status: WORKING
  id_asset: glosario_code_v5_main
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
  params:
    - scope: generic
    - coupling: none (no routes)
  result:
    - sections: [A,B,C,D,E,F,G,H,I,J,K]
    - feedback_slots: enabled
  log:
    - step1: scaffold_v5_main
    - step2: reorganize_D
    - step3: integrate_v2_items
```

```

## AingZ_Platf_Repo/legacy/ops_packages_pkg_aingz_v_0.md
meta: {size:15487, lines:580, sha256:"89cb128f685f5cb43e3752efd8fe55a28fdd25a3d3e1a7f72ad708654da972ae", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: ops/packages/PKG\_AINGZ\_V0.md code: PKGAZ name: AingzArchPackage version: v0.1 date: 2025-08-12 owner: AingZ\_Platform · RwB status: active xrf: blueprint: RwB\_Blueprint\_V4 mplan: RwB\_MasterPlan\_V4 glossary: CODE\_Glossary\_v2 dictionary: CODE\_Triggers\_v2 triggers: [TRG\_CONSOLIDATE\_TL, TRG\_AUDIT\_TL] chg: CHG\_main.md#pkg\_aingz\_v0 chk: CHK\_root.md#pkg\_aingz\_v0

# Paquete de Arquitectura — **AINGZ** (V0 / MVP)

> **Manifiesto** del paquete de salida ajustado a **nueva arquitectura** (naming sin "V4"). Incluye **árbol mínimo propuesto**, rutas provisoriamente definitivas y **10 archivos** (8 artefactos núcleo + README del paquete + plantilla de READMEs).

---

## 0) Árbol de directorios mínimo (propuesto)

```text
AingZ_Platform/
├─ core/
│  ├─ doc/
│  │  ├─ blueprint/BLP_AINGZ_V0.md
│  │  ├─ mplan/MPLN_AINGZ_V0.md
│  │  ├─ roadmap/RDM_AINGZ_V0.md
│  │  └─ adr/ADR_0001_AINGZ_V0.md
│  ├─ rules/RULES_AINGZ_V0.md
│  ├─ checklists/CHK_AINGZ_V0.md
│  └─ kns/
│     ├─ glossary/
│     └─ triggers/
├─ ops/
│  ├─ configs/CFG_AINGZ_V0.yaml
│  ├─ scripts/
│  │  └─ setup/SETUP_AINGZ_V0.md
│  ├─ packages/PKG_AINGZ_V0.md
│  └─ templates/
│     └─ README_TEMPLATE_V0.md
├─ src/
│  └─ aingz/
│     ├─ domain/
│     ├─ adapters/
│     ├─ orchestration/
│     ├─ memory/
│     ├─ eval/
│     └─ telemetry/
├─ storage/
└─ data/
```

> Este árbol es **mínimo viable** y alinea módulos del **Blueprint** con código (`src/aingz/...`).

---

## 1) `core/doc/blueprint/BLP_AINGZ_V0.md`

```markdown
---
file: core/doc/blueprint/BLP_AINGZ_V0.md
code: BLP
name: AingzBlueprint
version: v0.1
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: MPLN_AINGZ_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#blp_aingz_v0
chk: CHK_root.md#blp_aingz_v0
---
# Blueprint — AINGZ (V0)

## Patrones & topología
- **Base**: Monolito Modular + **Hexagonal** (Puertos/Adaptadores)
- **Flujo**: **Orquestación en grafo** en proceso (nodos = agente/herramientas)
- **Memoria**: Híbrida (episódica, semántica, factual) con **purga por objetivos**
- **Asíncrono**: **EDA ligero** (cola in‑process → Redis opcional)

## Boundaries (módulos)
- **domain/** núcleo de casos de uso (sin dependencias a infra)  
- **adapters/** I/O (DB, FS, queue, HTTP, APIs)
- **orchestration/** grafo de tareas; reintentos; timeouts
- **memory/** episodic/semantic/factual + políticas de retención
- **eval/** evaluación de prompts/outputs; métricas IA
- **telemetry/** tracing, logs, métricas

## Dependencias externas
- BD: **SQLite** (dev) → **PostgreSQL** (escala)
- Cache: **in‑memory** (TTL)
- Mensajería: **in‑process** (→ Redis opcional)
- Storage: **FS local** + adaptador **nube/drive**
- LLM/IA: proveedor vía **Puerto** (OpenAI como primer adaptador)

## Contratos
- **Puertos** (Protocol/ABC) para LLM, Tools, Storage, Queue, DB
- **Eventos** versionados; **Outbox**; **DLQ**; **idempotencia**
- **Prompt/Tool registry** con trazabilidad (alta para IA)

## Riesgos & mitigaciones
- Erosión modular → **tests de arquitectura**; reglas de dependencia
- Pérdida de eventos → **Outbox** + **DLQ** + reintentos idempotentes
- Lock‑in proveedor → **DIP** por puertos; adaptadores neutrales

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: blp_aingz_v0
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
  params:
    - patterns: [monolith_modular, hexagonal, eda_lite, graph_orchestration, hybrid_memory]
  result:
    - modules: [domain, adapters, orchestration, memory, eval, telemetry]
```

---

## 2) `core/doc/mplan/MPLN_AINGZ_V0.md`

```markdown
---
file: core/doc/mplan/MPLN_AINGZ_V0.md
code: MPLN
name: AingzMasterPlan
version: v0.1
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V0
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#mplan_aingz_v0
chk: CHK_root.md#mplan_aingz_v0
---
# Master Plan — AINGZ (V0)

## Fases
- **F0 Baseline (0–1 mes)**: Modular+Hex; memoria híbrida mínima; tool/prompt registry; telemetría básica; .env
- **F1 Eventos (1–3 meses)**: EDA ligero; outbox; DLQ; idempotencia; proyecciones de lectura
- **F2 Escala (3–6 meses)**: Redis opcional; migración selectiva a PostgreSQL; endurecer contratos
- **F3 API (6–9 meses)**: exponer endpoints (FastAPI opcional); autenticación básica; rate‑limit
- **F4 Serverless táctico (9–12 meses)**: funciones para picos/batch

## KPIs (objetivos)
- Interacción p95 **<3s**; Batch sin restricción dura  
- **MTTR < 1h**  
- **DLQ = 0** sostenido  
- **Cobertura tests 50%→70%** (F1)  
- **Costo** acorde a necesidad (flexible)

## Riesgos & planes
- Complejidad creciente → limitar deps; plantillas; revisiones ADR
- Debt de observabilidad → OTel básico en F0; ampliar en F1

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: mplan_aingz_v0
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
```

---

## 3) `core/doc/roadmap/RDM_AINGZ_V0.md`

```markdown
---
file: core/doc/roadmap/RDM_AINGZ_V0.md
code: RDM
name: AingzRoadmap
version: v0.1
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V0
  mplan: MPLN_AINGZ_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#rdm_aingz_v0
chk: CHK_root.md#rdm_aingz_v0
---
# Roadmap — AINGZ (V0)

## Hitos (MVP → F1)
- **M0** Repo & entorno; linters/type‑checks/tests base
- **M1** Memoria híbrida v1 (episódica/semántica/factual) + políticas por objetivo
- **M2** Prompt/Tool registry + trazabilidad IA
- **M3** Orquestación en grafo + reintentos/timeout
- **M4** EDA ligero + outbox/DLQ/idempotencia
- **M5** Observabilidad (tracing/logs/métricas)
- **M6** Redis opcional + vistas lectura
- **M7** PostgreSQL (si aplica)

## Criterios de done
- Código y docs cumplen **rutas V0** + front‑matter  
- **SOLID‑Gate** verde  
- KPIs mínimos de Fase alcanzados

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: rdm_aingz_v0
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
```

---

## 4) `core/rules/RULES_AINGZ_V0.md`

```markdown
---
file: core/rules/RULES_AINGZ_V0.md
code: RULES
name: AingzRuleSet
version: v0.1
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V0
  mplan: MPLN_AINGZ_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_AUDIT_TL]
chg: CHG_main.md#rules_aingz_v0
chk: CHK_root.md#rules_aingz_v0
---
# RuleSet — AINGZ (V0)

## SOLID (obligatorio)
- **DIP**: dominio no importa adaptadores/SDKs; todo I/O tras **Puertos**
- **ISP**: interfaces pequeñas (<5 métodos); una por caso de uso
- **SRP**: módulos con una sola razón de cambio
- **OCP**: extensión por registro/config (sin tocar core)
- **LSP**: tests de sustitución para cada adaptador

## Eventos
- Contratos versionados; **Outbox**; **DLQ**; idempotencia; **sagas** si aplica

## Persistencia & memoria
- ACID para estado fuerte; **TTL** en cache  
- Capas de memoria (episódica/semántica/factual) con **purga por objetivos**

## Naming & rutas
- **CODE ≤ 5**; nombre en PascalCase en `name:`; rutas según **árbol V0**

## Calidad & gates
- import‑linter (arquitectura), mypy (tipos), pytest (tests), ruff/pylint (lint)
- cobertura mínima 50% (F0) → 70% (F1)

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: rules_aingz_v0
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
```

---

## 5) `core/checklists/CHK_AINGZ_V0.md`

```markdown
---
file: core/checklists/CHK_AINGZ_V0.md
code: CHK
name: AingzChecklist
version: v0.1
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V0
  mplan: MPLN_AINGZ_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_AUDIT_TL]
chg: CHG_main.md#chk_aingz_v0
chk: CHK_root.md#chk_aingz_v0
---
# Checklist — AINGZ (V0)

- [ ] DIP: dominio no importa adaptadores/SDK
- [ ] ISP: interfaces pequeñas (<5 métodos)
- [ ] SRP: una responsabilidad por módulo
- [ ] OCP: registro/plug‑in para herramientas/LLM
- [ ] LSP: tests de sustitución para cada adaptador
- [ ] Eventos: outbox + DLQ + idempotencia
- [ ] Memoria: políticas por objetivo implementadas
- [ ] Observabilidad: tracing/logs/métricas activos
- [ ] KPIs: p95<3s, MTTR<1h, DLQ=0
- [ ] Docs: front‑matter + rutas V0 + OutputTemplate

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: chk_aingz_v0
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
```

---

## 6) `ops/configs/CFG_AINGZ_V0.yaml`

```yaml
---
file: ops/configs/CFG_AINGZ_V0.yaml
code: CFG
name: AingzConfig
version: v0.1
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V0
  mplan: MPLN_AINGZ_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#cfg_aingz_v0
chk: CHK_root.md#cfg_aingz_v0
---
arch:
  alias: AINGZ
  patterns: [monolith_modular, hexagonal, eda_lite, graph_orchestration, hybrid_memory]
modules:
  - id: domain
    purpose: casos_de_uso
  - id: adapters
    purpose: io_externo
  - id: orchestration
    purpose: grafo_tareas
  - id: memory
    purpose: memorias_y_politicas
  - id: eval
    purpose: evaluaciones_ia
  - id: telemetry
    purpose: observabilidad
ports:
  db:
    driver: sqlite
    dsn: sqlite:///./data/aingz.db
    prod:
      driver: postgres
      dsn: postgresql://<user>:<pass>@<host>/<db>
  cache:
    driver: in_memory
    ttl_seconds: 300
  queue:
    driver: in_process   # redis opcional
    redis_url: "redis://localhost:6379/0"
  storage:
    local_root: ./storage
    cloud_driver: none   # drive/cloud opcional via adaptador
llm:
  provider: openai
  model: <set_by_env>
  timeout_s: 60
  retry:
    max: 3
    backoff_s: 2
memory:
  episodic:
    enabled: true
    retention: by_objective
  semantic:
    enabled: true
    index_path: ./data/embeddings
  factual:
    enabled: true
    store: ./data/facts
telemetry:
  tracing: basic
  metrics: basic
  logs: info
secrets:
  source: env
  required:
    - OPENAI_API_KEY
    - GITHUB_TOKEN
ci_cd:
  containers: true
  pipelines: [build, test, lint]
```

---

## 7) `ops/scripts/setup/SETUP_AINGZ_V0.md`

```markdown
---
file: ops/scripts/setup/SETUP_AINGZ_V0.md
code: SETUP
name: AingzSetup
version: v0.1
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V0
  mplan: MPLN_AINGZ_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#setup_aingz_v0
chk: CHK_root.md#setup_aingz_v0
---
# Setup — AINGZ (V0)

1) **Entorno**
   - Python 3.12 (o 3.11)
   - `python -m venv .venv && source .venv/bin/activate`
   - `pip install -U pip wheel`
2) **Dependencias base**
   - `pip install ruff mypy pytest import-linter`
3) **Configuración**
   - Copiar `ops/configs/CFG_AINGZ_V0.yaml` y ajustar DSNs
   - Crear `.env` con `OPENAI_API_KEY` y `GITHUB_TOKEN`
4) **Calidad**
   - `ruff .` · `mypy .` · `pytest`
   - `import-linter -c arch_contracts.toml` (cuando lo agreguemos)
5) **Contenedores (opcional)**
   - Dockerfile simple + `docker compose up` para servicio base
```

---

## 8) `core/doc/adr/ADR_0001_AINGZ_V0.md`

```markdown
---
file: core/doc/adr/ADR_0001_AINGZ_V0.md
code: ADR
name: ADR0001_AingzArchitecture
version: v0.1
date: 2025-08-12
owner: AingZ_Platform · RwB
status: proposed
xrf:
  blueprint: BLP_AINGZ_V0
  mplan: MPLN_AINGZ_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#adr_0001_aingz_v0
chk: CHK_root.md#adr_0001_aingz_v0
---
# ADR-0001: Arquitectura AINGZ (V0)

## Contexto
Proyecto personal (1 dev) con agentes/IA, foco en **evolutividad**, **escalabilidad** y **confiabilidad**; memoria no‑loss y trazabilidad IA altas; volumen bajo; integraciones OpenAI/GitHub; despliegue local/contenedor con opción nube.

## Decisión
Adoptar **Monolito Modular + Hexagonal**, **orquestación en grafo** en proceso, **memoria híbrida**, **EDA ligero** con outbox/DLQ/idempotencia, **prompt/tool registry**, y telemetría abierta. SQLite (dev) → Postgres (escala); cache in‑memory; queue in‑process → Redis opcional.

## Consecuencias
- + Simplicidad, costo bajo, testabilidad (SOLID)
- − Escalado por proceso; disciplina en límites requerida

## KPIs
- p95 <3s; MTTR <1h; DLQ=0; cobertura 50%→70% (F1)

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: adr_0001_aingz_v0
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
```

---

## 9) `ops/packages/README_PKG_AINGZ_V0.md`

```markdown
---
file: ops/packages/README_PKG_AINGZ_V0.md
code: RDPKG
name: AingzPackageReadme
version: v0.1
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V0
  mplan: MPLN_AINGZ_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#readme_pkg_aingz_v0
chk: CHK_root.md#readme_pkg_aingz_v0
---
# README — Paquete AINGZ (V0)

## Propósito
Este paquete define la **arquitectura base** de AINGZ (V0), lista para versionar y evolucionar.

## Contenido
- Blueprint, Master Plan, Roadmap, RuleSet, Checklist
- Configuración (YAML), Setup, ADR inicial
- Plantilla de README para replicar en nuevos módulos

## Árbol
(Ver sección 0 del manifiesto o el repositorio).

## Cómo usar
1) Completar `CFG_AINGZ_V0.yaml`.
2) Seguir `SETUP_AINGZ_V0.md`.
3) Validar **Checklist** y **RuleSet** (SOLID‑Gate).
4) Registrar cambios en **ADR**.

## Crossref
Mantener XRF con Blueprint/MasterPlan/Glosario/Diccionario.
```

---

## 10) `ops/templates/README_TEMPLATE_V0.md`

```markdown
---
file: ops/templates/README_TEMPLATE_V0.md
code: RDTPL
name: ReadmeTemplate
version: v0.1
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#readme_template_v0
chk: CHK_root.md#readme_template_v0
---
# <Title> — README (V0)

## Propósito
<descripción breve>

## Estructura
```

<árbol de carpetas/archivos>

```

## Configuración
- Requisitos/variables/env

## Uso
- Pasos clave / comandos

## Calidad
- Lints/tests/tipos obligatorios

## Crossref
- Blueprint/MasterPlan/Glosario/Diccionario/ADR
```

---

## OutputTemplate (obligatorio)

output\_example: status: OK id\_asset: pkg\_aingz\_v0 generated\_by: ai created\_at: 2025-08-12T00:00:00-03:00 params: - alias: AINGZ - files: - core/doc/blueprint/BLP\_AINGZ\_V0.md - core/doc/mplan/MPLN\_AINGZ\_V0.md - core/doc/roadmap/RDM\_AINGZ\_V0.md - core/rules/RULES\_AINGZ\_V0.md - core/checklists/CHK\_AINGZ\_V0.md - ops/configs/CFG\_AINGZ\_V0.yaml - ops/scripts/setup/SETUP\_AINGZ\_V0.md - core/doc/adr/ADR\_0001\_AINGZ\_V0.md - ops/packages/README\_PKG\_AINGZ\_V0.md - ops/templates/README\_TEMPLATE\_V0.md result: - status: package\_ready log: - step1: generate - step2: assemble - step3: validate\_meta

```

## AingZ_Platf_Repo/legacy/ops_packages_pkg_aingz_v_4.md
meta: {size:12630, lines:476, sha256:"ffa97e30cf5578fc5806c5486bb0c9dcbf9ad2683a56e96d77f27d08dfc83215", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
file: ops/packages/PKG_AINGZ_V4.md
code: PKGAZ
name: AingzArchPackage
version: v4.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL, TRG_AUDIT_TL]
chg: CHG_main.md#pkg_aingz_v4
chk: CHK_root.md#pkg_aingz_v4
---

# Paquete de Arquitectura — **AINGZ** (MVP)

> **Este manifiesto agrupa los 8 archivos del paquete**. Cada sección contiene el **contenido completo** del archivo final (drop‑in‑ready) con **front‑matter** y, cuando aplica, **OutputTemplate**.

---

## 1) `core/doc/blueprint/BLP_AINGZ_V4.md`
```markdown
---
file: core/doc/blueprint/BLP_AINGZ_V4.md
code: BLP
name: AingzBlueprint
version: v4.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: MPLN_AINGZ_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#blp_aingz
chk: CHK_root.md#blp_aingz
---
# Blueprint — AINGZ

## Patrones & topología
- **Base**: Monolito Modular + **Hexagonal** (Puertos/Adaptadores)
- **Flujo**: **Orquestación en grafo** en proceso (nodos = agente/herramientas)
- **Memoria**: Híbrida (episódica, semántica, factual) con **purga por objetivos**
- **Asíncrono**: **EDA ligero** (cola in‑process → Redis opcional)

## Boundaries (módulos)
- **domain/** núcleo de casos de uso (sin dependencias a infra)  
- **adapters/** I/O (DB, FS, queue, HTTP, APIs proveedores)
- **orchestration/** grafo de tareas; reintentos; timeouts
- **memory/** episodic/semantic/factual + políticas de retención
- **eval/** evaluación de prompts/outputs; métricas IA
- **telemetry/** tracing, logs, métricas

## Dependencias externas
- BD: **SQLite** (dev) → **PostgreSQL** (escala)
- Cache: **in‑memory** (TTL)
- Mensajería: **in‑process** (→ Redis opcional)
- Storage: **FS local** + adaptador **nube/drive**
- LLM/IA: proveedor vía **Puerto** (OpenAI como primer adaptador)

## Contratos
- **Puertos** (Protocol/ABC) para LLM, Tools, Storage, Queue, DB
- **Eventos** con versión y semántica clara; **Outbox** e **idempotencia**
- **Prompt/Tool registry** con trazabilidad (alta para IA)

## Riesgos & mitigaciones
- Erosión modular → **tests de arquitectura**; reglas de dependencia
- Pérdida de eventos → **Outbox** + **DLQ** + reintentos idempotentes
- Lock‑in proveedor → **DIP** por puertos; adaptadores neutrales

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: blp_aingz_v4
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
  params:
    - patterns: [monolith_modular, hexagonal, eda_lite, graph_orchestration, hybrid_memory]
  result:
    - modules: [domain, adapters, orchestration, memory, eval, telemetry]
```

---

## 2) `core/doc/mplan/MPLN_AINGZ_V4.md`
```markdown
---
file: core/doc/mplan/MPLN_AINGZ_V4.md
code: MPLN
name: AingzMasterPlan
version: v4.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V4
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#mplan_aingz
chk: CHK_root.md#mplan_aingz
---
# Master Plan — AINGZ

## Fases
- **F0 Baseline (0–1 mes)**: Modular+Hex; memoria híbrida mínima; tool/prompt registry; telemetría básica; .env
- **F1 Eventos (1–3 meses)**: EDA ligero; outbox; DLQ; idempotencia; proyecciones de lectura
- **F2 Escala (3–6 meses)**: Redis opcional; migración selectiva a PostgreSQL; endurecer contratos
- **F3 API (6–9 meses)**: exponer endpoints (FastAPI opcional); autenticación básica; políticas de rate‑limit
- **F4 Serverless táctico (9–12 meses)**: funciones para picos/batch

## KPIs (objetivos)
- Interacción p95 **<3s**; Batch sin restricción dura  
- **MTTR < 1h**  
- **DLQ = 0** sostenido  
- **Cobertura tests 50%→70%** (F1)  
- **Costo** acorde a necesidad (flexible)

## Riesgos & planes
- Complejidad creciente → limitar deps; plantillas; revisiones ADR
- Debt de observabilidad → OTel básico en F0; ampliar en F1

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: mplan_aingz_v4
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
```

---

## 3) `core/doc/roadmap/RDM_AINGZ_V4.md`
```markdown
---
file: core/doc/roadmap/RDM_AINGZ_V4.md
code: RDM
name: AingzRoadmap
version: v4.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V4
  mplan: MPLN_AINGZ_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#rdm_aingz
chk: CHK_root.md#rdm_aingz
---
# Roadmap — AINGZ

## Hitos (MVP → F1)
- **M0** Repo & entorno; linters/type‑checks/tests base
- **M1** Memoria híbrida v1 (episódica/semántica/factual) + políticas por objetivo
- **M2** Prompt/Tool registry + trazabilidad IA
- **M3** Orquestación en grafo + reintentos/timeout
- **M4** EDA ligero + outbox/DLQ/idempotencia
- **M5** Observabilidad (tracing/logs/métricas)
- **M6** Redis opcional + vistas lectura
- **M7** PostgreSQL (si aplica)

## Criterios de done
- Código y docs cumplen **rutas V4** + front‑matter  
- **SOLID‑Gate** verde  
- KPIs mínimos de Fase alcanzados

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: rdm_aingz_v4
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
```

---

## 4) `core/rules/RULES_AINGZ_V4.md`
```markdown
---
file: core/rules/RULES_AINGZ_V4.md
code: RULES
name: AingzRuleSet
version: v4.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V4
  mplan: MPLN_AINGZ_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_AUDIT_TL]
chg: CHG_main.md#rules_aingz
chk: CHK_root.md#rules_aingz
---
# RuleSet — AINGZ

## SOLID (obligatorio)
- **DIP**: dominio no importa adaptadores/SDKs; todo I/O tras **Puertos**
- **ISP**: interfaces pequeñas (<5 métodos); una por caso de uso
- **SRP**: módulos con una sola razón de cambio
- **OCP**: extensión por registro/config (sin tocar core)
- **LSP**: tests de sustitución para cada adaptador

## Eventos
- Contratos versionados; **Outbox**; **DLQ**; idempotencia; **sagas** si aplica

## Persistencia & memoria
- ACID para estado fuerte; **TTL** en cache  
- Capas de memoria (episódica/semántica/factual) con **purga por objetivos**

## Naming & rutas
- **CODE ≤ 5** (SCREAMING_SNAKE para códigos); nombre en PascalCase en `name:`; rutas según **Blueprint V4**

## Calidad & gates
- import‑linter (arquitectura), mypy (tipos), pytest (tests), ruff/pylint (lint)
- cobertura mínima 50% (F0) → 70% (F1)

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: rules_aingz_v4
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
```

---

## 5) `core/checklists/CHK_AINGZ_V4.md`
```markdown
---
file: core/checklists/CHK_AINGZ_V4.md
code: CHK
name: AingzChecklist
version: v4.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V4
  mplan: MPLN_AINGZ_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_AUDIT_TL]
chg: CHG_main.md#chk_aingz
chk: CHK_root.md#chk_aingz
---
# Checklist — AINGZ

- [ ] DIP: dominio no importa adaptadores/SDK
- [ ] ISP: interfaces pequeñas (<5 métodos)
- [ ] SRP: una responsabilidad por módulo
- [ ] OCP: registro/plug‑in para herramientas/LLM
- [ ] LSP: tests de sustitución para cada adaptador
- [ ] Eventos: outbox + DLQ + idempotencia
- [ ] Memoria: políticas por objetivo implementadas
- [ ] Observabilidad: tracing/logs/métricas activos
- [ ] KPIs: p95<3s, MTTR<1h, DLQ=0
- [ ] Docs: front‑matter + rutas V4 + OutputTemplate

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: chk_aingz_v4
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
```

---

## 6) `ops/configs/CFG_AINGZ_V4.yaml`
```yaml
---
file: ops/configs/CFG_AINGZ_V4.yaml
code: CFG
name: AingzConfig
version: v4.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V4
  mplan: MPLN_AINGZ_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#cfg_aingz
chk: CHK_root.md#cfg_aingz
---
arch:
  alias: AINGZ
  patterns: [monolith_modular, hexagonal, eda_lite, graph_orchestration, hybrid_memory]
modules:
  - id: domain
    purpose: casos_de_uso
  - id: adapters
    purpose: io_externo
  - id: orchestration
    purpose: grafo_tareas
  - id: memory
    purpose: memorias_y_politicas
  - id: eval
    purpose: evaluaciones_ia
  - id: telemetry
    purpose: observabilidad
ports:
  db:
    driver: sqlite
    dsn: sqlite:///./data/aingz.db
    prod:
      driver: postgres
      dsn: postgresql://<user>:<pass>@<host>/<db>
  cache:
    driver: in_memory
    ttl_seconds: 300
  queue:
    driver: in_process   # redis opcional
    redis_url: "redis://localhost:6379/0"
  storage:
    local_root: ./storage
    cloud_driver: none   # drive/cloud opcional via adaptador
llm:
  provider: openai
  model: <set_by_env>
  timeout_s: 60
  retry:
    max: 3
    backoff_s: 2
memory:
  episodic:
    enabled: true
    retention: by_objective
  semantic:
    enabled: true
    index_path: ./data/embeddings
  factual:
    enabled: true
    store: ./data/facts
telemetry:
  tracing: basic
  metrics: basic
  logs: info
secrets:
  source: env
  required:
    - OPENAI_API_KEY
    - GITHUB_TOKEN
ci_cd:
  containers: true
  pipelines: [build, test, lint]
```

---

## 7) `ops/scripts/setup/SETUP_AINGZ_V4.md`
```markdown
---
file: ops/scripts/setup/SETUP_AINGZ_V4.md
code: SETUP
name: AingzSetup
version: v4.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: BLP_AINGZ_V4
  mplan: MPLN_AINGZ_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#setup_aingz
chk: CHK_root.md#setup_aingz
---
# Setup — AINGZ

1) **Entorno**
   - Python 3.12 (o 3.11)
   - `python -m venv .venv && source .venv/bin/activate`
   - `pip install -U pip wheel`
2) **Dependencias base**
   - `pip install ruff mypy pytest import-linter`
3) **Configuración**
   - Copiar `ops/configs/CFG_AINGZ_V4.yaml` y ajustar DSNs
   - Crear `.env` con `OPENAI_API_KEY` y `GITHUB_TOKEN`
4) **Calidad**
   - `ruff .` · `mypy .` · `pytest`
   - `import-linter -c arch_contracts.toml` (cuando lo agreguemos)
5) **Contenedores (opcional)**
   - Dockerfile simple + `docker compose up` para servicio base
```

---

## 8) `core/doc/adr/ADR_0001_AINGZ_V4.md`
```markdown
---
file: core/doc/adr/ADR_0001_AINGZ_V4.md
code: ADR
name: ADR0001_AingzArchitecture
version: v4.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: proposed
xrf:
  blueprint: BLP_AINGZ_V4
  mplan: MPLN_AINGZ_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#adr_0001_aingz
chk: CHK_root.md#adr_0001_aingz
---
# ADR-0001: Arquitectura AINGZ

## Contexto
Proyecto personal (1 dev) con agentes/IA, foco en **evolutividad**, **escalabilidad** y **confiabilidad**; memoria no‑loss y trazabilidad IA altas; volumen bajo; integraciones OpenAI/GitHub; despliegue local/contenedor con opción nube.

## Decisión
Adoptar **Monolito Modular + Hexagonal**, **orquestación en grafo** en proceso, **memoria híbrida**, **EDA ligero** con outbox/DLQ/idempotencia, **prompt/tool registry**, y telemetría abierta. SQLite (dev) → Postgres (escala); cache in‑memory; queue in‑process → Redis opcional.

## Consecuencias
- + Simplicidad, costo bajo, testabilidad (SOLID)
- − Escalado por proceso; disciplina en límites requerida

## KPIs
- p95 <3s; MTTR <1h; DLQ=0; cobertura 50%→70% (F1)

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: adr_0001_aingz_v4
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
```

---

## OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: pkg_aingz_v4
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
  params:
    - alias: AINGZ
    - files:
      - core/doc/blueprint/BLP_AINGZ_V4.md
      - core/doc/mplan/MPLN_AINGZ_V4.md
      - core/doc/roadmap/RDM_AINGZ_V4.md
      - core/rules/RULES_AINGZ_V4.md
      - core/checklists/CHK_AINGZ_V4.md
      - ops/configs/CFG_AINGZ_V4.yaml
      - ops/scripts/setup/SETUP_AINGZ_V4.md
      - core/doc/adr/ADR_0001_AINGZ_V4.md
  result:
    - status: package_ready
  log:
    - step1: generate
    - step2: assemble
    - step3: validate_meta

```

## AingZ_Platf_Repo/legacy/ops_packages_pkg_arch_creator_v_5_0.md
meta: {size:21065, lines:681, sha256:"b3ecd19f7ce5d035595ff0affea26177f84d2d08730b3850f0584b04a96dcff3", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: ops/packages/PKG\_ARCH\_CREATOR\_V5\_0.md code: PKGAC name: ArchCreatorPackage version: v5.0 date: 2025-08-12 owner: AingZ\_Platform · RwB status: active xrf: blueprint: RwB\_Blueprint\_V4 mplan: RwB\_MasterPlan\_V4 glossary: CODE\_Glossary\_v2 dictionary: CODE\_Triggers\_v2 triggers: [TRG\_CONSOLIDATE\_TL, TRG\_AUDIT\_TL] chg: CHG\_main.md#pkg\_arch\_creator\_v5\_0 chk: CHK\_root.md#pkg\_arch\_creator\_v5\_0

# Paquete **Arch\_Creator** — V5.0 (MTX + WF + Plantillas)

> **Objetivo**: que con **este paquete** puedas **diseñar, crear e implementar** una arquitectura nueva de forma repetible. Incluye: **MTX (V5.0)**, **WF de creación (V5.0)**, plantillas completas (blueprint/mplan/roadmap/rules/checklist/config/setup/adr), contratos de arquitectura y tests mínimos.

---

## 0) Árbol de directorios del paquete (propuesto)

```text
Arch_Creator/
├─ core/
│  ├─ data/mtx/MTX_ARCH_PATTERNS_V5_0.md
│  └─ wf/WF_ARCH_CREATE_V5_0.md
├─ ops/
│  ├─ packages/README_ARCH_CREATOR_V5_0.md
│  ├─ templates/
│  │  ├─ blueprint/BLP_<ARCH>_V0.md
│  │  ├─ mplan/MPLN_<ARCH>_V0.md
│  │  ├─ roadmap/RDM_<ARCH>_V0.md
│  │  ├─ rules/RULES_<ARCH>_V0.md
│  │  ├─ checklists/CHK_<ARCH>_V0.md
│  │  ├─ configs/CFG_<ARCH>_V0.yaml
│  │  ├─ setup/SETUP_<ARCH>_V0.md
│  │  ├─ adr/ADR_0001_<ARCH>_V0.md
│  │  ├─ readme/README_TEMPLATE_V0.md
│  │  ├─ contracts/arch_contracts.toml
│  │  └─ tests/test_substitution_contract.py
│  └─ scripts/
│     └─ GENERATOR_NOTES.md
└─ .
```

> **Nota**: Las plantillas usan **V0** para nuevos trabajos. Si es migración legacy, el **WF** te pide versionar a **V5\_0**.

---

## 1) `core/data/mtx/MTX_ARCH_PATTERNS_V5_0.md`

```markdown
---
file: core/data/mtx/MTX_ARCH_PATTERNS_V5_0.md
code: MTRAP
name: ArchPatternsAssessment
version: v5.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL, TRG_AUDIT_TL, TRG_AUDIT_LEGACY, TRG_PURGE_AI]
chg: CHG_main.md#arch_patterns_v5_0
chk: CHK_root.md#arch_patterns_v5_0
---
# Patrones de Arquitectura de Software — Snapshots + Matrices (V5.0)

> **Propósito**: documento **genérico**, sin naming de terceros, para evaluar y seleccionar patrones en **agentes/IA** con uno o pocos devs. Incorpora **SOLID‑first**, memoria del agente (episódica/semántica/factual), **orquestación en grafo**, EDA ligero y criterios V5.

## 1) Alcance y supuestos
- 1 dev (extensible a 2–3), repositorio único, contenedores, CI/CD repo‑based.
- Objetivos: **evolutividad**, **escalabilidad táctica**, **confiabilidad**, **trazabilidad IA**.
- No objetivos: tiempo real estricto, multi‑equipo, SLA 24x7 crítico.

### 1.1 Escenarios típicos (Agentes/IA)
- Agente único con **tool registry** y **puertos/adaptadores**.
- **Orquestación en grafo** (reintentos/timeout por nodo).
- **Memoria híbrida** con **purga por objetivos** (no por tiempo fijo).
- Trazabilidad de prompts/decisiones/evaluaciones (alta para IA, baja para humano general).

## 1.2 Principios SOLID (guía práctica)
- **SRP**: módulos con una razón de cambio; separar tooling del dominio.
- **OCP**: extensión por registro/config; evitar tocar el core.
- **LSP**: adaptadores deben pasar **tests de sustitución** comunes.
- **ISP**: **interfaces pequeñas** por caso de uso (<5 métodos).
- **DIP**: dominio depende de **abstracciones** (Puertos), no SDKs.

**Reglas ejecutables**: import‑linter (dependencias), mypy (contratos), pytest (sustitución), ruff/pylint (complejidad/estilo).

## 2) Snapshots de patrones (1‑pagers)
- **Monolito Modular** (base recomendada).
- **Hexagonal** (Puertos/Adaptadores) sobre el monolito.
- **Layered**, **Microservicios**, **EDA**, **CQRS**, **Event Sourcing**, **Serverless**.
- **Orquestación en Grafo**, **Agente con Tool Registry**, **Memoria Híbrida**.

> Cada snapshot: **Contexto → Fuerzas → Trade‑offs → Antipatrones → Indicadores** (idénticos a V4, revisados para V5).

## 3) Matrices comparativas (VRS)
- **Patrón × Criterios** (complejidad, escalabilidad, cohesión, acoplamiento, consistencia, latencia, despliegue, observabilidad, coste, fit equipo).
- **Requisitos × Adecuación** (para agentes/IA 1 dev), con escala 1–5.
- **Riesgos × Mitigaciones** (erosión modular, complejidad operativa, pérdida de eventos, lock‑in) con KPIs.
- **Stack de agentes × Integración** (grafo, tools, memoria, persistencia, mensajería, evaluación, observabilidad).
- **Matriz SOLID × Patrones** (ajustada a V5; Hexagonal sobresale en OCP/DIP/ISP).

## 4) Roadmap genérico (1 dev)
- **F0** Baseline: Monolito Modular + Hexagonal; memoria híbrida mínima; tool/prompt registry; telemetría básica.
- **F1** Eventos: EDA ligero (outbox/DLQ/idempotencia), proyecciones de lectura.
- **F2** Escala: Redis opcional; migración selectiva a Postgres; contratos endurecidos.
- **F3** API: FastAPI opcional; auth básica; rate‑limit.
- **F4** Serverless táctico: picos/batch.

## 5) WF — Selección y evaluación (APSEL)
**Pasos**: 0) **SOLID‑Gate** → 1) INGEST → 2) SCORING (VRS) → 3) RIESGOS → 4) DECISIÓN (ADR) → 5) KPIs → 6) CHECK (tests) → 7) CLOSE (CHG/LESSONS/Triggers).

## 6) KPIs mínimos
- p95 lat <3s; MTTR <1h; DLQ=0; cobertura 50%→70%; hit rate memoria; % decisiones explicadas; alucinaciones detectadas.

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: mtx_arch_patterns_v5_0
  generated_by: ai
  created_at: 2025-08-12T00:00:00-03:00
  params:
    - principles: [SOLID]
    - patterns: [monolith_modular, hexagonal, layered, microservices, eda, cqrs, event_sourcing, serverless, graph_orchestration, agent_tools_registry, hybrid_memory]
  result:
    - decision_matrix_path: core/data/mtx/MTX_ARCH_PATTERNS_V5_0.md
    - recommended_strategy: ModularMonolith+Hexagonal→EDA→CQRS(selectivo)
```

---

## 2) `core/wf/WF_ARCH_CREATE_V5_0.md`

````markdown
---
file: core/wf/WF_ARCH_CREATE_V5_0.md
code: WFARC
name: ArchCreateWorkflow
version: v5.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL, TRG_AUDIT_TL, TRG_AUDIT_LEGACY, TRG_PURGE_AI]
chg: CHG_main.md#wf_arch_create_v5_0
chk: CHK_root.md#wf_arch_create_v5_0
---
# WF_ARCH_CREATE_V5_0 — Crear Arquitectura Base (agentes/IA, 1 dev)

> **Propósito**: instanciar una arquitectura desde la **MTX V5.0** y el **ruleset** del paquete, generando **todos los artefactos** (blueprint/mplan/roadmap/rules/checklist/configs/setup/adr) con rutas correctas y metadatos.

## 1) Gates y entradas
- **VERSION‑GATE (0‑fail)**: ¿Trabajo nuevo o migración?
  - **Nuevo** → usar plantillas **V0** (naming `*_V0.*`).
  - **Migración** → usar sufijo **V5_0** (naming `*_V5_0.*`).
- **Inputs**: requisitos, prioridades/pesos, restricciones, **MTX V5.0**.

## 2) Flujo
```mermaid
flowchart TD
  A[Kickoff] --> B[VERSION-GATE]
  B --> C[Ingest requisitos]
  C --> D[SOLID-Gate]
  D --> E[Scoring MTX (VRS)]
  E --> F[ADR decisión]
  F --> G[Generar paquete artefactos]
  G --> H[Config & Setup]
  H --> I[QA (tests + checklist)]
  I --> J[Commit + Triggers]
````

## 3) Pasos

1. **Ingest**: completar plantilla de requisitos + pesos (defaults sugeridos: evolvability 0.28, reliability 0.20, performance 0.20, simplicity 0.12, cost 0.10, auditability 0.10).
2. **SOLID‑Gate**: DIP (dominio no importa infra), ISP (<5 métodos por puerto), SRP (módulos), OCP (extender por registro), LSP (tests de sustitución en adaptadores).
3. **Scoring**: aplicar matriz de la MTX (VRS) y seleccionar patrón/es.
4. **ADR**: registrar contexto, decisión, consecuencias, KPIs.
5. **Generación**: copiar plantillas desde `ops/templates` al destino del proyecto usando alias `<ARCH>` y versión (**V0** o **V5\_0**).
6. **Config & Setup**: rellenar `CFG_<ARCH>_<VER>.yaml` (puertos, storage, cola, secrets).
7. **QA**: ejecutar import‑linter, mypy, pytest (incluye test de sustitución), ruff/pylint.
8. **Commit**: registrar CHG/CHK/LESSONS; disparar triggers.

## 4) Salidas

- Paquete de 8 artefactos instanciado.
- ADR principal creado y aceptado.
- Checklist inicial en verde (o con gaps explícitos).

---

# OutputTemplate (obligatorio)

output\_example: status: OK id\_asset: wf\_arch\_create\_v5\_0 generated\_by: ai created\_at: 2025-08-12T00:00:00-03:00 params: - source\_mtx: core/data/mtx/MTX\_ARCH\_PATTERNS\_V5\_0.md - deliverables: [blueprint, masterplan, roadmap, ruleset, checklist, configs, setups, adr] result: - files\_template\_root: ops/templates - generated\_paths\_example: - core/doc/blueprint/BLP\_*V0.md - core/doc/mplan/MPLN**V0.md - core/doc/roadmap/RDM**V0.md - core/rules/RULES**V0.md - core/checklists/CHK**V0.md - ops/configs/CFG**V0.yaml - ops/scripts/setup/SETUP**V0.md - core/doc/adr/ADR\_0001*\_V0.md log: - step1: ingest - step2: solid\_gate - step3: scoring - step4: adr - step5: package - step6: qa - step7: commit

````

---

## 3) `ops/packages/README_ARCH_CREATOR_V5_0.md`
```markdown
---
file: ops/packages/README_ARCH_CREATOR_V5_0.md
code: RDACR
name: ArchCreatorReadme
version: v5.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#readme_arch_creator_v5_0
chk: CHK_root.md#readme_arch_creator_v5_0
---
# README — Arch_Creator (V5.0)

## Propósito
Paquete para **crear arquitecturas** de forma estandarizada. Incluye **MTX V5.0**, **WF V5.0** y **plantillas**.

## Uso rápido
1) Abrí `core/wf/WF_ARCH_CREATE_V5_0.md` y corré el **VERSION‑GATE** (¿nuevo **V0** o migración **V5_0**?).
2) Completá **INGEST** (requisitos) y **pesos**.
3) Pasá **SOLID‑Gate**. Si falla, corregí límites.
4) Hacé **Scoring** con la **MTX V5.0** y cerrá el **ADR**.
5) **Generá** los 8 artefactos copiando desde `ops/templates/` (ajustá `<ARCH>` y `<VER>`).
6) Completá `CFG_<ARCH>_<VER>.yaml` y `SETUP_<ARCH>_<VER>.md`.
7) Ejecutá QA (linters, tipos, tests, contratos) y registrá **CHG/CHK/LESSONS**.

## Árbol del paquete
(Ver sección 0 del manifiesto o el repositorio.)
````

---

## 4) Plantillas clave (listas para copiar)

### 4.1 `ops/templates/blueprint/BLP_<ARCH>_V0.md`

```markdown
---
file: core/doc/blueprint/BLP_<ARCH>_V0.md
code: BLP
name: <PascalCaseBlueprint>
version: v0.1
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: MPLN_<ARCH>_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#blp_<arch>_v0
chk: CHK_root.md#blp_<arch>_v0
---
# Blueprint <ARCH> (V0)
- **Patrones**: <Monolito Modular + Hexagonal + EDA ligero + Orquestación en Grafo + Memoria Híbrida>
- **Boundaries**: <módulos/contextos>
- **Dependencias externas**: <DB, cola, storage, API>
- **Contratos**: <puertos/interface + eventos>
- **Riesgos** & **mitigaciones**: <tabla>

---
# OutputTemplate (obligatorio)
output_example:
  status: DRAFT
  id_asset: blp_<arch>_v0
  generated_by: user
  created_at: <ISO8601>
```

### 4.2 `ops/templates/mplan/MPLN_<ARCH>_V0.md`

```markdown
---
file: core/doc/mplan/MPLN_<ARCH>_V0.md
code: MPLN
name: <PascalCaseMasterPlan>
version: v0.1
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: BLP_<ARCH>_V0
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#mplan_<arch>_v0
chk: CHK_root.md#mplan_<arch>_v0
---
# Master Plan <ARCH> (V0)
- Fases/KPIs/Riesgos

---
# OutputTemplate (obligatorio)
output_example:
  status: DRAFT
  id_asset: mplan_<arch>_v0
  generated_by: user
  created_at: <ISO8601>
```

### 4.3 `ops/templates/roadmap/RDM_<ARCH>_V0.md`

```markdown
---
file: core/doc/roadmap/RDM_<ARCH>_V0.md
code: RDM
name: <PascalCaseRoadmap>
version: v0.1
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: BLP_<ARCH>_V0
  mplan: MPLN_<ARCH>_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#rdm_<arch>_v0
chk: CHK_root.md#rdm_<arch>_v0
---
# Roadmap <ARCH> (V0)
- Hitos / Entregables / Done

---
# OutputTemplate (obligatorio)
output_example:
  status: DRAFT
  id_asset: rdm_<arch>_v0
  generated_by: user
  created_at: <ISO8601>
```

### 4.4 `ops/templates/rules/RULES_<ARCH>_V0.md`

```markdown
---
file: core/rules/RULES_<ARCH>_V0.md
code: RULES
name: <PascalCaseRuleset>
version: v0.1
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: BLP_<ARCH>_V0
  mplan: MPLN_<ARCH>_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_AUDIT_TL]
chg: CHG_main.md#rules_<arch>_v0
chk: CHK_root.md#rules_<arch>_v0
---
# RuleSet <ARCH> (V0)
- **SOLID** obligatorio; Puertos/Adaptadores; Eventos (Outbox/DLQ/idempotencia);
- Persistencia ACID; Cache TTL; Naming CODE≤5 y rutas V0.

---
# OutputTemplate (obligatorio)
output_example:
  status: DRAFT
  id_asset: rules_<arch>_v0
  generated_by: user
  created_at: <ISO8601>
```

### 4.5 `ops/templates/checklists/CHK_<ARCH>_V0.md`

```markdown
---
file: core/checklists/CHK_<ARCH>_V0.md
code: CHK
name: <PascalCaseChecklist>
version: v0.1
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: BLP_<ARCH>_V0
  mplan: MPLN_<ARCH>_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_AUDIT_TL]
chg: CHG_main.md#chk_<arch>_v0
chk: CHK_root.md#chk_<arch>_v0
---
# Checklist <ARCH> (V0)
- [ ] DIP/ISP/SRP/OCP/LSP
- [ ] Outbox/DLQ/Idempotencia
- [ ] Memoria por objetivos
- [ ] Telemetría básica
- [ ] KPIs definidos

---
# OutputTemplate (obligatorio)
output_example:
  status: DRAFT
  id_asset: chk_<arch>_v0
  generated_by: user
  created_at: <ISO8601>
```

### 4.6 `ops/templates/configs/CFG_<ARCH>_V0.yaml`

```yaml
---
file: ops/configs/CFG_<ARCH>_V0.yaml
code: CFG
name: <PascalCaseConfig>
version: v0.1
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: BLP_<ARCH>_V0
  mplan: MPLN_<ARCH>_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#cfg_<arch>_v0
chk: CHK_root.md#cfg_<arch>_v0
---
arch:
  alias: <ARCH>
  patterns: [monolith_modular, hexagonal, eda_lite, graph_orchestration, hybrid_memory]
modules:
  - id: domain
    purpose: casos_de_uso
  - id: adapters
    purpose: io_externo
  - id: orchestration
    purpose: grafo_tareas
  - id: memory
    purpose: memorias_y_politicas
  - id: eval
    purpose: evaluaciones_ia
  - id: telemetry
    purpose: observabilidad
ports:
  db:
    driver: sqlite
    dsn: sqlite:///./data/<arch>.db
    prod:
      driver: postgres
      dsn: postgresql://<user>:<pass>@<host>/<db>
  cache:
    driver: in_memory
    ttl_seconds: 300
  queue:
    driver: in_process
    redis_url: "redis://localhost:6379/0"
  storage:
    local_root: ./storage
    cloud_driver: none
llm:
  provider: openai
  model: <set_by_env>
  timeout_s: 60
  retry:
    max: 3
    backoff_s: 2
memory:
  episodic:
    enabled: true
    retention: by_objective
  semantic:
    enabled: true
    index_path: ./data/embeddings
  factual:
    enabled: true
    store: ./data/facts
telemetry:
  tracing: basic
  metrics: basic
  logs: info
secrets:
  source: env
  required: [OPENAI_API_KEY]
ci_cd:
  containers: true
  pipelines: [build, test, lint]
```

### 4.7 `ops/templates/setup/SETUP_<ARCH>_V0.md`

```markdown
---
file: ops/scripts/setup/SETUP_<ARCH>_V0.md
code: SETUP
name: <PascalCaseSetup>
version: v0.1
date: <YYYY-MM-DD>
owner: <Owner>
status: draft
xrf:
  blueprint: BLP_<ARCH>_V0
  mplan: MPLN_<ARCH>_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#setup_<arch>_v0
chk: CHK_root.md#setup_<arch>_v0
---
# Setup <ARCH> (V0)
1) Crear venv e instalar dependencias base (ruff/mypy/pytest/import-linter).
2) Copiar y ajustar `CFG_<ARCH>_V0.yaml` y `.env`.
3) Ejecutar QA: `ruff .`, `mypy .`, `pytest`, `import-linter -c arch_contracts.toml`.
```

### 4.8 `ops/templates/adr/ADR_0001_<ARCH>_V0.md`

```markdown
---
file: core/doc/adr/ADR_0001_<ARCH>_V0.md
code: ADR
name: ADR0001_<PascalCaseArch>
version: v0.1
date: <YYYY-MM-DD>
owner: <Owner>
status: proposed
xrf:
  blueprint: BLP_<ARCH>_V0
  mplan: MPLN_<ARCH>_V0
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#adr_0001_<arch>_v0
chk: CHK_root.md#adr_0001_<arch>_v0
---
# ADR-0001: Arquitectura <ARCH> (V0)

## Contexto
<resumen>

## Decisión
<patrones elegidos y justificación>

## Consecuencias
<trade-offs>

## KPIs
<p95/MTTR/DLQ/cobertura>

---
# OutputTemplate (obligatorio)
output_example:
  status: OK
  id_asset: adr_0001_<arch>_v0
  generated_by: user
  created_at: <ISO8601>
```

### 4.9 `ops/templates/readme/README_TEMPLATE_V0.md`

```markdown
---
file: ops/templates/README_TEMPLATE_V0.md
code: RDTPL
name: ReadmeTemplate
version: v0.1
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#readme_template_v0
chk: CHK_root.md#readme_template_v0
---
# <Title> — README (V0)

## Propósito
<descripción breve>

## Estructura
```

<árbol de carpetas/archivos>

```

## Configuración
- Requisitos/variables/env

## Uso
- Pasos clave / comandos

## Calidad
- Lints/tests/tipos obligatorios

## Crossref
- Blueprint/MasterPlan/Glosario/Diccionario/ADR
```

### 4.10 `ops/templates/contracts/arch_contracts.toml`

```toml
[linter]
contract = "layers"

[python]
source = "src/<arch>"

[rules.layered]
# Dominio no puede importar adaptadores/infra
layers = ["domain", "orchestration", "adapters"]
depend_on_lower = true
forbidden_dependencies = [
  "domain -> adapters",
]
```

### 4.11 `ops/templates/tests/test_substitution_contract.py`

```python
import importlib
import inspect
from typing import Protocol

class LLMPort(Protocol):
    def complete(self, prompt: str, **kw) -> str: ...

# Cada adaptador debe implementar LLMPort sin romper contrato

def test_llm_adapters_substitution():
    adapters = [
        "src.<arch>.adapters.openai_adapter",
        # agregar otros aquí
    ]
    for mod in adapters:
        m = importlib.import_module(mod)
        cls = getattr(m, "Adapter")
        assert issubclass(cls, object)
        sig = inspect.signature(getattr(cls(), "complete"))
        assert "prompt" in sig.parameters
```

### 4.12 `ops/scripts/GENERATOR_NOTES.md`

```markdown
---
file: ops/scripts/GENERATOR_NOTES.md
code: GENNO
name: GeneratorNotes
version: v5.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL]
chg: CHG_main.md#generator_notes_v5_0
chk: CHK_root.md#generator_notes_v5_0
---
# Notas para generadores (manual)
- Copiar plantillas desde `ops/templates` al repo del proyecto.
- Reemplazar `<ARCH>` y `<VER>` (V0 o V5_0) en rutas y metadatos.
- Completar ADR y CFG.
- Ejecutar QA y registrar CHG/CHK/LESSONS.
```

---

## OutputTemplate (obligatorio)

output\_example: status: OK id\_asset: pkg\_arch\_creator\_v5\_0 generated\_by: ai created\_at: 2025-08-12T00:00:00-03:00 params: - files: - core/data/mtx/MTX\_ARCH\_PATTERNS\_V5\_0.md - core/wf/WF\_ARCH\_CREATE\_V5\_0.md - ops/packages/README\_ARCH\_CREATOR\_V5\_0.md - ops/templates/blueprint/BLP\_*V0.md - ops/templates/mplan/MPLN**V0.md - ops/templates/roadmap/RDM**V0.md - ops/templates/rules/RULES**V0.md - ops/templates/checklists/CHK**V0.md - ops/templates/configs/CFG**V0.yaml - ops/templates/setup/SETUP**V0.md - ops/templates/adr/ADR\_0001*\_V0.md - ops/templates/readme/README\_TEMPLATE\_V0.md - ops/templates/contracts/arch\_contracts.toml - ops/templates/tests/test\_substitution\_contract.py - ops/scripts/GENERATOR\_NOTES.md result: - status: package\_ready log: - step1: generate - step2: assemble - step3: validate\_meta

```

## AingZ_Platf_Repo/legacy/ops_templates_prompts_prompt_arch_senior_v_5_0.md
meta: {size:5427, lines:127, sha256:"2fbf32c186d81235615106ff3a47c9c57d253e5dc0e828d31783b730747c0f5d", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: ops/templates/prompts/PROMPT\_ARCH\_SENIOR\_V5\_0.md code: PRMTA name: PromptArchSenior version: v5.0 date: 2025-08-12 owner: AingZ\_Platform · RwB status: active xrf: blueprint: RwB\_Blueprint\_V4 mplan: RwB\_MasterPlan\_V4 glossary: CODE\_Glossary\_v2 dictionary: CODE\_Triggers\_v2 triggers: [TRG\_CONSOLIDATE\_TL] chg: CHG\_main.md#prompt\_arch\_senior\_v5\_0 chk: CHK\_root.md#prompt\_arch\_senior\_v5\_0

# Prompt — Arquitecto/a de Plataformas Senior (Arch\_Creator · V5.0)

> **Usar este prompt como instrucciones del proyecto.** El objetivo es **diseñar, crear e implementar** una **nueva arquitectura** de forma repetible, trazable y lista para producción incremental (1 dev → 2–3). Se trabajará con archivos adjuntos y plantillas del paquete **Arch\_Creator V5.0**.

---

## 1) Rol y alcance

Actuás como **Arquitecto/a de Plataformas Senior**. Tu misión es **guiar, decidir y producir** artefactos **drop‑in‑ready** (con metadatos y OutputTemplate) para una arquitectura de **agentes/IA**.

- **Idioma/estilo**: Español técnico, **Markdown avanzado** (tablas, YAML, Mermaid). Sin ambigüedad.
- **Foco**: **Evolutividad > Escalabilidad > Confiabilidad**; costo bajo; simplicidad operativa.
- **Sin naming** de terceros; **provider‑agnostic** por **Puertos/Adaptadores** (Hexagonal).

## 2) Normativa, fuentes y árbol

- **MTX**: `core/data/mtx/MTX_ARCH_PATTERNS_V5_0.md`
- **WF**: `core/wf/WF_ARCH_CREATE_V5_0.md`
- **Plantillas**: `ops/templates/**` (blueprint, mplan, roadmap, rules, checklist, configs, setup, adr, readme, contracts, tests)
- **Árbol** raíz del paquete: ver `ops/packages/PKG_ARCH_CREATOR_V5_0.md` §0.

## 3) Reglas de Máxima Jerarquía (obligatorio)

Todo archivo que generes debe incluir:

1. **Front‑matter YAML** con `file, code(CODE≤5), name(PascalCase), version, date(ISO), owner, status, xrf, triggers, chg, chk`.
2. **Ruta exacta** dentro del árbol propuesto.
3. **WF específico** referenciado o embebido.
4. **OutputTemplate** al final, con ejemplo válido (YAML).

## 4) Principios técnicos (SOLID‑first)

- **DIP**: dominio no importa adaptadores/SDKs. Todo I/O tras **Puertos** (`Protocol/ABC`).
- **ISP**: **interfaces pequeñas** (<5 métodos) por caso de uso.
- **SRP**: una responsabilidad por módulo.
- **OCP**: extensión por **registro/config** (sin tocar el core).
- **LSP**: cada adaptador debe pasar **tests de sustitución** comunes.

## 5) Flujo operativo por iteración (PDCA)

- **VERSION‑GATE**: ¿Trabajo nuevo (**V0**) o migración (**V5\_0**)?
- **INGEST**: levantar requisitos y **pesos** (defaults sugeridos):

```yaml
weights:
  evolvability: 0.28
  reliability: 0.20
  performance: 0.20
  simplicity: 0.12
  cost: 0.10
  auditability: 0.10
```

- **SOLID‑Gate (0‑fail)**: validar DIP/ISP/SRP/OCP/LSP con reglas y tests.
- **SCORING (MTX)**: comparar **Alternativas** y justificar la **Recomendación**.
- **ADR**: crear/actualizar decisión (contexto, consecuencias, KPIs).
- **GENERAR PAQUETE**: instanciar 8 artefactos desde `ops/templates/` (ajustar `<ARCH>` y `<VER>`).
- **QA**: ejecutar import‑linter, mypy, pytest (sustitución), ruff/pylint; correr **Checklist**.
- **CLOSE**: registrar **CHG/CHK/LESSONS** y disparar triggers.

## 6) Manejo de **archivos adjuntos**

Al recibir archivos:

1. **Identificar** tipo (md/pdf/yaml/py/diagramas) y **ruta sugerida**.
2. **Resumir** puntos clave y **mapear** contra MTX/WF.
3. **Proponer** actualización de artefactos (Blueprint/ADR/Rules/Configs) y **aplicar**.
4. **Actualizar** CHG/CHK y añadir **LESSONS** si hubo desvíos/decisiones.

## 7) Entregables obligatorios por nueva arquitectura

- `core/doc/blueprint/BLP_<ARCH>_<VER>.md`
- `core/doc/mplan/MPLN_<ARCH>_<VER>.md`
- `core/doc/roadmap/RDM_<ARCH>_<VER>.md`
- `core/rules/RULES_<ARCH>_<VER>.md`
- `core/checklists/CHK_<ARCH>_<VER>.md`
- `ops/configs/CFG_<ARCH>_<VER>.yaml`
- `ops/scripts/setup/SETUP_<ARCH>_<VER>.md`
- `core/doc/adr/ADR_0001_<ARCH>_<VER>.md`

> **VER** = `V0` si es nuevo, `V5_0` si es migración. **ARCH** = alias (CODE≤5), p.ej., `AINGZ`.

## 8) Macros de operación (atajos)

- **/wf** → Scaffold de WF con metadatos + OutputTemplate.
- **/audit** → Barrido + tabla de compliance + gaps.
- **/migrate** → Plan de migración + nombres de destino + checks.
- **/readme** → README del bucket/artefacto con estructura y crossref.
- **/release** → Snapshot + checklist + release note.

## 9) Estándares de salida

- **Markdown** claro; tablas breves; mermaid solo cuando aporte.
- **No** duplicar contenido innecesario; **sí** enlazar rutas.
- Explicar **decisiones y trade‑offs**; proponer **alternativas** cuando haya incertidumbre.

## 10) Kickoff (plantilla)

Pegá y completá:

```yaml
kickoff:
  arch_alias: <ARCH>
  work_type: <V0|V5_0>
  objective: <1 frase>
  users: <devs y finales>
  horizon: <MVP|6-12m|>12m>
  constraints: [<...>]
  weights:
    evolvability: 0.28
    reliability: 0.20
    performance: 0.20
    simplicity: 0.12
    cost: 0.10
    auditability: 0.10
```

---

## OutputTemplate (obligatorio)

output\_example: status: OK id\_asset: prompt\_arch\_senior\_v5\_0 generated\_by: ai created\_at: 2025-08-12T00:00:00-03:00 params: - package: Arch\_Creator\_V5\_0 - sources: [core/data/mtx/MTX\_ARCH\_PATTERNS\_V5\_0.md, core/wf/WF\_ARCH\_CREATE\_V5\_0.md] result: - ready\_to\_use: true log: - step1: authoring - step2: validation

```

## AingZ_Platf_Repo/legacy/prompt_proyecto_centrado_en_conocimientos_y_aptitudes_version_base.md
meta: {size:7208, lines:153, sha256:"cabc48809134d9897198100a5fba4f926e6c5d49564945f7672a70ff06695ab5", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
# Prompt — Proyecto centrado en conocimientos y aptitudes (versión base)

> **Usá este prompt como instrucciones maestras de un proyecto** para diseñar y entregar arquitectura y artefactos de IA/agentes. Está enfocado en las **competencias y aptitudes** necesarias, sin referenciar documentos específicos.

---

## 1) Rol y alcance
Actuás como **Arquitecto/a de Plataformas Senior** especializado en soluciones de IA y agentes. Tu misión es **guiar, decidir y producir** artefactos **listos para integrar** (metadatos + plantilla de salida), priorizando:
- **Evolutividad > Escalabilidad > Confiabilidad**, con **bajo costo** y **simplicidad operativa**.
- **Agnosticismo de proveedor** mediante **Puertos/Adaptadores (Hexagonal)**.
- **Español técnico** y **Markdown avanzado** (tablas, YAML, y diagramas solo cuando aporten valor).

## 2) Competencias nucleares (conocimientos + aptitudes)
- **Arquitectura de software** con principios **SOLID** aplicados a agentes/IA.
  - DIP: I/O tras **Puertos** (protocolos/interfaces);
  - ISP: **interfaces pequeñas** (<5 métodos);
  - SRP: **una responsabilidad por módulo**;
  - OCP: extensión por **config/registro**, sin tocar el core;
  - LSP: **tests de sustitución** comunes para cada adaptador.
- **Evaluación técnica y toma de decisiones**: definir alternativas, **puntuar** con pesos (evolvability, reliability, performance, simplicity, cost, auditability) y **recomendar** con justificación.
- **Diseño de artefactos** de proyecto: **blueprint, plan maestro, roadmap, reglas, checklist, configuración YAML, guía de setup, ADR inicial**.
- **Gobierno de cambios y calidad**: versionado, **linting estático**, tipado, **tests**, checklist de salida y registro de **lecciones**.
- **Gestión de adjuntos**: identificación de tipos (md/pdf/yaml/py/diagramas), resumen de puntos clave y **mapeo** a requisitos y flujos; actualización trazable de artefactos.
- **Prácticas de plataforma de IA**: selección de modelos por objetivo/latencia/costo; **salidas estructuradas** (JSON/YAML); **herramientas** (búsqueda web, búsqueda en archivos, ejecución de código) cuando corresponda; control de **ventanas de contexto**.
- **Operación y producción**: separación ambiente **staging/prod**, límites de gasto, **observabilidad** (trazabilidad/evals), **optimización de latencia**, higiene de **API keys** y políticas de retención de datos.

## 3) Flujo operativo por iteración (PDCA)
- **VERSION‑GATE**: definir si es **V0** (nuevo) o **migración**.
- **INGEST**: levantar requisitos y **pesos por atributo** (valores por defecto sugeridos):
  ```yaml
  weights:
    evolvability: 0.28
    reliability: 0.20
    performance: 0.20
    simplicity: 0.12
    cost: 0.10
    auditability: 0.10
  ```
- **SOLID‑Gate (cero fallas)**: validar DIP/ISP/SRP/OCP/LSP con reglas + tests.
- **SCORING**: comparar **Alternativas** y justificar la **Recomendación** (matriz + narrativa de trade‑offs).
- **ADR**: crear/actualizar decisión (contexto, consecuencias, KPIs y fecha).
- **PAQUETE**: generar los 8 artefactos estándar del proyecto (ver §4).
- **QA**: ejecutar verificación estática y dinámica (imports/contratos, tipado, pruebas de sustitución, linters) + **Checklist**.
- **CLOSE**: registrar cambios, checks y **lessons learned**; activar **triggers** necesarios.

## 4) Entregables obligatorios
Entregá un **paquete mínimo** con:
1) **Blueprint** de arquitectura
2) **Plan maestro** de implementación
3) **Roadmap** por hitos
4) **Reglas/Normas** del proyecto
5) **Checklist** de control de salida
6) **Configuración** (YAML)
7) **Guía de Setup**
8) **ADR inicial** (Decisión 0001)

> Cada artefacto debe estar **listo para uso** y coherente entre sí.

## 5) Estándares de salida
- **Markdown claro**, tablas breves; diagramas **solo si agregan valor**.
- No duplicar texto: referenciar secciones del paquete cuando aplique.
- Explicar **decisiones y trade‑offs**; proponer **alternativas** si hay incertidumbre.
- **Fechas absolutas** en todo registro y plantilla.

## 6) Herramientas y ejecución (si están disponibles en el entorno)
- **Búsqueda en archivos** para anclar respuestas a adjuntos.
- **Búsqueda web** para validar información reciente.
- **Ejecución de código** para cálculos/verificaciones.
- **Salidas estructuradas** (JSON/YAML) cuando se solicite; controlar **token budget**.

## 7) Plantillas rápidas (copiar/pegar)

### 7.1 Kickoff
```yaml
kickoff:
  arch_alias: <ARCH>
  work_type: <V0|Migración>
  objective: <1 frase>
  users: <devs y finales>
  horizon: <MVP|6-12m|>12m>
  constraints: [<...>]
  weights:
    evolvability: 0.28
    reliability: 0.20
    performance: 0.20
    simplicity: 0.12
    cost: 0.10
    auditability: 0.10
```

### 7.2 Matriz de alternativas (ejemplo)
| Opción | Descripción breve | Evolv | Rel | Perf | Simp | Cost | Audit | Puntaje |
|-------:|-------------------|------:|----:|-----:|-----:|-----:|------:|--------:|
| A      | …                 | 0.28  |0.20 |0.20  |0.12  |0.10  |0.10   | **…**   |
| B      | …                 | …     | …   | …    | …    | …    | …     | **…**   |

### 7.3 ADR – Decisión 0001 (esqueleto)
```md
# ADR-0001: <Título>
- **Fecha**: <YYYY-MM-DD>
- **Estado**: Propuesta | Aprobada | Rechazada | Supersedida
- **Contexto**: <breve>
- **Decisión**: <qué y por qué>
- **Consecuencias**: <trade‑offs, riesgos, mitigaciones>
- **KPIs**: <medición de éxito>
```

### 7.4 Checklist de salida (extracto)
- [ ] Alineado a SOLID/Hexagonal
- [ ] Paquete de 8 artefactos consistente
- [ ] ADR creado/actualizado con fecha
- [ ] Tests de sustitución para adaptadores
- [ ] Tipado y linters sin errores
- [ ] Lecciones aprendidas registradas

## 8) Formato de respuesta esperado
Cada artefacto debe iniciar con un **front‑matter YAML** con: `file, code (≤5), name (PascalCase), version, date (ISO), owner, status, referencias internas, triggers, cambios, checks`. Al final de cada artefacto, incluir un **OutputTemplate** con **ejemplo válido** (YAML) y un breve **log** de pasos.

---

## 9) Ejemplos de interacción (few‑shot)
**Usuario**: "Necesito una arquitectura mínima para un agente de soporte con bajo costo y alta rapidez de respuesta."

**Asistente (resumen de salida)**:
1) Kickoff → prioridades: latencia y costo;
2) Alternativas (A: modelo pequeño + herramientas; B: modelo grande sin herramientas);
3) Scoring + Recomendación (A);
4) ADR‑0001 con trade‑offs;
5) Paquete de 8 artefactos generado con front‑matter;
6) Checklist de salida completado.

**Usuario**: "Adjunto un PDF con requisitos funcionales. ¿Qué actualizarías?"

**Asistente**: Identifico tipo y secciones clave, mapeo a requisitos, actualizo reglas y ADR, re‑ejecuto scoring si cambió algún peso, registro cambios y lessons.

---

## 10) OutputTemplate (general)
```yaml
output_example:
  status: OK
  generated_by: ai
  created_at: <YYYY-MM-DDThh:mm:ssZ>
  params:
    - work_type: <V0|Migración>
    - priorities: [evolvability, reliability, performance, simplicity, cost, auditability]
  result:
    - ready_to_use: true
  log:
    - step1: authoring
    - step2: validation
```

```

## AingZ_Platf_Repo/legacy/readme_template_v_5_1.md
meta: {size:11175, lines:337, sha256:"0f58770eee6dbcc2973164f5ee209ceae45cf43ff84141f781a8e29074e74055", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: ops/templates/readme/README\_TEMPLATE\_V5\_1.md code: RDM name: ReadmeTemplateV5 version: v5.1 date: 2025-08-14 owner: AingZ\_Platform · RwB status: draft xrf: blueprint: BLP\_* mplan: MPLN** roadmap: RDM** rules: - RULES** - ruleset/legacy/RULE\_NAMING\_METADATA\_CROSSREF\_V1.md checklist: CHK** adr: ADR\_0001** cfg: CFG**.yaml triggers: [TRG\_CONSOLIDATE\_TL, TRG\_QA\_GATES, TRG\_AUDIT\_LEGACY, TRG\_PURGE\_AI] chg: CHG\_main.md#readme** chk: CHK\_root.md#readme*\_

# &#x20;— README ()

> **Modo**: `<root|module|RDM_H|RDM_AI>` · **Arquitectura**: `<ARCH>`\
> Fuente de verdad para onboarding, contratos, auditorías y cross-refs vivos.

---

## 0) Panel rápido de edición (dinámico)

> ⚙️ Rellená estos campos y usalos como variables en el resto del doc.

- **ARCH (alias arquitectura)**: `<ARCH>`
- **VER (versión)**: `<VER>`
- **OWNER**: `<Owner|Team>`
- **FOLDER (ruta absoluta)**: `<ruta/absoluta/del/folder>`
- **ENTRYPOINT/COMANDO**: `<cmd principal>`

**Badges (opcionales)**

```
[![CI](<url_ci_badge>)](<url_ci_run>) [![Coverage](<url_cov_badge>)](<url_cov_report>) [![Style](<url_ruff_badge>)](<url_lint_report>)
```

---

## Índice

- [1) Propósito](#1-propósito)
- [2) Alcance & Supuestos](#2-alcance--supuestos)
- [3) Estructura](#3-estructura)
- [4) Configuración](#4-configuración)
- [5) Quick Start / Onboarding](#5-quick-start--onboarding)
- [6) Uso (operativo)](#6-uso-operativo)
- [7) Interfaces & Contratos](#7-interfaces--contratos)
- [8) Calidad & KPIs](#8-calidad--kpis)
- [9) Auditorías automáticas — listas dinámicas](#9-auditorías-automáticas--listas-dinámicas)
- [10) Funciones principales del módulo](#10-funciones-principales-del-módulo)
- [11) Observabilidad & Registro](#11-observabilidad--registro)
- [12) Seguridad & Datos](#12-seguridad--datos)
- [13) Versionado & Releases](#13-versionado--releases)
- [14) ADRs & Decisiones](#14-adrs--decisiones)
- [15) Crossref (links editables)](#15-crossref-links-editables)
- [16) Crossref ](#16-crossref-dinámico-instrucciones-de-pipeline)[**dinámico**](#16-crossref-dinámico-instrucciones-de-pipeline)[ (instrucciones de pipeline)](#16-crossref-dinámico-instrucciones-de-pipeline)
- [17) Compliance & Governance](#17-compliance--governance)
- [18) Integraciones & sistemas relacionados](#18-integraciones--sistemas-relacionados)
- [19) Flujos (mermaid opcional)](#19-flujos-mermaid-opcional)
- [20) Roadmap & TODO](#20-roadmap--todo)
- [21) Snapshot de assets & huellas](#21-snapshot-de-assets--huellas)
- [22) Triggers activos](#22-triggers-activos)
- [23) Changelog (local)](#23-changelog-local)
- [Bloque IA / ingestión automática](#bloque-ia--ingestión-automática)
- [OutputTemplate (obligatorio)](#outputtemplate-obligatorio)

---

## 1) Propósito

\<qué es este folder/módulo y por qué existe — 2/3 líneas de negocio y técnica>

## 2) Alcance & Supuestos

- Público objetivo: \<devs, ops, data, producto>
- Límites: \<qué incluye / qué no incluye>
- Premisas: <1 dev, contenedores, CI/CD repo-based, bajo costo, etc.>

## 3) Estructura

```text
<pegar árbol real del folder o generar con:>
# Linux/Mac:  tree -L 3 -I ".git|.venv|__pycache__" > structure.txt
# Windows:    dir /s /b > structure.txt
```

## 4) Configuración

- Variables: `.env` (claves mínimas) + `CFG_<ARCH>_<VER>.yaml` (puertos, storage, colas, secrets).
- Requisitos: Python <3.12/3.13>, ruff, mypy, pytest, import-linter.
- Setup rápido:
  1. Crear venv e instalar deps
  2. Completar `CFG_<ARCH>_<VER>.yaml` y `.env`
  3. Sanity: `python -m pip list` / `ruff --version`

## 5) Quick Start / Onboarding

```bash
# 1. Clonar repo raíz (con submódulos si aplica)
$ git clone --recurse-submodules <repo>
# 2. Navegar
$ cd <ruta>
# 3. Ejecutar scripts/pipelines clave
$ ls ops/scripts/
$ bash ops/scripts/<script>.sh
```

- **VS Code:** F1 → *Open Workspace* → `<workspace>.code-workspace`
- **Obsidian:** Abrir vault, filtrar backlinks a este folder.

## 6) Uso (operativo)

- Comandos frecuentes:
  - `ruff .` · `mypy .` · `pytest -q`
  - `import-linter -c arch_contracts.toml`
  - `<tu comando principal o script>`
- Ejemplo:
  ```bash
  uv run -m src.<arch>.<entry> --cfg ops/configs/CFG_<ARCH>_<VER>.yaml
  ```

## 7) Interfaces & Contratos

- **Puertos**: LLM, Tools, Repos/DB, Queue, Storage (Protocol/ABC).
- **Eventos**: versionados, idempotencia, outbox/DLQ, reintentos.
- **Dependencias externas**: BD, cache, mensajería, storage, IA vía adaptadores.

## 8) Calidad & KPIs

- **KPIs**: p95 < X s · p99 < Y s · MTTR < Z h · DLQ=0 · cobertura ≥ C%.
- **QA (obligatorio)**: lints, tipos, tests, contratos de arquitectura.
- **Definición de listo**: CI en verde + checklist del módulo sin gaps.

---

## 9) Auditorías automáticas — *listas dinámicas*

> Bloques reservados para herramientas que escriben resultados automáticamente.

### 9.1 Gate — **Version-Gate**

-

### 9.2 Gate — **SOLID-Gate** (contratos y acoplamientos)

-

### 9.3 Gate — **QA-Gate** (calidad)

-

### 9.4 Gate — **Perf/Cost-Gate** (presupuestos)

-

### 9.5 Gate — **Security/Data-Gate**

-

### 9.6 Resultados de auditorías (tabla autogenerable)

| Check       | Herramienta   | Resultado | Reporte | Fecha      |
| ----------- | ------------- | --------- | ------- | ---------- |
| Lint        | ruff          | TODO      |         | YYYY-MM-DD |
| Tipos       | mypy          | TODO      |         | YYYY-MM-DD |
| Tests       | pytest        | TODO      |         | YYYY-MM-DD |
| Arch        | import-linter | TODO      |         | YYYY-MM-DD |
| SAST        | bandit        | TODO      |         | YYYY-MM-DD |
| Licencias   | pip-licenses  | TODO      |         | YYYY-MM-DD |
| SBoM        | cyclonedx     | TODO      |         | YYYY-MM-DD |
| Secret scan | gitleaks      | TODO      |         | YYYY-MM-DD |
| Links       | lychee        | TODO      |         | YYYY-MM-DD |

> Los bloques `AUTO-*` pueden ser sobreescritos por pipelines. Mantener las marcas.

---

## 10) Funciones principales del módulo

> Describí las funciones/servicios clave y **proponé ediciones**. Dejá notas inline para que el asistente las procese.

| Función/Servicio | Descripción actual | Entradas   | Salidas     | Riesgos     | Owner |
| ---------------- | ------------------ | ---------- | ----------- | ----------- | ----- |
| `<fn_1>`         | `<qué hace>`       | `<inputs>` | `<outputs>` | `<riesgos>` | `<@>` |
| `<fn_2>`         | `<qué hace>`       | `<inputs>` | `<outputs>` | `<riesgos>` | `<@>` |

**Propuesta de edición (notas para el asistente)**

```notes-to-ai
# CONTEXTO
<qué mejorar, objetivo>

# CAMBIOS PROPUESTOS (bullets)
- [ ] <cambio 1>
- [ ] <cambio 2>

# IMPACTO / RIESGOS
<riesgos, mitigaciones>

# DECISIÓN
<pending|approved|rejected>
```

> También podés usar un bloque `diff` si preferís:

```diff
- descripción actual
+ descripción propuesta
```

---

## 11) Observabilidad & Registro

- Logs: niveles y formato (json/plain).
- Métricas: básicas del módulo (tps, errores, latencias).
- Tracing: propagación y correlación (trace/span/idempotency\_key).

## 12) Seguridad & Datos

- Manejo de secretos por `.env` / vault (no commitear).
- Política de datos: qué se guarda, retención, PII/SPI, borrado seguro.

## 13) Versionado & Releases

- SemVer interno; tags/branches; notas de versión.
- Migraciones (si aplica): path y reversión.

## 14) ADRs & Decisiones

- **Última ADR** relevante: `core/doc/adr/ADR_0001_<ARCH>_<VER>.md`
- Cambios locales:&#x20;
- Pendientes de decisión:&#x20;

## 15) Crossref (links editables)

> Editá los links en esta tabla. El campo `Val` es para confirmación manual o la salida de un verificador.

| Recurso     | Ruta/URL       | Val        | Notas |
| ----------- | -------------- | ---------- | ----- |
| Blueprint   | `<ruta o url>` | [ ] válido |       |
| Master Plan | `<ruta o url>` | [ ] válido |       |
| Roadmap     | `<ruta o url>` | [ ] válido |       |
| RuleSet     | `<ruta o url>` | [ ] válido |       |
| Checklist   | `<ruta o url>` | [ ] válido |       |
| Config      | `<ruta o url>` | [ ] válido |       |
| ADR-0001    | `<ruta o url>` | [ ] válido |       |

## 16) Crossref **dinámico** (instrucciones de pipeline)

> Para agentes IA/CI y humanos: procedimiento estándar de barrido y actualización de enlaces.

1. Barrido completo del repo (walk) y detección de rutas reales de **blueprint, master plan, prompt Codex, ruleset y ADR**.
2. Actualizar la **tabla Crossref** de este README y de todos los README afectados.
3. Registrar cambios en `ops/changelog.md` y `ops/lessons_learned.md`.
4. Revalidar con `lychee`/`md-check` y marcar `Val`.

## 17) Compliance & Governance

| Área       | Regla                       | Fuente         |
| ---------- | --------------------------- | -------------- |
| Naming     | `naming_universal`          | Blueprint §2.2 |
| Versionado | SemVer (`v<major>.<minor>`) | Blueprint §1.3 |
| Testing    | `ops/test/`                 | Master Plan §3 |
| Scripts    | `ops/scripts/`              | Blueprint §4   |

## 18) Integraciones & sistemas relacionados

- Sincronización con `data/dicts/` (glosarios, triggers, taxonomías).
- Interfaz con `wf/` (workflows, auditorías, migraciones).
- Pipelines `ops/` para QA y onboarding.

## 19) Flujos (mermaid opcional)

```mermaid
flowchart TD
  IN[Alta asset/trigger] --> SCR[Script ops/scripts]
  SCR --> PIPE[Pipeline ops/pipelines]
  PIPE --> TST[Test ops/test]
  TST --> LOG[Log ops/log]
  LOG --> OUT[Output/Update asset]
  OUT --> FIN[Registro en changelog y compliance]
```

## 20) Roadmap & TODO

-

## 21) Snapshot de assets & huellas

| Asset    | Ruta     | Hash/Commit | Tamaño | Fecha        |
| -------- | -------- | ----------- | ------ | ------------ |
| `<file>` | `<ruta>` | `<sha>`     | `<KB>` | `YYYY-MM-DD` |

## 22) Triggers activos

- `TRG_AUDIT_LEGACY` · `TRG_CONSOLIDATE_TL` · `TRG_PURGE_AI` · `TRG_QA_GATES`

## 23) Changelog (local)

- YYYY-MM-DD — init —  —&#x20;
- YYYY-MM-DD —  —  —&#x20;

---

## Bloque IA / ingestión automática

```yaml
bucket: <bucket>
version: <VER>
updated: <YYYY-MM-DD>
blueprint_ref: <ruta>
master_plan_ref: <ruta>
prompt_codex_ref: <ruta>
ruleset_ref:
  - <ruta>
  - <ruta>
triggers:
  - TRG_AUDIT_LEGACY
  - TRG_CONSOLIDATE_TL
  - TRG_PURGE_AI
note: "Validar crossref dinámico y realizar barrido 100% repo tras cada ciclo."
```

---

## OutputTemplate (obligatorio)

```yaml
output_example:
  status: OK
  generated_by: ai
  created_at: <YYYY-MM-DDThh:mm:ss-03:00>
  params:
    - arch: <ARCH>
    - ver: <VER>
    - mode: <root|module|RDM_H|RDM_AI>
    - folder: <ruta/absoluta/del/folder>
  result:
    - readme_ready: true
  log:
    - step1: authoring
    - step2: crossref_links
    - step3: qa_gates
```

```

