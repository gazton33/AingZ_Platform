---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/e1
part_index: 0
files_included: 9
size_bytes_sum: 5073
created_at: 2025-08-31T21:08:15.650300+00:00
integrity:
  sha256_concat: c43e27a5603a777a518115df199174b83ebb67bbb3cd666e59422279c005b139
---

## AingZ_Platf_Repo/.git/objects/e1/5e6579b32f0046e1fc7baae818e1a4d9815041
meta: {size:54, lines:0, sha256:"187cff20607dc88de75ce92e0da2c547bbb53c6bd52dafb6b11cda191da7bb60", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e1/6520950f4e098c2e18022e5c93d322aa073bcb
meta: {size:298, lines:0, sha256:"69772b2c47cbaf93b8d892861194a07306739c19a835d3eb327613742487323c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e1/6ea02c65c79dfc5d05d28427730a5640308f01
meta: {size:2178, lines:0, sha256:"9c8e8383956b48d0dd74f733f57247e350d65e01f92a3f81e819ead3d5e63b36", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e1/726b4eca19c8463151b626d2d7a617b85d6f78
meta: {size:213, lines:0, sha256:"23714e5262ec08a50a01961092ea4946c0fbaddf022df989d8d721bb9952b617", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e1/8a8665222de079ddaf710fba7fabfbc3ef9253
meta: {size:1037, lines:0, sha256:"318de94b3002ef33c171abd270dfdded291b0822cddebcef39f97c803ff8f9ac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e1/9c3a0ee3ea391fadaa338e6c8d019bd0464f65
meta: {size:200, lines:1, sha256:"bd3d10ed89f3700b27395a5681409d30734eb539e528ae73962e72dd8bc6763b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU024d040031QHÌÌK¯OLOÍ+/(Ò«ÌÍa¸«â¼cÙï3ÍbÕ?-ÿîZuª:)±85'3/5>9#59¬3:U:Î3a±²Lá3ÿE¥çÓy/~ªNÎO,MÉ,«[¼{£×Ìm·9ÄTuwtK.ØãùgÖ¨ºÔâb°"7)í¢«S^ô}eZ({«~õ~CËs2SK2óóÀ*Wüjæàþæü`ýÿ¥.O+òÛPV{
```

## AingZ_Platf_Repo/.git/objects/e1/9f780e45a913ec3202c35e3046e45d313cd386
meta: {size:484, lines:0, sha256:"6fb2044031466de2787f55e80785dba65c4c53c63cb935644381bba13cb731dc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e1/aaeabc821e41b0530bd87f3ffe9f9b648fcc0f
meta: {size:51, lines:0, sha256:"caf1c01a85fdcef5a4317af11491c107d281578221aa6a353e0b041ad383919c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e1/b9f78e1a8bde3fd192d404e40007e46d014fcf
meta: {size:558, lines:0, sha256:"3d35bd3cabf918dc42aa8d10293362f0ca5e43ac077c843148b3c3e560babd2d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

