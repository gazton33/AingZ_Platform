---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/e0
part_index: 0
files_included: 6
size_bytes_sum: 24567
created_at: 2025-08-31T21:08:15.650164+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/e0/17140ba2f4f9ae1fc1e287c8c71c23b43d2879
meta: {size:1383, lines:0, sha256:"6bc5f4665bd8a4096491fa3823501ceeaccc660862237a9c7defc8ece9670b2a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e0/1af25f6e2da85b86bc424b7e8491823a4c0941
meta: {size:375, lines:0, sha256:"3bb62e0266df4b0069105395cc746f1576137002d05a88f185a7e13802dcba25", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e0/316bb7d686cb6cd966257f23ef2fc484848359
meta: {size:19901, lines:0, sha256:"783400b47b726312719a555f07fbdc318811346bf1971e0ac0b73f27d3e2e7a6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e0/58aaf0c9a169d53ab3b3bc1e6ca4236a568cdf
meta: {size:890, lines:0, sha256:"f975f088e0a480c5d11a15daa410def8dd22e620ca7fc0f09d5970232279749f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e0/8c518bbe062577c94873ac01769682ec98267d
meta: {size:48, lines:0, sha256:"0a3748427aad97e0ab0393ebf3e63e8cbaa66614bdd812c64e265b7712075abf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e0/f7cc95846d1fa4c00f60e490abbc570894b64d
meta: {size:1970, lines:0, sha256:"f94923bf353a0284c5fe19e1cc1d98801faac7b8a355a8413ea95a82cbb544e7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

