---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/87
part_index: 0
files_included: 8
size_bytes_sum: 2970
created_at: 2025-08-31T21:08:15.626222+00:00
integrity:
  sha256_concat: 9e35795b0ee31604992c84de9c495be67eefce2e4bf0cb2f69cb5c1533945d2f
---

## AingZ_Platf_Repo/.git/objects/87/1231c2b03ad10f02ba341a8b942e43e75fd032
meta: {size:639, lines:2, sha256:"b467762b0f3f980a59db0c0bad70db49292fa5ff1a7db96a6b1c57cc84800f0c", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x]SËnÛ0ì9_±@.àÈHëC+«PÛ2d9EOMmd&ÉQç·zë5?Ö¥âm.zP»3»3£Ô;øôñúÝ9ÛEZ%ù,[Íé¶\/²é*I«»ÉÙÙù9\Ç°dªa^;¸Ð;)Zz´B»Ë³+(u£¡H§³e:fÎ¡wBqÙQtoµòWó-|.Q\«¨0A6Á]Zl²|5"ßtùfS¤_F0Ý·y1Ù´LëøÖ°ßGkD÷Þô¾ÄÎHæ1«³xïàßÙÝPýgÙ£±By¸DÑNÌA×©¿gk«;ã!ÑþÃ©p.µc¤ÞÓFGj	ÎVÃaØ­*l>§Õ0ÊJ¨öù·u¦Ç¡CÛ"³Á	¨Ëb^M·³¬¬ÊE¶Á=Dz(á¢b}#||ìd=|bñ`ÒûJ+Ú­£Î=ZÑhGj¯6ù"*ìÑ®ÓûbómM"Ï?Äp«õ£©9HÆ»°fp½ÖÆ÷¡`l,^qÝuÂ×7È{¹6G¿'GBíUÅtÕ9BauT|ü16Ç¤ÕèüàïdÓ»=áÇ+ôIÑ° 4MeeÐÒEyñô'È@ÅÅIId)9E3ÆS÷ó/õºÆ ÇªCOáòlÊ"e\±©¯äï@ä)ëAw
 ÷±â¯Q T`|`ÀY·£¿ªF ¢UXfpQÿgç%`ÈðmsîÓÊù©¥néd´"mâ{â()4G¸XÏé%yø5þE
```

## AingZ_Platf_Repo/.git/objects/87/1770fda3384e8ec5bcc9e83f9f565e69acaaa3
meta: {size:123, lines:0, sha256:"8d100dca79306255ec2e256b91a74dc6c56d10782c721a72fd6e33eda8a75138", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/87/49913d79764f734f74a032150a71e6ad308db3
meta: {size:180, lines:0, sha256:"e588c6e03a70529737e1c2e42b3476d7e2048816fdad4d0ee17446fe4b896a96", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/87/94dcbb45c7a357de3d9156fd0483634bfd04dc
meta: {size:615, lines:0, sha256:"5267afedad575345a7263f7789306308b9266e4f4da2757a335c2e978de21765", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/87/9e073fff43484c51c30b71d7545fca096b5992
meta: {size:53, lines:0, sha256:"2c311012a6dd32431c28fb5553bffd6bb7e18fa5fc606c23c03d0cdad2edeb3d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/87/a64ac0778d347e22eb048723804e74d18e8f25
meta: {size:288, lines:0, sha256:"7cc1eab462c7ffd9fa5447985ff167b25fbb459d59ee6c7790b3c424c8a9bf23", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/87/f7ce516e03edabde0162c1d109a65008201710
meta: {size:515, lines:0, sha256:"ea6a8a5bd31e94256e66a413322761f9b6ac17ff9ddc965b09cf06f5e4b91a49", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/87/ff50610e17feeed56a5c22e6f52fa8dfa070f0
meta: {size:557, lines:0, sha256:"792a33b9d7674ea3337957de7cec8cdd3825bc497ba76b1c491d579d5c25a059", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

