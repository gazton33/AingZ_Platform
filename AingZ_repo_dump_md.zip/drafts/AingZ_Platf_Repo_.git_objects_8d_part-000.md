---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/8d
part_index: 0
files_included: 10
size_bytes_sum: 5410
created_at: 2025-08-31T21:08:15.627165+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/8d/046661905e6b1c132d0ede358f974883756158
meta: {size:883, lines:0, sha256:"f7975d2559a2febc4df4dc3e2f8ede1afcbc2c7a423cf5b87147245674d1ed4e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8d/1c0b141df9f1d513d26d36667764a7eccb8cb9
meta: {size:631, lines:0, sha256:"86336e750287e3b302fc3168ff28569fd112417cec1b9672cceda6dc3a261f26", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8d/30bb225345cd81efef7ce071d0985b702b6b29
meta: {size:1024, lines:0, sha256:"706dfb2fea09211340a51ec7053359f85edd69bbf0d9b9efa0c5ad92011898fa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8d/3c7f0d4ea24868d6a668789b8e75997c58d432
meta: {size:129, lines:0, sha256:"720897d85f4fed38d3a79ddb0cb4326286330a81730f89d6a8fe9f0b6ba11c78", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8d/50a55a097191504c953d0ee199a88d35a245f1
meta: {size:502, lines:0, sha256:"c3ccda1730a10ba949d8f71ac4e18d83b2f5c9b3be5d7af44325df79f8ffe25d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8d/6a75a3cb3a4733086dd80a7fe22fd5b04b2770
meta: {size:82, lines:0, sha256:"e019ff4ab7f2466350587abbd76e4b5d6e43679f324da276e64ed5f822dd9914", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8d/7ea77310371e95997413ba3c194a33ee06588b
meta: {size:194, lines:0, sha256:"c094ca86587137e7e600d473b56f13abea8d07a326aeb78732af4917a6c67860", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8d/96cc8c5d3df776cc76a74c500b520d7725da59
meta: {size:382, lines:0, sha256:"a18a0f46deb324a790ec8725766b1aaba3d6fad9cac094d2b6a428c36dbe2929", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8d/dcd9978a7770be3cf2f7836c6a2b20e4b4dbd0
meta: {size:1527, lines:0, sha256:"0dc8e75e9232fe912dd3ae6e60609978dcb5c7a18fff13cb34e730f31d53e34e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8d/f6d158ec88873b6c92db769c724d45b8666aba
meta: {size:56, lines:0, sha256:"2666f9296477be59a63da17a3c3b74ea1ab7cd1433e02234a29af6ea53c11c56", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

