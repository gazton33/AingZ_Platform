---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/f0
part_index: 0
files_included: 7
size_bytes_sum: 5124
created_at: 2025-08-31T21:08:15.651761+00:00
integrity:
  sha256_concat: d0cb9432b95a2ac3f28dfd0336b44796669f7fadb737baa9ba89228a0dfb42e2
---

## AingZ_Platf_Repo/.git/objects/f0/25c905f0a62800717f7699cbbea5d5776403c7
meta: {size:642, lines:2, sha256:"79593aaa2bba43e54e62ca78d9d0b5d142e7c17ffd0d3d682de9062059589f0f", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xu]nÓ@yö*®Ô·¨qéHC(­D®AHQ4¾OÜi'3îxìÀØAÀKÈNX	gÜ!"ÿL|ï¹ç|wiÜö_½Ú¡yvs¼ )KïhfØR©hª+ÏRo[êdÒE¥íZÙàÈ«wd¸¡7ª!i¸ST³gZÇ/=mÈ:¿f£¿ã!¸Ò5dðc//tTÅrC®Z­léP×­Ju2¾9FíÎI·®½÷¡Âß¥¨!WèÇC©8L×e/b(nKßþb:ýON²Q$;;ô®¡öÚJ]³QM²Ò`pÌÞk(Ûä°½5®r¤­Í`ÑNKhÒ+-û½ªtâôÿ¸v>Ô7ø¸§ktir;íozÛÙeVÔZß>uÕ¦ïËPªS*£ó¯¹8Éf1ËÎÄ|}:óçï³ÉèíBG¹ø2ÉÄy>ùè$"M£g±3Õ­¯~i÷0îÔAÈK[{>À'KÅÞÓG{ElÃP¤ó §vÎÁÉ{þüø	ñirEdªÓwl/[ ÷ÐÿsocªA!s /¼PòªvÚ4Z)U.Y^ÝÁØÀßH·T¾Çjx+&ob¯S$ñHz©V#èæG2ÉÙ¥õ¿&05- ñµ ¨ìòe{Å.ãO°ÂáúW¾ï÷"3N 'w©¦FöÛÛ§¿Ç%Û+¬PîØÊ¸ôþHv
Ç äº~jÃ"^ö~8P»&nBï/Cm
```

## AingZ_Platf_Repo/.git/objects/f0/6149aec297ae27a375af9ef7699bdca9510cd9
meta: {size:342, lines:0, sha256:"c407b786bf48b14e4c59c19959139436ae7e12ca78df28aafa47e795f00731b4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f0/7bab7ca8f0a4e159a25e0043fb2f26f1137298
meta: {size:100, lines:0, sha256:"6d5a82e88ecdd6dad381b42f3be5bcf4098164da7ecbe3ad9dedd79bc0022c66", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f0/80934acbe7b7d2746a9a56973b9ac2fa93f82e
meta: {size:1463, lines:0, sha256:"29182e95c13c208ccf26be76a08bc55d13c74f96a991e59255bb36fb29f2196b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f0/899dc20fbad5bbc51309531260ac68a9c72513
meta: {size:854, lines:0, sha256:"36410aa1e4d2d424ad5f7c66e418922f14d81f508fef5a5904418fab1c775754", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f0/cfba5ae33d238901264a9cdb94863d56e0da20
meta: {size:1355, lines:0, sha256:"75954b07781155dcfe93b44a9b0ce40ce2e4907bffe21f2a458b14e6c58b5f6c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f0/e91388016ef32d42e1d1acffbbbd92ddc85399
meta: {size:368, lines:0, sha256:"dbae178751b116c29e9ff245473d47359999a141a7761918630f7aadc0d99661", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

