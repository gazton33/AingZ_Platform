---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/22
part_index: 0
files_included: 10
size_bytes_sum: 9368
created_at: 2025-08-31T21:08:15.569501+00:00
integrity:
  sha256_concat: 8105e21e569e5bf793756fb94f0a829a10c65060da5357bc674e628a18eb2c7c
---

## AingZ_Platf_Repo/.git/objects/22/2abb6dcfdc6210937db1890e778bf0721541e5
meta: {size:1758, lines:0, sha256:"5ca70edbc9c5c77c8d98a1ed5c0bfd0fff57e81e8cb999be1b8c9599c6431883", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/22/366f47f28dbfe0ffb33e0db8fdf303827babc4
meta: {size:383, lines:3, sha256:"76ec3971969b541ed11fd61a03263f0789b9b3861411b9db118659c784dfecbe", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xmQ;nÛ@MÍS &BA!l¨v\8JF.ÇËvwýPVª"×p#è&9IfÊj¿ó¾½n¶Ûw+Ø?íï>ß?<ÞïçnßmºÍ¶»^ûþüüw#KN,XAï'eà,ñüàÈ¢9LðñªiÚ¶mÕ
*T»Ù¶Ýõ?$ô=Kãp¦¦[:þÏ¿xL<#äà(ñðää¨ÿð Ìª)*Þ0#ãu#[KQw}
Ñ£9I¯¤ä©Ô_2Ù¸÷Í'È%p°Wkö&¼<?_Ô³â²ªÊkQBè^Ñß>F3ò\KHâxÀAReùÙSD`?9òò"'KÍ@)Ç¢EtT¡¼ÀTt`Ô1-Áó«§¥«fRØÜªµoûMRwd5®(@Ï#UV@^íh¾µ-RRÉºb4h¶¨ÌÕ~­z½ýNÓ5
```

## AingZ_Platf_Repo/.git/objects/22/4bac8620ff967380146a41ae104d8c480d91aa
meta: {size:1167, lines:0, sha256:"1fd0c8fb048d307411beede59c94c4d32e2eb89766164df884a3e75fb6b95569", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/22/797af30f029fcd417bf2503d780fe854fd01bf
meta: {size:649, lines:0, sha256:"a48da3ba258d5b776c9f7660090cc5e9c185102814baf263d1118a24db017b37", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/22/871d448b157aa85717865ddfe9610792706c29
meta: {size:940, lines:0, sha256:"473df1e2a4bfa8b7c94491f2db3dbb1f87ef19b1964581d94662a5c7ca799cef", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/22/8914d5dee26a0dcac3f073b863b3faa9195ae1
meta: {size:292, lines:2, sha256:"1cff264decf1858ae496c8d60705529651c8c1b2ad859560fbc11e3e3306b98b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU01³d040031Q(*OO,M)ÏML.Ê/ÈIÌÏÍL/JLÎÌÏ/7ÏÉ/IRFF¦æF¦z¹)g×oØ£,gØêzäd·Ïûåý_S0,JMLÉM/Ï/ÊNËÉ//ÆfµøÍ»Ö7æºj)îÍ¼QÃ 	ñé%ñEå@Wb3lÂÖÐüõwîòäDÛx8ÃpX°aKúEëÿ\ôº8ßò«ÆAé[Wâ1°*¾ (?+5¹$¾$5À`Ãv»ÚRtTÞ]_È¿«~õïÃï'#ZZ\Ìü¢ÌÄøò4læôìV
v=Ûøþ}ÍÂ3¢´³5#pµ¼
```

## AingZ_Platf_Repo/.git/objects/22/8cca6e0da18daca86c60d5a535abccf2cd03f3
meta: {size:1362, lines:0, sha256:"a22a419440505de8126344a864d968f77debe7a50c41cca6679490bbccbd7bab", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/22/a9d70173b02cbf8b87c23bd97c3ea3dbe52f02
meta: {size:992, lines:0, sha256:"602fa808b4ba9334b7163f9c724f18115098064206604f749ee46c6496a8cab0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/22/d2246e6f326996493ec864d5de3ff698778441
meta: {size:1679, lines:0, sha256:"2e12ec0a25afb5fa078e67de1cace90e518cd3bd8dc2170b7833133f5b05e190", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/22/d7c67bd6b1ea03991f67eceddb32dfc32c6e47
meta: {size:146, lines:0, sha256:"8159c44a49807f776674ae304e4f7ca48d0853aeec1b402d18014c382d7b6ff1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

