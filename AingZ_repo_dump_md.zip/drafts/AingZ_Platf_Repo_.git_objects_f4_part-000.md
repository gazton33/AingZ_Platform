---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/f4
part_index: 0
files_included: 12
size_bytes_sum: 7967
created_at: 2025-08-31T21:08:15.652194+00:00
integrity:
  sha256_concat: 47a3b6491eacd4f1adbbb0ebfa11d06c7a8b1df2857d8c92c2bd0bb60a5d9584
---

## AingZ_Platf_Repo/.git/objects/f4/0c74ff8c61259b5daa4edda14f60f55b443311
meta: {size:231, lines:0, sha256:"3ab91940553cf296bba181f04a560af1a0fe1cceaad4747de659f52cbbee2aa1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f4/221c4b99678284c770d04ced3e6e859c91dc1b
meta: {size:1322, lines:0, sha256:"46c5d9e0652502bf865b58194bcd2d18d1e17041e37e630d8a44ea3bca7e3af8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f4/22f5a054770a1aac8838a8c8a9868bf838992d
meta: {size:619, lines:0, sha256:"5b8064c0737cbc20dceae74878d17cef1bb2577a1640ddfc26da1b05a1851f6b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f4/43231c79f1f98aa16df9676b7c67aa3ad497de
meta: {size:3230, lines:0, sha256:"d459bb7da01f69f8495ea10649a4089cc00d4ed6127a826658db1a32345e51bd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f4/69cdcd50be8ba78d75972d89162928a389ce98
meta: {size:859, lines:0, sha256:"10fe0d322156a6cf2841bf1a260358e319e8cc16ba030d35c3d2292376e5d356", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f4/8203b723388e624d0c1bb524b33bfa41078a8c
meta: {size:57, lines:0, sha256:"96fa8e0ecf3c2e43ef1f43b4c11b440171cdd143d349b07de3d28887a613f09f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f4/943bfdce3edf5a378599205705ed4459e31874
meta: {size:218, lines:0, sha256:"7052a672fc2330c58ee2925e6f7be92ca8abc0ff99622c8104bc7e4cfb7a64c4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f4/a39794c12761fb3d3e991f6108855fe0202e7a
meta: {size:576, lines:0, sha256:"58e508092f486827f2692d8914e2687f2808fe6746281ca87e92b4c7fc39ab6d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f4/a72695ff021df99961a6e99dd1c4d274019399
meta: {size:84, lines:0, sha256:"dc1a702ae34d41389c73e0938506efa3efc83c896cdcae18de9468703a2fe80b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f4/adb8c0709a9ac92931227857116f9011c99db4
meta: {size:48, lines:0, sha256:"d96ec01a5bda47630325245e914d76d53783a53fe6e113f5babd232be81c204d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f4/be5a607d54d6ea972ecc945329eef1d77fc1b4
meta: {size:493, lines:0, sha256:"ea924a8be1653cd5ce153aa71eb8621c4c44ea28118957b7c1cd3200fe3a6135", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f4/f3fa8f3f160921ee87cec08df1ad11cbe290f5
meta: {size:230, lines:4, sha256:"617afd6c5873ce53b0d768d8ecd5110368c5ec6ed3a06c8e3f0ac1fb33c0fb00", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xmÁJ1=ïSx©Ý½y³k+Å¶E<¥Ìf§%nLB&+øpâ#ù
¦±xçK¾ïokar59;Íô¦¾|}Bs |À
½×v_c(ËGÚQ «4²"Ût]°©*ÑüCF
hÈèÆFÛþ"ÓAõ:â¨­Ä^+wþJÒ¾ÌÎp& iF)àö¡+¹\uÌßîó±zë~s3¼:R{JÄÈÐ;¦Yzñ2þxÞ¶¨úÁ§×Íe(r¶\¬gO§âz'n·
```

