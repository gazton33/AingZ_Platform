---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/07
part_index: 0
files_included: 8
size_bytes_sum: 15148
created_at: 2025-08-31T21:08:15.566544+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/07/0f70d3cfef7019f407844191a924bcb1147ac6
meta: {size:5591, lines:0, sha256:"cd7f7bfb91144da7c1d78ebce1f321853d4859bbfd9278b606d3b6a25d86b561", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/07/25b2e49444ef3a6c934c6f9a2243e83c2ee99b
meta: {size:877, lines:0, sha256:"df6be0a75676ef76ef85d17f5f6274917ebccdf3a79e4600f4b9aec1387582a2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/07/5b76e619a172bce43fbe728d0f163c063216e3
meta: {size:2172, lines:0, sha256:"9e8105b30242ad2e7296797e47494156cbb3bc40cb56c3fb28880b467883a714", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/07/752ce281690bf8b401675319b6e9cb3fb48f20
meta: {size:919, lines:0, sha256:"7d6612c0f6ecae7de16d66e13bf2649097bc9a20c9cf24aea4adee99351ff16d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/07/a2037aa94359b338652a6bcdea7e7a44022b35
meta: {size:1329, lines:0, sha256:"514931f4501d5ff88e5a40c5cbe864d226c377df9400093da85e6e2f488b2299", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/07/ad8326e876f92ec46715d9bd9854a5f5a2be1a
meta: {size:2479, lines:0, sha256:"045d4a71a7bde475ee761aeb59255fb54156a14c9358bb3b763d2bd21dc1afdf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/07/dadb838bc7cf74dc5a43406bd940dadc663fd4
meta: {size:919, lines:0, sha256:"8b33d4a3f63e512ff78219be757e18b30b31718ff793613564b144dfaf768385", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/07/ed3a91c111613786bb3e153b0f896993c9f8ea
meta: {size:862, lines:0, sha256:"a7f03d8c0a4bc2c59771c68318b9923c7031f79785787914c47c92350ce54602", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

