---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/4a
part_index: 0
files_included: 7
size_bytes_sum: 5007
created_at: 2025-08-31T21:08:15.618913+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/4a/10e3205fc131dc56541844a63784b19b976e1e
meta: {size:1111, lines:0, sha256:"d01783e52bcb5f4ae0491c7c0e1534acd5a0a3f049a7dc0ef2f64e247721f18e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4a/2be30955d268fa5bb78481b57e9395421867b1
meta: {size:1840, lines:0, sha256:"f6e403480ac8464d5fd7a80085a1029538f40692157f96a4d1f7b9cdb0468e6c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4a/4a91a006fac15748a539a131ee70d186974b0c
meta: {size:143, lines:0, sha256:"3221be3429b6dbe5e9a9daf1fca59ff1b6f6f9fd89502cab6ab05511db19e8ef", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4a/88aa70c2b840599a907fc413c176649d8510bb
meta: {size:692, lines:0, sha256:"bd3dec7a7ba1affe4565f94593e7c76c26b33ff361e487f0c53063cb84a56666", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4a/9ec9877c9e62094502744320866146fac5f14e
meta: {size:54, lines:0, sha256:"c2fa7c419a402e4614b26d90d72074a3eb533c91a1bec25551d95d9298450dd9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4a/bc230abcffe2d739a1ba80a6779cb35f782be3
meta: {size:864, lines:0, sha256:"207478fbe77e0ee72aeae9e94ac356c80c3180e3b06b866809cf70e43eddc421", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4a/d021db23a999bdd2842d2a1a41781e2a358a2e
meta: {size:303, lines:0, sha256:"2eed038a459b4d4482a047167cb6077d42f659ea51ae7b5a4a3e07e36ed30ff6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

