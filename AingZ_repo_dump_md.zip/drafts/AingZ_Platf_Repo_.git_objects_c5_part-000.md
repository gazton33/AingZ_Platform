---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/c5
part_index: 0
files_included: 9
size_bytes_sum: 8918
created_at: 2025-08-31T21:08:15.631026+00:00
integrity:
  sha256_concat: d16ed1c1583ad3774bf83e386647362cbf781e4321a186317ea1415501d8c50d
---

## AingZ_Platf_Repo/.git/objects/c5/160bb457084cef7c9020b4ff8af89295e193d3
meta: {size:727, lines:0, sha256:"d53d5812872628a64af40791a3ac1b44e99d8168ffdae5f145616961388860c1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c5/1b35a37f099137c7207de143df14125d38ee75
meta: {size:858, lines:0, sha256:"ce5927c16ce782cf9fc744a8e51c3c135baa1a68a417c5b376ea4b5a3d6a33c6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c5/421182a71622e49fb74403f923ed488af1d0e3
meta: {size:2804, lines:0, sha256:"676b838d5b6277e98e11e3107d2eae8429ca8929c9972d3c31363d4a797a0cf2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c5/43e46004ee955a538b36e16f559539758322af
meta: {size:75, lines:0, sha256:"420a1b08f4a2f5ce695cb44489084bc3660081e8198c4c54b85830ccfa28bd03", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c5/4e2da28de102a48ff88ce28bfad5dda355e20f
meta: {size:1551, lines:0, sha256:"2eb09d9834ae0a47cc7fc79dfd72d7bb8849fa4d9f049c5ac0fd09e11ca2f6c7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c5/68b5485c08dc6fc9675905dd68e7ed18f711aa
meta: {size:103, lines:0, sha256:"f9e46be35a29b391457c7e867cc8edb4c827a39409ceb15a1869bbd799e88f7b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c5/84b369ce500bc01acaa45f3973f71f1f3621c9
meta: {size:267, lines:0, sha256:"552588a07613a925f3fab3d54f0461a2a6da16c8a81daa90a2ec227a6d82898f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c5/9c496c077fe643bb8a946aba5be739eebd55d3
meta: {size:2374, lines:0, sha256:"31eafd4283e888310c574f8c1e745130141ae4c0c712b8b2393ac24dd007cc8e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c5/f581caf24fa898645f73214d2078587ffc4c94
meta: {size:159, lines:3, sha256:"a85ad95664f3c1becc4c9dbcb6bbfd1a679b2b89a5fa24b2f96bea7c35e52f05", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xQ
Ã ûí)öFÍªPJ¯²êb,bZÈé^¡ok)ÏJKoÌztÎ:ÌýÖ)Ã MÁ0Ëô[V¼¨ñÖ!g¯Iû09VqÚÉ;ë½Êväd¢ ½/µÁLG¯ÖpWKýp{Ìëk¹Ãh'Ò¢á*µâ¤çÅÎÅ¢Ð¶Ó
o#¾Å/G
```

