---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git
part_index: 0
files_included: 7
size_bytes_sum: 19725
created_at: 2025-08-31T21:08:15.564306+00:00
integrity:
  sha256_concat: c8a29ab86b9234f4ed009b54ebbde478a650e6454e0f41e93e1f921924a9cb2b
---

## AingZ_Platf_Repo/.git/COMMIT_EDITMSG
meta: {size:12, lines:1, sha256:"f8680584ffd90f2979d8630cd460515778751621a7268b40040b1e06c310c687", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
integration
```

## AingZ_Platf_Repo/.git/config
meta: {size:447, lines:19, sha256:"381ba397b82f02b464a712378296f5981933d3d4c59fffe4079afa5beb442d28", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
[core]
	repositoryformatversion = 0
	filemode = false
	bare = false
	logallrefupdates = true
	symlinks = false
	ignorecase = true
[lfs]
	repositoryformatversion = 0
[remote "origin"]
	url = https://github.com/gazton33/AingZ_Platform.git
	fetch = +refs/heads/*:refs/remotes/origin/*
[branch "main"]
	remote = origin
	merge = refs/heads/main
	vscode-merge-base = origin/main
[branch "v4-migration"]
	remote = origin
	merge = refs/heads/v4-migration
```

## AingZ_Platf_Repo/.git/description
meta: {size:73, lines:1, sha256:"85ab6c163d43a17ea9cf7788308bca1466f1b0a8d1cc92e26e9bf63da4062aee", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
Unnamed repository; edit this file 'description' to name the repository.
```

## AingZ_Platf_Repo/.git/FETCH_HEAD
meta: {size:254, lines:2, sha256:"31a180c5d31c2c731276a169f72bade3137f50620c9d74849993c93d57ecb2d9", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
6c958c44161094ff15e8501bcfd1f5f94d8e6d08		branch 'main' of https://github.com/gazton33/AingZ_Platform
cb09e1197746d22fe644c4d758947683e70bcdda	not-for-merge	branch 'codex/reorganize-files-for-bucket-ruleset' of https://github.com/gazton33/AingZ_Platform
```

## AingZ_Platf_Repo/.git/HEAD
meta: {size:21, lines:1, sha256:"28d25bf82af4c0e2b72f50959b2beb859e3e60b9630a5e8c603dad4ddb2b6e80", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
ref: refs/heads/main
```

## AingZ_Platf_Repo/.git/index
meta: {size:18877, lines:0, sha256:"5108731b04ec2701e818fd4d7181460e123b91ddc477578a3a740e05815dda01", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/ORIG_HEAD
meta: {size:41, lines:1, sha256:"ebdbc97c1d0dee62bd5a4cfc15b5bcbc9233cf12a52dafa3d39578edf1916e42", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
113f34fb07dd79e936e9526fb72df4ebe51ac788
```

