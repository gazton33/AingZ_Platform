---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/18
part_index: 0
files_included: 5
size_bytes_sum: 1094
created_at: 2025-08-31T21:08:15.568353+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/18/4df7997a14e7374218d8ec600a3bc8f22bb42e
meta: {size:80, lines:0, sha256:"02f5ecda2947521bed03c836142ab2cdce1586b79c036c8e4fdb352b1eb77f63", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/18/894627119aaa4c42095d9d1b7eeefce02bb369
meta: {size:66, lines:0, sha256:"8c8093c929f7109cc833ec126637c719fc4e792f778daaaa9c468a0d27f1cef7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/18/96ec0cefdfdcd5d164c6718fc3533785df8e79
meta: {size:644, lines:0, sha256:"54ad2c8faa32385c903ffecb7137414d34cca844aee199a91dca1d9432b95815", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/18/a46a641f84329250ebd46eb286bca0ad6ff281
meta: {size:83, lines:0, sha256:"0e8e4a25f20d8c68174b6d958a8992b8e0e55cb8fa1ef1d83b31f0f4a1db3f16", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/18/e5818fa8031c73d6d45d19853a6ab99dea035f
meta: {size:221, lines:0, sha256:"f7b28d1cb8375e553cebb33afc355ff23120c69e0fbd5f6ab4db2ac3cceadbb4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

