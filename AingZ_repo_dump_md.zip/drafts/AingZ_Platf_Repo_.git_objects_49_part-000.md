---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/49
part_index: 0
files_included: 8
size_bytes_sum: 45775
created_at: 2025-08-31T21:08:15.618648+00:00
integrity:
  sha256_concat: 080996f9a240cd2ac0a9e9a039fd89f2006b4998d1e18c77912a303a68080e94
---

## AingZ_Platf_Repo/.git/objects/49/0358b2d554c7257ce6a65944515401d9085866
meta: {size:13289, lines:0, sha256:"b6095f8446d5707e884940752cd43e1cd2b058cce8b560d2ce2f5246e6dcff9d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/49/1ef13178fd410b5289212045e89a87fdd8daf8
meta: {size:1294, lines:0, sha256:"699f7cdcafa4cb86cfb0ae368f58ec7e416aeb00e301bb2be621065560ea742e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/49/211662618a2ebdb9491c61e7e6338e6fb840e8
meta: {size:97, lines:1, sha256:"c3573dcb474def01bbe0b48b876d399b8c6d21a7ed7a64a2325b100f4ccc5d58", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xË10ÐÎ9Qg§HøU¢F¶	*·oº¿«DZçÇsðÍ{ðEq³ì'hBZ¯­T§÷IÔüÑ8$ÙñÝ¢F¸2Ò{Òû/a½Ü{"
```

## AingZ_Platf_Repo/.git/objects/49/6bf85e88bd71a14c78700a422545a51219e3b7
meta: {size:828, lines:0, sha256:"d1698c2f0d5a4d25e3fc46ff6e93149893e8d537d3f31808a0023058aa5a1550", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/49/6fb73abfbca2e7ec6c23fb16beef286cb6e112
meta: {size:441, lines:0, sha256:"9f87a6b0df9ab2d4200d7c7b594f5da010ad6567a16a316cf1f7fb739d0b7e05", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/49/86264fc319dfb269553ed76231217ff28af7f9
meta: {size:28630, lines:0, sha256:"6e042162d54db2f6fbf98a3faf064961e2f63a5d4af09483dc0ed205d0337e24", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/49/d90ae03134820c83a089665621b83780ede493
meta: {size:138, lines:0, sha256:"55df810fb7de7fadb44090e91820a6061fc234bb0f2657cbb6f3c9231d2c2cec", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/49/ec87391ee0bbff24eea117fd67aec46b614971
meta: {size:1058, lines:0, sha256:"5f0cfc33e3c591376a68b0a536e8a9107b1764d5dffbdfea74f0be39abdaf68e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

