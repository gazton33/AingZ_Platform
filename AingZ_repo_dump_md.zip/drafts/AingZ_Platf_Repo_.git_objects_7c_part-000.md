---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/7c
part_index: 0
files_included: 7
size_bytes_sum: 7115
created_at: 2025-08-31T21:08:15.624924+00:00
integrity:
  sha256_concat: 574802f553d812a0a60b9e9c79447b32c982053c3e6161e3b28865b9819a7510
---

## AingZ_Platf_Repo/.git/objects/7c/1dfbdc97ddb24126ccfc7f7781b8d1c97ef030
meta: {size:551, lines:0, sha256:"4745ec713827514d28138a0a92475a23ca97e63d853e6bccf67c0b542d3c95bb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7c/48262a6c2cb8d30c9ed7054a5a4339960aa6f1
meta: {size:479, lines:0, sha256:"c13f0d5add8e04901b307d89c76f918e4814615d9f6f65e10f27f7bfbecd58de", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7c/7d314f1eac7628b5c7be58673ad5772da4e029
meta: {size:175, lines:1, sha256:"42b2e2fee4bfe445231f64099757f287db2b1dce34c422c059da15293b99c1ed", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xInÃ0sÖ+æ1fÄÅLÎ7|ãÒ¢@Ð×_ðµº¨XKY;ÍZÞzÈêRø­BÔà²òÁº³öÁX7§<æéð{§ÀlPY`VCyhØ±ü£ßk£ïu_nôµþ°!ÞëÚu)~ÝN±ÉÙX-Æ*¡wVÌÓ £¯ãõçáû'ùèØ|ÏµzjÑíºîýOMì
```

## AingZ_Platf_Repo/.git/objects/7c/98244d1fe9683cd17d2da44602d93b95d3174c
meta: {size:831, lines:4, sha256:"66a5e7d605cb4ef46993f288cc37bb849ea40c638ae34f4f92bddfd27cd8ad24", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuSIÏ£VÌ_ñ¤\¡³/Ò$0øXØl¾±<³ÿú8É5écµªTªîJû¶­fc4õË<BÈ c*Y&£èòG`)Î&Çç,A³ÎÒÈ°Æã\Î¦OaB`$O§1ãxÎð<Ëp"ñ2ýª+àGñýýÇEWÍ÷´oÿe¦IçÀ7Ä0ä~ÎpJ5«K~týæøYTs¹$ÿC+bª
ðíïeE³­Øà¦)p÷\ùØ¦K*
xGt¾úÒ­³{Æc]Ú+á³dG&á¥ûQ0¢Ué±ZùÎ,ÌN3pú´@b,æiÔÜóØb×#Ýkv¬­ùä?TqÂÈ¨®rxå·Rwò©%åtJºÝn.MäìºÅÙ°;ÿ0ÉÅ×),«Z+ÜaUl-ðÞ<ÆKÔÆïc#n-nÑQÎ¯(öj7äýýôµ²`{Çí'Æ¶+	ýÆ=ìáJITÑ¦SÆáTÝCr TeuFó!
ö"*Øî#C;?³6ïâëÃ±SØ|]9rÚ=-oùËÜ àL$Ø[;ã6¼%ÆûýáÚ×ÑfRºÕÕÅråRÔ²µh1AÕ%ë)víð7Ð,S [Á¨×I½Yû,×rõE¿¦ÈLDëÌC×4úÝ$ÕVK¢yU+PB,â;@õ}F5CeçfXiz»ïZXPñ¬'Ö±/ÆÂ×kKtikÅûZ~r  íëu|ä'<sé·²pò=´¼¶ëýV<¥4uvD!³×ã%eßô¯ó53Ün¥êàµJ_YÍÑ³MOëÙçõ6=ûÔ°§³taìøÌöèY&©ú¹fÕoBxÇ.Ê7ë4¼ò¶%7Ú·Gdp'âe9µé¾4G+zEùõ*2_xÓ÷Oû«£f[SÖz:Ò¼øOýã%òo'dKúïF jy×pûq¿ýÊý FFM
```

## AingZ_Platf_Repo/.git/objects/7c/ab389c9fb1d591bfdb8d48d64a6633ba6423ed
meta: {size:1364, lines:0, sha256:"3fad26ceae094fd72d0cfb3bfc40adfbd2a99b31f14094c0e1c098da9eacfe28", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7c/c29d8b047fdcac85c17e3a30916343ff8299d3
meta: {size:500, lines:1, sha256:"382c86accf99843f70ec9e7f982d138bd9da9f4a6c997e52f136c396e67b5985", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU031b040031Q00ÏÌKË/ÊMO,MÉ,É/ÊLÏIMOL®ÔËMaØ0Ç/âíÔ÷3¾¿¾x>çÂwQ0ÆñÅé¥©y%©ÅñÅùÅññåùEÙi9ùåñÉùyÅù9)Éùy £/½róÑ¼WS~üñ<àòÄÑâ³(øø¸Æ2%ÏKuà©~ÞÉ¦9¤ )0bølÒ©ÔÄûú¥éi¹È1®iuw3¬øòczå¯YªO<¼öRToÂÐ´X¨kÁzèäb½¬âü<=ñ½YÌ7,½nÏuø;+%ÖEynbAAf^º^rqÃ£ÍÛuSV5Mÿ÷ë8ßýÉ§K·¼EQ\\XT	1:m9ÃD®³ªûVg>¼~âQÉdÕà`F	¢ø¢üÒÔâÄx##Ss#SP¨±G=\X´çý¾¢^~16#±ÇPRSÑ¬ø¢òø¤ø²xCÝ,¦oOoÓmk41ÿÐÇFk0Ý õÀP)A©øäÌä|CÄ'µ|:W'ö£xfÚöÄÀ0û}WÎ"Rt1F1ãÅ¯Ó¦?ÿ÷±tÞµõ]7özK
```

## AingZ_Platf_Repo/.git/objects/7c/f465371f12f0b527abd00e7b0aa29ce7b0e612
meta: {size:3215, lines:0, sha256:"3f5a259f9208cc954a780b479e44c1302fb2487442d69774835266a456bf979a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

