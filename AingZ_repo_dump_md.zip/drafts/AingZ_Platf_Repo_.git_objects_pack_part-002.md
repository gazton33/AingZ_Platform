---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/pack
part_index: 2
files_included: 5
size_bytes_sum: 236601
created_at: 2025-08-31T21:08:15.653083+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/pack/pack-c35a64df7612cdcd167fbf1deaf0f6e1e7c64737.pack
meta: {size:114140, lines:0, sha256:"8f4f980f71c9f4328712cf32ebd31f43ffadcecfd80a923ccad16a8c19d1c4ab", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-c35a64df7612cdcd167fbf1deaf0f6e1e7c64737.rev
meta: {size:632, lines:0, sha256:"8c31d48fa4a0b58a1ceef6c3fc8fde52602176f38b8b311461285f79f96da094", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-ca149c36d64c6c352a9e67ba246f17a6f3f039f7.idx
meta: {size:11768, lines:0, sha256:"4a12ba7f81b0c349de50eafc8b6308b14637f5c291509642ce973be14245a337", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-ca149c36d64c6c352a9e67ba246f17a6f3f039f7.pack
meta: {size:108481, lines:0, sha256:"88dfacf48e3796bedecd1b5ab3e3da760034ce68acd1842484895236c5b4014d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-ca149c36d64c6c352a9e67ba246f17a6f3f039f7.rev
meta: {size:1580, lines:0, sha256:"3415c62a1b3e7d693f21005a3c45a2355aca6e2248d4599f2ce126233894a9eb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

