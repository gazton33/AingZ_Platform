---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/0c
part_index: 0
files_included: 10
size_bytes_sum: 6255
created_at: 2025-08-31T21:08:15.567490+00:00
integrity:
  sha256_concat: 15fcc3d2b3251254678cdf69800328a5adf0c7ab88fde4dfb632e8be9650a2dc
---

## AingZ_Platf_Repo/.git/objects/0c/1182a92acb385bc09636abb0995316db042411
meta: {size:230, lines:2, sha256:"52727e1498741c238924dcc608af1ed750e16d6cddf411c96f4b8eacf0462cd0", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU026g040031QÏÌË,×+¨dHi>8Q÷ØãðÛ¶Î?rm
;îþ*K,MªÊKÌÍÌK)å¼jsk¡þÇ]Í=Ürq*Í/(/N.Ê,()/JMLÉM/77ÔËMa¨(êwkØõäj éÆïfwB¶ZOj+J-È/*Ï.È,Y Pµgq6¯õlku5Ë®,ÝmµÝ¦²4/>9?%µ">)±85'3hI|rFjr6HçIÞw7'F\³^±:Ñ®äIÝë-Äa
```

## AingZ_Platf_Repo/.git/objects/0c/2ddcafefcd1d85d2230ea951f2796fd486f393
meta: {size:836, lines:0, sha256:"9ff58434d17e0f27b08e7483fa9b2378a7db88d33e38a0abd031c8fba5520daa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0c/89d1e12dcb20ca85332a01d6d1b2ef0d1b95e1
meta: {size:1940, lines:0, sha256:"c050a83dcf6f1beb55b26387b12ded39725e4cc42e2f47f48f243ea564dcc0dd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0c/b5e0128013e017ffcc9bf074c651a584d857e7
meta: {size:99, lines:0, sha256:"15960dab9fd99312778b55ad56defe01a1417192117e20c8d21cfa59781a0116", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0c/ba434c8a0b0fc90ead8b9e21bc990e3e8c6eb8
meta: {size:197, lines:2, sha256:"3dc67ea69ecb082a2a6b5c767a3852abc5df448b40fdb2e93feab0bc70c80ca5", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xµÍjÄ0{öSè¾4ÄñOäRÊîk´ô 914ñâ8}ûºôÚktù@ÒpÙ¶ÜÀýÔª`ÂB@bç}ôiãÇ4öaã#©;UÙX+Ø
RHãÌQN494:ùÄ%Eg[K%·õÏÄ-ýø¥}Â«ÕpÂéòGz=©Ç°*÷¯ÇðK\¶7Ð³³èÌìg¸]ª»ý&ÿ¼FÝò¾¼Ãmé¼@Þ¹¬ÒË`9 YjSßn©
```

## AingZ_Platf_Repo/.git/objects/0c/deda1c5f5d0211edbe4087671d307a8d0fb716
meta: {size:268, lines:0, sha256:"e46499ac4be7203aaf322777f9d13dd6652a123bb84e0fd0cabc4c42d26ebde3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0c/e205f3373a388f25da2410033c9a8e7892b5c5
meta: {size:153, lines:0, sha256:"7e71a808230fae838b94e79c0a93b23db23aaeaf7789d46b4e39702d83a96bcf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0c/f4587553363ba732a322f97c080a492058afb1
meta: {size:1395, lines:0, sha256:"3ef1ff549339f7febc7315b680ba66a87f7837fb54630d9bef04b0b3747f6a84", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0c/f5a02cbe7a24f7f3c663f106cd7067a7252998
meta: {size:948, lines:0, sha256:"260249b04ff7c6cd2cb998ed87598c8fa2cb29650ee4fd3f21cd82df0cfbf92a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0c/fdadc41fab4a1868dfb5f17260845fa2c7273c
meta: {size:189, lines:0, sha256:"cf4700efdda1c6de6c90c016e2d4e1b9e146d963a7d0cc226726dbdab2ff9847", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

