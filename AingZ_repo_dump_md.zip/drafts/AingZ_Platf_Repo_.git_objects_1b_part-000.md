---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/1b
part_index: 0
files_included: 11
size_bytes_sum: 4835
created_at: 2025-08-31T21:08:15.568571+00:00
integrity:
  sha256_concat: 7de3acfeecb41533f96b7fe1403f52212473769baefa21f1fd790c60624df479
---

## AingZ_Platf_Repo/.git/objects/1b/0f246f2d27cda85e062559838d8185f3eba0b7
meta: {size:47, lines:0, sha256:"b9304986a9631b7ea3bba5e3ff0639761ec5d79b6f44e25acb3a7c1bc9105e8c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1b/29ba753c2c35094edafd045f99a00b511e3cc7
meta: {size:631, lines:0, sha256:"597af216d9e74a1afce2b01c75a4a12c8cf3ac3a7633dca30f5439e7afe8f4f8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1b/524ae66bfc27fa557519dea0ae05519ede3120
meta: {size:1416, lines:0, sha256:"7f563e678c9c768ccd0d4e3349cb934649984d224c275615cfe5e216bef3e471", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1b/6a75bb3e80b1043c7f89542c03ca2ad1237e3b
meta: {size:154, lines:2, sha256:"4a6468ad83295078a56c29f733261f23490ef835269dc5252ea121a6c9340ddb", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎ[
Â0@Q¿³lÀ2I:i"ne:V´FJDpõº/¸Ü¶íÚ}Ó¡ïª'TÈBÉ³¸11ÛT*º'íúèÌ¹r©hh¢ØHeV,#¢¤hT½úÚv¿Ð§·GJþ´½+¯í­ûeÙèz¸mg&C	¢?Bp¿ú[ìúvíæ¾}E
```

## AingZ_Platf_Repo/.git/objects/1b/7a25bd32d1f7845778c87b569dfd2b85750473
meta: {size:502, lines:4, sha256:"b0fed4af7905b11d2962b4fefd74fb29f26f2b317d0302e9873a7ad3b93bd871", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xíVÑn0Ý3_q¥>t{ Ð,é*&1°*$T6mÓd¸4H[ÆÙi_ÓtY:-@3MËÃ$Àùø_Ëñ9&7/NÀ[¤õ2~gdV!`­ä
.«T9	#{46ís}Áw©ZX[EÉð¬Êõw²Ärl2Y
UòxÙÃ´a¦~@"òTaäM#õð²¸þ5Ñs8 ¿Ñ9³%
YÖ~¥c+u^æêðj_Rû¢g¾V­3ÂJXÃÁTi£PRÁÒú*á{ÈpÑXú¦Ó¼Bÿ5=?ºi\ò¾ÍïPl{åûÇ¨àp%ù{jGxÈCÝ£ýôþ©;Þ%!¡ÞÌ¦Wº¹¾	wêú~üèfhÉ%kPY]cuö·NhÚúÒ¶»¡ûqtEÝÄbP¤Úµ©~&RÖF_`Ê¡Yfh=¸¼).×îBOûbx³éí,|7&Ez:Ao¼ðöÃÍëia½sÿ×k»ÿ½zýZ¾m!ÿYµxéx±ÁGp½8qÃà~Øm³5|ÕºÕ?]àô½g¢óÆÚúþ\Ò»Èß±h:]ç¬·¼f<ÇÕs?ÅÖKÆ{ùdT~
```

## AingZ_Platf_Repo/.git/objects/1b/99af46a49c7e1716315a3b31c3c1f9cc88a5d9
meta: {size:125, lines:0, sha256:"66c5f8473ff4a4c7814f364685e8dc0e41c4c4f0694ffd40bd3f550e35dd6124", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1b/a7a40ad38077498610d3a68c52946c85b8dc4b
meta: {size:150, lines:0, sha256:"fa05ae0ba4a06a90eb90505056ce2cd468d76d70365cc4d19149161936fa53ec", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1b/c83603a6fce8823bfc0566dd896c60d1943f97
meta: {size:863, lines:0, sha256:"51e72acf39f436f91340b781a30177f31109142078f0073028b9b68f175ad365", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1b/dc072d3a165b67a5d408af2236b8ceba147ef6
meta: {size:423, lines:0, sha256:"85c8e58ab1c084b0db4236bbddf94b143d622d82db3c46e45cf3a2461a3e6364", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1b/ea4532ec519d81c45627bf6099a2d6c434f263
meta: {size:156, lines:0, sha256:"38370abbb93b4c38bc9323fc9618f11641806314c8b456208b30818b0ffcfb7a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1b/f1509e6cadbda8a925d2efa37551cd83068b8e
meta: {size:368, lines:0, sha256:"b8c2b0be5d249f07b4584515a0d25da770b9c9de0df3525fae9ee39fe7950a07", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

