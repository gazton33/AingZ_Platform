---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/f9
part_index: 0
files_included: 13
size_bytes_sum: 6522
created_at: 2025-08-31T21:08:15.652469+00:00
integrity:
  sha256_concat: 7cdade5fb4b5a3b9ccd51e23fd12d34c31aaddf99232f3ed0a1b61d6b4f48aca
---

## AingZ_Platf_Repo/.git/objects/f9/0d34143f50f0905066282f1c826a1519e8ce89
meta: {size:793, lines:0, sha256:"ac4b4f7a324de1f96b3a5b327b552550e4e07fd7a87b925c34da55a647cd8e74", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f9/203fca7ed0f72e55399f434a51f6f6f8b2f898
meta: {size:421, lines:0, sha256:"b36bf62c059834ed4f52af6680eef9d708ced4d3f7b2470bf436137234fcd6bb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f9/229ebdecfae5423ec655e418cae893e915e339
meta: {size:155, lines:0, sha256:"19df15f7767612d8b675481acefde23129f035f35cbd4084499855e8986396d3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f9/280ddd3ada8b42bf3ef28058860efe03d343f3
meta: {size:88, lines:0, sha256:"79b9689ed73c6d04632ce15a942c44ddbc1ce3620468cecad633ebefe845e129", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f9/43e9d48c9fabffffe4c7dadcb7a4093a4628e2
meta: {size:972, lines:0, sha256:"1c01e98577d184c9900efedb33c4548226ffbcd01a0285cf6818b18aca810a3c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f9/4ef59df33dfba6306239f91dc1f0e5e837d24f
meta: {size:851, lines:0, sha256:"0eddc544d30ac637481d91d6f8bd4801e3a94806b2a4cb6867688fd7c3378c9e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f9/69471a80075f0dfb95fb6a0b299701678376c2
meta: {size:414, lines:0, sha256:"8302504286d4e1a30ee3970efd919c8df58b1efe903f29fece00ad4b7168b283", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f9/7857d26c34986b52ee41cf4c347074309e956a
meta: {size:1504, lines:0, sha256:"e16ac8eb08df419241787609c4a8a389495bdd19f370542578a6d1f9d83220ab", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f9/81ba8c9661c2c9b2e47ca91d4aaf227d3ed4e0
meta: {size:267, lines:0, sha256:"6d5fe347daa4f58f3ff5eea0d4b4f205df9970b553f8a92188db4b6b4bf77d06", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f9/8c20680070b862383faa2412455c126670f1c9
meta: {size:153, lines:0, sha256:"dc2e98bf5c618723dac982d1f1fde3ba4bc57c47df816341bb0b7f1781530821", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f9/bca28863e372659ff0bbc5949151e9c2a7a44c
meta: {size:173, lines:3, sha256:"476ceab7242627a8eebce09a5ec07c70c2041e55f2b5f05c4a17b13e80da8229", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x5Î¿
Â0Çqç>ÅÏÉ?VtóÁ¡tHÍÙ¦w%I¾½©E¸é8îûi48N«»±i&=>Ø¿Õèâ¾È²«ê
, /é)ËmªzzRi­à,wuC<¢PEC¸ôøH¾Þp.KCn(¤	V[ÅE¯Ë[Ë¡üîÖYö0Ä³cã	é½rhr2)b~vÍtË/îI
```

## AingZ_Platf_Repo/.git/objects/f9/cea5fe2ebad0d5eadfd4b09b2768843cff55dd
meta: {size:633, lines:0, sha256:"63ed87c56b9c59d5cb2c4757f5d3db9010a1eef1fe8886cdea61b8f04af968f2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f9/f0821bf157886af398928f6fb39cedf2343655
meta: {size:98, lines:0, sha256:"a570b661fd8bfe9f42d1bc0aa2d2e425813817c57ea0be0b12d5e4a3a776e221", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

