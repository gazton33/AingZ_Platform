---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/86
part_index: 0
files_included: 13
size_bytes_sum: 13548
created_at: 2025-08-31T21:08:15.625986+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/86/0eed22a1bfe372d39b878ac121bac211311435
meta: {size:289, lines:0, sha256:"5a08b3a93d3d94151e0c2dea9bc2a53417c248b323d20ad8428db5105c415b33", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/86/219dc4fa247b3b183fb91f91635fe111b2ea1c
meta: {size:209, lines:0, sha256:"f163774bc4e379d6fbca0405108a693239a2421f1f3f1bb7e5f52226c6ba69df", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/86/24e5ab5c02e4e1a5d17baec69fd24b9357a8e6
meta: {size:1567, lines:0, sha256:"b033c28417ab5bc8aa29eabbe2b9922be3ea2179681a76b1a223f721eb10ff7b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/86/25ddb5f9e88206c093f70185e3364362d8c062
meta: {size:1265, lines:0, sha256:"625700703868364311f8881ebf5da5f110872bc4001709b86583bf6b94872746", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/86/4f2e570c3d0a7c64c567afc9a7e4410dc51736
meta: {size:1887, lines:0, sha256:"127c95bcde7c7d8a54f68bea31ad9d8e42c0ff968694cad173f0f2e556c09705", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/86/579b95dfd19e0d7df61ed526a26865edb5a613
meta: {size:73, lines:0, sha256:"a81f0f40fd1e9fee6aab852334f3f5f4f62faeefc503ffd59797728204d2c896", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/86/6b3352b833ea9ea3d0a2ce740c8c65747186af
meta: {size:856, lines:0, sha256:"b7b912e9a38400ef3129686e896bfe07f0806942487bd719da711f65748796c6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/86/711dc8884d287e14bb73de9820c17288e4ec88
meta: {size:800, lines:0, sha256:"c9f768970b632418889d224f8b7e794e17a63e4fdd50c4df2ba95b71b688ed41", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/86/82193ca522c392807b39b3a362430f9a39a262
meta: {size:2514, lines:0, sha256:"ae8b01ccab4295e0dbf7d8e43d0994a853f92baa21544ca70044339ff2f517fe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/86/9244fd92ce6112d72b60da447b0ac3eaefa5ed
meta: {size:1038, lines:0, sha256:"d6d29d84f8f03ecc52e01dedafd90d552cb89e6ba969ab4d12a1ae7cb91a2566", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/86/9b571a17d9083252aabaf84ad66e3eacdc5fa8
meta: {size:843, lines:0, sha256:"3b7b3b684bcb90b95991b86d440c87775d85fc473cea5ec873f9dbc7c8f928ff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/86/c43c4d4070526f118c787b6e5d05bbe40a6108
meta: {size:297, lines:0, sha256:"267157fc5ff5c74406976259ac838837410a1f261405268ea27ba37b297dc79c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/86/d180b518ec440fa29c913a81167042e75be614
meta: {size:1910, lines:0, sha256:"9f23f73105a67f6a14bc13ae8577b5b88135cdf204c615779903871fd9a3dc44", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

