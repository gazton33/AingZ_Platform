---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/f8
part_index: 0
files_included: 13
size_bytes_sum: 7444
created_at: 2025-08-31T21:08:15.652413+00:00
integrity:
  sha256_concat: a724eca97b60df0715579934e6ddd48753e3a6b0860f857c4ffc75fe2c469ab7
---

## AingZ_Platf_Repo/.git/objects/f8/0be846d5a71b035a63e49e63c17b61ca0b4a7f
meta: {size:844, lines:0, sha256:"25ce4a565bf30fa1443fa0bee9424e3f694931ec550b10bc5c3c661555e164b6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f8/10cc591211d8ad530d0ab791c4fabb5b097f88
meta: {size:211, lines:0, sha256:"a245899bdfa4516b6e04dffd14918f2d035c377c28a781f49b6a43efde5e5962", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f8/159f7abb2b0a7cfc7e8345bedd81c73d5c20d9
meta: {size:262, lines:0, sha256:"470efce3b76a88749fc463f80a81eac97e971bae9adc588ec97856d13a203035", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f8/20c74588cd54b0363e79705c151a2c344e6536
meta: {size:154, lines:0, sha256:"4e7218dfe503254d48763fac0efc920fd4d6df7266a404879cfa60a5c8fab6f1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f8/5db03c8b3b876455387216024977f83af22362
meta: {size:864, lines:0, sha256:"b63cdad864f967e130c02c6b9886a88abf45d66465f3495cfb49d7e289c4d1f6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f8/69a58e374315b91be654fddfd26cd2458819c2
meta: {size:76, lines:0, sha256:"adf9d2023e3391c28902aac420ece35133bdab75f34c880764c68ea5ef2f4ad8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f8/970ce63873c904601c940506097c2d26289745
meta: {size:79, lines:0, sha256:"78df3606ec1962790ef1f2975b3a8fd9788769a0018474f752745f5729e61127", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f8/9818112a68b5f0cad282c613937c85a76b76ef
meta: {size:731, lines:0, sha256:"4c061afb188df650f28488a02b4239be6c76f0cabce3e7be15c6153252794601", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f8/c021bfda2b97148b146a8ee3f3b5f045141c84
meta: {size:781, lines:0, sha256:"0331e9b285e94210e4ff7c16be5cc74ce311c18d7bb4962b99f51720042506ec", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f8/d35e27b66039bd3d36ff94aecdbd9de917c0af
meta: {size:308, lines:2, sha256:"7393ce607a7a67edb58ea9bc3d189c57099c27a155c4814ecf7107f6b2e12eee", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÍMk1{Þ_1Ðó6«]KñP°ºAmìuÈnf5MB6¶
ýñMÕC/ÚP(]H2!ÌÇ'aJeJèåþÕ57\¯Iu;ÞXE@Ú»=ÔÆ5ÜúY?O³^ðûóÕRÑM#ÂÉ£T ¶rÒzi4ªCÚ$IÓ4,°²{P9Ó¶.¸KËb4!ÇÜ;Xª-Y'µÇ7Ìv´Â`(?Àì³»¯zé(YSµ¯1OeñÁBÞzrh×¿~F±-qÑP¨½0º,+òÊç/2ü±ãß;;í»H0^f$¿#:ÂáÛE?ËûWßzÛr5+pü<.¿Ì¦£Å¸À×üÔÍ*ã¹­jÉ³K¾É't(û­
```

## AingZ_Platf_Repo/.git/objects/f8/f4dd48c1b6b10d5dde877c7ece8386630b6dd0
meta: {size:496, lines:0, sha256:"1634bcfca97e0f2e39245421f26b17dfa2a0f947cda63feff28c22858126af64", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f8/fcff8e4062dc4d8c4ccad9901ab3698df9fe43
meta: {size:1976, lines:0, sha256:"cbc33a93d5a9e517aafc31c0a98bd8eb70e9c48782a9398341ff660bd3e2c89c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f8/ffb15883bf88c41b121d46ac0e76c34c42599d
meta: {size:662, lines:0, sha256:"4611bd1e5c99e75cf9e0c20073ca7e346b42fd238812fa5af06d218a303e9e19", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

