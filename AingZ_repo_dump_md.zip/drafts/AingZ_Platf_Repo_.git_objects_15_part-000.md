---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/15
part_index: 0
files_included: 11
size_bytes_sum: 126801
created_at: 2025-08-31T21:08:15.568037+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/15/0304c5c8010d244f896f9dae02da128f1d2bb5
meta: {size:766, lines:0, sha256:"d81c975d37021de077f8d7aa6ff6a17594ce868833c1be8d7df9b872da2ba8ba", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/15/2b359c1bccbaa1716ec3ecd1635e207f62430c
meta: {size:722, lines:0, sha256:"5d5d3f1d665910f0256e4dd97c963f9865428e2184f8b99a0def92cce6df8314", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/15/44d746cbbec3f2a32cea5d423a808fff91d32c
meta: {size:1351, lines:0, sha256:"62196a3e35c3f56f42fb144cc4953d5437aeb0edabafe7715e6bc83cb03f4099", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/15/4a285014c458d22d26f148c7b96b6c5d5afff2
meta: {size:634, lines:0, sha256:"f905ddf9395cbefcc6007305fa6060db4394829ac60ff315cfaf404f6b230fe9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/15/7b3acb35d660a0ce9be9c515343f1bc5c644b4
meta: {size:406, lines:0, sha256:"21ac1cccf1c5c60fe4a57c7dc3bc517e5ebbf656f2eeba69f9c98e6a99604fef", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/15/8c78a308d10b91186d17254674f6e7604d3f82
meta: {size:30006, lines:0, sha256:"158a2a012c2b4a75d0fd8a27eb12777459c8351d57b8ba2a74ce6e9e08bb4782", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/15/9295c45ed6058d568702ffdabca5d7a9701340
meta: {size:631, lines:0, sha256:"9f0658e78e34dd4ac51d6cb6d3967c1ba50186205ca81d8fd7fa63dce1491f06", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/15/93a92c17eddb4bf8054cb880a1279ca5699fd8
meta: {size:84119, lines:0, sha256:"82b1b85f8b13f2673bc5f2c70e8c65c470e5fc67fe5a6f376f3552a432aa313b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/15/a08a6b5c3e77792b4bb83f7a4c6a04e11083c8
meta: {size:1838, lines:0, sha256:"6920b4317cd8388dc0a62092f2b13fad3843d4ec26620dc87688f56d57b821ba", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/15/cd7710b52c107cdb7160ed4ee063bc54c0000a
meta: {size:6088, lines:0, sha256:"e5d15d0a1f37be23d03002b6fb24f83e9db8c529b8cb3f23c8125aff228184ed", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/15/eb686e7d2a374a065d1a168ca7ea752a4e5abd
meta: {size:240, lines:0, sha256:"579bd7201bd591f4ae08d638f74edf1fdfc1352c0a54780666f4e2d84cb4ceb5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

