---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/5d
part_index: 0
files_included: 11
size_bytes_sum: 5361
created_at: 2025-08-31T21:08:15.621230+00:00
integrity:
  sha256_concat: 2709e31f6c275b0c2eaf052d65b87c8a8d85e298575185ccfc7224a563c87217
---

## AingZ_Platf_Repo/.git/objects/5d/119ef1042d76834b68ae60dc74361464fc3e4c
meta: {size:54, lines:0, sha256:"d3d16565a5f56f7dc587ad9f4b7896b1645d31dc4ca74f4040345fd327ea7345", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5d/2349410731c98d5cc786fdb72a671ba81247d3
meta: {size:398, lines:0, sha256:"7419afe65dfc5242e13bccb124358f3ad00e00744ecb2d26207405fede6e006c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5d/3226c85c687ce03888067c980a792bd1fd175d
meta: {size:432, lines:2, sha256:"7f470ad53207054ed8c927ddcd8d712cdc68c337a8d062c29c567233cabe2a2c", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU05³d040031QHÌKÌÉ,Î,O-*Ê/*OLOÍ+ÏÍOIOÎÏKËL/772025°00×ËMaØ¼¬úÚeÉÇª­my)¼-zKì:¨ayiùE¹©ñE©@º*±ÈHLòòf±¯mV{QöSïHºèÍ½3B~]´O
jVNfZjrerNj|IjnÌ¤²xãxC+*Ì0ÒûÖ ½÷¯Ñ¼Û*Bs]ÙÕYìâd ¿(µ Ãúç¾¥ìrÏ"ê'«¾ÓÝb<sCÌ¢üÜ`¤¤VÄ'%§ædæ¥HÎHMÎ9AõÍÃ[rß¦¥×¹j}ý!v$pb=T7È¶¢Pf¤¥æ%g&Ægæ&'gæç¥ãcåï)­{ÎújÛL³>ðtÖ,%0CËãârJS2qÔÔ¼Ì|pÅXÄCgIüÃ')Æ,-G.5\`+ÐPB6%7±¸$µ(RøÌ	áí1þs5çPDÝÍ·U¼wb¶Ü
```

## AingZ_Platf_Repo/.git/objects/5d/424e0ba018afeb47e97d780866b187b10e7123
meta: {size:221, lines:0, sha256:"35c5442c52d322e4d0383ecc8648e93ad60cfb82b4e85ca69a732be04f201d7a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5d/557c99ee527cbc1af6a072905c74e9b58a4b77
meta: {size:867, lines:0, sha256:"427acf5c1bf534a5d8e6c1426b89ac01936361216d993404cdd6e2515bbc0e5a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5d/7508386f3a153033282bc694626870d4bb956a
meta: {size:101, lines:0, sha256:"24646b43cb0874107b0b5d22d39939be001d047ba48434d3505fa7756a5350af", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5d/7889713821b58ab5c354aeb28e41c6351ad7f7
meta: {size:855, lines:0, sha256:"736da63493062310bf74b3bb81533a3fc3e3d0ac2ad3f99bb0f6c58a78264289", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5d/798dd7f56c0718040e815ce7a7f017974edb90
meta: {size:263, lines:0, sha256:"77891502097d2982ca75dbe9729450ddf0ed3ae28179b5757d462db4f4b5dd4d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5d/804566ef4e619c96c052f6bb4a8b1bc77086a1
meta: {size:152, lines:0, sha256:"fe018346e6ea655b65bad21fb60678a4808d209de52898dda3cbf95972a01c18", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5d/8eacb9a452ad014a2c3763620c4356e749c8c0
meta: {size:1193, lines:0, sha256:"d48a745b6908239f44686cfea073ceaed271c230e76112766773472094bc024d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5d/9cd0ff42b0d558864302944552b66d0b0a9238
meta: {size:825, lines:9, sha256:"cbafb3a0f05d5864b338f46dffd705292429075fcf662becc03bd9db728882e1", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xeTKnGÍzNQ6	Ar,&/P¤#Aqì%Ùì):ìét÷PW9D.3øºINWó!ig3ßª®Wï½ªõº¼ýøÍ-îûýþîv9_Þ¯®WïU
æ°Zø=UòêÎ'­ö«ÙÙÕ·³«iUdÙO´ð.zk
Ux*Ú4Íq]&½Ð®j«GúV¡Ùwôï_ÓÂ61q ë,L&YvqASz¾~ýMòÙÎlV¬¢Âë¦b6¯ªa[*ÚÇöW>?äÁ¢x:¯UP¤ýCjSàÚd\(ï6^B^K\e§'X³i×Ø7	ÇÜvAÊ&4]ÛëDz¢_îï£Ñ;º
³ÞÇ87ò)ògv[ëñ1ê`jùk}+úÅU{·5eÎn?¦Ò»¦ÆG7Þïðx=m,|U{8¾èÁÒªPôúO`t|$²1m×Ò9&ÑGm}¨5¸Í÷vLªI`Í¡cxTìn"Òu/ñJUGtX{T (béõÎÙB[F4¡?E<HI[¬¼æ¤rØFö%ìÔuw
i´h
CK§^=ÞÌïoHHm­öùÍJ¡øâô@<2DR:½mJïÎmUchë"!¦àÛþ0±e¦ÍÆèôâ
iÉ^ôE~uþÙrQ2¢Ä Q¢ àhXÔ<öûéÙÐ½Ð#o90´V6¹uÚ6&t6<7ë|°d¾ÞÊãc
BxZéEG=ÁÇ»
²¦<GÕÚNr	Å$Üi/<âêtcû¬u¾ºÍ×cà:H÷ÚI÷"räë³1ýaN¿p `G2Ï­HòVÃ[âX,|B$bK/ñtð±içC!.Gxk°LÞªäÍ±Âÿ8Npdìt*»ËÁØ_Ñ3Råë6F?vIÂ|Çõ|Ü·Ç5<eÙS=È
```

