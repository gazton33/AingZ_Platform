---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/83
part_index: 0
files_included: 6
size_bytes_sum: 4077
created_at: 2025-08-31T21:08:15.625696+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/83/0e2dfa7c839220457b595a5a5529817b9bae7e
meta: {size:399, lines:0, sha256:"b06fb35a6af70479f5dee275ab8fbc739beddd17aadf03e3608e95eab82b9b3a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/83/130541025f8dd96b27657a35d1075afa4c461d
meta: {size:665, lines:0, sha256:"8e76ae4cce94db07038e84e44f84822f5a08347467b4e1b38013a0ef5f334ed9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/83/5c4317d5bed7ca4651b60736f313131f5adae7
meta: {size:172, lines:0, sha256:"7b8d72c3d00a476221f88b4c3b9f274a5e6a30e57edb667087482a5ad9374373", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/83/6f93cd9add1f624b0d68d46ac54949f3675176
meta: {size:286, lines:0, sha256:"f622bff08877f0e10fd3f9c5e389cab75d3d33a887785a0df2f92ab0998c68ec", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/83/c81e860091edbaf53647181a98d410a98ea05c
meta: {size:800, lines:0, sha256:"162bae0a44abd8587e2de68f5438dd52956cc538e5c844576b8e01289f493ef1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/83/ed1eb2201893ecdc3e6bdfbb76d752cf35f809
meta: {size:1755, lines:0, sha256:"179092dbbb1c2698636713203c91b58ecfb830fd8153c6db8067bf2881e6f3df", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

