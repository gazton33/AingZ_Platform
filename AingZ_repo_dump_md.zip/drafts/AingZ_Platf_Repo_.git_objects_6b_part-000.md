---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/6b
part_index: 0
files_included: 14
size_bytes_sum: 10711
created_at: 2025-08-31T21:08:15.623156+00:00
integrity:
  sha256_concat: a94412fa9eba8709aa969b581bbedbda07f890eef18d32762ca12caec29a2d94
---

## AingZ_Platf_Repo/.git/objects/6b/04fe25d9c03dc558eb937687c69711df005db2
meta: {size:1436, lines:0, sha256:"e1fb3a17deb799742af3e77b417b99ae6fd4fe73607d6a3f377369f0f16ada2a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6b/1a79204480a2f569ee3d549dc898f54ee7b6e0
meta: {size:1838, lines:0, sha256:"226b8294ce87e08dcbab8d98485166338a90ac0c5236a310a0e6859618425597", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6b/1ae666a8c86d6e9b62982a2e950b9459a85f7d
meta: {size:299, lines:0, sha256:"4c8bbe053f17261a56eb08451fc50e1ffaab17f8c3eee78847f926a52082383f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6b/2485f4a3572efbab655277326a0197b983719a
meta: {size:462, lines:0, sha256:"ac639b3a7626d057ae145ded160f047021b4c01dfd0668ea2dacd07600e000b4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6b/4541421f152e6f842a971f25872bd94b24a91b
meta: {size:232, lines:2, sha256:"de4c4a4499f537ea460462ff29f0d40331a47198b8a10f96fd5f273555c73389", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x½nÃ ;û)Ø25\pUUm÷.»D/`)6%§/ò]ÎÏwBY×¥1	ö©U"&x"m¤4sÉcÂÁ#D¥@£í$Ý¬ÝUÚÓ³åJ#RTb
®!¢÷ÊY/|0[tâáG²à&ëBCo#­EQ¯	ap×KeÉÝ[Ù¤d¯éx§\nTßÓêË1õu$Å'-Q²çÌ®öKþ¾¨&b¾º-dvè3ÛÈrkûÏË8¦¥å«ÿ[hãéöy>Ñ^ÎË¾_?³fô
```

## AingZ_Platf_Repo/.git/objects/6b/4e25be7a0f5d3c17efec797bb7f6b4553b5551
meta: {size:133, lines:0, sha256:"20ee5ec143422201955f9a776f137fb30fe39f176b2b0400e5e43195cb1d7b05", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6b/5a5f93a3abfeac8cf3a753fc5219e77aa9b9be
meta: {size:920, lines:0, sha256:"65233aa16a30254d1b9c0c74c7bffad16e564067b30230b926f019839eeb1644", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6b/6ce760cca7457fd19ff4aa900c53a300b23d49
meta: {size:196, lines:3, sha256:"6a906bd104a7ddddbfbb7e36f5e16b4b1dd5f55c6caef7bff9f6a0500c5f6749", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xµKjÄ0D³Ö)z?±¤Ö/¹FBú´lÃØäv ·!ÛlSËªEUnëº0he¸j«,tÚ¡rñ^[b¨Ê&
¡Fñ6GHEÉSÍdS2+W(ê`UJª6Õ2xðÜ:LÏGºÆÌKÛöÔø^PúàW?Ò·c§¾[ëô¸¿ÄÛú
ÒôMppOÓ=Ç0ýs¸-Ûô·é<àZÏ3íÜ#ÓõÅÇGlÚ
```

## AingZ_Platf_Repo/.git/objects/6b/9230d93b79729f53fdb7ec60c6c84f9614f4c7
meta: {size:279, lines:1, sha256:"5fb27433072285aeeb780afd0c85df91959a26ba3f91df27ab7be1aa12938000", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÏJÄ@Æ=÷)^v/­ >AéuYÚt&]ÓIÉL·îsyóº/fzX/Â2|/¿/Óéàæöúâ6õ|¿GqÓ@1cfð$ÁÅÄÌ	zR1}fÒhÅPÝ;ï%£hF/©,^ÒÔ9Ô2BÛ¶#6µÙ,&U+³¡S¢·!`é>7gVíÚß2`0POðj/ïC²N?-&ðÀÞnÜ³q³Ùè`J`³PYLSÚ®Ê²ú2ò;JÕ"z¨tnºæÔÚ8ñÔì++ÊÁ¯ËÿmjÚ³ùÿ¹q	àO?âøøçµ(JnÒ´lü,ª\
```

## AingZ_Platf_Repo/.git/objects/6b/990b1534198d9d399e026f715a4a9149fbd5b2
meta: {size:573, lines:0, sha256:"dcf4b960dfd08eddc06aa75a353b6698b82a9e89c0ca52ad88fa506263a4d6eb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6b/bb5ab8185a71f6f318daacfe87752471d55a4f
meta: {size:3383, lines:0, sha256:"391bdb347a549366ae1144528e1da084f479c2a67900e3086cf1322789b2bec7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6b/db4ae618c545788b6e482ee5adfb9a06495f64
meta: {size:724, lines:0, sha256:"633c0bb494006c1c821a4bd4e8724096c7d7a97b117d78801ca22832d78d0f9f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6b/f6a303abb86f87fd303487a89401a7ec22fa96
meta: {size:126, lines:0, sha256:"0501a36aa1a8afde226e56d8b5d589176ae227f338438f461bcbea79524a5a65", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6b/fb22b0e0143bceb4cf1d2cf7ae39324d4c1e28
meta: {size:110, lines:0, sha256:"2d8bd785b979a18b303781e902bd5ed8cb75bdc23e86a84490eca1672d4d06bd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

