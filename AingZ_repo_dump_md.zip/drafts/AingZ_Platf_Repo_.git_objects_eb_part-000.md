---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/eb
part_index: 0
files_included: 5
size_bytes_sum: 2237
created_at: 2025-08-31T21:08:15.651180+00:00
integrity:
  sha256_concat: f8ef9096a7fdcb604469d388527264e50883ea71af155e4a84dff3c8e0488559
---

## AingZ_Platf_Repo/.git/objects/eb/0ab819847107ed9eb5d66ea3292720a1f256b4
meta: {size:175, lines:0, sha256:"f420acac7c657d14334a4b1da3b7718572b4688a566ed9e963a3f773b389d8af", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/eb/6bd3b7809d9abdc5cc6cac7aee626de3b62aac
meta: {size:170, lines:2, sha256:"97664c77ffd555cb59305ef212405d5c9b1d3a2186f6cb24f9cd25171c2d921c", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎM
Â0@a×9E.`Éo]º<ÀdfZcJ=½=Û<¬¥<4VïÚÂ,3y²S`ÏYcoÆäÀÅ:"éÈhbßMZL½MLÙFÇ|Oà¡1Ø&èO{ÔEN°¶ú¶V¦nåã£~y9M¯k9J¼ÓÎõÚÈ½²J­nÿÂâ>4·á|¹]!ñ;I
```

## AingZ_Platf_Repo/.git/objects/eb/77fc3529b695d4ad05942590292816a58cab17
meta: {size:769, lines:0, sha256:"75e357b96e2151af60e127455164414c312000db290e91ac81b145b0f0b337c5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/eb/7a3e1eb0cc6d87d24ac51a5715ac93eb566514
meta: {size:534, lines:0, sha256:"2a9e06d193f60f680796ac1412c2580fe60e715a123bfaa517d73c487447fa3e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/eb/95cba96cbda937d51383fa9349284bdc23d56b
meta: {size:589, lines:0, sha256:"5c5894ba757a7a28ecd2df49e155131a9e51e48726b16d3e43fafe1ec2295306", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

