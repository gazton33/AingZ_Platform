---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/7b
part_index: 0
files_included: 9
size_bytes_sum: 6430
created_at: 2025-08-31T21:08:15.624793+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/7b/134695f4f718737eaf31822ec3c303a4d4ed38
meta: {size:321, lines:0, sha256:"efec22cd99d434f16c0557a5339945f37c238721890c58a7dc63df895f73e4c7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7b/253118b48c64d9ab3826c3e94088c31a7567d4
meta: {size:800, lines:0, sha256:"8f50fa6658e79a5163c28f173264ad2629baa7af18461f8559fa3f0f87ee4d03", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7b/3fd45eb18952438d43f3b6bf48a0cc0e44a071
meta: {size:1874, lines:0, sha256:"355e4e3a815ea50b475ada3e9815ab75f50ee3705b339548e44dcb6688020c22", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7b/4f12b619802dcae9f0b5e93d209191d3c97c8f
meta: {size:57, lines:0, sha256:"57740260b97d0398a2524d226cf400f71aa0c6ed3087bb7e8a3f88856c6adbf4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7b/8b6c215099fefe1915493a44208fa0d69d7ef6
meta: {size:1174, lines:0, sha256:"88158bac81d358d9c21cc752d8101f2cdf416ec4043b7fd3555ae90753f1aee1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7b/c2833ead95b457c3eeb9e6216567cf5b4c1612
meta: {size:1099, lines:0, sha256:"895d4370b06a68ade7c7736287e306a03675e40aa5104e1a0ceeca9a171fed95", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7b/d0fe6d555a066091a8b95e682024332fe74e24
meta: {size:144, lines:0, sha256:"c6160f43e7d3b38bc9ba888d4d5d7ccd837a6288b910bf9d32403b9443aaf686", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7b/dd463589befb58b587c22eb678ad049b13ea21
meta: {size:883, lines:0, sha256:"4dee69c2464880ce11779038db5bc55f91b3f702619f01bd6d02525e027181b3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7b/ebd2712b3ff97af98ffc6f391058e6a5e9c06d
meta: {size:78, lines:0, sha256:"7bd2588ab6f34003a87ba01defb965e3b7938bc45dc2387ec36b77d5332c7ba2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

