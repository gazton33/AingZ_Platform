---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/08
part_index: 0
files_included: 8
size_bytes_sum: 59135
created_at: 2025-08-31T21:08:15.566781+00:00
integrity:
  sha256_concat: 3ad75c4e654ec4ed56ad720c018133a5fd09776f8ad636ec57dfb4fc95531819
---

## AingZ_Platf_Repo/.git/objects/08/055bfabd4ddb9f04edb3bb1ae9bba85cc993af
meta: {size:328, lines:0, sha256:"e27d68f9ba8b7b3babe5ab7e28f99d86e6b6c443766bebadc7027f9557f26bae", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/08/1c07797ab4c815b819094059cf30f6dc024674
meta: {size:66, lines:0, sha256:"875b9bd4d9f39b9d21d7087477052ed74f15e95f55f856fe6f4e9904decd638a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/08/320e3446249109e41bf8c856095cdc64b390ab
meta: {size:56259, lines:0, sha256:"250ac1b3cfe5d9dced725fba7d22f69aa6d2377d10a7b0957b7f9eacf9091940", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/08/3ddbd9e0cd9465473b87ccdcab467578c8f6b3
meta: {size:115, lines:0, sha256:"c18851769d5ef57853463adc83b1eb66b978a36a4015e440b113877ca90741e3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/08/452c46e35b7d3ed8079edab92d3ab3098543d8
meta: {size:1245, lines:0, sha256:"fbc0e5e05dd2b8d9aa96eb09f88a26c7ae6137635bfeb2fc7079ea00a1c0c424", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/08/61d94050558c1919515f2af9a17e785d63f5ec
meta: {size:200, lines:0, sha256:"8cca38b2bca1c819bd44b18dbf8dc88ced657a50583778c9fe592ad4375e4554", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/08/909ea77a00d0249e609ebbdb9cf89599a99245
meta: {size:763, lines:0, sha256:"369ffa72ab53ac017838996ca5f73943640691e6dc5d385a60af98f6d5900b38", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/08/db69c895f5f758aa93cfaedbefd6d455d32fa9
meta: {size:159, lines:3, sha256:"661537372d81d3972d7daa75c9e2ed78b425954adf4c178f13beee1acfac6ed5", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎK
Â0a×9E.`Édò¨{!I[0ÐÓÛ3¸ýá?µZ.5Ð©oÌ²P),ÆBDÐI±w	M2Úcï°ñÚ¥Õh-g|6Ò¡Øâ³CYÕL\áÓç¶É)ì½­ò2;¿8ÍíËÛ}ªay©Õ«o8íF'Ï
G=;ÿÅóq?Ù£D
```

