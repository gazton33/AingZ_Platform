---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/f2
part_index: 0
files_included: 7
size_bytes_sum: 4741
created_at: 2025-08-31T21:08:15.652063+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/f2/3b6966dbbc4b741f47d66649790d145f0627cd
meta: {size:939, lines:0, sha256:"60def7989566a48652455b64d192615f0eaebcb0ba373c70210786b8b60d2706", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f2/56576d21c2d97db846b26c5ad9b2cf3d9de4b0
meta: {size:110, lines:0, sha256:"304db260f3ec6162c8a67124ef074773ca261814e858be4734491e4a7b073784", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f2/62ee21262650ff80ac8dba9f3466225a071b03
meta: {size:54, lines:0, sha256:"d93c4cdf57892b85749c2887ab45b1f1f4ba0a6a8a063342f2eb74dcf964464f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f2/66b4649965a8cacc671c22bb62a9b15fe74282
meta: {size:54, lines:0, sha256:"83637bde3093d08e9965d03a95158e8bf38bf9748f2746fddaf92087f20aa5c3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f2/a22d11befc1477972593b50cd0ee2060296e2b
meta: {size:1341, lines:0, sha256:"79f9873aad17a8443ee35f33ca2d06fe5fe89a1d132cb6d72f41ed4273bd51f5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f2/bccaf42ca0ae8e41a09a26d2b487b660a1e829
meta: {size:1372, lines:0, sha256:"a1ba8fed251fc72b12dee7eacd97baa85ed0959979fbbc6472482c41475e7765", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f2/cc88ad7529ca8467652e5f12987658272e2f83
meta: {size:871, lines:0, sha256:"705e992e26db1e0fe96d80ff79482c6f6e4c4c3fd491de1abdb0dd04267be8b3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

