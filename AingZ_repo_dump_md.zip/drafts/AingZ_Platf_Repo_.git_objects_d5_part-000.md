---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/d5
part_index: 0
files_included: 9
size_bytes_sum: 4259
created_at: 2025-08-31T21:08:15.649392+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/d5/086d52bcb1bb1228b9a82af58e4ecce4ff2736
meta: {size:1295, lines:0, sha256:"eb553d0db133aa6a52596ccc793977a85a9efaba47cf7412ccde0800ef7022b9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d5/5cb7ccf06ecf3ca8e1039a8ecb45084958af9a
meta: {size:51, lines:0, sha256:"28b3b509847ba429c15cb8dc1c42657e189ad7b05089e606b3b8331e70786a1e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d5/8a8aa82df344184af07b578ee6d23e061e7b98
meta: {size:612, lines:0, sha256:"476442709b2651180c77a7ab0f0c39c2cbb2d87bd357e9450622f95c712b7fb2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d5/904bbfeaa444aff8137b6e7f675da3cbe05710
meta: {size:161, lines:0, sha256:"c0d2b1a74c248491e171830b9da3466589a1f07d8a677f0b4ff2147abf918f65", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d5/bb2226541e0dc1f5faa041382c4081ce2072f4
meta: {size:484, lines:0, sha256:"62261d6dca88849574503e2df927c2541612519c7680103520d6201401c28046", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d5/c042e5f3f8f55b387ef0e133545d8c16a7a36a
meta: {size:841, lines:0, sha256:"c5e7c2b0c90f2c5ae1e8df4f5a3101b59b57b96e063f0feaf5dbc66a2318688a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d5/c8bcb21cae2ab474b20b077210440e97ad4cec
meta: {size:82, lines:0, sha256:"e7b1f5544f611a7426a53bf31f7657b89b036531d0a97d0ecc5a7988d71dc55d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d5/d5bb12be63a3233a0f58aa039fda16591c1c21
meta: {size:630, lines:0, sha256:"f2e006ce0445c5710a53d3315c2a8ef876a83e7efb5ae667811ba900748c7848", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d5/e19e43a0f427de352467292f27e378441fc04c
meta: {size:103, lines:0, sha256:"7e86104e976c4e928192f5d45a8779337d49ec8a5de7d83c91d7a75c0524f4d0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

