---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/6f
part_index: 0
files_included: 6
size_bytes_sum: 7616
created_at: 2025-08-31T21:08:15.623702+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/6f/275f7103356905276c8bd1b0fca85ccb046277
meta: {size:1248, lines:0, sha256:"94b667150647507ac6d86a752eba48410b81f027236d82afe4521ccda4083814", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6f/9509c88bed7080d496fc5e1d87a9315e30549d
meta: {size:59, lines:0, sha256:"b997ea11414db588856ded0346306cf4b8334aedd7e40aea0758f4d5ddafb448", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6f/bb63ed122c9034b30a42f3032868ec532578f0
meta: {size:840, lines:0, sha256:"fa49f8f0b204925da6c970551e6b83820d9853c4430a1d7106724dd732b5c3de", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6f/c12ca574ff47f72ae779b5246324e92c5140ba
meta: {size:3210, lines:0, sha256:"d9a36edd12d9e503e7e06ce1aa1ba965911d26eafa7078a789a21087c2c5d16e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6f/ca778a1a10046cb3a1a2b179aed80119cc6d08
meta: {size:634, lines:0, sha256:"57c3f2dd8030f73a2993efc42e5581ff77c17f0af2e33446e4a16a19836d3081", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6f/d9f56186029596f60ee2d7e3d3c6e134e076f5
meta: {size:1625, lines:0, sha256:"c52bc7a1f621f82ee7842aeba38b36443fcfb1442bd90ce9cf95aa765931136b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

