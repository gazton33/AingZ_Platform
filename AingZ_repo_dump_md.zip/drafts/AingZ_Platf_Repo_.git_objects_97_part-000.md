---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/97
part_index: 0
files_included: 7
size_bytes_sum: 6811
created_at: 2025-08-31T21:08:15.628025+00:00
integrity:
  sha256_concat: 8c9a8890220d9d6869bf90f9af7d0b296f23b7700fbcb7f23e3d961e6b2f0267
---

## AingZ_Platf_Repo/.git/objects/97/0b759dadffe68be4834a583f8c30ce9bdfe8c5
meta: {size:235, lines:2, sha256:"c6385123e099ef4213867d8c6e1a88b8de9843158fbf024199158419d9250a82", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xAK1=ï¯Xz.f­«ö*µH¡­"èEdØ$£M6C2ÕúïÍ¦v¡
ÂÌoÞ<´^õÍøìµ(Ë5ï¨¾EÁèH/ í)ájÀ-c«ö0ªFWP¡º>wz0<µîÈlÓþ[wÄ ¼Æ-È&¢5-fµBµîï*PÈâéy>ÉÃÝlyÊâq>»]N¦ðR÷´§(ÒvÜ%\|¡|iõÓéÆÈY²kþÂ\!19Ý®Û³9èï¨!Þøí÷ü±gë?²T â­ø¥.¥ý
```

## AingZ_Platf_Repo/.git/objects/97/13ad343d27cc46a1d1262e839afc8a56edcd7d
meta: {size:4490, lines:0, sha256:"e11e9d66082e23b1d52fad3ae8e6b5d2eeedebbd3d7da934a3b3a52365926e02", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/97/3d52b06d04bad255d11f7ab7108543121d781f
meta: {size:115, lines:0, sha256:"98db48726bfbc017a06c6cf48819dcaa966ba270c7308fc2926ce24f1e298c73", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/97/5440b0db7558c23c1cbaf552c47baf30683edc
meta: {size:924, lines:0, sha256:"c075e17f919b076aae9a251c3a7076bac32c077c326c6b1afd226c414b2761bd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/97/87d5246c9140d7e79df6bd3e90872e2d97e13e
meta: {size:91, lines:0, sha256:"db184e824c1a3f06b81f23f48de477a5a7dcf0f105764cf02ddf7e23cad39af8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/97/9c063b346ecd72222dd5cf44ce05d4606e98e0
meta: {size:99, lines:1, sha256:"c2aa61620f8b0f3191319f0d68d11c7f001dcc3ba92eba24fbbc402102e7e41c", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU044b040031Q(IÍ-ÈI,I/JMLÉRåñIñeñÆñz¹)>Ù¢-bMº¿@àz²º©J2~& méé~ý³ÉÙðØ.óÏù:Éáÿô-)
```

## AingZ_Platf_Repo/.git/objects/97/9f22ff8002d6712be6a3785a4c14815d42fbd3
meta: {size:857, lines:0, sha256:"803c55a7ccb0c1c8f25ba4e29d12d41f22cb41cc5a48691d683c80dbdbc6649b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

