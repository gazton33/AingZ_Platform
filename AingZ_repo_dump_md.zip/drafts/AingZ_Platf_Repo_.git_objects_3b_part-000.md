---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/3b
part_index: 0
files_included: 8
size_bytes_sum: 2982
created_at: 2025-08-31T21:08:15.572136+00:00
integrity:
  sha256_concat: bbbdc313869d71161cc3f3a2c23efd01b255f0121b80de64e0db62989ff344f4
---

## AingZ_Platf_Repo/.git/objects/3b/0330226cc0239a5a75ed8711f7eb84933fe5cb
meta: {size:190, lines:0, sha256:"ac4c0261af5f7d757fb3226ba087c431f1c2e0cb3e297334ee2f3ba9a984337b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3b/20374230a435c482b206d12ac8ae221256a58f
meta: {size:87, lines:0, sha256:"9a6028abdb976bc0755b59ee7d24785351988ba780adbe380037f22cf9fb5bed", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3b/31f1566015e075b8be3f8c15b14defc8462f56
meta: {size:590, lines:0, sha256:"ebd95ed113ad1ef84cc0b28f822e3679615a5834288a452c523862c3cf4c18f2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3b/3eed9b429152434f08d4c8095622f0333e0f05
meta: {size:139, lines:0, sha256:"6f31c044b0cf072531c32505690ec0156a6f37092eca2ddf60de5888c9589871", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3b/6d76320172800111c34515518a5514f46b7ae0
meta: {size:288, lines:0, sha256:"f1d586c9673722bde9e9caec32d2baee4c705e47f16884387ace25f8d37e650a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3b/a8647704968f1de70998df7cb0c1fed6946529
meta: {size:1173, lines:0, sha256:"4fdd2d1568ceb2c2fb0d54eb6acadf04ed1003806b705c286f520e768b2c3ee4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3b/c5494685d7f8f65a286f19f49181f36eef4f43
meta: {size:292, lines:2, sha256:"f24450758826727a39d6171c452546a79eb9b32bd7168b13abb41cd32fc5d149", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xu1OÃ0ó+ÞÖÉíÐ²¤±ª¢$½*ôlrçÒJüxl'-¢É²ï½ûîùÞ5¸_®î¸>PÖíèdZ¨·L¦í¨}/
Çeø ]:f¨9¤ÄæP[ÞæbßW}ýGT¼¹FRml~FG|YM`¦¯5vËDQòÙðA¼nÕ:EÒ}8®²8)Æ8¯¤ÏgíO5Ü¸4xã³ä§ðiu1~V#©%fËùivÃ{bÑºï±#O¼#n-Éãøº^»Çfômv ±Ê\OíÚÃ[;µ4ÃÝ{{3ÀK`<¦â²C;3ä¿/§(p^q¨*ï¢ºªãªÊ¹?ßáx¨Á
```

## AingZ_Platf_Repo/.git/objects/3b/eeb22d79eab9ba38c069231d65e63f79c15f45
meta: {size:223, lines:0, sha256:"3180ed04b8c52d7aba6ab14370295f71ebf5d98b780b2d718f318f8db07d9f0c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

