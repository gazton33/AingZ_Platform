---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ae
part_index: 0
files_included: 5
size_bytes_sum: 7704
created_at: 2025-08-31T21:08:15.629450+00:00
integrity:
  sha256_concat: 20d859ea90342f2befb9f575984d3a9d06bee2ff85d2c39526d9b14461795955
---

## AingZ_Platf_Repo/.git/objects/ae/4f8036b94ed64b632d76f181621bb1de0d5e41
meta: {size:1373, lines:0, sha256:"3ac95a04556d6fe3e56b1f0719052f242228037428591ed65840eb1d4922e978", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ae/576f2afe1cfbb4861237c45523b3f075793e1e
meta: {size:4640, lines:0, sha256:"b526d3e6003dba50a34c07bc9f915830fe6986a984d2a347c52f975a003ad172", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ae/5903954bf88ee79ca1a76890018d8709eccda0
meta: {size:862, lines:0, sha256:"f30da716dd629f5c998e0778a2315253cef55c220b9c21ae1c84cbeaa3d0dd8f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ae/6b419cb69708c9cdc2dbdfcd8ee91beff506ad
meta: {size:643, lines:0, sha256:"fff894d1d4fdc669dcc82caee3e7c53c57e56106f04d750b18a622c333db7472", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ae/dafcfdb67d4b198354239a9dcb55f196bc96e7
meta: {size:186, lines:3, sha256:"35ede2d989e46c004e2d9b37c36c2fb8642466cb0e35ac8e958f855893bc8f9a", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xM±MAE§
K"hàï¬Gð÷<^\7p%lcxÈ¾¿üß$:Ññøxw ¸Õ+ñ§së
ÃWã±ç§wøóë[J§óºÝhp@lûî$:hÙcc·È_aÈÎ¶Ý×Aç)k[´sO{ÿ¢öQD/ÿßßÚ"}VPíE­!×í§ïÚg±*qê0ZØvH½AeôQÀWD
```

