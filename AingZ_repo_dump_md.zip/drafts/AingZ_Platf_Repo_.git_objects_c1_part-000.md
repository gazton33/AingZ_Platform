---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/c1
part_index: 0
files_included: 6
size_bytes_sum: 2848
created_at: 2025-08-31T21:08:15.630780+00:00
integrity:
  sha256_concat: 0756bffaf6ac19a030e63fdb663da8e45f0c9ad3098bfa75031c14287b22db8e
---

## AingZ_Platf_Repo/.git/objects/c1/175ee390151532252371be127276c086174059
meta: {size:609, lines:0, sha256:"4451344367448f75a3cd79d4aa7c3b398973d1960e7f1bd9fe130bfeeae92f1e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c1/3f99117e366fd54b4c097b67ca34dfb1fb8ba1
meta: {size:646, lines:2, sha256:"de5f2f2fb62d4ad86889c6ff369fe8666c34fba7dd8b1e0c2bbe580d73a659aa", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x]RK0îÙ¿bÓVBÛíªí¡7Å*`dMsäáWGØ4Úß1I¶j%$äñÌ÷7màóÓ×or® 3­&$¶ç·É{íGx~zþBH©§qÎØ^OºyãT^w&­Á íëé¨#ðêñÎzr8`_ÑG¨¡El¾GgþRO;¨³­©:ÛÎ'=úÚ¾´ßkXU·ÕÇ¤Óõ@ÌhîWp1¾·³I;?6`D`Æv» á~=¹1ñÅ°#¨|vè èàd;s½Ø:ÏÍ`\Agt3{ìt¡¸$ìNAº¯Õ-=!Ìùo¹P¹ôöô¯ãÈaF¤ÄP°£³ÙÂøK·>Tò{	ÖZ;v&øuß	QxU7ö·^¼\÷9ZR¸,"®[½]¹¾hô-0äÅx±ônÝÍó¸xSp¶ÓÂ÷¿ÍGäOTb£vT2àR¼ò%°¢Wì¸JÅVvHZ¨=Ðb?xDÀ~UIx^faq¶Mxñk+>ZOA@xâç63§L×<ãjWEÀÜ	J*·Pne)*ô	Â¼ØHda9+Ô#²bØ+ Ji*B·¨^}r/ùKª YÂ°¸f¨®3v¥BSqFyABsúÔI"Ih»ª]ÊB)ðQübÅElÄ¢Pºê}tÇ+¼
l¤È#âÄ	DG+Ø%D½ô¾l	mÑô]$fë)÷æGòµRO
```

## AingZ_Platf_Repo/.git/objects/c1/719dac8af8213dc76834e1976743f028b33963
meta: {size:344, lines:0, sha256:"365c7e8eb82576943f2fdf9d467c6d1eced9033ab7ff234c1492ec9fdce6da27", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c1/ae34c67fc848f24ee4111fc4fb93fc3426e1db
meta: {size:591, lines:0, sha256:"1e3ebedcbed3ed0f4f12612ed371791284a171bcf06237ae1e611bed70987988", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c1/bedb9aed3e05caf6ca7ff895ef2d74081ff811
meta: {size:153, lines:0, sha256:"d00e56e39f3c0b6a7d42b1b9ea5980c9b82523e20ab31c4c93a017d1b583bee7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c1/e9aa1fa3cfc6d054e95fc9ecc5ecfea36079d1
meta: {size:505, lines:0, sha256:"000b27ca56b917956cef273f68f52f130a327f521216b71b4e8de129495d9425", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

