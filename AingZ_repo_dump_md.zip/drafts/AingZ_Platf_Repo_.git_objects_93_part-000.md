---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/93
part_index: 0
files_included: 9
size_bytes_sum: 9766
created_at: 2025-08-31T21:08:15.627755+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/93/0d7ccf56a5c29a54bba75bf0ed07da479127ea
meta: {size:240, lines:0, sha256:"50ebb3343dd04d7a2c91e4f1e40ada393f884515ca4331b109d23f58f2aa3367", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/93/1fead6ab6bf395e3201e99e1f4b0fb8df42bbe
meta: {size:147, lines:0, sha256:"f0e041bfa67eac19b2cbbaec48d19c9aec33e7eb744d66cbc76b1ba02527c55e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/93/4b800570dabf286f19bc7101195dad1d5feadf
meta: {size:2809, lines:0, sha256:"45e8164615d604b58037f341df9d35bac3b52a44f043f2fcb90629b3402c492b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/93/7fad0b763818cafcb775f793928dc195582ebd
meta: {size:872, lines:0, sha256:"a16c70db674f88c2449f7155d3c060c6452297abde3f9b72e1c89d8373a885ac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/93/9d3f2ff96e5c54ba6a25211b77ab15b19f04fe
meta: {size:1154, lines:0, sha256:"fabc627fc1137993b36d7ce7cecf908086dba7e14e0e4a10607f181e6770771b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/93/b224c96804581d36203296e9621e8f907b9fbf
meta: {size:75, lines:0, sha256:"e71cbd156ae34a00cc5dd5d09772077c894c4e1211dce6c80d9174b4cc2acec0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/93/c518def7e5213987a95b5782f00850807890ad
meta: {size:762, lines:0, sha256:"f30ed555b0867b51849fefdb86e403dc2e5ba69009973f5760a8953e4dbf78d5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/93/d1f925e5ab60702a9e61b8dbff2175a5b14ca7
meta: {size:399, lines:0, sha256:"4df0e213a6930f3b944d1779841d09e0cd715a8bed8587d4376e3c38601cf7b1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/93/d771d3381fd81d041e894b8712c75e92d54b73
meta: {size:3308, lines:0, sha256:"42996b03650b0d6459eaaa98f8eb8823142bea26b66754c591a4aea73984775f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

