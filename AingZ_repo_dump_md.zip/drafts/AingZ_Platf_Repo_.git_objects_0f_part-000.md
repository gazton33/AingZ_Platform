---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/0f
part_index: 0
files_included: 6
size_bytes_sum: 53206
created_at: 2025-08-31T21:08:15.567688+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/0f/331eda3e221c1462b838679c2a6788b41b82ca
meta: {size:5239, lines:0, sha256:"4cb1e35931801dcd735fdb02727280a29d9c97daeaa087f29f7496b6c64f42dc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0f/3a3ff8bba3fa989bcd76f39ad427fc77cddb1d
meta: {size:85, lines:0, sha256:"ec3154302d018f50b2e2eae5c58e2d7cf191d883db853866fde955659370a4e2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0f/433964a066b2bbdaad230cf3a0ac347e69f2a3
meta: {size:91, lines:0, sha256:"e57ae709c0e1457c9dd9d36ccb6ebc98e59afb4fe0763273727720405d99f547", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0f/59240005fd8d6627e28ab1ed3a388ffe855deb
meta: {size:855, lines:0, sha256:"51fe608a13504532a48e12026892f4f7f218465657d0449eca9a3be9c9ed5382", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0f/893b86f2ef33a5a1c2a391650243cdfdb70cbc
meta: {size:779, lines:0, sha256:"6383cb7e18f32b0604cd9b9111def380043400f8fb9df88e320c14df829643c2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0f/a5e8249e57a49ba1da7731ca7b99187087cb02
meta: {size:46157, lines:0, sha256:"66f18a2235ca6e9450dbf9ef83482ed96df71dab754a9dd796c6372956672a48", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

