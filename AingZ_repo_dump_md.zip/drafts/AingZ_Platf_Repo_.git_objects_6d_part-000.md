---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/6d
part_index: 0
files_included: 7
size_bytes_sum: 6107
created_at: 2025-08-31T21:08:15.623547+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/6d/06755bec56a068fd30fdadff7a293da7431a53
meta: {size:426, lines:0, sha256:"8c3f4d4875ae8d393745b1897983c72dba2455c768fb737287f994d162f79993", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6d/28d0779861f5452e4b3e1bb285449879842177
meta: {size:214, lines:0, sha256:"d4cd2a604a88574043a93622dd1217d730ff1d1e1f742474f782334efdc72da0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6d/2e5f91515a52c0ed1e581825e3501be30e89a8
meta: {size:906, lines:0, sha256:"6c0c8e4a84d694a9423e804ada521c17e9904b10f5f78ec5ce13217543f472d5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6d/3ce491e1a8bc8d1e11410e0d9ac485cea5991f
meta: {size:1661, lines:0, sha256:"c59cde360baccc971e15d373ef7e08de72aa34a7f39d07be620fe6b7a763dd65", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6d/e0243f4b6091d21aa27a4c2ba696a222b5bebf
meta: {size:1419, lines:0, sha256:"865fd84936ee4155450afdced1ac18645a0302da939dba2f7b5270e98af61d71", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6d/e56ed9da7728fac93c9c80f85086ee95253066
meta: {size:847, lines:0, sha256:"1ee78bcf86f909cbc5368ce6934bc9e80dab2873474bb05691d55ffb459c8ade", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6d/f05cf50deaff57e59db8050a208b7084749bc9
meta: {size:634, lines:0, sha256:"2dcc7375cfcd114d75c23283c90adf0d39bdba79b6ca815db18b1ee179d53ec2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

