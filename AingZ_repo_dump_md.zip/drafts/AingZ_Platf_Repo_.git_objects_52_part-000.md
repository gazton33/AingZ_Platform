---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/52
part_index: 0
files_included: 10
size_bytes_sum: 6576
created_at: 2025-08-31T21:08:15.619727+00:00
integrity:
  sha256_concat: 18da70c1ba9b541c9096ba986912c16d5b33b41b7814f1d2ceb9527370f777dd
---

## AingZ_Platf_Repo/.git/objects/52/0dccf816abc0239d6ac5e925b22dd63c5b38fb
meta: {size:168, lines:0, sha256:"04a2609b0fdb115465ae48100b7f198709d32bd1eb4056d3b7b70ee1e6f036db", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/52/17f916895289afabb9c09a3b7fc0caa06503b2
meta: {size:80, lines:0, sha256:"6868f572d274812f88671d459b1ba512b58e8132607fabce1dac9f135c4009ac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/52/183edc13d60f404bb8309528e300ed8a513afd
meta: {size:2520, lines:0, sha256:"f60062eb3278dce0497b1f96f58032495ce120f2913c4450040c3856f6002943", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/52/1e9555df82ce89602d5adce728196db8a2fab2
meta: {size:962, lines:0, sha256:"da1c05375f00b21c37af1112229364b5ed075979a135acd98c66681c7f7cd9e6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/52/2f8f32f1cf5dbf90f125c2ba547df56dd7888a
meta: {size:714, lines:0, sha256:"d865c83ae6884f3e53606bc1a02c25949a74b5ab4c36c52f9d66a7d94dba5e85", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/52/30609c69ab5c4e4137cbba8cf7d15f7174157b
meta: {size:65, lines:1, sha256:"6ea3f2fc9d3435b4c6aab01a55130a1a8640eaca6aa9eb8a08dcbda4c1255bc0", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU0±d040031QHJ,NÍÉÌKOÎOI­/3ÑËÉOg>'oØ.èY¶áé_7¡Üÿ_¼[
```

## AingZ_Platf_Repo/.git/objects/52/355ed6c7d48bf02af5f7d63eb23e0152e8086f
meta: {size:883, lines:0, sha256:"e08abc10a66f1d632ead9fdecd184afa328b09ce95d57fb351d2a7c5da0413b5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/52/4e89146da22a363c23caee96aa2e441f5f90dc
meta: {size:851, lines:0, sha256:"23ebc6c6ecc986aa0ae732c04cb118139bfe87eedcaecbc795a9efa4e2187ef4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/52/556feeebb6f18a74c183b8a5ebed4442489845
meta: {size:154, lines:0, sha256:"87e73ef722513b3bdaf577cda5919b34fdb7925110195050bd8a206d24c49dd7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/52/88fe9dc819f7c852fe4a72eb8ac8c6a8247f9e
meta: {size:179, lines:0, sha256:"40045e218a48218a62afb31bdc8a65e26f2af49c508e81ffde059b4263b4b126", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

