---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/c4
part_index: 0
files_included: 7
size_bytes_sum: 5651
created_at: 2025-08-31T21:08:15.630968+00:00
integrity:
  sha256_concat: f366e94e328a0dd4e24902da976884ef7fd579e05d2fac9bb86df0ec2c45a4d8
---

## AingZ_Platf_Repo/.git/objects/c4/52de0bb5351138ecc2b4d32ca891abda9a9e84
meta: {size:246, lines:0, sha256:"2aaf79b25c77c416f82a4a4f2777683fc251a77460b0ef609161de0ecdd39249", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c4/6a87a632da935f57af7a099bb063a04c7cfdeb
meta: {size:702, lines:0, sha256:"82018b6ecc409cadc45db75be5adc92ba235cb6c8c1b4e8f4fa192283278c9eb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c4/7146af607691540d7bfb1bfba5b06bd45d4814
meta: {size:713, lines:0, sha256:"2cf6e841c27b039632c612baea10915475d89fec3db15287809f8581de5a8536", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c4/bb783c63222531b1289f77a466cbac8a4efde7
meta: {size:160, lines:0, sha256:"83b7e3382645c2364562d206138a1374a43572bed2a082db166e4d3c448e8217", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c4/c7d40daa9bdd3e761cbb1ed751b67c6750a973
meta: {size:1195, lines:0, sha256:"10e8403ae0aa9597e6d12baa48116d96c5dc97be32fa0a8aadbf1e7e0e3bc756", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c4/c881e82a72ba76ab9b05140782da86785e949d
meta: {size:2438, lines:0, sha256:"fe0dab30bc2109e8664261f28b104316f6d08502d07ed38a19866e3c69d7624e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c4/e20f1c71b26a0fbf1704b3ed6ce389695a9d64
meta: {size:197, lines:2, sha256:"74f4a1efe1ee6a3fbbb53e68dc551804669994f9e1de1215def3648d4b28ef04", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xµP»nÄ LÍWl,E§»ßHÇb#áq¿RÚ´rÝ	ußsDñÒ£áËA4iIJ{¢<FAhdÒ+ötJC"ro)ÒÞ9¤äp½RDJz¤9sgßj5÷íô¯.ô\Ëñékÿw%ìb¥?ÔÛyP;¦R=ßÓ¯c
u¿0³²³ÒáÂØ`Ç3þ¹ÝsY?à¾Þ P7c:`Y[g?=Ào<
```

