---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/a4
part_index: 0
files_included: 10
size_bytes_sum: 8096
created_at: 2025-08-31T21:08:15.628822+00:00
integrity:
  sha256_concat: adaa0b637dd4b9356f5cbdcc7241ef3b4f06bd05405b812d4f41763ca6644bda
---

## AingZ_Platf_Repo/.git/objects/a4/3c53a5443f9d56f6210d66e2be8e469480a227
meta: {size:1930, lines:0, sha256:"44bb949e10974883f2ccad55735db20235160d7af90d523347cbf5cfabc3dbfe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a4/529ea9949d9bf8c7a685f25959681ca7a8904b
meta: {size:848, lines:0, sha256:"872c8f72e4ba1a9010d557c07a3539e505697ef7e844a4ccd0ecf8c47d2c3d80", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a4/5513b390f5be39d3f6658cf95ae1c05eca84e6
meta: {size:156, lines:5, sha256:"4c82409dbf1effa1cba043b89b33a1457de3f307f0e23434aa1a56fabb793721", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎ[
Ã @Ñ~»
7Ð óHJéVÆÑ< %X
Y}³þ¸pµnÛÒ,»µ£	õYÉù !¬%y¼MÍ[²7ËCHC
Æ,ÊY{±'éÑÈ§Íõ°­îö1ugYÎõ[×´É²vZ·§õSèíÝ¡sæÒk±¿b³ìZgójD­
```

## AingZ_Platf_Repo/.git/objects/a4/5c9877279e63b33f247cefcebf95877c4abfb2
meta: {size:209, lines:0, sha256:"57d225f6db1d8da7addfe26e49326b726fd283495efa5fded8f487170b3dac08", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a4/7e4f099b82baced5c16a8bc933c5024ca31a52
meta: {size:199, lines:1, sha256:"022109ac7cb0955cf082c168308402ea282ed93afd724a036f6826819c48dfd5", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xMOMK1õÜ_ñèIxÞ¼xºÌL±4]ðßeÄHHò>rÎå§Ó÷þU~PKbm@WÂGjýËópBñ;,4Øµs³ã8wíBã´Õ"À\4h*ÜsÍÎ÷x|CSyu°0ü'°QkÆÄSãe®pjW¶ùàvð×j£Fr¡`	;´<üùQ{È×ÕÍ~Ó Ú+rYR{ÿïÕCÑ»_^È
```

## AingZ_Platf_Repo/.git/objects/a4/8f8ef9fdb5c32052b3464173779087bcdc7d48
meta: {size:441, lines:2, sha256:"37dc1404b63a0159154776b63470f45a53b735946de0aed0362df1c962d19874", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xµÏNã@Æ÷ÌSÄ!mXW¤æÔBEÚåf&ÙaqðLZõex^l¶ü?m½DMüó'û³³(i¡ÆÉÙÃC5ÃÚÂ&PõòlFê(%gÑè<:¬Õ]PMMÙZ«ñÁ:R5SÝÈÔZ¾¢Hî6Oy»¼ÌãéÍ<q¼¶uXÆS
Æï³ù/ÈVuð'Úmz=¹J¯çé&Ã¿2­ó,³äÌ ÀÃÈEã#à]¡èêK´Ô´·zrBÖÖP´½k{^NfiÏð$Þ3;õ-°©	ÊaÌV0®z«úTjðæ¹zS»®ÿä%­<P-Î	vI°ã[ÿw#6:O~öÎñnÇMf´qÙWk¯ÂÀ¶ý6ªæ|j´uez×h.Fñ2Lb Êøæû2­¦`ìÖ@¨LElÑÃo+;QNeï­Ä;Ýú`êÝ¾rwÝû*e»°Ô]Þ1C·²îê-ãw¿Éô®É'þ«¯;êwâ_ïlÑ
```

## AingZ_Platf_Repo/.git/objects/a4/a5c82b31a92cf35ceee4f05d095ff666390b2d
meta: {size:636, lines:0, sha256:"13e75f597a7c25d6b2b8fd5cf96abb5062edd6deaa238ac9ffb4780170774478", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a4/ea3a22af552320314bb2993e0909c6bc0ebb75
meta: {size:325, lines:0, sha256:"50b7932ca1aa6676e00b3c97b0e4561490650d3a5ba46528b5fd2f59be450b22", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a4/f5b77df827f4a041d18ff78771f61f1c788d46
meta: {size:1932, lines:0, sha256:"3b24e7a129da2f19f5a9970d448b3a2ac42536734565615e767b8ce81b82f171", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a4/f6f63e813ba54d86178435f848fc986c4e0248
meta: {size:1420, lines:0, sha256:"8651428af1aff676f3eaa90b90a45d1de13a3d7337f8447070aa572bb5dbe50c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

