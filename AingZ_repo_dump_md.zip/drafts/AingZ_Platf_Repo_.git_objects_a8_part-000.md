---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/a8
part_index: 0
files_included: 16
size_bytes_sum: 67527
created_at: 2025-08-31T21:08:15.629062+00:00
integrity:
  sha256_concat: 1065ca6dae2cccf4221067a651536571b4f0d08e6388c836adc789223e82096d
---

## AingZ_Platf_Repo/.git/objects/a8/1368a95e772b1d49e5e5dd3ace6efcc9f664e3
meta: {size:5098, lines:0, sha256:"ed15cb2580550d89773ac212c259fe222360a85028aba63f7f4363f85a00231b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/20b5556faf21dcdf310c6d545b3ccc1c1091c3
meta: {size:1099, lines:0, sha256:"8a29acf286c6a15b2f21686ddc1e527e166ab114460bb8f92b673a4f19d4fe55", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/2da7fa0d2fb101505d32f18a02622bfd8098cd
meta: {size:1352, lines:0, sha256:"8b30d922308379db5a40431720d417553a13ee492a3dba9a3facb171b5b884b9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/438bb42c0d1838261215ba3f8e190b3fb6b4d7
meta: {size:53699, lines:0, sha256:"850f7a6e9478185f733bea0b43d3fb079cf26a64cfdddfcb0b46b0592673cc2c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/48a967dc5f23df6cbf15648ddaa7beb1d4c0c5
meta: {size:633, lines:0, sha256:"8361fe15a3104d10cd7f25b964beed9292eb45f181bfd951db02e6e54a6863e6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/54d8e24d6f1b660520d38a84aebf9ed67d8fcc
meta: {size:518, lines:0, sha256:"aa66f1423e03f6d0ac4ff377102c2309211d2a3f4031dbbe80c21c2c0d4bd135", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/894ad6fd83659d2006040bbe7fa71b163c04f6
meta: {size:430, lines:0, sha256:"55f225b4a46c880afd2834c4e1af1e8c7c17990937f4696660052715a1dfb3c9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/b885fed6d15622840cab75eeaf45067234bedb
meta: {size:54, lines:0, sha256:"ed96b29431e6dc7479ebf78757c9c1bb85f5b151302d6bce71f988413aa944d0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/c35ef34ae7bb6c8f5ff69fbd231775cefff4a6
meta: {size:1116, lines:0, sha256:"20263a6d894ba599ff0766e4ad87ac35c7425576aedd0047deedd5351689265b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/c390ef242721cf0ce05ddef1ca57d3bd46d4bc
meta: {size:192, lines:0, sha256:"f9db1bf96cfd91d4c4cbd4f4534091d3db7cf5c8264a33fdc01bf52d75323a8e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/ca29be0149e5568fe990829fbe5cb2892dac95
meta: {size:82, lines:0, sha256:"144eccfa0649e890740ed59580f6da1093c2c10c3e37faa7d66c3125aed767dd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/cd44b8f848349df0790a8e765cb0985f529f1d
meta: {size:1628, lines:0, sha256:"7e1f5e34b664cf91c25aa6e59101bdd93f5d8625bc366e1656718df63e2c0b6a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/dad3d3c05689f4304587d031578f070d79b88c
meta: {size:133, lines:0, sha256:"be743804efdd6bbf85de962f3f3892e5b351555b4341d76b431a1cb308c63a7a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/e45f67e6891dcd1847787d9f25f105f865ffd7
meta: {size:1045, lines:0, sha256:"9cd51e6a4639e18938799ccb38e4b133d83c7a6bf40cec65463a7a24f1d99bcf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/f4f89779fa9af27bc8e1d6e9152e90ac55665d
meta: {size:92, lines:0, sha256:"fb4f74bbf8a00420c24cb63ccb784751630ce8cde1ac6df2196e7ba0ac8c9619", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a8/fa83080bf64363e0afff60a5395944e481786f
meta: {size:356, lines:3, sha256:"af84ef06f307d096db45589a390a6ccd46b447625b2c97067222a987a875f34b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xKKÃ@]çWà*­¢ ÄD ¢RÂ$½5cÓÉ8÷NUjÿ»3Ií¢âcù8ß¹7SÔMÃÝ½-£fa®j=V¢$ÉÀz®â(2eEa8SÚÚËºÎ½xbùJãÝÔêÔmÜtÞpð7âÓZIHiMdæ]pq?Ü\_çwùi~6È°½X©t$ÜÛ¼ÅrÙ°m¥±w
Ï±µ*ã\Ü3ÓÆËñü #óªe5e<ÒL)Tû+
ºåÝÀ[Ü¾Kö×aCÎ$Þ¦¶E~+ÐéÒvö{o;«Ì/ßÀ°¨ºÆ,1R¯µa½>ÖG@O0D:Aü]ÚÑLX ¼	FG¬¶Ð«ÈÔ}ã0ÑNüXK^§µ©wõÑXîsé´î«çÜ³ïQwÞàêv¬ñüÖayxS³>©×Z
```

