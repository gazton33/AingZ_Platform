---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/92
part_index: 0
files_included: 7
size_bytes_sum: 10808
created_at: 2025-08-31T21:08:15.627699+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/92/59fda6735d45d58e04f4d40f3f1d07c8d08b01
meta: {size:840, lines:0, sha256:"9fc262997d309d6b1ac71faf1cd4c023847725a1b74d96c6d7cf620aff1c0d24", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/92/76bb249255c16f9fb227d83def7d4e2c9f5805
meta: {size:1992, lines:0, sha256:"9bf055401f8e8f37006c3755a19466ac8977fc3e81d3cd11461d70b3c10fdf55", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/92/7fcb4a4c2b94fac033430ea4749baa161466a4
meta: {size:662, lines:0, sha256:"d44c122ffec7b5c10970c5620bc252b93b41b317701f9751905400bb9c78ca16", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/92/b09b516ddcca37bfe861db9a3cff9349a40e95
meta: {size:1890, lines:0, sha256:"58c05f57d13d958fbf14c2cd516914e4aeb4d37cbb6be3c486d3846c5083d4f2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/92/d6e3f82ce38438c066a7a81cfe14ee1ecc12e4
meta: {size:1845, lines:0, sha256:"8be0526bd3175e079c84c06b2ba276cd5ecb252dd5b80180b8d789616955f5c8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/92/dc6592c62683853b54aedfecbb61200b0148af
meta: {size:213, lines:0, sha256:"2a57cac2d2a45a91992e7ebcdef3b576d1d072df0ace044637d706f39a5b5b68", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/92/e01857f3e0854f1b90ea8f74abd16bcfe1ffda
meta: {size:3366, lines:0, sha256:"7c80eeb47058155670e357cc6bc62bb9b16b887c1552c96afd9a683e5c659c08", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

