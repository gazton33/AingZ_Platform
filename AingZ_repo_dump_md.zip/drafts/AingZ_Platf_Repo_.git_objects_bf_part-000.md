---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/bf
part_index: 0
files_included: 5
size_bytes_sum: 2333
created_at: 2025-08-31T21:08:15.630619+00:00
integrity:
  sha256_concat: 67284eb6eeaae1886a875b0957feace97c280f1736d78e7f37b90ca9e2ac517d
---

## AingZ_Platf_Repo/.git/objects/bf/5b5eb99fafc3c51a18856eec69c286fb6be0a7
meta: {size:397, lines:5, sha256:"ec2e59376811f3a3d59885129b84b792e7f9288361ff0a22db02b144218baa6d", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU05´d040031QpÊÉ/,MU0ÔË*ÎÏc(}gõ"FþMIåõy&G§N/^ÐrU¡D¡ª7çî¼óú
©ÂrKRú£¢*4(·­Õ,AM~úhþÔÇªd¶ *4(Ìlb0ûÝÈûÎ/¼î·úSÆ)QBþ?Z>GÀµöå<ó¸ßh?ütU¡DáUN.Ì¼jµyó¹%ÊYa=h
Í!
O­}§ÖìÈ&){æ´]×¯¶^F5Ñ¢pézOëû'_Z¾xÿ?÷Ú÷N8 
ËÜKòóôRò.|xO÷Ðo³Õe£|ã×@U»)¸G)§&¾ %éyáKf/¼Unxªz¦DAûi&¨ÒôÔÜøÌôøôªøôø¢Är½Ü#'_hí*[=U½éV[EÜ¹85ÄÅ4=UÐ·oÂ''Þá»páàócÙáÐf
```

## AingZ_Platf_Repo/.git/objects/bf/64c63b34151c575320aefe32e3fd4822a68b6a
meta: {size:803, lines:0, sha256:"2a25b91b8bc727adffeb242453c8722ce64ea60a6ec3cca55bdcae9a7e7dfd06", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bf/6e04f18c05f09b7550661487cef1c4f2423a4b
meta: {size:977, lines:6, sha256:"e0ac3740cba6715bd0bf6ad5388781c687822ece5bbbceb79ad5e19d94ed49c1", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xolEÆKJPQ¢¢T.5­5¦íýµZÚ$hhPkçvçî¦·;³Ìì¸@
gøÚ4Æ~ Q
­b
*DÈ)ÄÀö"Ô		*"©±ï\·å$1~Ûûüö}çy×x|@°Àçõ>z0eQ@í&Ò8cD³¹ÈÄ¶ KP3òWzAï×ä´ÿ\uäÚÓÎ5Ó¯Ú0CHÕÆAb1
Ò§Ït;ãìºî«:ºÜ^>xpáWÆBP#ÚD`i6|6s´EÑÃX#l	ÂtÀMDÑæO«={WÿÄº½Þ·Ê(¸¼v^ÍÐÐÑI2ªQÎA¢X[ªé=¡ÒWg¶´U·/8¼Ü!±e6R¾äÙ« ¿×òVr;½90máÕÕsïm»Ôjï<?þ}öËÐRøgYÊÝ°£Å-ÿY·fsý{eµNÇúf¶¾ñwA-]µ¹NåSyyB<´H«zlpê¿J&sÆvà*u*P.A !Ë¨À9OVdS»ö]|úÖ;JçÔ÷nûrÊD®#¬ÙD:7¤£°¤b}«ÛTÜs¢½«gËÑ3¡Ý>÷¹ªÂLP-ò6!qËÛæqÂ mºb?ù}\ò7ãd\ä¶¼°î¸¬sqxIõCô!Ì°A%ù)ÂVÆ>:òÐ»}c·ù2Ëj®}åLË`®©Â37·«®£^p)ènªx%»ìÛòµ»êwO³~öÔÇ(âL má7I%ðÅ»ûÇÓÒ÷_©:¼jÕë/ºCÕ©F;!Ê	6å({(W-_ñÜs¤¤åçSó.d"ÏÝr_*ëBÁºIÜFß¸7¥:pç~kjÅ#çôX_Áö+1ý¢'GUQ
sò&×I2"nÙ0G"7Â¤Vo,|~ÛÚúÙ¦ÁílÙtóf-p©Au¬£\)²£uÃàÐ§_xæ2«^.n{cÿÙå³GG&gðnG¡áÑkþ÷5¨ØúÒ²ÏÖZëÚþîÜùT²kïGPê÷¢ÅÀ±6c¦*ïJ½j}Å½éÂ1×ìéìEíÅO´~X¶õ×|ÂÍ×tÏÊÿ¨R;ûÓÙÊ_^î1úÎ3+ûzÂB
```

## AingZ_Platf_Repo/.git/objects/bf/7e60807e62004b4fcc501a53ff3c0450ab4883
meta: {size:80, lines:0, sha256:"3f6f09b11973d1c58ef8e3bdeaddfe451973007fcec9ed3c1e46bb73cc06e781", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bf/dc5e052740097464d4a9955b9388f2a0a0a80a
meta: {size:76, lines:0, sha256:"fe2078d75450b5b58c945b76eb79d3594a6f31e9d8e7b58851a847d12d17dba5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

