---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/a1
part_index: 0
files_included: 5
size_bytes_sum: 4807
created_at: 2025-08-31T21:08:15.628605+00:00
integrity:
  sha256_concat: 576697af17fffb5806a98fa4197a0b43825d868870db9d5d7c0d01ed6dd9b842
---

## AingZ_Platf_Repo/.git/objects/a1/1a9deae2b82dd2d5d41a0261b787b21791fdba
meta: {size:292, lines:2, sha256:"9d7dd3d47237055b5e862753cca686ca5b01295e1e921559ca98f43f422fe842", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU01³d040031Q(*OO,M)ÏML.Ê/ÈIÌÏÍL/JLÎÌÏ/7ÏÉ/IRFF¦æF¦z¹)g×oØ£,gØêzäd·Ïûåý_S0,JMLÉM/Ï/ÊNËÉ//ÆfµøÍ»Ö7æºj)îÍ¼QÃ 	ñé%ñEå@Wb3lÂÖÐüõwîòäDÛx8ÃpX°aKúEëÿ\ôº8ßò«ÆAé[Wâ1°*¾ (?+5¹$¾$5À`Ãv·lþ75|²ôáEJó+!ZZ\Ìü¢ÌÄøò4læôìV
v=Ûøþ}ÍÂ3¢´³5Ø¿´©
```

## AingZ_Platf_Repo/.git/objects/a1/3cedf40db15ad8efe9f906e685441261ff8e8b
meta: {size:1524, lines:0, sha256:"e78d64908c058c21b930820996a754da224e10eaa1ec39e69e4438779d7110e7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a1/40e536e826c7b1b19d7fcee4b40b0b14271819
meta: {size:828, lines:0, sha256:"a3b9d7ed78ef9c5410ffdb83747c1cdd3a80a891aa8280cd7140a5c1d731cce1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a1/9567e1a1bf44b0d69b1d5f0a458b9d81bc0c7a
meta: {size:833, lines:0, sha256:"0729af4a3097ff9a726bc9aac9fb90cc3fd703311e545f3bdf77231b8df47f86", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a1/e19848c4f9a500731409138305a65dc5437c27
meta: {size:1330, lines:0, sha256:"44b954cf69217bcdb56f164833719a19fb60af6eb439367915188c2b3c8993ba", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

