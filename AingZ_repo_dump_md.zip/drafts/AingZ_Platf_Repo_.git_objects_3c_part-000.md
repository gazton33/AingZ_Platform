---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/3c
part_index: 0
files_included: 9
size_bytes_sum: 6753
created_at: 2025-08-31T21:08:15.572192+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/3c/274c98b2ad47aa3ab5098fdbbf2c16835bc1e9
meta: {size:1374, lines:0, sha256:"a49f05083d721d0ceaed8c53035d344ece1820ae766c9a7144c87061a4b12422", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3c/2852e6dda51035cac9ed5e6c8e9fb08cb13bed
meta: {size:634, lines:0, sha256:"0f20c8d2e7b1c39c9cdef984903c826f1d2f2598e9f9a764cc760ad0431c3b77", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3c/368c5a570eef54849ddd2a2b3e850a5b6aa573
meta: {size:108, lines:0, sha256:"a313a378e94f110d654fc037fa19d4f810555cd5da510ac4fc09511fb4687cf3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3c/440cb07327c077df3117c834fad59d4d7571b5
meta: {size:931, lines:0, sha256:"7465f3d61647080c619014319f464294a3753b8fe2ac223d4682f180e9eb9adb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3c/9639edb3809eeffd56da54dc22a7e52edda847
meta: {size:848, lines:0, sha256:"4b026fc7b7dce53ffb719776c3b200be1e918fdc2bd048a95db3e7acf27176b9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3c/b74300ee3f0a8487f47fabb4a767d3c9b67c82
meta: {size:297, lines:0, sha256:"f31ae812cdcd364675f1e2ac20aceff30c5fa6a2247ff2214e4664d61b37c7c2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3c/cf01343ec4431c3eafc647e0dfd5f839281ba8
meta: {size:800, lines:0, sha256:"4679e5b568820433eb84195128cacf1cc32a07c7c22c4d88609111f92283d327", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3c/e022faa689a81fae6e4f95a8467be42a24b119
meta: {size:1443, lines:0, sha256:"7a1af33c11473dc9aebfbe356e794cd0345542f459b1ec31ef13cd105b2f01e0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3c/f07dd34ebce0edc0bf7f14d70535ec34fa7fa9
meta: {size:318, lines:0, sha256:"b24e808fbcfcd9a9a2c450382585469a824ba3024c071deddedb5cdaa807219a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

