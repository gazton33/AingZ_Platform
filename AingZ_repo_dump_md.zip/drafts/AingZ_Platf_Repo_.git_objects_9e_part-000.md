---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/9e
part_index: 0
files_included: 8
size_bytes_sum: 6281
created_at: 2025-08-31T21:08:15.628419+00:00
integrity:
  sha256_concat: bd0caa76ecb76f8b6dd86b94643bf91fabe23511bed689e1625f27fd6d0e9802
---

## AingZ_Platf_Repo/.git/objects/9e/26dfeeb6e641a33dae4961196235bdb965b21b
meta: {size:17, lines:0, sha256:"5163428e8bc545dddc6a8602552a5dc6db4bd3f394d3200097d0abc66dc28fb6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9e/29a16dc67950147d52f4bcd47d25a12057c180
meta: {size:215, lines:0, sha256:"ca883ba0a60903811c853a94e1447bf5e65c3f4422816205d85898f2b9585db5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9e/3aa1298313aafe130eb7f564f27c021b491bf5
meta: {size:1692, lines:0, sha256:"54f102d9469949d8164ef6040a910e12b7cf1431315719ee8e22ed6999cd7304", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9e/3dceddb2e0076febc32c5bd4787eaab4f5b65b
meta: {size:852, lines:0, sha256:"cfffbabb2d4e8930c96217cc65fa58daec2013a0ed41c5efc102b6f7d9f36dd1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9e/7ce9f1de9e01beb5b22f38440e2a75683e123d
meta: {size:1291, lines:0, sha256:"993821ca8aaec6dee456b8aabbf6d41383352bd8d3f3ad0c6926bdc1aa70e55f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9e/8f7d458090e450e43dcfb9606e892ace61ff4d
meta: {size:762, lines:0, sha256:"660b2d5de30609b694a45f8fae5d1e72303a2703babf680dbe3426daeb6ee1c6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9e/961647a83189d3bef31015aaa670de12314c1c
meta: {size:321, lines:0, sha256:"05b8aabd77bc0eb8e457979b0383f1b0c63100692263c63a06b614a210375869", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9e/e291bd26c70adf550ceea7002b439c98b887b4
meta: {size:1131, lines:6, sha256:"d62ea5ae3ea0ffbf641c2d2c06cefe3d7016aa315627d6523ae030db0ae024f8", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xíX[oâFîs~ÅöaÛJ6¥»²¨"b²ÚVÕh°É4ãïÌÔß36&@ÂeY­Jð¹}ß¹ÌÉXê14ï?¼Z«¥+7
ãÎ#O3Ê9$Ú¤ÜµNjpÖ8kÖïèÿ@ÆÝ}Ýéz"$¦1}sa&£ÈÐ
t²P~rR«ÕèFYÌÆm­¡Ça'¸¼î³±Ì13B96eMU,bÍÈü¯¬qÎï½½Úo EÑ<XwfõÃt$åÖ¡aäêWßâÎlþA§Höaï^F»Ý:0ämä(¾±2÷Jä÷¯ÁÃÝ<ï¨Ô"éúÜïÞàJozÖ\vûWt¹¾éu~»ÃîniuK®¾ëYÊ~ß	kszQÛ] ûpxÅÑe7daN­êc³¿ ¯ÁæÑ=øÚ@,FNyÞ®¾Ýg£=èßzÝË ìgi]Á^{½ÛO7GÄãÅöêþ¯%ÿ{ñÚß­å Ú-øñ²vÚa0Ï´ÃQÐëþA£0ðÙÚûÉw«ê°*ø-}kMìð¹l~¾­Ó«/y}`ÓÙUg;üÎN3Ç"ãã×z¾.«r)w9±Ú(Àª¶öáz?8ÂÒº½ö¾WCyNÚMÉUÛsÅ.¸E)R×gí{^>É®rÄÆ?G¡]=÷aYk«[àÉ_+Åõ7òzõÇÃògÅê¤#1;CÌN³9Mª\ÅÄRa­¿.OýÅt²Òb¡*2"7¸·71åRø­¥è8ÝðÒÂ3mniAòè~ÉiîÅP=ä
rå.¤=B*°4i±~gYë,§áîóq}¦ÍC"õÌÖ¦hrùMe®>²pð{§ÏØkwý*<w÷Ê=Èó©sWø°ÀjÓ¤1¡c¬ízYõí:d´E| ÒLg7õ¦ßìÅ¦Qª½%:X-äj,5ÁU=ís]«ÇO¶¸LRkóÅÆH<J9ö4 ²Ä§%°¼0A{Ì7Ýõ&ª8ìàîªHæ1B¤U"&è|D	@FÀ<Ñ´>Àkôë«e§:ýÖ_ÒÚö Í­£­´2`îë(OlôVå[Ë¤b´À¦HK.Ë¸¥÷¢U³JåÅ\`ï³«qÞøà;O¤SÎ;NøÁdaF	k:Ð­Ð2N[éIûpUùmá&c*"þ6Ï
>|MÄð\º
Éù²*°¶DMæûÓb³ò8É%7e]ÛC~DM"müôoâÙRëw¾<t¹ËòÄWlDâ6Õ~[¾]hÃ©Ãxª(S=%<yâ	ªÈÏÚÿ«Ü
```

