---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/42
part_index: 0
files_included: 13
size_bytes_sum: 10101
created_at: 2025-08-31T21:08:15.573123+00:00
integrity:
  sha256_concat: 14cd9d5360233a214c2faa8cd0997ea38ba07d8bea6e83375ac52e17350e5bbd
---

## AingZ_Platf_Repo/.git/objects/42/067d289d1741c510ced8eb5b0a2c7080bb98d9
meta: {size:610, lines:0, sha256:"26b6c93aebbe2736599bd1d67fe76ae7adc1b826d516799eaaa97d0d14ceccf6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/42/1ac3ea505a6595c5e8b444b670edf16adad4c6
meta: {size:1347, lines:0, sha256:"9a0f5763e20294385bbf92fd79aeecfc0263b04ada0445265bd22aed25fecea1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/42/25280b09bb6ecf2f206541131ea512648f5ba1
meta: {size:725, lines:0, sha256:"a45c1562929b3c428772d35e032960ac8c9eb94fa3f853f31b9001da3912c461", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/42/5cb432ccf689fc7b849c78eb4a188d9ea817aa
meta: {size:48, lines:0, sha256:"3ae35067d18c165f9fd8e1b5b5532f41aff7ac9da68128f7076bc174b4169452", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/42/6b772243a6bada199c4e268bf78c80273b659a
meta: {size:81, lines:0, sha256:"aef54ec22fd147cdba833be762452f8f941596cbc9c3a7d9b4d9b8a5f49ac8ee", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/42/7fbcbd1cdaa0470b60e386486155b9c914ad99
meta: {size:1261, lines:0, sha256:"2bdda6410e20f98cd94dec6e992c60751142ed6eeeb62fa08e2087c50f8e85c5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/42/95e5dbd35cf8c4c0c599a9d939c5cc7571f850
meta: {size:1496, lines:0, sha256:"a2ebef00245b9961f94ae1f1041f9959d316e138b2a23df4e8b6c0cca685819b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/42/a46ecafa5be07ad794ed16685f35e44f55ad29
meta: {size:262, lines:4, sha256:"5700ba667d60d74a5a80f5d2768d6aac390fa86684d8509cd336dd0a781f378b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuMOÃ09ïWT=3ÔMÛ¸!!8!â¥nÍÄã2>Ä'iYµ¸Åïk¿~âÒ.YlÊ³ÏY¤ó0¯
pzwp-u4êªñA©ú¦ ^(Ý¾©×
-'|êÏØ=»VÙ82®iÂxÞ0uîwñíQ~zîÁÆ©Êxêý4ÑG>f:LÖ¼Éªà®C1Mÿñ¬³TÁÖ|L­¼·ÐØÿ¬¡&Ö0EwÞ
m$3»XæëU^õfyÑ38À®|À	;÷§êdm¼(«!Ë¡×k±h5U<îìëýbÓ
```

## AingZ_Platf_Repo/.git/objects/42/b0a9c7903c96842a9e7ad9351a41bcf3f341b1
meta: {size:829, lines:0, sha256:"61d59e0a051bb45191f59538344b7dec7d2fd6533f352219ed89e72eeea2ac23", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/42/def0272a64383f2fe6cea89c98939b731bc584
meta: {size:633, lines:0, sha256:"c95370c5cf77134060711ed52f67a850b15117043b1df0a30a33d06d875e5ea7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/42/e64109568f3f2c4c3e995b70d3a313ead7ab55
meta: {size:393, lines:0, sha256:"59626c033ce2bbbb693878d4867b802befb178568930ab6ec6aabc8dd4cdd0b0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/42/f49ffa25b0dcc9829ba9109d192a77e986f015
meta: {size:185, lines:0, sha256:"42c996cf863f667e25af7650e1d35690f6bb268277697c5b9ebed157dcbdc771", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/42/fe9bffbc5e781a659d38619e485b49e4dd1d45
meta: {size:2231, lines:0, sha256:"b52375100f294ac7a99797ad84d5d9ee0abd951c3c8435e664ed90ba0b524eb8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

