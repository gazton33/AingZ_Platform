---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/51
part_index: 0
files_included: 5
size_bytes_sum: 23678
created_at: 2025-08-31T21:08:15.619655+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/51/04ab089ccf7fda4bdb46c372702dcc1b1084d1
meta: {size:46, lines:0, sha256:"ecd9ef094bb40ce06f3a8430b97c101dd2b47d3913573df5b2afb44c4f240264", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/51/04bbd690a39fc50a043744f6b04233d7991de7
meta: {size:855, lines:0, sha256:"624ba6d5c3ee3c7eab22c0a351dd93f4be52477a3af1253c0448aeb20786c878", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/51/a42ba23f0c98d889a489a82de552536ea13f0c
meta: {size:1680, lines:0, sha256:"33f365edbccfb368c6d3cc37204a55c5f26764eebd6615a04c1512609ed88e28", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/51/ec8c7e9b5d0aa4ed4dc3e0521ffcfda58522f3
meta: {size:19903, lines:0, sha256:"cff282997ae20f1fa90d8f1227587e580ee4c502cb497905274a8f69ae5023e8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/51/f1860dea9317ca1248c679c08c3aa60765cfd2
meta: {size:1194, lines:0, sha256:"e63e7edfcf581ed3d50bfa1ece5c5be7c5325dfa87051540aef1517dfd194ca1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

