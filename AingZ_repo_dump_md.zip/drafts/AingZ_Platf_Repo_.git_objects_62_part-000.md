---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/62
part_index: 0
files_included: 9
size_bytes_sum: 3202
created_at: 2025-08-31T21:08:15.622130+00:00
integrity:
  sha256_concat: 17f78b2c740ca7975486834f159d4db90cabb00ba6cfa1f6b7eb23b2e62766b6
---

## AingZ_Platf_Repo/.git/objects/62/0191e1f643e328e0faa902eb528449f5c15296
meta: {size:844, lines:0, sha256:"19476a4b558de50fe9de9989416c6827a936cbd5d2d6e19d0a5c7d7de6d4ca49", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/62/2eb9665d51b207894a522de7ddec93eb62f3ef
meta: {size:157, lines:0, sha256:"24e5304ebf4107a12552fef0a418d8f49d4c65fa97478c5fe44717a391bb1a92", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/62/40cbc7dbb051b4b879fed8cc975b398989aa4b
meta: {size:235, lines:0, sha256:"45c1c145fa673524860e4a44d58a1c5ded665acee06da9e7de87655e9e6749bf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/62/43d9ebb2dfb26beeee1f631cf25d9c53dedcad
meta: {size:144, lines:0, sha256:"3f70282b8904457e9417fc32864add1ac556ed622fac72f989857bf7932a9ff2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/62/4b73e38f31a7226b0e7208454b1a3883e8f9ec
meta: {size:117, lines:0, sha256:"f19980c335a5c792f1f26ecf0a4f440860da861cd0ddb1f9f3b89a50e1a89b81", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/62/7182a3d406f2d5b2e8001f72f5f5b4c1cfc019
meta: {size:358, lines:2, sha256:"a52747b4edd2a010db6e802ea644e42cafa224bf56762419323c3b8af8b6b7ce", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuRMO0õÜ_17 Ù°ìI¯Fc¼mHC¡hc¦âî¿·_¸KENß{3óLNîî«1¨I#Lôz@5ø)X~µG¿Ù,$Ñ¥ ÎÈ@4­
ÍBlec5m3B:ÞÒ^W½Üä8(êZìó{=dÏïo ùm'Ìò[äù	ó¬É¿§GOØÀ³73,]][É¼ý(¯Nè<J;ìÕÕle57³D«|Y»üw×_-2­KÜÚol¼ËU96~Ò @t8àøTü¾a²úÚè=Í²3uz¿®F½©ßÎ<¿v;Îê.ªÇÖ¼jRäu³JX¶rá¹ÃF7[NÙDö)µ*U£ù«ìwKs+§µUG¿ýü®;°BþUÕá§qc¶Sû.`ïc¤oRÖÎ 
```

## AingZ_Platf_Repo/.git/objects/62/8ca5923a134531f338eb76dae8827680201dc1
meta: {size:190, lines:0, sha256:"9a04a884162c865c15d6a3ebc48cdfd07186d86d1a715d55631bc09e55a3a2ff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/62/956dcfc119f65bae77969ef489c5c76ef7a473
meta: {size:702, lines:0, sha256:"ad43e911a22abf08a87637bd356de83930e7064720675c52b0f341ef71262ea1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/62/c2c99b14c4dd4fdaede62bc484a0dbe2c3629a
meta: {size:455, lines:0, sha256:"d45a2cd275e50d07d2f9c8307b04155fd43bac6d842a514ee39af5b0f2425b16", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

