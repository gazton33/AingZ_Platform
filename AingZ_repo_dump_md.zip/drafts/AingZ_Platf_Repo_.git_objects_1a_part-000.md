---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/1a
part_index: 0
files_included: 12
size_bytes_sum: 63766
created_at: 2025-08-31T21:08:15.568496+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/1a/1600799a7c8f071e9341025dd8d648202a5167
meta: {size:414, lines:0, sha256:"7c17a4c9c3049e6399f3b72aeb3aea913fb4442f19abfe6cad6085088e6d51e2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1a/1cd65bcc9fe146a1cb0c318e96eef57b864419
meta: {size:1017, lines:0, sha256:"375f3ce10582c87944bfad2313d05069d0e3535784347b52a13fd8420198a0eb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1a/585e0ed5d65f40a02c012e4957ff2ef1d1fba1
meta: {size:57162, lines:0, sha256:"b0ae07a0439d23a50970f2053ef7c5c9f1a11cd9004ba3f5edac86a9d9a52f41", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1a/618ad74d2129953a698415361fc0ec47e0ea32
meta: {size:839, lines:0, sha256:"48455c4d93debfbeacff031be1e255c5ae7e407112a1440abb39224bb9cd1539", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1a/7b0757508184d95fbc7fb9f065982a2cab461b
meta: {size:846, lines:0, sha256:"f31d5c9837bfca84098e8dcc017c5dd9cb5fe157a9165e2aa6b097a481009394", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1a/8c8f1f236ab43e75a0690b6fa72bec6b18a2b7
meta: {size:210, lines:0, sha256:"71fb2b5f8eeea2236d5a65e277a579b051e1f932f8056e083a17beb6c048151c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1a/a5f6ba4ae7a33814362a3d367218818ff938ea
meta: {size:782, lines:0, sha256:"bbd53054b7ad524945df36a64490f0ef3dbe3f54917ead80456b8cbbd8d0ee7a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1a/ad2383d73470d5ef3401669006ba3ee2c02de1
meta: {size:82, lines:0, sha256:"309295b3a43fcf7a9d9974113255aeb4d9d18a44321aa545d2a5177847ad23d7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1a/b13779285b1e1486d7bba6ea825ee83cb05622
meta: {size:719, lines:0, sha256:"b04cf57a7df3363342189b73c01be69139dc1c2038d4dc1d5c091df10b67daa1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1a/e794ebe811bbcd009a0206c1b94f80f25ffaa3
meta: {size:840, lines:0, sha256:"a84a1965ac63988277c9e68d259b0ef684695f4491f2362f5c9f9dcd3026ae2c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1a/f8c06d7952577d915fac507ab3e5af19b4237c
meta: {size:801, lines:0, sha256:"b0e9a6f73e068056cc9783e02dac304e00acccc78f52df0b2d57ca71d2aafce3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1a/fc55c4a986d860f34d35a35bfd48c79d6a731d
meta: {size:54, lines:0, sha256:"cde21f608cf9a5682617deb119b68b9440a1a771db9d6acbfefb995676310a19", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

