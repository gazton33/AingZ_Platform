---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/99
part_index: 0
files_included: 5
size_bytes_sum: 43565
created_at: 2025-08-31T21:08:15.628157+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/99/028205ec2f6bf0a613b9e19c1b082f36161891
meta: {size:155, lines:0, sha256:"35163a2473a43ebd78ae172dd1d640a624ec126a7e6f951efeaa9bd4f5e1f806", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/99/ee85e2f09e98b2ddd69d2cfca23dafd9c658b8
meta: {size:108, lines:0, sha256:"cbea71a693d4e3bae65256fd72061f03a5150f0443cabf58da0bfbf9239e4fdc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/99/f65572ab0fe056b79cc167e5a8a919e3a15fcb
meta: {size:848, lines:0, sha256:"45e6ef4dcf227d77be8f4770b7c7438a399100b5139b9af24d0dedd93043040b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/99/f9aa2589fb4d10ffb3096ab2dd42811c15c4a6
meta: {size:41929, lines:0, sha256:"8c982595b7df12672caccd2d33d931e45b00cf0f43c2db15068799a47d9bafc1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/99/ffb34cbf8a1420048c78cdcb3eb09681705ac9
meta: {size:525, lines:0, sha256:"848a22b8530f58e16d64aa77482eb9d414900e7c74fb165c97152a7b6d966b9a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

