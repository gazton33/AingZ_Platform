---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/94
part_index: 0
files_included: 5
size_bytes_sum: 2354
created_at: 2025-08-31T21:08:15.627817+00:00
integrity:
  sha256_concat: 0a2b5837a432271f5d29afcfba8e4d3cffee5bf7d631c0dd5a0d1fef9125d6a8
---

## AingZ_Platf_Repo/.git/objects/94/5a597d6e66f937849b98a992c5c13f4872e97e
meta: {size:905, lines:0, sha256:"93a1e5e9c2bb4e82a5752c3172b3934daa2f933fd5ffda411874063bc1fbfafd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/94/70259868524b6f3dd4dbc41d0f741ad51d47b2
meta: {size:269, lines:0, sha256:"990f97288fe418b53d1855e462cd38b5885c05cf7d789c03e06f0ee26958a2e2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/94/7dbe857f9037865a617468b017159ec3d25912
meta: {size:130, lines:0, sha256:"212e6a9f0f7c8b193e0ec2d0b80c0ca6e193e86f4564fd620d619256fba3d80a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/94/8b2eb18e1d6a093d3a44fe35fafc0317b68922
meta: {size:841, lines:4, sha256:"77b855da7c961ea23c2d3481dd2978ea510a20c70886e169478144e8ed8f83ff", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuÉHE{ÍWÔnY	Å(¥[a0Æ`cðlï»ùú8mú-ô®ÎÞê²,(þ ]U.Á±EXæIISªH¤ Ê¥L»¤¢ ,¦± &FJ$È
ÏA>M#Æ)1' TTS4¯; Uvß²¯sB(¯Ç¤û¸ _£ºü@YD Èª
¾pãýÒ¤«ÚC¾Uu4äý=+h>ÿ³5Y_dàËÏÑ«µüë§Oûå{+Ò5M74-Ð§.n#kìyÄSN4MyhFü®
¹Æ+°Ð.ÎööÖ<.y+h[*BU)ætg/P¾¢Î³Âì³ìÚK1ì*ºúa«ÂhpG·ìõí±à¡eátNRpïÚU¶rÛ[£óh,[ç@\D'Ç8÷ÞI³&@ÈFx~LOãQÂßüx½ííçAí{:_mdt¨ò3qìËVz]¡ØdÊnÇÇ÷f>&ÑÈ.Æ:YÕHÅö1]8ëUóGÓíÔíÑ5äÊNãMà.&%U¿ÁæåÕ0@×¥EqY¸¸½®Q.);é^$zÂ~>4Û¦ÒÐZ$¯Ccj¡ã}Óðî©KìÜ,®Îµ'¾­BéÒ¨ã.øi¥þq{Øê5<Ø>¯ºñ$®_¬kPQ´ðÐÎ}<A.H{}ðác~õOw¤=}FTz%¨öµ=/¹³LT¢ÖKüÞâ"}âÅ¸ºDèÞ­kÉ·9¤Ö=&ñ¦î=u­É´ûf×ÝÌG§ØVüKHíÈ÷ÍPuÞ},Ûø=Ûj_£­/ÃMMãfð¢©¡³½[½vkîÁ÷Â²­»Ü×FöÙ´:$éJ.Ë*PúuWNàz¹%uÖ^>dy¯áD:z¸L¥­_ñU÷Ï!ùhªåZ¾ýÛölþ0¿:±ôÌß7YN®bû>¡ Ä´+&ðMiâ:êÁ_"õoùx·W/
```

## AingZ_Platf_Repo/.git/objects/94/a6cbda330b6818d46d7dd281f525a87875ef9a
meta: {size:209, lines:0, sha256:"a0e959c83139feab454eac9a00d3c15b67fba83356fa478f973710aa47859e36", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

