---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/b0
part_index: 0
files_included: 7
size_bytes_sum: 3485
created_at: 2025-08-31T21:08:15.629567+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/b0/1b6de03ab00ee3f1e51e64e3b221e45efd0805
meta: {size:858, lines:0, sha256:"e013bb3272d747fd2e3b6ba75622ef13524c4b65b628665a5d0846d00aa01510", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b0/2b7ca6fcdd8971c548c04e42dcc35a4bb90dcb
meta: {size:806, lines:0, sha256:"680718ebb226d82a57d66f1d4292bb69c02ba188fccff068a0109706e0e31775", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b0/7c270c235c0350fdb7dfc50c9e43239fa71ddf
meta: {size:801, lines:0, sha256:"69cd7ef678e5d4f78850f2fb5613ed334ee9c7be14aef69ccdb8abdf8ddfeac3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b0/94b4fb1ee53ac68340741c83f895b3bdd5ecf2
meta: {size:762, lines:0, sha256:"1ad45707c5a93e460775526f414b666e7782ffd89cb671d8cd830c2371d9da6f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b0/b8b4d4b9bcecd60f2f2a67b54735b79a97879f
meta: {size:94, lines:0, sha256:"57373630453786b6ee3fe5c4ebf5dcba06ebed368a5a42ae5989c979e9d775e6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b0/cfe0eb0bd104e8407a44064eac9cb42c0dad9d
meta: {size:76, lines:0, sha256:"a7d5a67a4df6ca4c603f2497fd4be600854df0edd235a2c142ac8b762aa64da0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b0/f3358e1ce6a37efba68d895092946d7ef1217b
meta: {size:88, lines:0, sha256:"56c54a0cd83a88ffd02e650b82e7f55a6fb0776f8897972b88909e6bcc4e336f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

