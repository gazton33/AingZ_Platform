---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/de
part_index: 0
files_included: 15
size_bytes_sum: 12920
created_at: 2025-08-31T21:08:15.649921+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/de/07855a63934a12dbc27e3885b9e708f52ac2b8
meta: {size:949, lines:0, sha256:"5a51cde1f9cd2eaf0fec0c4f572655ca523c860c744ffbc616256332f337d2e2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/23f462d12ea34e588a7c06ab99291cb2e29d61
meta: {size:147, lines:0, sha256:"99b98e1d0fcb14320a1992c16bfa5cbe88ec6ef0986a71f09b18d1c24285ed48", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/38fa7491299695c7cffde31b6ed674b87f8ad9
meta: {size:1638, lines:0, sha256:"d77d90c8f636ad4ab27c2ae01cc4aa702aa324fd418825f4219618ea2dc7dc3f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/44a0c5249bd8ac8c7ae3963171e6c3f1df05a1
meta: {size:1088, lines:0, sha256:"33ffb4d1786022e45d0ee24f42348bf70e5649e976beada3dc82f078f96bd9ec", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/8f955ef0e279b3fa8c0bde91fa838d020f330b
meta: {size:213, lines:0, sha256:"59bbc3a76a8c471ef531d780c7a6de6ca10daa9c75310acb43f1e80079bd7675", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/9804c1b44d44bc1a7335ae41ba9070613c22c9
meta: {size:213, lines:0, sha256:"900c46bd6784bcc754bcb1794d4472187ddb4115b86a735fd360eb97e47ad8c4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/a124a809933f0ac5e0bb92d6940f8b5902d643
meta: {size:736, lines:0, sha256:"da66a7ac57cc1f447c76b2c488596b80fe8711885c85437e0ed749da60d56be5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/a5ce0d688085558c9684239ee9a3d1d7e498b8
meta: {size:590, lines:0, sha256:"d482ea2287faefdb8de8fc650473523b2a7fac5bdd47976f1a4a2a55701db81e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/b82fa87d904e56ec5cadc7cbcaea0f9af05f1b
meta: {size:2809, lines:0, sha256:"ae4d5af59313ae4aa1181000d4ab33fdd9d49a194e96121f260f128a7b7fd2fd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/b996539640550cd6a7bde0e4fd3f9645d73462
meta: {size:48, lines:0, sha256:"0e36c8f4f8a939b65d956253c218f5812eaac644b1a92ed7ed13daafe948c6d3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/c1c4b0485a0cdf51b6335d98e0951c6fe08736
meta: {size:106, lines:0, sha256:"1e5c6d2422aa384922505cf04e9c17c2abe0ca57601502650d20e04a6aeb516e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/cef4d738b4c548124431e02ca9004b9498cc2d
meta: {size:2072, lines:0, sha256:"dbcd1a71aabfd3ac0f44db2aee16d37b7cd85f5593f70790b519c5abe0151e54", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/d24ad1866fe442d896417efb90eb1dd9cb4198
meta: {size:1174, lines:0, sha256:"3a08adf4dafe73a346fd59417ea18c9766f6d45747d0d1ca62bfd08e7c93dcb7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/e8ab0edc979903ee5a63ca9d7edc9d52d58a12
meta: {size:632, lines:0, sha256:"5aa46f1c6a307b93f723efe3511338a3c0cebabb4d1ad66b84baec97cdfcb4d2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/de/f3138f8b6367f6e07aa2815da4988da552a4a8
meta: {size:505, lines:0, sha256:"f3f58a9a180e6445699bae9c88c2da76243d28df24088b3d01540b106cbca944", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

