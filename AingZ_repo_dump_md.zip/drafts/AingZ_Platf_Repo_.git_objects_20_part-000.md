---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/20
part_index: 0
files_included: 10
size_bytes_sum: 12908
created_at: 2025-08-31T21:08:15.569214+00:00
integrity:
  sha256_concat: 33e7875ceb51ea62aae05a86faa61158da3c1c178a3f679783213bf0836d71d6
---

## AingZ_Platf_Repo/.git/objects/20/255c06b6b389942e61b53bf7244e84a0999e8a
meta: {size:1139, lines:0, sha256:"63f459761838a14440670e89fe14fe4c0ac073e3222d0a682f2d440f5ecc11c3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/20/2632930a9fbab7598ec8dad04800141203be0c
meta: {size:842, lines:0, sha256:"cc7e9be8b91f3b61fbb088b3acef101651f2514bce19edea1263ae9ed7aee2b4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/20/4e5e4dbd5e53644c55b6e0f8187093d584c9ae
meta: {size:406, lines:0, sha256:"7676f6a1fe4db9afb042af95f6f604905207f432e66679dd3a703d6d2478c8f8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/20/5390e9c5cb835bf36d62d128e935127c6325e4
meta: {size:89, lines:0, sha256:"8e5958e722bb996c58f391bc3c3397180c5555bea37b060af102fb7abd834d0f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/20/5394e9a2192e0a715e37cff57de79c3fe0aa41
meta: {size:156, lines:4, sha256:"63c28ab71f16d1323490ed7e2c9f2f68971a78e92d525ce92d314ad580909fbb", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎA
Ã @Ñ®=hQG(¥WQ£I Ö"¶¾9C·üÔjÝÔÊ_FÏYZ1ÑXZA0¤dçA#cÀ¢(Úì´xCRÔh<%`dEÌ5%å
ù03Å¹Ì
ðkër	ÇhODy[¦#ï9­íûc©aÛ§Ôê]*gÈhëä@õ\ù/,>4ø¤NBZ
```

## AingZ_Platf_Repo/.git/objects/20/91e0c072e7d7031e67695221f25de94173b24f
meta: {size:153, lines:0, sha256:"f3820f492d71cd09082bc08a347fd706dc06f41a81e4ec8a1fea237a67b9c1f2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/20/c7fd58ac9e0d497e53bec9bd9a3a05260b3e05
meta: {size:54, lines:0, sha256:"7a428fb29484bbf412dbc2a9ceb92065771d0f0fad9a31a4199fe2cfb3c734f7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/20/d239f79a1632a5349dd46640d8bba5eeb3b559
meta: {size:9631, lines:0, sha256:"3cbbf6ed4021dce68b9300182df77fb87d0b1b06f8f35c4cfc2b56a9ba33e054", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/20/d4b66772175cfd7fb4f1c6696b0176470f55fc
meta: {size:224, lines:0, sha256:"27332ccab6926d57178bc7a3a3a97d05cf13d445bc6edbdb445f416069b76b49", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/20/d9428e53dcc4028b093b88b046574b8bcf2927
meta: {size:214, lines:0, sha256:"6aa8935a99f5093e03bb97d55153d43ee82baa9f59dad64f798db07e0354b2f3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

