---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/d8
part_index: 0
files_included: 7
size_bytes_sum: 11640
created_at: 2025-08-31T21:08:15.649571+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/d8/10c63b7f58c3456c39cbc3c9c7b1665fbd085d
meta: {size:72, lines:0, sha256:"a5f0d3687f011a29b76af8811556c86eec6b92cc6896dab9c3abd0ee6dbc21a0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d8/1757d705e5d97ba5c8d8dfd1f3907c00423af8
meta: {size:1731, lines:0, sha256:"bdc4cd3b5c9b304dae8f3c19a52a951130df242248ea9937388bd447b050c334", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d8/64809d7078182e49f477487c0d182f60fefd04
meta: {size:51, lines:0, sha256:"318b1875b6ed33ef2496308ddcd1212c26a10d04e22a4f093a8fd49aa3dd1d33", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d8/6b6b70ce970eb91ce87776227d68a2202ad56b
meta: {size:447, lines:0, sha256:"7eacd46172042e0e6d3814ae63f9422ffc3dc107d91ff360ea6936f913acd57a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d8/b94706f733c09b2a74c90364a4495b7e72e9bf
meta: {size:2196, lines:0, sha256:"5e529db17f0f2cd1cb95e8f8ea98da85ca9107ea07b65a68b48dad4d7fdc230e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d8/cfd751a614be169052a694865cc9ecc64466da
meta: {size:6991, lines:0, sha256:"80589c722a6f6ceb406aa644f0f0b1cc275cc9c2181c2d70ef1a571a025b1fde", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d8/fb19964d035d8621afe704c48353ba2d3ce715
meta: {size:152, lines:0, sha256:"892bb3cd3798f6f1f3176d7c5539eff10839bb90e55ed4a6e0fb0e7ec30942c4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

