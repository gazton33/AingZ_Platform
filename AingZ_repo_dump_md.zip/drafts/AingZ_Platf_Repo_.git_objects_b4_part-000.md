---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/b4
part_index: 0
files_included: 3
size_bytes_sum: 1727
created_at: 2025-08-31T21:08:15.629784+00:00
integrity:
  sha256_concat: 9caa475e0470f9a1410ecbf2d539f7a978eeac393bafc98e3ca3f750cd8881dd
---

## AingZ_Platf_Repo/.git/objects/b4/107d21823f18b0cccaa947cc443d8754be7d7b
meta: {size:1088, lines:0, sha256:"5a9d1985f8d92fc0a9d335772623e8245ac86af49bb01c3522a34a9af3c24eb8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b4/82a8c0bfbe58575b67fa148f4ddc13f41910fb
meta: {size:542, lines:4, sha256:"e62dc3f29067d71298cab60c4c4a19f4367197301f2738afe2e230af59c7eb31", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuSKZ1Ìú¢%6 MøF(YÌ¢$"#Í!ÓØq06²Í{¬r#«97ÉIÒï3@²³ìruuuõÒú%úýÑ«Ì¦Å»9<ú°YY_D¸óVQÈ²)í|4ÉãAGßQÀdrßîU	9üÄ+PF&Tþ
YÊqkÈ%á	¶FæðìºYÖjÁØ»DÎ(½E(ÄR+aÆÀU\Ü\Ä°?¼é®Ý­ZÀ¯ï?@òßà-Tp´¬Ìr½Òöã|<tÎ¹4µ±^ LùYáMYäò7Kå¯EÿîKÂ¿y*?1RçUß\D7î	£ãÿ²olHH]ÁìØG'õòfZV4ÝU8~j±ØJÁ	«­åÔüÃ?ýÈÆ¨0È5Ç¢Ñ{ÐÌq?NCØ[âþçín·h»³¨W¿õªêõY48Öä±MÎ9ß¸X-m9¹É`ñ0¸Þ¢}Æ ÏÊè*»@+ó¥[{Îª´õËx?½¿|XéÚ8_XRb¯|gÀS­íÍ+:VN°ÆÒý#«xNîïo§_^è«6ÏP5[
Fk
e0W´õÂLiE49³ñ&ëu¹ÇÅ·åZ¾-·i·«Ý=P'û8~bÙ
```

## AingZ_Platf_Repo/.git/objects/b4/94485e9cda7f43b3d96d80544958b8fccad16b
meta: {size:97, lines:0, sha256:"fb898d54482154e78e6988c7e4c1f875ff816280ef0dfbf1be3c8d6ef7ce0d3a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

