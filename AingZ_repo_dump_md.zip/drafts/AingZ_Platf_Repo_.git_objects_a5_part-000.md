---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/a5
part_index: 0
files_included: 10
size_bytes_sum: 8319
created_at: 2025-08-31T21:08:15.628889+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/a5/16ad0c4bb91219e1075a7775a62da4cc0ef1ab
meta: {size:158, lines:0, sha256:"b8aeedcdff41122b079d388bfedb546f2f8e67c5b64bfe7ef26b4b2c45e6b309", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a5/22be32c6143f4dcf419253da722a11825d70ff
meta: {size:803, lines:0, sha256:"8f0285f7343d64cca6d73b4d5bd98d547c4fe65a26c4b1ff2949868dc7c72176", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a5/3fcdf882d346397ed7b060b5409741d49c72b7
meta: {size:1101, lines:0, sha256:"85db9a5edd4319249d76e21e4e50c375aca79a2e1966f5b7c44d813095d4550b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a5/65909f6660359247254b135a5eccbab62adb93
meta: {size:1369, lines:0, sha256:"5ece39be0ed1d1fc5c59e55bad43eece69a69b4c4d8a8033ed2a55b6eb4199eb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a5/71df77aab650cbb16d3237399af5f179c0a7e9
meta: {size:343, lines:0, sha256:"42337ca416c77cdbbaf6406b291d64fd9bb467c2a4352a120e0f01699f0ea193", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a5/82738fcb52629dbaeee6df9939f7249f865d9a
meta: {size:197, lines:0, sha256:"54fd89a08a8860ab4890d57e1223d2f1961bda579cd14ea71dcf149baa8acb29", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a5/82dca8c8f9b794ec8f3df404eee1dc38b612fe
meta: {size:534, lines:0, sha256:"0e5de8d7e74cc19d47cd55c7912f1a4de6620f9634be3f813b1f8b7ce31b0fb5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a5/a426f49c31cc86ba7113c0704f6f3771844022
meta: {size:244, lines:0, sha256:"7c6a571a77539feb271157cf5758482dec7d745f90ed4600b60843c28011d9e9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a5/af49343bdf01c9e939e8efff6dd6ccef429208
meta: {size:1541, lines:0, sha256:"1d7903980e8582f530ee4b94d763e3b22aca529a7eb75f7cf2b5e661d429535e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a5/f9e4ee1ce7f570a8fb486aae9d710d91f457d5
meta: {size:2029, lines:0, sha256:"a40aa55604ddf8625e78b6f96e5c9705f70db3ed1e943c6126a88846b2605c61", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

