---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/66
part_index: 0
files_included: 10
size_bytes_sum: 8382
created_at: 2025-08-31T21:08:15.622709+00:00
integrity:
  sha256_concat: d302c4003c4c45ffc31ea9a8435f1671359e230300a836f758b3785c14a578ae
---

## AingZ_Platf_Repo/.git/objects/66/0301ceb89f156e3f9491da8fa6264676dd4fbd
meta: {size:951, lines:6, sha256:"ea44083555ea759919b5b866c1bef13f66522a964e1a78e2a58ecb266cd50c71", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuÁrÛ6{ÖSì/¶c·tÜä¤®+7öXêÅ¬hDÁ ùè±9ärÊ#èMò$ùAQ¤OOâÅî¿ßþ3cgtòëÉëèîqÿ~3ÍÆï&Ùå}v{wóçÛivõnruùÇt]ßLßf§¯NÏ^½>=,}ûø/+¥u/ØWÉP9aÈp.äß81G½^¿ßïõèd@·Î¯·RiÀííeQLFÐ¸°UÎ4ñÒ÷ñæ{®
¯óà¿}ütN¥ÓÔ¥¶­cÐ¬âBxm>Ë ¥À_½·Ç¯p+Z;£	¯t¸À»Y<]Seeµä"Ü¥¡.òûôâAËÛé ëètÓÊÑcórèÅ#KQ²Ý¦×§ãã±ÿTH*!ê³þüø¸GÔGm7"êã¬!|®ØymØÜJ­Ô¯Õ/â)P!(OBP:çõ{;sL¶Yá®$Ô6Z'MZeæPJTº&oMÕãoab±$*JÁÄªÖT¹}S.1ã9;Æ¸0éª'¡ð! QpZÆÖt3Ù­[Ì}×Æ#F¬xPk÷W­hn¬NÛ´£n§áiÉéß´áÌüFó
5ÄBÁÕÖiA+¾àá ©V6[)ÓN<l{#a«F¹Ã-¡9³	¹Ø'¬lhæÿÑÛíçÍg£½ö
<ÇzÛ`ã÷Ö	â° Î±-uk7 Î!FÏ¼,À¨ÓVúÖ´=a9º11É!vÉs*µ46ÎfR-hlGQÞnÃvðÔ° é}Í"X.ÐTZ¡(ZwtPµ~òË.ö/K;c-áó°
ÌÎt\E+íÑNî4à5ë£Z¨váÖ/mP'6_Àé9ÝýÃ2u6Ò-Kz·G{9
ÚdµK?(ãèönr¸Øy`?eh%z_¶ÛøïQeXÛï5µo`Úun!±Xzf¸nu;Ðï/¬1!èãs9è¢(`íà^·ÃJ`zâR8hØiã¯kÑLÝRÉN±Ûáº]îHcC\ãÁwÙz®~ºÏ­BY\^»|:¡1Ôçd×\7<oµú}Ö
```

## AingZ_Platf_Repo/.git/objects/66/0c3c85c215950169d9a8fff8b6379fbe03356a
meta: {size:154, lines:0, sha256:"701861fbaf00e9e55e5a96d4d71e2958ae7e30f48562bd6e8340f93346959398", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/66/188736cfc6b135fbffd0ddfb8d9d28b739e163
meta: {size:851, lines:0, sha256:"9962743291e21c2ed217fa4c1b069b42f6f30e2777238905b68a13f08f8ed4bb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/66/47a0ac2860ed1bb6b08b3e83a4f060d1032b77
meta: {size:282, lines:0, sha256:"32efa1f280a7e7b04b3c8e965531dbeba770ed8748396bef3fbc54f58ba28821", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/66/799cd1d00ec54473a9453825c8c160865ead0d
meta: {size:854, lines:0, sha256:"6eb0556761b29db3ba8e3f2184fa35530a5e2d14eeb841cb49f3b73bd78b35d3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/66/7a5b5a87c1bf1cf1e1e37afb166c644c21c516
meta: {size:634, lines:0, sha256:"c42640d03a3eeb4e13b59b6f8752d06639ca2db8f3efcdabcbcd9b13cd10ab38", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/66/a700910acd2519beab69e1d557c8e2863834b8
meta: {size:3954, lines:0, sha256:"08047ef5cb363003177d83d147e17c63a70beeb8642be716386be8b706e289ad", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/66/c9e5064dedbae9cf18a9792479bfc75bbe6abf
meta: {size:443, lines:4, sha256:"dbbac42f3858b0b3cea1f4c0e5d4332b487f13d0e0a4fb214ea42273020e1409", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU0±0`040031QðÎË/ÏIMIOUpJ,NUðM,)Ê¬R(JMNMIÍKÎLTIÍ-ÈI,I-VÍË,K-*NÌ²ËõrSªms6?;}HcfÑeuö½äêèâë
Rlý;jA°Øós{MâØ.³eÚ¯&@ ]À`qTO{÷+){¿Í·*ÿ¶öÂ	ù=Pé
ÕûDìV¾Þ$9× #îDßç?Ç&BdÓsò*ª/üËbK¸bg\±þs?¨#²aÞO¯/(ÊÏJM.ÏÌ+ÎLÏ()¹Í6ê¨ýPÃþÕê<÷J~í]âÄ3	®·8>¹¤">'5=1¹2>73½(193?/>-3/1'ÞÈÀÈÔÀÜÈd5ÿ¡'óýj
Ï0õoboxe ðx7Ô\pÆ§V¤æ¥d¦$Æ§¥&¥ÍÎH,I/(/Ï/ÊNËÉçº[þn«õlQ5÷tèÇi{¦=TT÷Oq|QJn|Y¼Èz½Q³³J§ý1s{kË8áßÄîJWklÃE
```

## AingZ_Platf_Repo/.git/objects/66/e6e53ed25774a2e0316f87bec1b8712acb0ffd
meta: {size:131, lines:0, sha256:"b1b2eba8b4aea181a4bd510be35f7135502362afcc2d9db33d8873f5324b1148", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/66/f81befdffdc2672be1a3ddce7c7add51e550cc
meta: {size:128, lines:0, sha256:"0addc8e872e35c1a7e73fd79e6892435694a85b226fde7cf18bdfada55f241b4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

