---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/75
part_index: 2
files_included: 13
size_bytes_sum: 34300
created_at: 2025-08-31T21:08:15.624148+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/75/09f68ecfd3dda06988f87a8a62406f382e036c
meta: {size:2237, lines:0, sha256:"961a244a5cc362a35757453d5308f2d1a7ffd8b5ef028a541f57afa024f3ec6b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/75/4b5fdedebf1d3d03c36c544e939f8820a144fb
meta: {size:224, lines:0, sha256:"27b0348151093b1c620e44e7aba56255f55c92f347639a23f6adb7106ab0c4db", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/75/7272964f644f80eb31daef2db94f96d2549bcf
meta: {size:855, lines:0, sha256:"b123319b082488bbb68a2529542dbde1dfc5a0fb865792bd3c571aab3f15cfe6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/75/7a59af5b51255380bb954ffe3cd6f44bd6e1c8
meta: {size:1922, lines:0, sha256:"b8f61b232ed94c4463fab30ad5cc76fed55e0616f43e54287552fe1d67ef12ff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/75/88fac5c5c1d19120a84bda219f632637910754
meta: {size:2355, lines:0, sha256:"83c101acce3680a3d416279ec75ba7f06392d8e2f2088d3600dc4bab9fe00d58", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/75/89855b359fd6057e6596af5ff3c1e1e4e50770
meta: {size:17150, lines:0, sha256:"abb30038f4db78f465f56a70c80bf95509fc73482aa7115a5bf1e44c5b8ce5a8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/75/9558a2aa937d471faaf954333e3e074d02b5df
meta: {size:1921, lines:0, sha256:"bfa3f4b3fba918f13e6a95e339f0488f28dfdb36f4ce9628417949794903f9ec", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/75/9d18d6f35909474ccd181411f0957c2f44e732
meta: {size:1602, lines:0, sha256:"ab349349d24b34ff7203bfd91a7f7370bc8c783c38a6309704621e1d3281e0d8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/75/b59a6d2910644d4da56947b0ac86dab9d322de
meta: {size:736, lines:0, sha256:"a68565ace315e54567bab32f69e1c25ff933d027c2655ec85d7ce51754fa6cca", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/75/bcc16d93c7ff2e817af05ca91ffd91dd2046ff
meta: {size:3137, lines:0, sha256:"40e5a5b01aedfc8cdd02494f67271bc66c1c8c9bcfd15ae2267bf5dc90a4e1ad", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/75/c030a8540389820429367508d6e21bc19ac5ee
meta: {size:71, lines:0, sha256:"a53a5ade4bb0715367d39736204fefa00b457bec4c0d6225c1760c6c646c12e1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/75/ee3ae85c1fec7479d79e34c59597735ba084d5
meta: {size:793, lines:0, sha256:"968febdca936cb4fb8b5215b9c356722535aacf1197a5b5b3a812fc3b8025206", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/75/f1dde0e9765857ab6029d3f15d7cfac7391cd9
meta: {size:1297, lines:0, sha256:"d4cafb8e1e398a186bdaca6cb2dad60fc0835033e126dfa30579682478fa69a9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

