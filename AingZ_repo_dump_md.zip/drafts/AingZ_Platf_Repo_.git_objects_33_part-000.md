---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/33
part_index: 0
files_included: 9
size_bytes_sum: 6431
created_at: 2025-08-31T21:08:15.571480+00:00
integrity:
  sha256_concat: 70e2c6c175ce9b1926ece57258aae8c410db25c6a4c5da038aefa02d0838e289
---

## AingZ_Platf_Repo/.git/objects/33/12364e56a8ff51dc93e746b48185973e81e990
meta: {size:54, lines:0, sha256:"6bc4a1897142b73b179052fd285c06bbc2c03c6a7da282f60f285ac6cb119fae", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/33/23f7696485bccd4d2b3c963bc0e59a9a2200d9
meta: {size:2666, lines:0, sha256:"8d30aac922a0ebbefecac4ff719e07fccf0de019cae9729b9a5d36aabf64c5fc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/33/3603fc5bef07e90886c5871ce224d897558b51
meta: {size:155, lines:3, sha256:"13cc55218a2616e57215537ab8b5f93611c21912471247bc2ca9344f20bb4f05", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎ[
Ã @Ñ~»
7Ð`PJ·2:cHjÛBV_×Ðßn®Ç±u©çxéYdÊº2¦ 2öÎ@.1åT"º0c ^Øø9 ¬S`L¬"pRÖÛT4K>&Ü`ß}­M.xöú·e:yç¼Ö/·Çrà¶O¹w9{ë¬sÁ+yU u,vþøãXFø
```

## AingZ_Platf_Repo/.git/objects/33/488d6238c2ef6d6a1aaf821f43f77f11ef7ca6
meta: {size:665, lines:0, sha256:"dbf038ba8c52b842e636499a24e9a617373f95358a30eb5dea440b618bab7d5d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/33/7dc3ca2a65151107b161f0364d9289340df861
meta: {size:125, lines:0, sha256:"cce9e3d1de6d72cab3e468889106846259cec3143b38f21f859f02665c01b032", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/33/8d62a7dd431772362d21026808d2181c7a096a
meta: {size:239, lines:0, sha256:"161747e940a4f3dbb5d1fb0100ecaaab900bd8836e537e96ca5acc0fe575345b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/33/972a322c4d18096400845b20c9987a653fc31c
meta: {size:881, lines:0, sha256:"311524ab77d16de7377588ce27861b20f92f0d70d361ea6b41d9534cbd0016db", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/33/a253d8c1fbba83433e2b249ed728b27d4e261c
meta: {size:846, lines:0, sha256:"4d7c7eb8c9ac433495f46892b0e9f82677d38e748906f2cc1674c687ef9e9dc5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/33/c7a6c1836deb05208eab5bc901bb22e97da1d3
meta: {size:800, lines:0, sha256:"3d12a134099f9b0db74fb139f995372f291acd943e67b37e4e605fb02fb53a05", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

