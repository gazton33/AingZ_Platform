---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ce
part_index: 0
files_included: 8
size_bytes_sum: 89572
created_at: 2025-08-31T21:08:15.648791+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/ce/05b0430e9b430ce30868d622d097dada1dba61
meta: {size:146, lines:0, sha256:"e28d9b04d15f16500e0011a3a445e7ad047c1f99189dc2f682fea5f87470bdbb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ce/1e54ff8192e8f1f2e0b21c56167762c5af1e01
meta: {size:284, lines:0, sha256:"9eadad5174d2767819f67c0e2100425dc4653fb79a9cef61415f4ecc22c92fcd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ce/70bee7880becfd69dc7707a7b34c0b3b140391
meta: {size:240, lines:0, sha256:"eded5aa3b33f7de0c7f3566b420978d8849fa1619ee7adccb2e33baf27695480", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ce/89ffb305c5e31e37096bd89e671c4d008a2add
meta: {size:826, lines:0, sha256:"a4f62f029a7bce8795188df3b7c4e676b0847bda81765233e7e4f2b89e0b7e5c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ce/9d9b867c05bd05e00bd220453fbe51e229b66a
meta: {size:91, lines:0, sha256:"0ee577a84ab160daacc3b5a87de10c7efd39ff7a6fea94c1bb1a2177e09dbe5b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ce/aac2fd9a79b4fbe21bcce0955669d91cf0a004
meta: {size:11789, lines:0, sha256:"7f195467e5adfde67be0310924465e272f4e5c0d18fa15028fe114def92c2894", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ce/c4c7b0c6d5fd5f429111c243030813378b3f9a
meta: {size:73528, lines:0, sha256:"a40d62086aea2ef3cd378f8e36e9450ed2bcb63e1d51b71b409e5dbf554cd2b4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ce/cd65d932de3766f5fae8c794df6c3a1cf37427
meta: {size:2668, lines:0, sha256:"218287718bf06acb8bde2d50fc07e60558c10a26510d792edb2fcaff4b289e2a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

