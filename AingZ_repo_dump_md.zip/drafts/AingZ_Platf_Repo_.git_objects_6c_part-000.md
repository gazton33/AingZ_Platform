---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/6c
part_index: 0
files_included: 8
size_bytes_sum: 6321
created_at: 2025-08-31T21:08:15.623317+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/6c/0d35b29ff027c5b13ec9a8e9012a9061043fc8
meta: {size:295, lines:0, sha256:"b4b2d5c3626ec2a291dee54ceebc0cd8c698bc5c26733aabca76c7aced2aadee", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6c/145d06fada2555d2941079fbcd669b6136c51c
meta: {size:1125, lines:0, sha256:"5d379c24176a401faca6275ef0b3468f21a571390977353a33197f17165009f8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6c/40938cc99dc469142a1010890bb1da69cad9e6
meta: {size:692, lines:0, sha256:"2031c7e71d394744ad38fe169396c25c2e33601da97e6d9a6a70cd7eba864f07", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6c/43872892ceb78cc8e310b7b7c723e1b93c8e64
meta: {size:763, lines:0, sha256:"9f29a839b4721766bd9b4b830941139469f2ba5f734c2216df6820b0fad088d5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6c/478355904b22560e215d4965dcdd1a203102b1
meta: {size:2290, lines:0, sha256:"dec3ce2cb2586cc2d451834adc4479bee5b69b4fa2dca64b6c9d6e2ddfe61677", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6c/958c44161094ff15e8501bcfd1f5f94d8e6d08
meta: {size:160, lines:0, sha256:"32a2bf19c3895c90ebc3bf8169999dba03781b2957f269303f619ed810ccc6ab", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6c/b417c5ac67ec97d82cfd092d265431aa3b367b
meta: {size:915, lines:0, sha256:"6c9286b6ca847fc6470fdb0ce39c0d564a65030001abecc226e5f5ad7a41b125", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6c/e42e83cfabf946ec41ee22510148bd61aff32f
meta: {size:81, lines:0, sha256:"e873a7bdf119b9c6ccfd89f0b70a1091e078db68571111b8a74eb84c257e720a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

