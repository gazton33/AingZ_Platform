---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/43
part_index: 0
files_included: 10
size_bytes_sum: 4789
created_at: 2025-08-31T21:08:15.573213+00:00
integrity:
  sha256_concat: 0c1186ea764dafb28f6ad8b43006ad4ce4250d2ade8a9967f1df296200700a10
---

## AingZ_Platf_Repo/.git/objects/43/2e59eeef6a1f2569597ec206a334c0ccc06db0
meta: {size:210, lines:0, sha256:"2433a0ce18838509e574a08510a2c0ae8fa5e1bf816e359345d77152a8bd3912", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/43/3ac7b98a37fd997c8bfb8bb1493de18a643aa8
meta: {size:183, lines:3, sha256:"198a227ccda8802cd846565532da6c71d1043ea50a5020e2a4dfcc1c32b0b310", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎMjÄ0á®s
] ,GþR:ËÒM×Ýil%&ëèéë+tûÁÃ÷¦²mKù©UU!'e'Hl%+ªå`BCªîÔ83:rÉ±Ë¤B7åÀÁ£ïÆÓ4ÈO»
×e¿àe¾üêªé^N­oó&ËzIe{ãy4±g´C_{_ÓÿËá3||¾CÕ£ÔÖá;Õåh {³ÔÇ´ó¬M¤
```

## AingZ_Platf_Repo/.git/objects/43/3c7f2196a0477dead089b1c7d62480ce8acfc5
meta: {size:897, lines:0, sha256:"cf98c574545a205c5650fdeb42ad1e1eb480f356b9386382a4653de2c1709df6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/43/3dc0f3604e030bb2044148e7106d69eaed3b39
meta: {size:742, lines:0, sha256:"58d2af378e31ad27bacea9ebf92502791772583ad26744938e635693b1ab7b81", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/43/4e309110db77ee0b4fd67c5196b836a1b4e3bd
meta: {size:218, lines:0, sha256:"a2b64ec633a9df09fa8a1a6602641be3be58154f9dfabaa688c5728c628f443c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/43/626ee173745149cd88367ba9f26be99fa40ded
meta: {size:635, lines:0, sha256:"fe870cf28769ff8eca08e4e17dafe9586afdde7b96f60008a07bd906694379ff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/43/79f450506f9e7b353a7802cb29eb8c203d95d0
meta: {size:129, lines:0, sha256:"bbd976587e8174ae95b81b6753f6b4e4a2ca7f293450371a108929e859f59e22", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/43/9820a289e384d6aadf59b696df99cf35d589e6
meta: {size:69, lines:0, sha256:"16e7a33e812e13cf7626de046efbb0157e90da58b0d7af115eef0837ede86f79", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/43/a7f3199d571564f41525ac648ab84592e8b8e0
meta: {size:762, lines:0, sha256:"0916498d5d2eef4179872e0df52f7e029000bd501602fbdbbb6cea494e16566b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/43/cde281d3256efa1e6c87d04fcfbea7d9c5cdd6
meta: {size:944, lines:0, sha256:"9f5865931cca4e62a14cadec6029c9b33c1fe61e87290546df5e623dbf7c337b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

