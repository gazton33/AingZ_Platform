---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/ruleset
part_index: 0
files_included: 5
size_bytes_sum: 16898
created_at: 2025-08-31T21:08:15.670450+00:00
integrity:
  sha256_concat: 4a6dab93356d938830c6f481fb4c5cba6238579b1b3fdc9403b68b6d2a5f0036
---

## AingZ_Platf_Repo/ruleset/aingz_v_5_rule_pipe_minipack_2025_08_18.md
meta: {size:8596, lines:303, sha256:"50d5bbd798c54a95ea5fad502439ed8ac0c676468459bdd54c08759281a0426f", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
file: PACKAGE.index
code: PKG-RULE-PIPE
name: AINGZ_V5_RulePipe_Minipack
version: 1.0.0
date: 2025-08-18
owner: Arch
status: Ready
refs: [DIR::, GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::]
triggers: [router_chain, qa_lite]
changes: [CHG-2025-08-18-001..007]
checks: [no_file_refs, wikilinks_only, router_chain_enforced]
---
# Índice del paquete
- 01 — Coverage ARBBL↔BAMBL
- 02 — RULESET::Router (RREAL)
- 03 — PIPE::Registry (PIPLT)
- 04 — QA Lite + CHG/ADR
- 05 — Master Plan Ops Package v4
- 06 — Master Plan Ops Package v0
- 07 — Roadmap Glosario Full V5 (Fase 2)

---
file: coverage.report
code: COVR
name: Coverage_ARBBL_vs_BAMBL
version: 1.0.0
date: 2025-08-18
owner: Arch
status: Ready
refs: [DIR::, QMS::, CHG::]
triggers: [bucket_check]
changes: [CHG-2025-08-18-001, CHG-2025-08-18-004]
checks: [no_file_refs, wikilinks_only]
---
# Informe de cobertura (ARBBL.codes ↔ BAMBL.mapa)
**Resultado**: coverage_pct 100, links rotos 0.

## Resumen
- Fuente de verdad códigos: ARBBL.
- Export `tree_export.codes` base: [[DIR::ROOT]], [[DIR::MAIN]], [[DIR::RULE]], [[DIR::PIPE]], [[DIR::DB]], [[DIR::CACT]], [[DIR::DOCS]], [[DIR::DATA]], [[DIR::SEM]], [[DIR::AILE]], [[DIR::DEVP]], [[DIR::OTPL]], [[DIR::GUID]], [[DIR::WF]], [[DIR::KCTX]], [[DIR::CDEV]], [[DIR::CARC]], [[DIR::LOG]], [[DIR::GIT]], [[DIR::PKG]], [[DIR::SCRIP]].
- Mapeo en BAMBL: 21/21 presentes.
- Extras aceptados por diseño: [[DIR::AUD]], [[DIR::IMG]], [[DIR::VID]], [[DIR::LIB]], [[DIR::GLOS]], [[DIR::FTUN]], [[DIR::TRNG]], [[DIR::RELV]].

```yaml
coverage_report:
  source: ARBBL
  export_codes_total: 21
  mapped_in_BAMBL: 21
  missing: []
  extras_example: [AUD, IMG, VID, LIB, GLOS, FTUN, TRNG, RELV]
  coverage_pct: 100
  integrity_checks: {links_broken: 0}
```

---
file: ruleset.router
code: RREAL
name: RulesetRouter
version: 1.0.0
date: 2025-08-18
owner: Arch
status: Ready
refs: [DIR::, GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::]
triggers: [router_chain]
changes: [CHG-2025-08-18-005]
checks: [no_file_refs, wikilinks_only, router_chain_enforced]
---
# RULESET::Router
## Targets
```yaml
targets:
  global:
    default: [[RULESET::INDEX]]
    policies:
      - only_namespaces: [DIR::, GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::]
  platform:
    aws:     {goto: [[RULESET::INDEX]], section: platform/aws}
    gcp:     {goto: [[RULESET::INDEX]], section: platform/gcp}
    azure:   {goto: [[RULESET::INDEX]], section: platform/azure}
    local:   {goto: [[RULESET::INDEX]], section: platform/local}
  app:
    console: {goto: [[RULESET::INDEX]], section: app/console}
    etl:     {goto: [[RULESET::INDEX]], section: app/etl}
    ui:      {goto: [[RULESET::INDEX]], section: app/ui}
  api:
    rest:    {goto: [[RULESET::INDEX]], section: api/rest}
    graphql: {goto: [[RULESET::INDEX]], section: api/graphql}
    sdk:     {goto: [[RULESET::INDEX]], section: api/sdk}
```

## Validación
```yaml
validation:
  assertions:
    - router_integrity: true
    - broken_links: 0
    - routes_count_min: 10
  audit_log:
    - 2025-08-18: "Router validado en README→RULESET→PIPE"
```

---
file: pipelines.registry
code: PIPLT
name: PipelinesRegistry
version: 1.0.0
date: 2025-08-18
owner: Arch
status: Ready
refs: [DIR::PIPE, WF::, QMS::, CHG::]
triggers: [wf_dispatch]
changes: [CHG-2025-08-18-006]
checks: [io_only_DIR_namespace, wikilinks_only, router_chain_enforced]
---
# PIPE::Registry
## Pipes
```yaml
pipes:
  - code: P01
    purpose: Ingesta y normalización
    node: [[DIR::PIPE]]
    triggers: [WF::INGEST]
    inputs:  [[DIR::DOCS], [DIR::LIB]]
    outputs: [[DIR::DB], [DIR::DATA]]
    raci: {R: Platform-Ops, A: QMS, C: Arch, I: Devs}
    slos: {max_latency_min: 30, success_rate: ">=0.99"}
    prechecks:  [schema_detected, checksum_ok]
    postchecks: [db_delta_recorded, data_profiled]
  - code: P02
    purpose: Entrenamiento base
    node: [[DIR::PIPE]]
    triggers: [WF::TRAIN]
    inputs:  [[DIR::LEARN], [DIR::DATA]]
    outputs: [[DIR::TRNG], [DIR::EVAL]]
    raci: {R: MLE, A: Arch, C: QMS, I: Devs}
    slos: {epoch_time_min: 120, eval_pass: ">=0.8"}
    prechecks:  [dataset_card_present, license_ok]
    postchecks: [metrics_logged, eval_report_saved]
  - code: P03
    purpose: Fine-tuning
    node: [[DIR::PIPE]]
    triggers: [WF::FT]
    inputs:  [[DIR::TRNG]]
    outputs: [[DIR::FTUN]]
    raci: {R: MLE, A: Arch, C: QMS, I: Devs]
    slos: {train_budget_usd: "<=50", eval_pass: ">=0.85"}
    prechecks:  [base_model_tagged, ft_budget_ok]
    postchecks: [model_card_updated, drift_watch_enabled]
  - code: P04
    purpose: RAG/actualización de relevancia
    node: [[DIR::PIPE]]
    triggers: [WF::RAG]
    inputs:  [[DIR::DATA], [DIR::DB]]
    outputs: [[DIR::RELV]]
    raci: {R: Core-Dev, A: Arch, C: QMS, I: Devs}
    slos: {index_latency_min: 20, recall_at5: ">=0.7"}
    prechecks:  [kb_consistency_ok, schema_compat_ok]
    postchecks: [index_health_ok, recall_logged]
  - code: P05
    purpose: Cierre con feedback
    node: [[DIR::PIPE]]
    triggers: [WF::FB]
    inputs:  [[DIR::INSI], [DIR::FDBK]]
    outputs: [[DIR::CHG]]
    raci: {R: QMS, A: Arch, C: Platform-Ops, I: Devs}
    slos: {closure_time_h: 24}
    prechecks:  [issue_linked, owner_assigned]
    postchecks: [chg_recorded, lessons_appended]
```

## Validación
```yaml
validation:
  assertions:
    - count_min: 5
    - io_namespaces_only_DIR: true
    - broken_links: 0
  metrics:
    - name: pipe_success_rate
      target: ">=0.98"
```

---
file: qa_lite_and_chg
code: QALITE
name: QA_Lite_and_CHG
version: 1.0.0
date: 2025-08-18
owner: Arch
status: Ready
refs: [DIR::RULE, DIR::PIPE, DIR::WF, QMS::, CHG::]
triggers: [qa_lite]
changes: [CHG-2025-08-18-007]
checks: [no_file_refs, wikilinks_only, router_chain_enforced]
---
# QA lite y registros
## RouterChain y Mapping WF→PIPE
```yaml
WF_to_PIPE:
  WF::INGEST: P01
  WF::TRAIN:  P02
  WF::FT:     P03
  WF::RAG:    P04
  WF::FB:     P05
router_chain: {readme_to_ruleset: true, ruleset_to_pipe: true}
```

## BucketChecklist (lite)
```yaml
ChecklistRun:
  date: 2025-08-18
  buckets:
    - DIR::RULE
    - DIR::PIPE
    - DIR::WF
  assertions: [no_file_refs, wikilinks_only, router_chain_enforced, broken_links==0]
  result: {passed: true}
```

## CHG/ADR
```yaml
chg_log:
  - id: CHG-2025-08-18-001
    title: Cobertura ARBBL↔BAMBL verificada
    result: {coverage_pct: 100}
  - id: CHG-2025-08-18-004
    title: Instanciación RUTPL en buckets objetivo
    scope: [ROOT, MAIN, DB, SEM, AILE, DEVP, OTPL, GUID, WF, CDEV, CARC, LOG, GIT, PKG, RULE, SCRIP]
    result: {broken_links: 0, router_integrity: true}
  - id: CHG-2025-08-18-005
    title: Alta RULESET::Router (RREAL)
    result: {routes_count: 10, router_integrity: true}
  - id: CHG-2025-08-18-006
    title: Alta PIPE::Registry (PIPLT)
    result: {pipes: [P01,P02,P03,P04,P05], broken_links: 0}
  - id: CHG-2025-08-18-007
    title: QA lite en RULE/PIPE/WF
    outcome: pass
adr_log:
  created: 0
  note: "Sin cambio de alcance."
```

---
file: ops.pkg_aingz_v4.masterplan
code: MPLN4
name: MasterPlan_OpsPackage_V4
version: v4.0
date: 2025-08-12
owner: AingZ_Platform · RwB
status: reference
refs: [DIR::RULE]
checks: [wikilinks_only]
---
# Master Plan — Ops Package v4
- Documento: ops_packages_pkg_aingz_v_4.md (legacy)
- Cumplimiento regido por [[DIR::RULE]].

---
file: ops.pkg_aingz_v0.masterplan
code: MPLN0
name: MasterPlan_OpsPackage_V0
version: v0.1
date: 2025-08-12
owner: AingZ_Platform · RwB
status: reference
refs: [DIR::RULE]
checks: [wikilinks_only]
---
# Master Plan — Ops Package v0
- Documento: ops_packages_pkg_aingz_v_0.md (legacy)
- Cumplimiento regido por [[DIR::RULE]].

---
file: roadmap.glosario_full_v5_fase2
code: RMAPV5F2
name: Roadmap_GlosarioFullV5_Fase2
version: v0.1
date: 2025-08-15
owner: AingZ_Platform · RwB
status: draft
refs: [DIR::RULE]
checks: [wikilinks_only]
---
# Roadmap — Glosario Full V5 (Fase 2)
- Documento: aing_z_v_5_roadmap_glosario_full_barrido_adjuntos_fase_2.md (legacy)
- Alineado con [[DIR::RULE]].

---
OutputTemplate:
  example:
    package:
      files: [COVR, RREAL, PIPLT, QALITE]
      acceptance:
        coverage_pct: 100
        broken_links: 0
        router_integrity: true
      router_chain: [README, RULESET, PIPE]
  log:
    - step1: authoring
    - step2: validation

```

## AingZ_Platf_Repo/ruleset/context_pack_index.md
meta: {size:1128, lines:29, sha256:"269d8572dd747344a8eb9e308e1763c31ad10b13b81c54c88fe85547c42f0780", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
file: ruleset/context_pack_index.md
code: KCTXIDX
name: ContextPackIndex
version: v1.0.0
date: 2025-08-30
owner: "AingZ_Platform · RwB"
status: draft
refs: [DIR::KCTX, RULESET::]
triggers: [TRG_CONTEXT_PACKAGE]
---

# Índice de paquetes de contexto

## chat_gpt_plus_knowledge_context_pack_v_1.md
- Finalidad: guía de funcionalidades y límites de ChatGPT Plus para investigación, agentes y herramientas.
- Relación con reglas: complementa el ruleset de la plataforma para uso de ChatGPT.

## codex_knowledge_context_pack_literal.md
- Finalidad: compilación literal del repositorio de Codex para referencia de desarrollo.
- Relación con reglas: alinea la ejecución de Codex con las políticas y normas del ruleset.

## V5/context_package_new_thread_v_1.md
- Finalidad: empaquetar el estado base para reanudar trabajo en hilos nuevos.
- Relación con reglas: vincula baselines (ARBBL, RBL, etc.) y mantiene la cadena README→RULESET→PIPE.

## Política de actualización
- Este índice se actualiza cuando se agregan o modifican paquetes de contexto.
- triggers: [TRG_CONTEXT_PACKAGE]
```

## AingZ_Platf_Repo/ruleset/ruleset_baseline_v_1_locked.md
meta: {size:2549, lines:96, sha256:"896a4c2fb79c182c732f26682f155c4443f924cb398167cf148296318204f48d", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: core/doc/workbench/ruleset_baseline_v_1_locked.md code: RBL name: RulesetBaselineV1 version: v1.0.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: locked referencias:

- RREAL (RulesetRealV1)
- RSTBL (Ruleset\_Template\_Baseline\_v1.1\_Locked)
- DTTBL (DirTree\_Template\_Baseline\_v1.1\_Locked)
- PIPLT (Pipelines\_Template\_v1)
- PCTRL (PlatformControlPrinciplesV1) triggers: [TRG\_BASELINE\_LOCK, TRG\_RULESET\_ROUTER] cambios:
- 2025-08-18: Baseline real del ruleset bloqueado según template. checks:
- goto sólo `DIR::`
- Sin rutas de archivo ni anclas
- Namespaces válidos

---

# Baseline Lock — Ruleset v1.0.0

**Baseline-ID**: BL-2025-08-18-Ruleset-v1.0.0\
**Árbol**: BL-2025-08-18-DirTree-v1.4.2\
**Snapshot**: `AINGZ_V5_Ruleset_Real_v1.md` validado 2025-08-18

> Estado congelado. Ediciones futuras en *working copy* de Ruleset y nuevo lock.

## Router (snapshot)

```yaml
ruleset_router:
  targets:
    global:   [[DIR::RULE]]
    platform: [[DIR::RULE]]
    app:      [[DIR::RULE]]
    api:      [[DIR::RULE]]
  routes:
    - match: { kind: platform, name: aws }
      goto: [[DIR::RULE]]
      section: platform/aws
    - match: { kind: platform, name: gcp }
      goto: [[DIR::RULE]]
      section: platform/gcp
    - match: { kind: platform, name: azure }
      goto: [[DIR::RULE]]
      section: platform/azure
    - match: { kind: platform, name: local }
      goto: [[DIR::RULE]]
      section: platform/local
    - match: { kind: app, name: console }
      goto: [[DIR::RULE]]
      section: app/console
    - match: { kind: app, name: etl }
      goto: [[DIR::RULE]]
      section: app/etl
    - match: { kind: app, name: ui }
      goto: [[DIR::RULE]]
      section: app/ui
    - match: { kind: api, name: rest }
      goto: [[DIR::RULE]]
      section: api/rest
    - match: { kind: api, name: graphql }
      goto: [[DIR::RULE]]
      section: api/graphql
    - match: { kind: api, name: sdk }
      goto: [[DIR::RULE]]
      section: api/sdk
```

## Normas globales (snapshot)

- Anti‑archivo activa.
- Namespaces aprobados.
- Roles R/A desde QMS.
- ADR para cambios con impacto.

## Integración PIPE

- Rutas válidas habilitan ejecución en [[DIR::PIPE]].

## Checklist

-

## OutputTemplate

```yaml
output_example:
  status: RULESET_BASELINE_LOCKED
  baseline_id: BL-2025-08-18-Ruleset-v1.0.0
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - files_frozen: [core/doc/workbench/ruleset_baseline_v_1_locked.md]
  log:
    - step1: qa_pass
    - step2: checkpoint
    - step3: freeze
```

```

## AingZ_Platf_Repo/ruleset/ruleset_master_v_1.md
meta: {size:3334, lines:118, sha256:"1a342815159fe6af23bd4996b834866f7aded750eb4cdeab1a1332b11f02e14f", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
file: ruleset/ruleset_master_v_1.md
code: RSMSTR
name: RulesetMaster
version: v1.0.0
date: 2025-08-31
owner: "AingZ_Platform · RwB"
status: draft
refs:
  - ruleset/ruleset_baseline_v_1_locked.md
  - ruleset/develop/ruleset_chatgpt_v_1.md
  - ruleset/develop/ruleset_codex_v_1.md
  - legacy/ruleset/RULE_CODING_COMPLIANCE_V4.md
  - legacy/ruleset/RULE_NAMING_METADATA_CROSSREF_V1.md
  - legacy/ruleset/readme_core_data_ruleset_rw_b_v_3_2.md
  - ruleset/context_pack_index.md
triggers: [TRG_RULESET_MASTER]
---

# Ruleset Maestro — AingZ_Platform

> Documento de máxima jerarquía para todas las apps, conectores y plataformas. Evolutivo y validable con participación del usuario.

## 1. Alcance

- Aplica a ChatGPT, Codex, VSCode, GitHub, Obsidian, Excalidraw y cualquier conector futuro.
- Este archivo prevalece ante reglas locales; los rulesets específicos se heredan desde aquí.
- Baseline y referencias: RBL, RSCGP, RSCDX y reglas legacy.

## 2. Principios globales

- **Naming y Metadatos**: seguir `RULE_NAMING_METADATA_CROSSREF_V1`.
- **Coding Compliance**: cumplir `RULE_CODING_COMPLIANCE_V4`.
- **Crossref**: toda modificación actualiza referencias y changelog.
- **OutputTemplate**: bloque YAML con `status`, `created_at` ISO8601 y `log`.
- **Context Packs**: utilizar índice en `context_pack_index.md` para seleccionar paquetes.

## 3. Reglas por plataforma

### ChatGPT
- Aplicar `ruleset_chatgpt_v_1.md`.
- Registrar ruta exacta y OutputTemplate en cada interacción.
- Contratos ≤120 caracteres y literalidad (LSWP).

### Codex
- Aplicar `ruleset_codex_v_1.md`.
- Naming PascalCase con `CODE` ≤5.
- Acciones reproducibles y alineadas con templates `V5/`.

### VSCode
- Sincronizar con Git; commits claros y trazables.
- Respetar naming y metadatos; linting activo.
- Integrar con GitHub para validar antes del push.

### GitHub
- Pull requests directas desde `main`, sin ramas extra.
- Ejecutar checks locales antes de `git push`.
- Mantener cadena `README→RULESET→PIPE` y crossref en cada PR.

### Obsidian
- Notas en Markdown con YAML front‑matter completo.
- Naming `snake_case` y vínculo con ruleset mediante context packs.

### Excalidraw
- Diagramas versionados (`*_vN.excalidraw`).
- Referenciar en crossref y documentar cambios relevantes.

## 4. Flujo de interacción y evolución

1. **Proponer** — El usuario agrega o modifica reglas en la sección pendiente.
2. **Validar** — Se revisan los cambios y se actualiza `status`.
3. **Lock** — Cuando se estabiliza, se genera snapshot según `ruleset_baseline_v_1_locked.md`.

### Sección Pendiente / Feedback del usuario

```markdown
- [ ] Propuesta:
- [ ] Autor:
- [ ] Fecha:
- [ ] Discusión:
- [ ] Resultado:
```

## 5. Router

```yaml
ruleset_master_router:
  global: [[DIR::RULE]]
  platforms:
    chatgpt: [[DIR::RULE]]
    codex: [[DIR::RULE]]
    vscode: [[DIR::RULE]]
    github: [[DIR::RULE]]
    obsidian: [[DIR::RULE]]
    excalidraw: [[DIR::RULE]]
```

## 6. Checklist

- [ ] Cumple naming y metadatos.
- [ ] Crossref actualizado.
- [ ] OutputTemplate válido.
- [ ] Reglas por plataforma revisadas.

## OutputTemplate

```yaml
ruleset_master_v1:
  status: draft
  id: RSMSTR-2025-08-31
  created_at: 2025-08-31T00:00:00Z
  approvals:
    - user:
    - maintainer:
  log:
    - step1: authoring
    - step2: review
```
```

## AingZ_Platf_Repo/ruleset/ruleset_template_baseline_v_1.md
meta: {size:1291, lines:54, sha256:"0a91795cb90c2cd6d46d40d86eb675a5e832d4f26fdb3f2b543c207d8bcf042d", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: ruleset/ruleset_template_baseline_v_1.md code: RSTBL name: RulesetTemplateBaselineV1_1 version: v1.1.0 date: 2025-08-18 owner: AingZ_Platform · RwB status: locked referencias: [RST11, DTT11, BAT11, PIPLT, PCTRL] triggers: [TRG_BASELINE_LOCK, TRG_RULESET_ROUTER] cambios:

- 2025-08-18: Congelada la plantilla de router de Ruleset. checks:
- goto sólo `DIR::`
- Sin rutas de archivo ni anclas
- Namespaces válidos

---

# Ruleset — Plantilla (Baseline v1.1 bloqueado)

**Objetivo**: centralizar reglas y enrutar a secciones bajo `[[DIR::RULE]]`.

**Notas**: Ruleset no ejecuta. Sólo define políticas y rutas.

## Políticas

```yaml
policies: { no_file_refs: true }
namespaces: { dir: "DIR::", ruleset: "RULESET::", wf: "WF::", qms: "QMS::" }
```

## Router (plantilla)

```yaml
ruleset_router:
  targets: { global: [[DIR::RULE]], platform: [[DIR::RULE]], app: [[DIR::RULE]], api: [[DIR::RULE]] }
  routes: []
```

## Secciones sugeridas

- Global · Platform · App · API (todas bajo [[DIR::RULE]]).

## Checklist

-

## OutputTemplate

```yaml
output_example:
  status: RULESET_TEMPLATE_BASELINE_LOCKED
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - targets: [global, platform, app, api]
  log:
    - step1: author
    - step2: validate
    - step3: freeze
```

```

