---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/bd
part_index: 0
files_included: 10
size_bytes_sum: 5202
created_at: 2025-08-31T21:08:15.630460+00:00
integrity:
  sha256_concat: 7a4399b10410ff84b50446c9950f4add11963f0d98b452001590acd3765d1879
---

## AingZ_Platf_Repo/.git/objects/bd/0d1a5e8e02e5f4348fbdaa5b41de2fd69dec48
meta: {size:787, lines:0, sha256:"c62a5662937dfbd955d9467488fcaef0c47e5b493bf64f6fbca302a7a5da2c8b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bd/0e4dd670172d38de6468d500a8ef6864d41145
meta: {size:1149, lines:0, sha256:"9c76948ed0205d3e011b675d8a8eaff34d19e479bfc85ac5c6b305a1530494e8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bd/12a68ab0e1bec549aa255983e609f83bd253ed
meta: {size:157, lines:0, sha256:"e175b45e942da5f28ac86e343180a4eef05135c799f860166e208863c3fef63c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bd/171b7cdd5514934a055ad109d9d2774d7a6197
meta: {size:60, lines:0, sha256:"7a6fabc55e9d0ecd0057f7dddb548acab68840acbc1fe4cd22c87a628aa0622e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bd/388267b738cbd576d77f58002095c5795eb70a
meta: {size:80, lines:0, sha256:"6a46af49f1709e7d96e7c2c29e37061eff7d1d2b19147a659dbf4ed37d0e456d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bd/3fadef890da376e5d86011528f85db34f6734c
meta: {size:472, lines:2, sha256:"a4d72180c7f8e122537c5fbd962b4f849ed1f8e1abca041a20f0f2d187b81c9b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xUA1EYç%eÒ$ÊAYÄ"Ò ª¶+Ù®Æv	+Áf9V!7á$|wUbwÕÿW¹ÖÑæõí9}üòn·ýði»;®wëÕúÍj³¾[FO¿¾}§m*Új!)5s=?÷ê¬ÐK§.ñèµZ>ÿ`
Ò³;Q°*tûj6[,³Ù|NMp±Ú,Öwÿëy	4Ìô>|5hÕHRÍBò80ØçNä,ì*»éìl¬ÃWªä(^áiÀ?=30dsRà#cü40îOâªA§>³7ÜO,Wj«k¡¼-añÉn¡«; ZYö§LG=2ñ¥s£VN4³Wß¨ðº·¯VÕ1t¢<XF-x:c4¤¾5ìÇ:æÆµÀJ¼e)ÍÌÛ±Zäª_2qDù%µÔ¨fí{\4(ÑòYüè4­ªÄá<ðy°¤6ÛøqòÀû)ÿn½Ç+BèbVà³;èq2}ô8¸Ãv±16ªF¸¿ÐÄóSº_A§Uï5A¾­"Ë`¥=6µ$BÓ£F¦"ýaÝ#7îk¶°¼>¿ßDÙ
```

## AingZ_Platf_Repo/.git/objects/bd/527b40a345bb1c62f94a270e18cd18ec9dfa8c
meta: {size:801, lines:0, sha256:"5840d89aed54c94625e1261f29dc4224fc361441d08579ac8827e8b193223150", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bd/55bb6964a63d2d8b952e1c5fd0c925ca0eecce
meta: {size:120, lines:0, sha256:"c305992878093ee0bba69678bff617ce8536c210bf0761147ad87e0529455858", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bd/5f826225a980fb9b321ed07d45660f82abb639
meta: {size:51, lines:0, sha256:"81c9a47abfa5bbc8cdab856949bcaf600140cf8fe3af970a8df48cac0ef210e9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bd/dc15cc9ed9421b62c86c380928a444a6c8134b
meta: {size:1525, lines:0, sha256:"6ab03eecadfea109aa275572e597b1b749c5170e6eb5517b065b04037c1575c3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

