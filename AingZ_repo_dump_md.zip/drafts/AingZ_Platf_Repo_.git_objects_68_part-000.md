---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/68
part_index: 0
files_included: 9
size_bytes_sum: 9905
created_at: 2025-08-31T21:08:15.622932+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/68/2d94be724e74e471a9c29e434d5c8629cd4c56
meta: {size:190, lines:0, sha256:"9410de9d8a1b9eaa2854512f68150eb4e885a536f3a0d6cf8b1fb8f82aa0efe0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/68/4350a25565a17c1890fc8c59052c1478af25ac
meta: {size:763, lines:0, sha256:"9ccf3ac8b1ada87691e22684dc93aa3c49eb0cc3197ba0c82ac054e8cc6b701c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/68/449224764e07311b149bdc2bcb29f0ad97edb1
meta: {size:294, lines:0, sha256:"ceb4fe5c9e5cdca8781ea329a05c18dce7a8f78fc8aa5d133172a07aea55e259", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/68/807994fbfdb36b801ecb9d79aa77b3e5749d02
meta: {size:156, lines:0, sha256:"ea1d072aa635834ef66dc701cf71c098c947b780788b7dc1f1b31dad9ed349bd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/68/842d0c13d43d197d672f8966f5d2629d0ec60e
meta: {size:2606, lines:0, sha256:"66b579fc419da0606b93a7e16f4e724b27ca461997a85107309d5b4afcaf8dfb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/68/9b7fcf8cfae2a285aaca91d6417d2a3b6f8048
meta: {size:750, lines:0, sha256:"24e2bb12fe21785e9167af403e4d872a0582c46a45b02cf79dcb459ee98068cb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/68/cb05d9cb0862b4e886f1b91413077f458ea37a
meta: {size:1472, lines:0, sha256:"4455629d7b4cd5733e29d913564c24f46c1a7724b7cc20eea87f3971a6661785", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/68/dbe08bf56a0aace66a3ab9a51dda91fbc29cbf
meta: {size:301, lines:0, sha256:"5f685c96a4ae5263a410fa8ad5b80d84b879904c12eddf0df92823894c95ef31", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/68/ffa1c062eb1abb93899b3884f2351a008832bb
meta: {size:3373, lines:0, sha256:"b49367d544e31d8862f04a2e895d77728f3aaff35265721774d9dca7c31326ae", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

