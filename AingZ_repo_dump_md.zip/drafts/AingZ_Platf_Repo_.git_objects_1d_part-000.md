---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/1d
part_index: 0
files_included: 6
size_bytes_sum: 26519
created_at: 2025-08-31T21:08:15.568815+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/1d/21b614cc72917fd6b79caf329679a275b1d670
meta: {size:158, lines:0, sha256:"e7042a2c95b326b7f568172ee671d15e355395a3e83232f017d5b499fc49accf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1d/91aa97707eac0a60b6eed45865b5e67ce2c1c6
meta: {size:1866, lines:0, sha256:"1ae239fc8704becafb8d3169bc1fb8baa1c7248e3492705979dc10c3c0aa97d3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1d/b1097bfc0689f14c1a2c7b2ea787c62b42037f
meta: {size:157, lines:0, sha256:"d03bc0f60d8fc98e4987bb76a5f91452d7e31e1bb8aa1c7669e40a0714ca3cf2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1d/d51669a08bc0c1d0f65ea941a7dde2bf596eda
meta: {size:4315, lines:0, sha256:"5c0357875580da2dd1c83cc5776dfd93f537735363c1fc15e145378fbde69e19", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1d/d744ff204c9ea2f504905a9a8945a0771b82bf
meta: {size:138, lines:0, sha256:"f2ae4bb47f1a90ec69522c1ac74f58d03db39e83c7312265bb4ea3ba1aa0c383", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1d/ee84a693381a0345e0acd1a16610d38d14a7cd
meta: {size:19885, lines:0, sha256:"5303880656acaad41a5371fda6125bab8f4c90ada5dbb8bd21e82926f32cf125", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

