---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/8c
part_index: 0
files_included: 5
size_bytes_sum: 3132
created_at: 2025-08-31T21:08:15.627078+00:00
integrity:
  sha256_concat: 621f60f2107b8a1e0c572d0177bde82bc40928c04445cc8bfaf134616b127f8e
---

## AingZ_Platf_Repo/.git/objects/8c/807636f90b2562d1e9d56f1f10885755d7c940
meta: {size:1571, lines:0, sha256:"8ddca68dd75ab6fac41ccc493685cffb4afc020201a52d8bc34a4c6144715a70", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8c/b2b592fa29a2c3813add205ae0a39e4a6ac467
meta: {size:235, lines:1, sha256:"067286aa38c6eb8935188b3ae2a499ccf75c335e0835d8317c1232ca0a2dff73", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuÍJ1]ÏS\pSvtçÎN§Rlkð2w2·%NLB}Òw0Åèú|ïV¦ÓóSØÎ.ËëÎª§û> tÆ{G;x5Z+õ>Ë&ç·´#GZHôtG:ÐEÃ¶(Xýñ 0CEþpf¢¤îÏ8DOÁCG>Hm |Z)ÌèÏ¨±0ã0«xU=úùMÉÖ|µaâ8¾Ù§°xé¾5<Ï¸´WG^1>HÒÃÇ³Ç¸iQômè-Äz.ò%¯VËMu÷}·Ñoä
```

## AingZ_Platf_Repo/.git/objects/8c/b8a77eff6bd408f0e7a6f144a07109729e764d
meta: {size:984, lines:0, sha256:"56f638a2fe183ea910360d486226d028c14f8f9a5b83ffd7188862d0e7ebf2ef", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8c/f3de8fd9af6db8d5cae980f40eff1cd0667a60
meta: {size:288, lines:0, sha256:"2ac3cee354014a144a1caa5be95edcbdc4480ee034b153188200f499baf01935", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8c/fbd1d5e5e55b0ef498882ce4a77d63255f4bf5
meta: {size:54, lines:0, sha256:"01e0aadecb741fcdfb0841ca57bd5d389f45ea59b7ae11b146aee8d7b8b23c8e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

