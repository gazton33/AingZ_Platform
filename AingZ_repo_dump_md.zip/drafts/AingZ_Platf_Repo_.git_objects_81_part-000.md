---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/81
part_index: 0
files_included: 5
size_bytes_sum: 33883
created_at: 2025-08-31T21:08:15.625504+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/81/6a4afb5adb6aa1c0c4bd6c3c21f3ffb6285f24
meta: {size:29835, lines:0, sha256:"85e2042989b5321ef9650339853535719090ac8f387957c5595a84512c2a6b40", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/81/8e0280744a08672888739c34242cbe1485b7d5
meta: {size:2068, lines:0, sha256:"a3f368d35040d0abcf5ce8ba501673a3cda997f6a7590abbd959b00210a18698", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/81/99f48528a7da8e5265f7ce1098873b14ab316b
meta: {size:321, lines:0, sha256:"54f6071d9bc10743fee02e27ef98fdc3972f17367e791b9682474a840fea5e43", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/81/a34d87af5e16db737078a1c7f9e387943dad81
meta: {size:152, lines:0, sha256:"f49066b7dc875caba0e57267a012cea7b69d6d7dbc57cd8c689620dcd62bcdb3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/81/e5c7c4342f31205d4d15e1052aeba8d2e1ca36
meta: {size:1507, lines:0, sha256:"3043d51b54116c742984e73f338bc1d356e3ab58cb127c2d0bf4e92afa214549", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

