---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/12
part_index: 0
files_included: 7
size_bytes_sum: 4668
created_at: 2025-08-31T21:08:15.567862+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/12/16ede801c038ca3ec32b53325fe6c7efbc9972
meta: {size:1108, lines:0, sha256:"caf0d17fb586fe64332fe60e168cd38346733d65098bab9a001152eb44681c82", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/12/38533bcff9a209a0aee10e39c241b24d061cb3
meta: {size:89, lines:0, sha256:"2b27ddbc2f4431090c64de2102b910ff0c6b69459092f542c42b79331b1d1421", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/12/9bccadbf76f2aacc709b1d712479565a847ebe
meta: {size:763, lines:0, sha256:"dd7d0fb3a52c99dc5834488a246f91b6b4f710feefd92c8e7cb40c5df3306d77", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/12/9f6e9082454bc44fef025727cc3a6fed0eece2
meta: {size:1898, lines:0, sha256:"b46cbc1bb68f8ceb25576c83a7ba67f462c5fbf774c8a1e56cbf95ead4d5d1c9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/12/a997d484389412690da7927f4f688060e55d72
meta: {size:343, lines:0, sha256:"7297a5cf15fbbb1c47ebe92e4a094580a03f8e6cde5e705d2b71e14284f0afc9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/12/bac007242818a5eacf429e9a272f1e2cde0f90
meta: {size:413, lines:0, sha256:"0c208a020cd018ab7775659f70f1b5048f71ed28d1ecf6b48f1088096d879cdf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/12/d220e8ceb891d3e64dca237022b3bac907c2bd
meta: {size:54, lines:0, sha256:"d3916b087a8aa7b9933937bc13a84b5474938c8a181d81db91cbe3db267c86b2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

