---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/c2
part_index: 0
files_included: 7
size_bytes_sum: 6634
created_at: 2025-08-31T21:08:15.630845+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/c2/0b3cdb54315176852053d285ba47f4060c5177
meta: {size:850, lines:0, sha256:"6bc5b856164c098c8396a000dbc3871d1b883356a42c29e2b06f45d0ddf06fa9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c2/a1aa2c65815ca579f06b1687b2e034630f9cbf
meta: {size:862, lines:0, sha256:"63872ecd67b0ab57781ea36ded6d6463e4b5ba63960ecabcd12d6154d503b37e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c2/b162b887c339dc30f78d1059a8ef8b263ff2d6
meta: {size:764, lines:0, sha256:"0178587e9c472e68f4731416b9bee123794f23810b302b7e10ff8c1e5a77662e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c2/b6e82347de4c303d50d60210ea34924f53ffc7
meta: {size:505, lines:0, sha256:"08d9a1e7f5d384cc6c46f513bc009a24ec17b358cee31048d57350c593159d4d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c2/b75554c1b7ede77e99432e1dedd38255558627
meta: {size:1174, lines:0, sha256:"9cb2a6582c65d4cd859ea6c5978008b4ca761ba12e87e65aaa5425cc5577ce48", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c2/d15c5c27baf95f00df69c661873b12baa4cab6
meta: {size:297, lines:0, sha256:"ed81fb67f537d7c61e45c80266a974e76de01b415f1cc878d8b1f34208c67fbb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c2/e753931ca15847ad99ec04efebc2bfc2a8fe53
meta: {size:2182, lines:0, sha256:"73a3e069822550c160cf8ae583c18876e62bf8c197d573cea3ccc0dbb69d7558", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

