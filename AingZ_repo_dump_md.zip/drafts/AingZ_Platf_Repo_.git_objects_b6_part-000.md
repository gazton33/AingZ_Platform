---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/b6
part_index: 0
files_included: 4
size_bytes_sum: 1870
created_at: 2025-08-31T21:08:15.629877+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/b6/4b9bc7566f9bfd756b3d189f46e69da1a7752c
meta: {size:99, lines:0, sha256:"dab48dfc5022ca876c57903658f503fa00e438fc9a6b02d46cca380d31dcc4fe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b6/54ec79359ea5ce679de4b2e06ec33e17236f06
meta: {size:72, lines:0, sha256:"b61ac75b5742f34fcc9587759e0e245cea651e5f53336cdcce9bd8f07793f575", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b6/68d6bcb0c0a8c913de7526c151ab21eddcc00c
meta: {size:701, lines:0, sha256:"92dfd3f73be4748c6944f5339a39d1fb43460d401260d8ebd1864ba2087268d7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b6/fb610e8d7d09f1de43cc205bf4a1d8c2422764
meta: {size:998, lines:0, sha256:"566adeba4b1272f7fda0069a18f847a3aeb39ea59b7a90d36432a705e20bbef0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

