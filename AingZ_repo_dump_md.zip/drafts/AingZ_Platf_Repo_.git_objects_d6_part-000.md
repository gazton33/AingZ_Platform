---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/d6
part_index: 0
files_included: 7
size_bytes_sum: 60769
created_at: 2025-08-31T21:08:15.649464+00:00
integrity:
  sha256_concat: 66bed9f4f0745034de89da3f81bd32a9a7fda9233518704802c019bd92b3d099
---

## AingZ_Platf_Repo/.git/objects/d6/0343a3f2453729fef4ab6e05d6c51a5a789da8
meta: {size:51, lines:0, sha256:"78bc2b4a9c6b34058f0876fb626286933f6526e2b10dbc26a5b6cbc808a54da2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d6/25471cfaf7debb7a9e599da26e2434370655dd
meta: {size:191, lines:0, sha256:"c63373f1a5202411ca545acb7c8c2d223a55c5a83ddd6dce7b17d612460ba82d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d6/558ba2ea9ee6abf96c02921b8f495d13afb73a
meta: {size:1662, lines:0, sha256:"d9f3248c6dffa94902ae917a8b379d5df1476b5e929715560f2f20fb77c9c796", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d6/5ff83ae0b64e8e3d777ab33b33c377e0d202dc
meta: {size:776, lines:0, sha256:"70c8d1224689d5e9584a3d9084da2c9af461870de0a3106463e3c71445c97c70", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d6/78e760785ac4ba21e10e0b4bd097c48f56ab9d
meta: {size:157, lines:3, sha256:"5c6752bd1765e774e1d238c97293f02a18c2fe160b1479318226c8b4cf5fd8fc", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xMKÂ0DYç#±¯
â\E/à&¦HãÈuùÜ´lØÙ½y³8÷§Ã·Lvñ¼t=®¢ìÜÓJþAÃK1JeÅmQÓª¤b»'õ¿Çú½­Ê\U4×ÌsÈ4¡±£äÀ
*K576Õ»¶¼ÅÝC­òüÞÎ2%ß¹/Ï~J4
```

## AingZ_Platf_Repo/.git/objects/d6/8fdf3ad591ed1bc880fb79f919069e3e581501
meta: {size:666, lines:0, sha256:"e62da809a523da40ff4f9da92bb20164baf4446cedaef5cd39111a954699f486", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d6/d413dccc7fd6d67d65c416e1e7a9daa6edfa31
meta: {size:57266, lines:0, sha256:"2970b8eff055efca813ccf3a5b6d9f79a4148a8377a5c5155fb452be1a8a526a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

