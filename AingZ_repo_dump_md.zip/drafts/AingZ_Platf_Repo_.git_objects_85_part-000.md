---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/85
part_index: 0
files_included: 6
size_bytes_sum: 3191
created_at: 2025-08-31T21:08:15.625888+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/85/00e7007b30cb1529348a0b66157ed2983fe87b
meta: {size:1486, lines:0, sha256:"31f00ae21c37f61a00871e187ab3a92c5d3260fe1573423e49a7a7c59244b83c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/85/0f8536eda8b7a373e2399f22b7ff2b0210eed7
meta: {size:139, lines:0, sha256:"943787b0e91478bc47dc5f4a4dc84e379855b3e88260d56e1fb1b15352adcfd2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/85/358502ccfd93ebd0292695ea5a1fa7ce3a4617
meta: {size:154, lines:0, sha256:"686b547cf4275e0cb23bdb955d7aa2a1679109e96989d792c980ff2fb63bf03e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/85/7212079b3eefb35e7f7fa27d495ff7ef3b2882
meta: {size:128, lines:0, sha256:"17631e1c8282a026c9d66f6ea901187d4cd94516b965598036def7782e1edafa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/85/85471a32efe74936a6246427a43256896171eb
meta: {size:916, lines:0, sha256:"8891ccdb500cf1712e47312764bba618e957dd946cb36abd21147784292f2661", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/85/de9abfd7b63427615d9ba8fa60af3c7745a14d
meta: {size:368, lines:0, sha256:"835e99477166d3d946ee528ea587035f1dfc1f1f3a9c9b7c88a14aeab75e64e3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

