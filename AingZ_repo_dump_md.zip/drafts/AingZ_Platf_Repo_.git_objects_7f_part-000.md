---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/7f
part_index: 0
files_included: 9
size_bytes_sum: 6213
created_at: 2025-08-31T21:08:15.625252+00:00
integrity:
  sha256_concat: d0bf02bee1c1bddbccd2e529394911d08e3fe48fc576cb015522a6e0db6a00c5
---

## AingZ_Platf_Repo/.git/objects/7f/0ee21333c3363a7d27853a6ee490fd762c1d73
meta: {size:155, lines:2, sha256:"a18a72863b36c00c88bbb6bf570fe53679945e215db9529c5493ebbcb2ac5bc7", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎQ
!á=(FÇÑè*®Îl»b¾ÎÐëü¥íû:¬w|]Ä*QâªUç¢GVvµ8!0UÔ<rû°3iHD=Ì8{JÁ'Z(ÎHØäç¸µnüíhÏËé#[{K¿.{^·SiûÅºD89Äö`~õ·8ä/líåÍÉDo
```

## AingZ_Platf_Repo/.git/objects/7f/14d6374d6eff4ee5ac42c82b87cda01471477d
meta: {size:255, lines:0, sha256:"fc899c5a7b9feeac3ffdf3ca9003be3ed7e1c8ac82576c59d32f3c74092ae98e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7f/1ebdfddc058e73dd2f82453ad6d78c1618080b
meta: {size:247, lines:0, sha256:"be2014d05b2b951d3e3a109cec3a83c3649eb2cc126623b7c8212f168837be24", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7f/296b10c9e5408185fdd83bdefd0107cd73c6b6
meta: {size:636, lines:0, sha256:"a3d5b3419f23de10bad04e571f210515ffa8f1a3bc7514910dea0744c1497a42", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7f/4115d75adc5a1386ffbc24e097a769e37ceed4
meta: {size:91, lines:0, sha256:"c5ec1f325032303f4aed5d590714e2f342d7a8b29fafcf78f337f8cd657d8028", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7f/618bb7db191ba7b32d71abd84fad7fb4acc0f4
meta: {size:811, lines:0, sha256:"ed3ce23442c97c7d31fc8bcbd97685fb140dd033d3e4134e5ea7a3f53a508e86", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7f/85767f07f7319519b4c39f304c988b3b36f970
meta: {size:2347, lines:0, sha256:"a0daeea32b5687fb6af391a30347cfa56177d25d750d3cf361d8e2f57b08d94f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7f/95e2609d84319558ab2ca5039c5f5ed96cb471
meta: {size:837, lines:0, sha256:"4588c80f3f70ec12339c9759933d3d45423b97f861546ad9d26e8a12e490e8c8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7f/a4f1b8b223b994c5033d78a66f743a369da0e0
meta: {size:834, lines:0, sha256:"cb7372b59c6ae5144232b34c040a8048ad0e2e1fdfc7a893f101ec81d57e95b0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

