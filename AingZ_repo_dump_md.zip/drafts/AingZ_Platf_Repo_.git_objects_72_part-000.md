---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/72
part_index: 0
files_included: 5
size_bytes_sum: 4226
created_at: 2025-08-31T21:08:15.623915+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/72/39106b56fc3fa24a6c1aae30b799b9cbd7c8d2
meta: {size:737, lines:0, sha256:"b33387a9aa89637b2bca473d0ff6c799122f70d830acf5557788653b9e896879", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/72/9068361df13f38f0493e86dbcbb040da4d592f
meta: {size:1721, lines:0, sha256:"906d9e90ca08e810e260656034d049911d3518cac79f34fcc04b63f4aa82c1b5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/72/9f9a04873b8a04cf5da609bdb3f2202987d320
meta: {size:534, lines:0, sha256:"c2e07761814d7944f294c19436f8cc15ef8bfba03a0db23fdff57367fe2e60ee", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/72/f377c4928f61f7525f9212ec048dc0aafaa81b
meta: {size:51, lines:0, sha256:"0fd09e10cb95b22dfafaab8a1fbb6e6889a3709eb1125a69ea6584dc61600735", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/72/f5dbbfe7fb9a354d76774c5d819b4e0430739f
meta: {size:1183, lines:0, sha256:"82060449c106e089c2066045559c4a166670550eb3f094639d330d8c001e0535", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

