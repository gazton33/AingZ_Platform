---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/legacy/data oficial/Docs_OpenAi
part_index: 4
files_included: 2
size_bytes_sum: 199090
created_at: 2025-08-31T21:08:15.526976+00:00
integrity:
  sha256_concat: b8e2a17b1b8979081198d24e4f4bde8d33d06466409c1da49ad99bef713048ea
---

## AingZ_Platf_Repo/legacy/data oficial/Docs_OpenAi/6.Realtime_Api.md
meta: {size:63522, lines:1231, sha256:"b9d90f6088422257a08ce271425ee03e8a5a406a4a799156437685b585014eba", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md


## Imported snippet – 2025-07-03 14:37:10

Realtime API
Beta
====================
Build low-latency, multi-modal experiences with the Realtime API.
The OpenAI Realtime API enables low-latency, multimodal interactions including speech-to-speech conversational experiences and real-time transcription.
This API works with natively multimodal models such as [GPT-4o](/docs/models/gpt-4o-realtime) and [GPT-4o mini](/docs/models/gpt-4o-mini-realtime), offering capabilities such as real-time text and audio processing, function calling, and speech generation, and with the latest transcription models [GPT-4o Transcribe](/docs/models/gpt-4o-transcribe) and [GPT-4o mini Transcribe](/docs/models/gpt-4o-mini-transcribe).
Get started with the Realtime API
---------------------------------
Just getting started with Realtime? Try the new [Agents SDK for TypeScript](https://openai.github.io/openai-agents-js), optimized for building voice agents with Realtime models.
You can connect to the Realtime API in two ways:
\* Using [WebRTC](#connect-with-webrtc), which is ideal for client-side applications (for example, a web app)
\* Using [WebSockets](#connect-with-websockets), which is great for server-to-server applications (from your backend or if you're building a voice agent over phone for example)
Start by exploring examples and partner integrations below, or learn how to connect to the Realtime API using the most relevant method for your use case below.

### Example applications
Check out one of the example applications below to see the Realtime API in action.
[
Realtime Console
To get started quickly, download and configure the Realtime console demo. See events flowing back and forth, and inspect their contents. Learn how to execute custom logic with function calling.
](https://github.com/openai/openai-realtime-console)[
Realtime Solar System demo
A demo of the Realtime API with the WebRTC integration, navigating the solar system through voice thanks to function calling.
](https://github.com/openai/openai-realtime-solar-system)[
Twilio Integration Demo
A demo combining the Realtime API with Twilio to build an AI calling assistant.
](https://github.com/openai/openai-realtime-twilio-demo)[
Realtime API Agents Demo
A demonstration of handoffs between Realtime API voice agents with reasoning model validation.
](https://github.com/openai/openai-realtime-agents)

### Partner integrations
Check out these partner integrations, which use the Realtime API in frontend applications and telephony use cases.
[
LiveKit integration guide
How to use the Realtime API with LiveKit's WebRTC infrastructure.
](https://docs.livekit.io/agents/openai/overview/)[
Twilio integration guide
Build Realtime apps using Twilio's powerful voice APIs.
](https://www.twilio.com/en-us/blog/twilio-openai-realtime-api-launch-integration)[
Agora integration quickstart
How to integrate Agora's real-time audio communication capabilities with the Realtime API.
](https://docs.agora.io/en/open-ai-integration/get-started/quickstart)[
Pipecat integration guide
Create voice agents with OpenAI audio models and Pipecat orchestration framework.
](https://docs.pipecat.ai/guides/features/openai-audio-models-and-apis)[
Stream integration guide
Learn how to deploy voice agents in mobile and web applications using Stream's global edge network.
](https://getstream.io/video/voice-agents/)[](https://github.com/craigsdennis/talk-to-javascript-openai-workers)
[
](https://github.com/craigsdennis/talk-to-javascript-openai-workers)
[
Client-side tool calling
](https://github.com/craigsdennis/talk-to-javascript-openai-workers)
[](https://github.com/craigsdennis/talk-to-javascript-openai-workers)
[Built with Cloudflare Workers, an example application showcasing client-side tool calling. Also check out the](https://github.com/craigsdennis/talk-to-javascript-openai-workers) [tutorial on YouTube](https://www.youtube.com/watch?v=TcOytsfva0o).
Use cases
---------
The most common use case for the Realtime API is to build a real-time, speech-to-speech, conversational experience. This is great for building [voice agents](/docs/guides/voice-agents) and other voice-enabled applications.
The Realtime API can also be used independently for transcription and turn detection use cases. A client can stream audio in and have Realtime API produce streaming transcripts when speech is detected.
Both use-cases benefit from built-in [voice activity detection (VAD)](/docs/guides/realtime-vad) to automatically detect when a user is done speaking. This can be helpful to seamlessly handle conversation turns, or to analyze transcriptions one phrase at a time.
Learn more about these use cases in the dedicated guides.
[
Realtime Speech-to-Speech
Learn to use the Realtime API for streaming speech-to-speech conversations.
](/docs/guides/realtime-conversations)[
Realtime Transcription
Learn to use the Realtime API for transcription-only use cases.
](/docs/guides/realtime-transcription)
Depending on your use case (conversation or transcription), you should initialize a session in different ways. Use the switcher below to see the details for each case.
Connect with WebRTC
-------------------
[WebRTC](https://webrtc.org/) is a powerful set of standard interfaces for building real-time applications. The OpenAI Realtime API supports connecting to realtime models through a WebRTC peer connection. Follow this guide to learn how to configure a WebRTC connection to the Realtime API.

### Overview
In scenarios where you would like to connect to a Realtime model from an insecure client over the network (like a web browser), we recommend using the WebRTC connection method. WebRTC is better equipped to handle variable connection states, and provides a number of convenient APIs for capturing user audio inputs and playing remote audio streams from the model.
Connecting to the Realtime API from the browser should be done with an ephemeral API key, [generated via the OpenAI REST API](/docs/api-reference/realtime-sessions). The process for initializing a WebRTC connection is as follows (assuming a web browser client):
1. A browser makes a request to a developer-controlled server to mint an ephemeral API key.
2. The developer's server uses a [standard API key](/settings/organization/api-keys) to request an ephemeral key from the [OpenAI REST API](/docs/api-reference/realtime-sessions), and returns that new key to the browser. Note that ephemeral keys currently expire one minute after being issued.
3. The browser uses the ephemeral key to authenticate a session directly with the OpenAI Realtime API as a [WebRTC peer connection](https://developer.mozilla.org/en-US/docs/Web/API/RTCPeerConnection).
![connect to realtime via WebRTC](https://openaidevs.retool.com/api/file/55b47800-9aaf-48b9-90d5-793ab227ddd3)
While it is technically possible to use a [standard API key](/settings/organization/api-keys) to authenticate client-side WebRTC sessions, \*\*this is a dangerous and insecure practice\*\* because it leaks your secret key. Standard API keys grant access to your full OpenAI API account, and should only be used in secure server-side environments. We recommend ephemeral keys in client-side applications whenever possible.

### Connection details
Connecting via WebRTC requires the following connection information:
|URL|https://api.openai.com/v1/realtime|
|Query Parameters|modelRealtime model ID to connect to, like gpt-4o-realtime-preview-2025-06-03|
|Headers|Authorization: Bearer EPHEMERAL\_KEYSubstitute EPHEMERAL\_KEY with an ephemeral API token - see below for details on how to generate one.|
The following example shows how to initialize a [WebRTC session](https://webrtc.org/getting-started/overview) (including the data channel to send and receive Realtime API events). It assumes you have already fetched an ephemeral API token (example server code for this can be found in the [next section](#creating-an-ephemeral-token)).
```javascript
async function init() {
// Get an ephemeral key from your server - see server code below
const tokenResponse = await fetch("/session");
const data = await tokenResponse.json();
const EPHEMERAL\_KEY = data.client\_secret.value;
// Create a peer connection
const pc = new RTCPeerConnection();
// Set up to play remote audio from the model
const audioEl = document.createElement("audio");
audioEl.autoplay = true;
pc.ontrack = e => audioEl.srcObject = e.streams[0];
// Add local audio track for microphone input in the browser
const ms = await navigator.mediaDevices.getUserMedia({
audio: true
});
pc.addTrack(ms.getTracks()[0]);
// Set up data channel for sending and receiving events
const dc = pc.createDataChannel("oai-events");
dc.addEventListener("message", (e) => {
// Realtime server events appear here!
console.log(e);
});
// Start the session using the Session Description Protocol (SDP)
const offer = await pc.createOffer();
await pc.setLocalDescription(offer);
const baseUrl = "https://api.openai.com/v1/realtime";
const model = "gpt-4o-realtime-preview-2025-06-03";
const sdpResponse = await fetch(`${baseUrl}?model=${model}`, {
method: "POST",
body: offer.sdp,
headers: {
Authorization: `Bearer ${EPHEMERAL\_KEY}`,
"Content-Type": "application/sdp"
},
});
const answer = {
type: "answer",
sdp: await sdpResponse.text(),
};
await pc.setRemoteDescription(answer);
}
init();
```
The WebRTC APIs provide rich controls for handling media streams and input devices. For more guidance on building user interfaces on top of WebRTC, [refer to the docs on MDN](https://developer.mozilla.org/en-US/docs/Web/API/WebRTC\_API).

### Creating an ephemeral token
To create an ephemeral token to use on the client-side, you will need to build a small server-side application (or integrate with an existing one) to make an [OpenAI REST API](/docs/api-reference/realtime-sessions) request for an ephemeral key. You will use a [standard API key](/settings/organization/api-keys) to authenticate this request on your backend server.
Below is an example of a simple Node.js [express](https://expressjs.com/) server which mints an ephemeral API key using the REST API:
```javascript
import express from "express";
const app = express();
// An endpoint which would work with the client code above - it returns
// the contents of a REST API request to this protected endpoint
app.get("/session", async (req, res) => {
const r = await fetch("https://api.openai.com/v1/realtime/sessions", {
method: "POST",
headers: {
"Authorization": `Bearer ${process.env.OPENAI\_API\_KEY}`,
"Content-Type": "application/json",
},
body: JSON.stringify({
model: "gpt-4o-realtime-preview-2025-06-03",
voice: "verse",
}),
});
const data = await r.json();
// Send back the JSON we received from the OpenAI REST API
res.send(data);
});
app.listen(3000);
```
You can create a server endpoint like this one on any platform that can send and receive HTTP requests. Just ensure that \*\*you only use standard OpenAI API keys on the server, not in the browser.\*\*

### Sending and receiving events
To learn how to send and receive events over the WebRTC data channel, refer to the [Realtime conversations guide](/docs/guides/realtime-conversations#handling-audio-with-webrtc).
Connect with WebSockets
-----------------------
[WebSockets](https://developer.mozilla.org/en-US/docs/Web/API/WebSockets\_API) are a broadly supported API for realtime data transfer, and a great choice for connecting to the OpenAI Realtime API in server-to-server applications. For browser and mobile clients, we recommend connecting via [WebRTC](#connect-with-webrtc).

### Overview
In a server-to-server integration with Realtime, your backend system will connect via WebSocket directly to the Realtime API. You can use a [standard API key](/settings/organization/api-keys) to authenticate this connection, since the token will only be available on your secure backend server.
![connect directly to realtime API](https://openaidevs.retool.com/api/file/464d4334-c467-4862-901b-d0c6847f003a)
WebSocket connections can also be authenticated with an ephemeral client token ([as shown above in the WebRTC section](#creating-an-ephemeral-token)) if you choose to connect to the Realtime API via WebSocket on a client device.
Standard OpenAI API tokens \*\*should only be used in secure server-side environments\*\*.

### Connection details
Speech-to-Speech
Connecting via WebSocket requires the following connection information:
|URL|wss://api.openai.com/v1/realtime|
|Query Parameters|modelRealtime model ID to connect to, like gpt-4o-realtime-preview-2025-06-03|
|Headers|Authorization: Bearer YOUR\_API\_KEYSubstitute YOUR\_API\_KEY with a standard API key on the server, or an ephemeral token on insecure clients (note that WebRTC is recommended for this use case).OpenAI-Beta: realtime=v1This header is required during the beta period.|
Below are several examples of using these connection details to initialize a WebSocket connection to the Realtime API.
ws module (Node.js)
Connect using the ws module (Node.js)
```javascript
import WebSocket from "ws";
const url = "wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview-2024-12-17";
const ws = new WebSocket(url, {
headers: {
"Authorization": "Bearer " + process.env.OPENAI\_API\_KEY,
"OpenAI-Beta": "realtime=v1",
},
});
ws.on("open", function open() {
console.log("Connected to server.");
});
ws.on("message", function incoming(message) {
console.log(JSON.parse(message.toString()));
});
```
websocket-client (Python)
Connect with websocket-client (Python)
```python

# example requires websocket-client library:

# pip install websocket-client
import os
import json
import websocket
OPENAI\_API\_KEY = os.environ.get("OPENAI\_API\_KEY")
url = "wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview-2024-12-17"
headers = [
"Authorization: Bearer " + OPENAI\_API\_KEY,
"OpenAI-Beta: realtime=v1"
]
def on\_open(ws):
print("Connected to server.")
def on\_message(ws, message):
data = json.loads(message)
print("Received event:", json.dumps(data, indent=2))
ws = websocket.WebSocketApp(
url,
header=headers,
on\_open=on\_open,
on\_message=on\_message,
)
ws.run\_forever()
```
WebSocket (browsers)
Connect with standard WebSocket (browsers)
```javascript
/\*
Note that in client-side environments like web browsers, we recommend
using WebRTC instead. It is possible, however, to use the standard
WebSocket interface in browser-like environments like Deno and
Cloudflare Workers.
\*/
const ws = new WebSocket(
"wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview-2024-12-17",
[
"realtime",
// Auth
"openai-insecure-api-key." + OPENAI\_API\_KEY,
// Optional
"openai-organization." + OPENAI\_ORG\_ID,
"openai-project." + OPENAI\_PROJECT\_ID,
// Beta protocol, required
"openai-beta.realtime-v1"
]
);
ws.on("open", function open() {
console.log("Connected to server.");
});
ws.on("message", function incoming(message) {
console.log(message.data);
});
```

### Sending and receiving events
To learn how to send and receive events over Websockets, refer to the [Realtime conversations guide](/docs/guides/realtime-conversations#handling-audio-with-websockets).
Transcription
Connecting via WebSocket requires the following connection information:
|URL|wss://api.openai.com/v1/realtime|
|Query Parameters|intentThe intent of the connection: transcription|
|Headers|Authorization: Bearer YOUR\_API\_KEYSubstitute YOUR\_API\_KEY with a standard API key on the server, or an ephemeral token on insecure clients (note that WebRTC is recommended for this use case).OpenAI-Beta: realtime=v1This header is required during the beta period.|
Below are several examples of using these connection details to initialize a WebSocket connection to the Realtime API.
ws module (Node.js)
Connect using the ws module (Node.js)
```javascript
import WebSocket from "ws";
const url = "wss://api.openai.com/v1/realtime?intent=transcription";
const ws = new WebSocket(url, {
headers: {
"Authorization": "Bearer " + process.env.OPENAI\_API\_KEY,
"OpenAI-Beta": "realtime=v1",
},
});
ws.on("open", function open() {
console.log("Connected to server.");
});
ws.on("message", function incoming(message) {
console.log(JSON.parse(message.toString()));
});
```
websocket-client (Python)
Connect with websocket-client (Python)
```python
import os
import json
import websocket
OPENAI\_API\_KEY = os.environ.get("OPENAI\_API\_KEY")
url = "wss://api.openai.com/v1/realtime?intent=transcription"
headers = [
"Authorization: Bearer " + OPENAI\_API\_KEY,
"OpenAI-Beta: realtime=v1"
]
def on\_open(ws):
print("Connected to server.")
def on\_message(ws, message):
data = json.loads(message)
print("Received event:", json.dumps(data, indent=2))
ws = websocket.WebSocketApp(
url,
header=headers,
on\_open=on\_open,
on\_message=on\_message,
)
ws.run\_forever()
```
WebSocket (browsers)
Connect with standard WebSocket (browsers)
```javascript
/\*
Note that in client-side environments like web browsers, we recommend
using WebRTC instead. It is possible, however, to use the standard
WebSocket interface in browser-like environments like Deno and
Cloudflare Workers.
\*/
const ws = new WebSocket(
"wss://api.openai.com/v1/realtime?intent=transcription",
[
"realtime",
// Auth
"openai-insecure-api-key." + OPENAI\_API\_KEY,
// Optional
"openai-organization." + OPENAI\_ORG\_ID,
"openai-project." + OPENAI\_PROJECT\_ID,
// Beta protocol, required
"openai-beta.realtime-v1"
]
);
ws.on("open", function open() {
console.log("Connected to server.");
});
ws.on("message", function incoming(message) {
console.log(message.data);
});
```

### Sending and receiving events
To learn how to send and receive events over Websockets, refer to the [Realtime transcription guide](/docs/guides/realtime-transcription#handling-transcriptions).
Was this page useful?


## Imported snippet – 2025-07-03 14:37:17

Realtime conversations
Beta
==============================
Learn how to manage Realtime speech-to-speech conversations.
Once you have connected to the Realtime API through either [WebRTC](/docs/guides/realtime-webrtc) or [WebSocket](/docs/guides/realtime-websocket), you can call a Realtime model (such as [gpt-4o-realtime-preview](/docs/models/gpt-4o-realtime-preview)) to have speech-to-speech conversations. Doing so will require you to \*\*send client events\*\* to initiate actions, and \*\*listen for server events\*\* to respond to actions taken by the Realtime API.
This guide will walk through the event flows required to use model capabilities like audio and text generation and function calling, and how to think about the state of a Realtime Session.
If you do not need to have a conversation with the model, meaning you don't expect any response, you can use the Realtime API in [transcription mode](/docs/guides/realtime-transcription).
Realtime speech-to-speech sessions
----------------------------------
A Realtime Session is a stateful interaction between the model and a connected client. The key components of the session are:
\* The \*\*Session\*\* object, which controls the parameters of the interaction, like the model being used, the voice used to generate output, and other configuration.
\* A \*\*Conversation\*\*, which represents user input Items and model output Items generated during the current session.
\* \*\*Responses\*\*, which are model-generated audio or text Items that are added to the Conversation.
\*\*Input audio buffer and WebSockets\*\*
If you are using WebRTC, much of the media handling required to send and receive audio from the model is assisted by WebRTC APIs.
If you are using WebSockets for audio, you will need to manually interact with the \*\*input audio buffer\*\* by sending audio to the server, sent with JSON events with base64-encoded audio.
All these components together make up a Realtime Session. You will use client events to update the state of the session, and listen for server events to react to state changes within the session.
![diagram realtime state](https://openaidevs.retool.com/api/file/11fe71d2-611e-4a26-a587-881719a90e56)
Session lifecycle events
------------------------
After initiating a session via either [WebRTC](/docs/guides/realtime-webrtc) or [WebSockets](/docs/guides/realtime-websockets), the server will send a [`session.created`](/docs/api-reference/realtime-server-events/session/created) event indicating the session is ready. On the client, you can update the current session configuration with the [`session.update`](/docs/api-reference/realtime-client-events/session/update) event. Most session properties can be updated at any time, except for the `voice` the model uses for audio output, after the model has responded with audio once during the session. The maximum duration of a Realtime session is \*\*30 minutes\*\*.
The following example shows updating the session with a `session.update` client event. See the [WebRTC](/docs/guides/realtime-webrtc#sending-and-receiving-events) or [WebSocket](/docs/guides/realtime-websocket#sending-and-receiving-events) guide for more on sending client events over these channels.
Update the system instructions used by the model in this session
```javascript
const event = {
type: "session.update",
session: {
instructions: "Never use the word 'moist' in your responses!"
},
};
// WebRTC data channel and WebSocket both have .send()
dataChannel.send(JSON.stringify(event));
```
```python
event = {
"type": "session.update",
"session": {
"instructions": "Never use the word 'moist' in your responses!"
}
}
ws.send(json.dumps(event))
```
When the session has been updated, the server will emit a [`session.updated`](/docs/api-reference/realtime-server-events/session/updated) event with the new state of the session.
||
|session.update|session.createdsession.updated|
Text inputs and outputs
-----------------------
To generate text with a Realtime model, you can add text inputs to the current conversation, ask the model to generate a response, and listen for server-sent events indicating the progress of the model's response. In order to generate text, the [session must be configured](/docs/api-reference/realtime-client-events/session/update) with the `text` modality (this is true by default).
Create a new text conversation item using the [`conversation.item.create`](/docs/api-reference/realtime-client-events/conversation/item/create) client event. This is similar to sending a [user message (prompt) in Chat Completions](/docs/guides/text-generation) in the REST API.
Create a conversation item with user input
```javascript
const event = {
type: "conversation.item.create",
item: {
type: "message",
role: "user",
content: [
{
type: "input\_text",
text: "What Prince album sold the most copies?",
}
]
},
};
// WebRTC data channel and WebSocket both have .send()
dataChannel.send(JSON.stringify(event));
```
```python
event = {
"type": "conversation.item.create",
"item": {
"type": "message",
"role": "user",
"content": [
{
"type": "input\_text",
"text": "What Prince album sold the most copies?",
}
]
}
}
ws.send(json.dumps(event))
```
After adding the user message to the conversation, send the [`response.create`](/docs/api-reference/realtime-client-events/response/create) event to initiate a response from the model. If both audio and text are enabled for the current session, the model will respond with both audio and text content. If you'd like to generate text only, you can specify that when sending the `response.create` client event, as shown below.
Generate a text-only response
```javascript
const event = {
type: "response.create",
response: {
modalities: [ "text" ]
},
};
// WebRTC data channel and WebSocket both have .send()
dataChannel.send(JSON.stringify(event));
```
```python
event = {
"type": "response.create",
"response": {
"modalities": [ "text" ]
}
}
ws.send(json.dumps(event))
```
When the response is completely finished, the server will emit the [`response.done`](/docs/api-reference/realtime-server-events/response/done) event. This event will contain the full text generated by the model, as shown below.
Listen for response.done to see the final results
```javascript
function handleEvent(e) {
const serverEvent = JSON.parse(e.data);
if (serverEvent.type === "response.done") {
console.log(serverEvent.response.output[0]);
}
}
// Listen for server messages (WebRTC)
dataChannel.addEventListener("message", handleEvent);
// Listen for server messages (WebSocket)
// ws.on("message", handleEvent);
```
```python
def on\_message(ws, message):
server\_event = json.loads(message)
if server\_event.type == "response.done":
print(server\_event.response.output[0])
```
While the model response is being generated, the server will emit a number of lifecycle events during the process. You can listen for these events, such as [`response.text.delta`](/docs/api-reference/realtime-server-events/response/text/delta), to provide realtime feedback to users as the response is generated. A full listing of the events emitted by there server are found below under \*\*related server events\*\*. They are provided in the rough order of when they are emitted, along with relevant client-side events for text generation.
||
|conversation.item.createresponse.create|conversation.item.createdresponse.createdresponse.output\_item.addedresponse.content\_part.addedresponse.text.deltaresponse.text.doneresponse.content\_part.doneresponse.output\_item.doneresponse.donerate\_limits.updated|
Audio inputs and outputs
------------------------
One of the most powerful features of the Realtime API is voice-to-voice interaction with the model, without an intermediate text-to-speech or speech-to-text step. This enables lower latency for voice interfaces, and gives the model more data to work with around the tone and inflection of voice input.

### Voice options
Realtime sessions can be configured to use one of several built‑in voices when producing audio output. You can set the `voice` on session creation (or on a `response.create`) to control how the model sounds. Current voice options are `alloy`, `ash`, `ballad`, `coral`, `echo`, `sage`, `shimmer`, and `verse`. Once the model has emitted audio in a session, the `voice` cannot be modified for that session.

### Handling audio with WebRTC
If you are connecting to the Realtime API using WebRTC, the Realtime API is acting as a [peer connection](https://developer.mozilla.org/en-US/docs/Web/API/RTCPeerConnection) to your client. Audio output from the model is delivered to your client as a [remote media stream](hhttps://developer.mozilla.org/en-US/docs/Web/API/MediaStream). Audio input to the model is collected using audio devices ([`getUserMedia`](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia)), and media streams are added as tracks to to the peer connection.
The example code from the [WebRTC connection guide](/docs/guides/realtime-webrtc) shows a basic example of configuring both local and remote audio using browser APIs:
```javascript
// Create a peer connection
const pc = new RTCPeerConnection();
// Set up to play remote audio from the model
const audioEl = document.createElement("audio");
audioEl.autoplay = true;
pc.ontrack = e => audioEl.srcObject = e.streams[0];
// Add local audio track for microphone input in the browser
const ms = await navigator.mediaDevices.getUserMedia({
audio: true
});
pc.addTrack(ms.getTracks()[0]);
```
The snippet above enables simple interaction with the Realtime API, but there's much more that can be done. For more examples of different kinds of user interfaces, check out the [WebRTC samples](https://github.com/webrtc/samples) repository. Live demos of these samples can also be [found here](https://webrtc.github.io/samples/).
Using [media captures and streams](https://developer.mozilla.org/en-US/docs/Web/API/Media\_Capture\_and\_Streams\_API) in the browser enables you to do things like mute and unmute microphones, select which device to collect input from, and more.

### Client and server events for audio in WebRTC
By default, WebRTC clients don't need to send any client events to the Realtime API before sending audio inputs. Once a local audio track is added to the peer connection, your users can just start talking!
However, WebRTC clients still receive a number of server-sent lifecycle events as audio is moving back and forth between client and server over the peer connection. Examples include:
\* When input is sent over the local media track, you will receive [`input\_audio\_buffer.speech\_started`](/docs/api-reference/realtime-server-events/input\_audio\_buffer/speech\_started) events from the server.
\* When local audio input stops, you'll receive the [`input\_audio\_buffer.speech\_stopped`](/docs/api-reference/realtime-server-events/input\_audio\_buffer/speech\_started) event.
\* You'll receive [delta events for the in-progress audio transcript](/docs/api-reference/realtime-server-events/response/audio\_transcript/delta).
\* You'll receive a [`response.done`](/docs/api-reference/realtime-server-events/response/done) event when the model has transcribed and completed sending a response.
Manipulating WebRTC APIs for media streams may give you all the control you need. However, it may occasionally be necessary to use lower-level interfaces for audio input and output. Refer to the WebSockets section below for more information and a listing of events required for granular audio input handling.

### Handling audio with WebSockets
When sending and receiving audio over a WebSocket, you will have a bit more work to do in order to send media from the client, and receive media from the server. Below, you'll find a table describing the flow of events during a WebSocket session that are necessary to send and receive audio over the WebSocket.
The events below are given in lifecycle order, though some events (like the `delta` events) may happen concurrently.
||
|Session initialization|session.update|session.createdsession.updated|
|User audio input|conversation.item.create  (send whole audio message)input\_audio\_buffer.append  (stream audio in chunks)input\_audio\_buffer.commit  (used when VAD is disabled)response.create  (used when VAD is disabled)|input\_audio\_buffer.speech\_startedinput\_audio\_buffer.speech\_stoppedinput\_audio\_buffer.committed|
|Server audio output|input\_audio\_buffer.clear  (used when VAD is disabled)|conversation.item.createdresponse.createdresponse.output\_item.createdresponse.content\_part.addedresponse.audio.deltaresponse.audio\_transcript.deltaresponse.text.deltaresponse.audio.doneresponse.audio\_transcript.doneresponse.text.doneresponse.content\_part.doneresponse.output\_item.doneresponse.donerate\_limits.updated|

### Streaming audio input to the server
To stream audio input to the server, you can use the [`input\_audio\_buffer.append`](/docs/api-reference/realtime-client-events/input\_audio\_buffer/append) client event. This event requires you to send chunks of \*\*Base64-encoded audio bytes\*\* to the Realtime API over the socket. Each chunk cannot exceed 15 MB in size.
The format of the input chunks can be configured either for the entire session, or per response.
\* Session: `session.input\_audio\_format` in [`session.update`](/docs/api-reference/realtime-client-events/session/update)
\* Response: `response.input\_audio\_format` in [`response.create`](/docs/api-reference/realtime-client-events/response/create)
Append audio input bytes to the conversation
```javascript
import fs from 'fs';
import decodeAudio from 'audio-decode';
// Converts Float32Array of audio data to PCM16 ArrayBuffer
function floatTo16BitPCM(float32Array) {
const buffer = new ArrayBuffer(float32Array.length \* 2);
const view = new DataView(buffer);
let offset = 0;
for (let i = 0; i < float32Array.length; i++, offset += 2) {
let s = Math.max(-1, Math.min(1, float32Array[i]));
view.setInt16(offset, s < 0 ? s \* 0x8000 : s \* 0x7fff, true);
}
return buffer;
}
// Converts a Float32Array to base64-encoded PCM16 data
base64EncodeAudio(float32Array) {
const arrayBuffer = floatTo16BitPCM(float32Array);
let binary = '';
let bytes = new Uint8Array(arrayBuffer);
const chunkSize = 0x8000; // 32KB chunk size
for (let i = 0; i < bytes.length; i += chunkSize) {
let chunk = bytes.subarray(i, i + chunkSize);
binary += String.fromCharCode.apply(null, chunk);
}
return btoa(binary);
}
// Fills the audio buffer with the contents of three files,
// then asks the model to generate a response.
const files = [
'./path/to/sample1.wav',
'./path/to/sample2.wav',
'./path/to/sample3.wav'
];
for (const filename of files) {
const audioFile = fs.readFileSync(filename);
const audioBuffer = await decodeAudio(audioFile);
const channelData = audioBuffer.getChannelData(0);
const base64Chunk = base64EncodeAudio(channelData);
ws.send(JSON.stringify({
type: 'input\_audio\_buffer.append',
audio: base64Chunk
}));
});
ws.send(JSON.stringify({type: 'input\_audio\_buffer.commit'}));
ws.send(JSON.stringify({type: 'response.create'}));
```
```python
import base64
import json
import struct
import soundfile as sf
from websocket import create\_connection

# ... create websocket-client named ws ...
def float\_to\_16bit\_pcm(float32\_array):
clipped = [max(-1.0, min(1.0, x)) for x in float32\_array]
pcm16 = b''.join(struct.pack(' 1 else data
base64\_chunk = base64\_encode\_audio(channel\_data)

# Send the client event
event = {
"type": "input\_audio\_buffer.append",
"audio": base64\_chunk
}
ws.send(json.dumps(event))
```

### Send full audio messages
It is also possible to create conversation messages that are full audio recordings. Use the [`conversation.item.create`](/docs/api-reference/realtime-client-events/conversation/item/create) client event to create messages with `input\_audio` content.
Create full audio input conversation items
```javascript
const fullAudio = "";
const event = {
type: "conversation.item.create",
item: {
type: "message",
role: "user",
content: [
{
type: "input\_audio",
audio: fullAudio,
},
],
},
};
// WebRTC data channel and WebSocket both have .send()
dataChannel.send(JSON.stringify(event));
```
```python
fullAudio = ""
event = {
"type": "conversation.item.create",
"item": {
"type": "message",
"role": "user",
"content": [
{
"type": "input\_audio",
"audio": fullAudio,
}
],
},
}
ws.send(json.dumps(event))
```

### Working with audio output from a WebSocket
\*\*To play output audio back on a client device like a web browser, we recommend using WebRTC rather than WebSockets\*\*. WebRTC will be more robust sending media to client devices over uncertain network conditions.
But to work with audio output in server-to-server applications using a WebSocket, you will need to listen for [`response.audio.delta`](/docs/api-reference/realtime-server-events/response/audio/delta) events containing the Base64-encoded chunks of audio data from the model. You will either need to buffer these chunks and write them out to a file, or maybe immediately stream them to another source like [a phone call with Twilio](https://www.twilio.com/en-us/blog/twilio-openai-realtime-api-launch-integration).
Note that the [`response.audio.done`](/docs/api-reference/realtime-server-events/response/audio/done) and [`response.done`](/docs/api-reference/realtime-server-events/response/done) events won't actually contain audio data in them - just audio content transcriptions. To get the actual bytes, you'll need to listen for the [`response.audio.delta`](/docs/api-reference/realtime-server-events/response/audio/delta) events.
The format of the output chunks can be configured either for the entire session, or per response.
\* Session: `session.output\_audio\_format` in [`session.update`](/docs/api-reference/realtime-client-events/session/update)
\* Response: `response.output\_audio\_format` in [`response.create`](/docs/api-reference/realtime-client-events/response/create)
Listen for response.audio.delta events
```javascript
function handleEvent(e) {
const serverEvent = JSON.parse(e.data);
if (serverEvent.type === "response.audio.delta") {
// Access Base64-encoded audio chunks
// console.log(serverEvent.delta);
}
}
// Listen for server messages (WebSocket)
ws.on("message", handleEvent);
```
```python
def on\_message(ws, message):
server\_event = json.loads(message)
if server\_event.type == "response.audio.delta":

# Access Base64-encoded audio chunks:

# print(server\_event.delta)
```
Voice activity detection
------------------------
By default, Realtime sessions have \*\*voice activity detection (VAD)\*\* enabled, which means the API will determine when the user has started or stopped speaking and respond automatically.
Read more about how to configure VAD in our [voice activity detection](/docs/guides/realtime-vad) guide.

### Disable VAD
VAD can be disabled by setting `turn\_detection` to `null` with the [`session.update`](/docs/api-reference/realtime-client-events/session/update) client event. This can be useful for interfaces where you would like to take granular control over audio input, like [push to talk](https://en.wikipedia.org/wiki/Push-to-talk) interfaces.
When VAD is disabled, the client will have to manually emit some additional client events to trigger audio responses:
\* Manually send [`input\_audio\_buffer.commit`](/docs/api-reference/realtime-client-events/input\_audio\_buffer/commit), which will create a new user input item for the conversation.
\* Manually send [`response.create`](/docs/api-reference/realtime-client-events/response/create) to trigger an audio response from the model.
\* Send [`input\_audio\_buffer.clear`](/docs/api-reference/realtime-client-events/input\_audio\_buffer/clear) before beginning a new user input.

### Keep VAD, but disable automatic responses
If you would like to keep VAD mode enabled, but would just like to retain the ability to manually decide when a response is generated, you can set `turn\_detection.interrupt\_response` and `turn\_detection.create\_response` to `false` with the [`session.update`](/docs/api-reference/realtime-client-events/session/update) client event. This will retain all the behavior of VAD but not automatically create new Responses. Clients can trigger these manually with a [`response.create`](/docs/api-reference/realtime-client-events/response/create) event.
This can be useful for moderation or input validation or RAG patterns, where you're comfortable trading a bit more latency in the interaction for control over inputs.
Create responses outside the default conversation
-------------------------------------------------
By default, all responses generated during a session are added to the session's conversation state (the "default conversation"). However, you may want to generate model responses outside the context of the session's default conversation, or have multiple responses generated concurrently. You might also want to have more granular control over which conversation items are considered while the model generates a response (e.g. only the last N number of turns).
Generating "out-of-band" responses which are not added to the default conversation state is possible by setting the `response.conversation` field to the string `none` when creating a response with the [`response.create`](/docs/api-reference/realtime-client-events/response/create) client event.
When creating an out-of-band response, you will probably also want some way to identify which server-sent events pertain to this response. You can provide `metadata` for your model response that will help you identify which response is being generated for this client-sent event.
Create an out-of-band model response
```javascript
const prompt = `
Analyze the conversation so far. If it is related to support, output
"support". If it is related to sales, output "sales".
`;
const event = {
type: "response.create",
response: {
// Setting to "none" indicates the response is out of band
// and will not be added to the default conversation
conversation: "none",
// Set metadata to help identify responses sent back from the model
metadata: { topic: "classification" },
// Set any other available response fields
modalities: [ "text" ],
instructions: prompt,
},
};
// WebRTC data channel and WebSocket both have .send()
dataChannel.send(JSON.stringify(event));
```
```python
prompt = """
Analyze the conversation so far. If it is related to support, output
"support". If it is related to sales, output "sales".
"""
event = {
"type": "response.create",
"response": {

# Setting to "none" indicates the response is out of band,

# and will not be added to the default conversation
"conversation": "none",

# Set metadata to help identify responses sent back from the model
"metadata": { "topic": "classification" },

# Set any other available response fields
"modalities": [ "text" ],
"instructions": prompt,
},
}
ws.send(json.dumps(event))
```
Now, when you listen for the [`response.done`](/docs/api-reference/realtime-server-events/response/done) server event, you can identify the result of your out-of-band response.
Create an out-of-band model response
```javascript
function handleEvent(e) {
const serverEvent = JSON.parse(e.data);
if (
serverEvent.type === "response.done" &&
serverEvent.response.metadata?.topic === "classification"
) {
// this server event pertained to our OOB model response
console.log(serverEvent.response.output[0]);
}
}
// Listen for server messages (WebRTC)
dataChannel.addEventListener("message", handleEvent);
// Listen for server messages (WebSocket)
// ws.on("message", handleEvent);
```
```python
def on\_message(ws, message):
server\_event = json.loads(message)
topic = ""

# See if metadata is present
try:
topic = server\_event.response.metadata.topic
except AttributeError:
print("topic not set")
if server\_event.type == "response.done" and topic == "classification":

# this server event pertained to our OOB model response
print(server\_event.response.output[0])
```

### Create a custom context for responses
You can also construct a custom context that the model will use to generate a response, outside the default/current conversation. This can be done using the `input` array on a [`response.create`](/docs/api-reference/realtime-client-events/response/create) client event. You can use new inputs, or reference existing input items in the conversation by ID.
Listen for out-of-band model response with custom context
```javascript
const event = {
type: "response.create",
response: {
conversation: "none",
metadata: { topic: "pizza" },
modalities: [ "text" ],
// Create a custom input array for this request with whatever context
// is appropriate
input: [
// potentially include existing conversation items:
{
type: "item\_reference",
id: "some\_conversation\_item\_id"
},
{
type: "message",
role: "user",
content: [
{
type: "input\_text",
text: "Is it okay to put pineapple on pizza?",
},
],
},
],
},
};
// WebRTC data channel and WebSocket both have .send()
dataChannel.send(JSON.stringify(event));
```
```python
event = {
"type": "response.create",
"response": {
"conversation": "none",
"metadata": { "topic": "pizza" },
"modalities": [ "text" ],

# Create a custom input array for this request with whatever

# context is appropriate
"input": [

# potentially include existing conversation items:
{
"type": "item\_reference",
"id": "some\_conversation\_item\_id"
},

# include new content as well
{
"type": "message",
"role": "user",
"content": [
{
"type": "input\_text",
"text": "Is it okay to put pineapple on pizza?",
}
],
}
],
},
}
ws.send(json.dumps(event))
```

### Create responses with no context
You can also insert responses into the default conversation, ignoring all other instructions and context. Do this by setting `input` to an empty array.
Insert no-context model responses into the default conversation
```javascript
const prompt = `
Say exactly the following:
I'm a little teapot, short and stout!
This is my handle, this is my spout!
`;
const event = {
type: "response.create",
response: {
// An empty input array removes existing context
input: [],
instructions: prompt,
},
};
// WebRTC data channel and WebSocket both have .send()
dataChannel.send(JSON.stringify(event));
```
```python
prompt = """
Say exactly the following:
I'm a little teapot, short and stout!
This is my handle, this is my spout!
"""
event = {
"type": "response.create",
"response": {

# An empty input array removes all prior context
"input": [],
"instructions": prompt,
},
}
ws.send(json.dumps(event))
```
Function calling
----------------
The Realtime models also support \*\*function calling\*\*, which enables you to execute custom code to extend the capabilities of the model. Here's how it works at a high level:
1. When [updating the session](/docs/api-reference/realtime-client-events/session/update) or [creating a response](/docs/api-reference/realtime-client-events/response/create), you can specify a list of available functions for the model to call.
2. If when processing input, the model determines it should make a function call, it will add items to the conversation representing arguments to a function call.
3. When the client detects conversation items that contain function call arguments, it will execute custom code using those arguments
4. When the custom code has been executed, the client will create new conversation items that contain the output of the function call, and ask the model to respond.
Let's see how this would work in practice by adding a callable function that will provide today's horoscope to users of the model. We'll show the shape of the client event objects that need to be sent, and what the server will emit in turn.

### Configure callable functions
First, we must give the model a selection of functions it can call based on user input. Available functions can be configured either at the session level, or the individual response level.
\* Session: `session.tools` property in [`session.update`](/docs/api-reference/realtime-client-events/session/update)
\* Response: `response.tools` property in [`response.create`](/docs/api-reference/realtime-client-events/response/create)
Here's an example client event payload for a `session.update` that configures a horoscope generation function, that takes a single argument (the astrological sign for which the horoscope should be generated):
[`session.update`](/docs/api-reference/realtime-client-events/session/update)
```json
{
"type": "session.update",
"session": {
"tools": [
{
"type": "function",
"name": "generate\_horoscope",
"description": "Give today's horoscope for an astrological sign.",
"parameters": {
"type": "object",
"properties": {
"sign": {
"type": "string",
"description": "The sign for the horoscope.",
"enum": [
"Aries",
"Taurus",
"Gemini",
"Cancer",
"Leo",
"Virgo",
"Libra",
"Scorpio",
"Sagittarius",
"Capricorn",
"Aquarius",
"Pisces"
]
}
},
"required": ["sign"]
}
}
],
"tool\_choice": "auto",
}
}
```
The `description` fields for the function and the parameters help the model choose whether or not to call the function, and what data to include in each parameter. If the model receives input that indicates the user wants their horoscope, it will call this function with a `sign` parameter.

### Detect when the model wants to call a function
Based on inputs to the model, the model may decide to call a function in order to generate the best response. Let's say our application adds the following conversation item and attempts to generate a response:
[`conversation.item.create`](/docs/api-reference/realtime-client-events/conversation/item/create)
```json
{
"type": "conversation.item.create",
"item": {
"type": "message",
"role": "user",
"content": [
{
"type": "input\_text",
"text": "What is my horoscope? I am an aquarius."
}
]
}
}
```
Followed by a client event to generate a response:
[`response.create`](/docs/api-reference/realtime-client-events/response/create)
```json
{
"type": "response.create"
}
```
Instead of immediately returning a text or audio response, the model will instead generate a response that contains the arguments that should be passed to a function in the developer's application. You can listen for realtime updates to function call arguments using the [`response.function\_call\_arguments.delta`](/docs/api-reference/realtime-server-events/response/function\_call\_arguments/delta) server event, but `response.done` will also have the complete data we need to call our function.
[`response.done`](/docs/api-reference/realtime-server-events/response/done)
```json
{
"type": "response.done",
"event\_id": "event\_AeqLA8iR6FK20L4XZs2P6",
"response": {
"object": "realtime.response",
"id": "resp\_AeqL8XwMUOri9OhcQJIu9",
"status": "completed",
"status\_details": null,
"output": [
{
"object": "realtime.item",
"id": "item\_AeqL8gmRWDn9bIsUM2T35",
"type": "function\_call",
"status": "completed",
"name": "generate\_horoscope",
"call\_id": "call\_sHlR7iaFwQ2YQOqm",
"arguments": "{\"sign\":\"Aquarius\"}"
}
],
"usage": {
"total\_tokens": 541,
"input\_tokens": 521,
"output\_tokens": 20,
"input\_token\_details": {
"text\_tokens": 292,
"audio\_tokens": 229,
"cached\_tokens": 0,
"cached\_tokens\_details": { "text\_tokens": 0, "audio\_tokens": 0 }
},
"output\_token\_details": {
"text\_tokens": 20,
"audio\_tokens": 0
}
},
"metadata": null
}
}
```
In the JSON emitted by the server, we can detect that the model wants to call a custom function:
|Property|Function calling purpose|
|---|---|
|response.output[0].type|When set to function\_call, indicates this response contains arguments for a named function call.|
|response.output[0].name|The name of the configured function to call, in this case generate\_horoscope|
|response.output[0].arguments|A JSON string containing arguments to the function. In our case, "{\"sign\":\"Aquarius\"}".|
|response.output[0].call\_id|A system-generated ID for this function call - you will need this ID to pass a function call result back to the model.|
Given this information, we can execute code in our application to generate the horoscope, and then provide that information back to the model so it can generate a response.

### Provide the results of a function call to the model
Upon receiving a response from the model with arguments to a function call, your application can execute code that satisfies the function call. This could be anything you want, like talking to external APIs or accessing databases.
Once you are ready to give the model the results of your custom code, you can create a new conversation item containing the result via the `conversation.item.create` client event.
[`conversation.item.create`](/docs/api-reference/realtime-client-events/conversation/item/create)
```json
{
"type": "conversation.item.create",
"item": {
"type": "function\_call\_output",
"call\_id": "call\_sHlR7iaFwQ2YQOqm",
"output": "{\"horoscope\": \"You will soon meet a new friend.\"}"
}
}
```
\* The conversation item type is `function\_call\_output`
\* `item.call\_id` is the same ID we got back in the `response.done` event above
\* `item.output` is a JSON string containing the results of our function call
Once we have added the conversation item containing our function call results, we again emit the `response.create` event from the client. This will trigger a model response using the data from the function call.
[`response.create`](/docs/api-reference/realtime-client-events/response/create)
```json
{
"type": "response.create"
}
```
Error handling
--------------
The [`error`](/docs/api-reference/realtime-server-events/error) event is emitted by the server whenever an error condition is encountered on the server during the session. Occasionally, these errors can be traced to a client event that was emitted by your application.
Unlike HTTP requests and responses, where a response is implicitly tied to a request from the client, we need to use an `event\_id` property on client events to know when one of them has triggered an error condition on the server. This technique is shown in the code below, where the client attempts to emit an unsupported event type.
```javascript
const event = {
event\_id: "my\_awesome\_event",
type: "scooby.dooby.doo",
};
dataChannel.send(JSON.stringify(event));
```
This unsuccessful event sent from the client will emit an error event like the following:
```json
{
"type": "invalid\_request\_error",
"code": "invalid\_value",
"message": "Invalid value: 'scooby.dooby.doo' ...",
"param": "type",
"event\_id": "my\_awesome\_event"
}
```
Was this page useful?


## Imported snippet – 2025-07-03 14:37:26

Realtime transcription
Beta
==============================
Learn how to transcribe audio in real-time with the Realtime API.
You can use the Realtime API for transcription-only use cases, either with input from a microphone or from a file. For example, you can use it to generate subtitles or transcripts in real-time. With the transcription-only mode, the model will not generate responses.
If you want the model to produce responses, you can use the Realtime API in [speech-to-speech conversation mode](/docs/guides/realtime-conversations).
Realtime transcription sessions
-------------------------------
To use the Realtime API for transcription, you need to create a transcription session, connecting via [WebSockets](/docs/guides/realtime?use-case=transcription#connect-with-websockets) or [WebRTC](/docs/guides/realtime?use-case=transcription#connect-with-webrtc).
Unlike the regular Realtime API sessions for conversations, the transcription sessions typically don't contain responses from the model.
The transcription session object is also different from regular Realtime API sessions:
```json
{
object: "realtime.transcription\_session",
id: string,
input\_audio\_format: string,
input\_audio\_transcription: [{
model: string,
prompt: string,
language: string
}],
turn\_detection: {
type: "server\_vad",
threshold: float,
prefix\_padding\_ms: integer,
silence\_duration\_ms: integer,
} | null,
input\_audio\_noise\_reduction: {
type: "near\_field" | "far\_field"
},
include: list[string] | null
}
```
Some of the additional properties transcription sessions support are:
\* `input\_audio\_transcription.model`: The transcription model to use, currently `gpt-4o-transcribe`, `gpt-4o-mini-transcribe`, and `whisper-1` are supported
\* `input\_audio\_transcription.prompt`: The prompt to use for the transcription, to guide the model (e.g. "Expect words related to technology")
\* `input\_audio\_transcription.language`: The language to use for the transcription, ideally in ISO-639-1 format (e.g. "en", "fr"...) to improve accuracy and latency
\* `input\_audio\_noise\_reduction`: The noise reduction configuration to use for the transcription
\* `include`: The list of properties to include in the transcription events
Possible values for the input audio format are: `pcm16` (default), `g711\_ulaw` and `g711\_alaw`.
You can find more information about the transcription session object in the [API reference](/docs/api-reference/realtime-sessions/transcription\_session\_object).
Handling transcriptions
-----------------------
When using the Realtime API for transcription, you can listen for the `conversation.item.input\_audio\_transcription.delta` and `conversation.item.input\_audio\_transcription.completed` events.
For `whisper-1` the `delta` event will contain full turn transcript, same as `completed` event. For `gpt-4o-transcribe` and `gpt-4o-mini-transcribe` the `delta` event will contain incremental transcripts as they are streamed out from the model.
Here is an example transcription delta event:
```json
{
"event\_id": "event\_2122",
"type": "conversation.item.input\_audio\_transcription.delta",
"item\_id": "item\_003",
"content\_index": 0,
"delta": "Hello,"
}
```
Here is an example transcription completion event:
```json
{
"event\_id": "event\_2122",
"type": "conversation.item.input\_audio\_transcription.completed",
"item\_id": "item\_003",
"content\_index": 0,
"transcript": "Hello, how are you?"
}
```
Note that ordering between completion events from different speech turns is not guaranteed. You should use `item\_id` to match these events to the `input\_audio\_buffer.committed` events and use `input\_audio\_buffer.committed.previous\_item\_id` to handle the ordering.
To send audio data to the transcription session, you can use the `input\_audio\_buffer.append` event.
You have 2 options:
\* Use a streaming microphone input
\* Stream data from a wav file
Voice activity detection
------------------------
The Realtime API supports automatic voice activity detection (VAD). Enabled by default, VAD will control when the input audio buffer is committed, therefore when transcription begins.
Read more about configuring VAD in our [Voice Activity Detection](/docs/guides/realtime-vad) guide.
You can also disable VAD by setting the `turn\_detection` property to `null`, and control when to commit the input audio on your end.
Additional configurations
-------------------------

### Noise reduction
You can use the `input\_audio\_noise\_reduction` property to configure how to handle noise reduction in the audio stream.
The possible values are:
\* `near\_field`: Use near-field noise reduction.
\* `far\_field`: Use far-field noise reduction.
\* `null`: Disable noise reduction.
The default value is `near\_field`, and you can disable noise reduction by setting the property to `null`.

### Using logprobs
You can use the `include` property to include logprobs in the transcription events, using `item.input\_audio\_transcription.logprobs`.
Those logprobs can be used to calculate the confidence score of the transcription.
```json
{
"type": "transcription\_session.update",
"input\_audio\_format": "pcm16",
"input\_audio\_transcription": {
"model": "gpt-4o-transcribe",
"prompt": "",
"language": ""
},
"turn\_detection": {
"type": "server\_vad",
"threshold": 0.5,
"prefix\_padding\_ms": 300,
"silence\_duration\_ms": 500,
},
"input\_audio\_noise\_reduction": {
"type": "near\_field"
},
"include": [
"item.input\_audio\_transcription.logprobs",
],
}
```
Was this page useful?


## Imported snippet – 2025-07-03 14:37:32

Voice activity detection (VAD)
Beta
======================================
Learn about automatic voice activity detection in the Realtime API.
Voice activity detection (VAD) is a feature available in the Realtime API allowing to automatically detect when the user has started or stopped speaking. It is enabled by default in [speech-to-speech](/docs/guides/realtime-conversations) or [transcription](/docs/guides/realtime-transcription) Realtime sessions, but is optional and can be turned off.
Overview
--------
When VAD is enabled, the audio is chunked automatically and the Realtime API sends events to indicate when the user has started or stopped speaking:
\* `input\_audio\_buffer.speech\_started`: The start of a speech turn
\* `input\_audio\_buffer.speech\_stopped`: The end of a speech turn
You can use these events to handle speech turns in your application. For example, you can use them to manage conversation state or process transcripts in chunks.
You can use the `turn\_detection` property of the `session.update` event to configure how audio is chunked within each speech-to-text sample.
There are two modes for VAD:
\* `server\_vad`: Automatically chunks the audio based on periods of silence.
\* `semantic\_vad`: Chunks the audio when the model believes based on the words said by the user that they have completed their utterance.
The default value is `server\_vad`.
Read below to learn more about the different modes.
Server VAD
----------
Server VAD is the default mode for Realtime sessions, and uses periods of silence to automatically chunk the audio.
You can adjust the following properties to fine-tune the VAD settings:
\* `threshold`: Activation threshold (0 to 1). A higher threshold will require louder audio to activate the model, and thus might perform better in noisy environments.
\* `prefix\_padding\_ms`: Amount of audio (in milliseconds) to include before the VAD detected speech.
\* `silence\_duration\_ms`: Duration of silence (in milliseconds) to detect speech stop. With shorter values turns will be detected more quickly.
Here is an example VAD configuration:
```json
{
"type": "session.update",
"session": {
"turn\_detection": {
"type": "server\_vad",
"threshold": 0.5,
"prefix\_padding\_ms": 300,
"silence\_duration\_ms": 500,
"create\_response": true, // only in conversation mode
"interrupt\_response": true, // only in conversation mode
}
}
}
```
Semantic VAD
------------
Semantic VAD is a new mode that uses a semantic classifier to detect when the user has finished speaking, based on the words they have uttered. This classifier scores the input audio based on the probability that the user is done speaking. When the probability is low, the model will wait for a timeout, whereas when it is high, there is no need to wait. For example, user audio that trails off with an "ummm..." would result in a longer timeout than a definitive statement.
With this mode, the model is less likely to interrupt the user during a speech-to-speech conversation, or chunk a transcript before the user is done speaking.
Semantic VAD can be activated by setting `turn\_detection.type` to `semantic\_vad` in a [`session.update`](/docs/api-reference/realtime-client-events/session/update) event.
It can be configured like this:
```json
{
"type": "session.update",
"session": {
"turn\_detection": {
"type": "semantic\_vad",
"eagerness": "low" | "medium" | "high" | "auto", // optional
"create\_response": true, // only in conversation mode
"interrupt\_response": true, // only in conversation mode
}
}
}
```
The optional `eagerness` property is a way to control how eager the model is to interrupt the user, tuning the maximum wait timeout. In transcription mode, even if the model doesn't reply, it affects how the audio is chunked.
\* `auto` is the default value, and is equivalent to `medium`.
\* `low` will let the user take their time to speak.
\* `high` will chunk the audio as soon as possible.
If you want the model to respond more often in conversation mode, or to return transcription events faster in transcription mode, you can set `eagerness` to `high`.
On the other hand, if you want to let the user speak uninterrupted in conversation mode, or if you would like larger transcript chunks in transcription mode, you can set `eagerness` to `low`.
Was this page useful?
```

## AingZ_Platf_Repo/legacy/data oficial/Docs_OpenAi/7.Model_Optimization.md
meta: {size:135568, lines:2314, sha256:"81bc0afee9637dd06d4516ca137795d8a71ce2c2994552b434161bd18e9c1098", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md


## Imported snippet – 2025-07-03 14:38:14

Model optimization
==================
Ensure quality model outputs with evals and fine-tuning in the OpenAI platform.
LLM output is non-deterministic, and model behavior changes between model snapshots and families. Developers must constantly measure and tune the performance of LLM applications to ensure they're getting the best results. In this guide, we explore the techniques and OpenAI platform tools you can use to ensure high quality outputs from the model.
[
![Evals](https://cdn.openai.com/API/docs/images/blue\_card.png)
Evals
Systematically measure performance.
](/docs/guides/evals)[
![Prompt engineering](https://cdn.openai.com/API/docs/images/orange\_card.png)
Prompt engineering
Give context, instructions, and goals.
](/docs/guides/text?api-mode=responses#prompt-engineering)[
![Fine-tuning](https://cdn.openai.com/API/docs/images/purple\_card.png)
Fine-tuning
Train models to excel at a task.
](/docs/guides/supervised-fine-tuning)
Model optimization workflow
---------------------------
Optimizing model output requires a combination of \*\*evals\*\*, \*\*prompt engineering\*\*, and \*\*fine-tuning\*\*, creating a flywheel of feedback that leads to better prompts and better training data for fine-tuning. The optimization process usually goes something like this.
1. Write [evals](/docs/guides/evals) that measure model output, establishing a baseline for performance and accuracy.
2. [Prompt the model](/docs/guides/text) for output, providing relevant context data and instructions.
3. For some use cases, it may be desirable to [fine-tune](#fine-tune-a-model) a model for a specific task.
4. Run evals using test data that is representative of real world inputs. Measure the performance of your prompt and fine-tuned model.
5. Tweak your prompt or fine-tuning dataset based on eval feedback.
6. Repeat the loop continuously to improve your model results.
Here's an overview of the major steps, and how to do them using the OpenAI platform.
Build evals
-----------
In the OpenAI platform, you can [build and run evals](/docs/guides/evals) either via API or in the [dashboard](/evaluations). You might even consider writing evals \_before\_ you start writing prompts, taking an approach akin to behavior-driven development (BDD).
Run your evals against test inputs like you expect to see in production. Using one of several available [graders](/docs/guides/graders), measure the results of a prompt against your test data set.
[
Learn about evals
Run tests on your model outputs to ensure you're getting the right results.
](/docs/guides/evals)
Write effective prompts
-----------------------
With evals in place, you can effectively iterate on [prompts](/docs/guides/text). The prompt engineering process may be all you need in order to get great results for your use case. Different models may require different prompting techniques, but there are several best practices you can apply across the board to get better results.
\* \*\*Include relevant context\*\* - in your instructions, include text or image content that the model will need to generate a response from outside its training data. This could include data from private databases or current, up-to-the-minute information.
\* \*\*Provide clear instructions\*\* - your prompt should contain clear goals about what kind of output you want. GPT models like `gpt-4.1` are great at following very explicit instructions, while [reasoning models](/docs/guides/reasoning) like `o4-mini` tend to do better with high level guidance on outcomes.
\* \*\*Provide example outputs\*\* - give the model a few examples of correct output for a given prompt (a process called few-shot learning). The model can extrapolate from these examples how it should respond for other prompts.
[
Learn about prompt engineering
Learn the basics of writing good prompts for the model.
](/docs/guides/text)
Fine-tune a model
-----------------
OpenAI models are already pre-trained to perform across a broad range of subjects and tasks. Fine-tuning lets you take an OpenAI base model, provide the kinds of inputs and outputs you expect in your application, and get a model that excels in the tasks you'll use it for.
Fine-tuning can be a time-consuming process, but it can also enable a model to consistently format responses in a certain way or handle novel inputs. You can use fine-tuning with [prompt engineering](/docs/guides/text) to realize a few more benefits over prompting alone:
\* You can provide more example inputs and outputs than could fit within the context window of a single request, enabling the model handle a wider variety of prompts.
\* You can use shorter prompts with fewer examples and context data, which saves on token costs at scale and can be lower latency.
\* You can train on proprietary or sensitive data without having to include it via examples in every request.
\* You can train a smaller, cheaper, faster model to excel at a particular task where a larger model is not cost-effective.
Visit our [pricing page](https://openai.com/api/pricing) to learn more about how fine-tuned model training and usage are billed.

### Fine-tuning methods
These are the fine-tuning methods supported in the OpenAI platform today.
||
|Supervised fine-tuning (SFT)|Provide examples of correct responses to prompts to guide the model's behavior.Often uses human-generated "ground truth" responses to show the model how it should respond.|ClassificationNuanced translationGenerating content in a specific formatCorrecting instruction-following failures|gpt-4.1-2025-04-14 gpt-4.1-mini-2025-04-14 gpt-4.1-nano-2025-04-14|
|Vision fine-tuning|Provide image inputs for supervised fine-tuning to improve the model's understanding of image inputs.|Image classificationCorrecting failures in instruction following for complex prompts|gpt-4o-2024-08-06|
|Direct preference optimization (DPO)|Provide both a correct and incorrect example response for a prompt. Indicate the correct response to help the model perform better.|Summarizing text, focusing on the right thingsGenerating chat messages with the right tone and style|gpt-4.1-2025-04-14 gpt-4.1-mini-2025-04-14 gpt-4.1-nano-2025-04-14|
|Reinforcement fine-tuning (RFT)|Generate a response for a prompt, provide an expert grade for the result, and reinforce the model's chain-of-thought for higher-scored responses.Requires expert graders to agree on the ideal output from the model.Reasoning models only.|Complex domain-specific tasks that require advanced reasoningMedical diagnoses based on history and diagnostic guidelinesDetermining relevant passages from legal case law|o4-mini-2025-04-16|

### How fine-tuning works
In the OpenAI platform, you can create fine-tuned models either in the [dashboard](/finetune) or [with the API](/docs/api-reference/fine-tuning). This is the general shape of the fine-tuning process:
1. Collect a dataset of examples to use as training data
2. Upload that dataset to OpenAI, formatted in JSONL
3. Create a fine-tuning job using one of the methods above, depending on your goals—this begins the fine-tuning training process
4. In the case of RFT, you'll also define a grader to score the model's behavior
5. Evaluate the results
Get started with [supervised fine-tuning](/docs/guides/supervised-fine-tuning), [vision fine-tuning](/docs/guides/vision-fine-tuning), [direct perference optimization](/docs/guides/direct-preference-optimization), or [reinforcement fine-tuning](/docs/guides/reinforcement-fine-tuning).
Learn from experts
------------------
Model optimization is a complex topic, and sometimes more art than science. Check out the videos below from members of the OpenAI team on model optimization techniques.
Cost/accuracy/latency
Distillation
Optimizing LLM Performance
Was this page useful?


## Imported snippet – 2025-07-03 14:38:18

Evaluating model performance
============================
Test and improve model outputs through evaluations.
Evaluations (often called \*\*evals\*\*) test model outputs to ensure they meet style and content criteria that you specify. Writing evals to understand how your LLM applications are performing against your expectations, especially when upgrading or trying new models, is an essential component to building reliable applications.
In this guide, we will focus on \*\*configuring evals programmatically using the [Evals API](/docs/api-reference/evals)\*\*. If you prefer, you can also configure evals [in the OpenAI dashboard](/evaluations).
Broadly, there are three steps to build and run evals for your LLM application.
1. Describe the task to be done as an eval
2. Run your eval with test inputs (a prompt and input data)
3. Analyze the results, then iterate and improve on your prompt
This process is somewhat similar to behavior-driven development (BDD), where you begin by specifying how the system should behave before implementing and testing the system. Let's see how we would complete each of the steps above using the [Evals API](/docs/api-reference/evals).
Create an eval for a task
-------------------------
Creating an eval begins by describing a task to be done by a model. Let's say that we would like to use a model to classify the contents of IT support tickets into one of three categories: `Hardware`, `Software`, or `Other`.
To implement this use case with the [Chat Completions API](/docs/api-reference/chat), you might write code like this that combines a [developer message](/docs/guides/text) with a user message containing the text of a support ticket.
Categorize IT support tickets
```bash
curl https://api.openai.com/v1/chat/completions \
-H "Authorization: Bearer $OPENAI\_API\_KEY" \
-d '{
"model": "gpt-4.1",
"messages": [
{
"role": "developer",
"content": "Categorize the following support ticket into one of Hardware, Software, or Other."
},
{
"role": "user",
"content": "My monitor wont turn on - help!"
}
]
}'
```
```javascript
import OpenAI from "openai";
const client = new OpenAI();
const instructions = `
You are an expert in categorizing IT support tickets. Given the support
ticket below, categorize the request into one of "Hardware", "Software",
or "Other". Respond with only one of those words.
`;
const ticket = "My monitor won't turn on - help!";
const completion = await client.chat.completions.create({
model: "gpt-4.1",
messages: [
{ role: "developer", content: instructions },
{ role: "user", content: ticket },
],
});
console.log(completion.choices[0].message.content);
```
```python
from openai import OpenAI
client = OpenAI()
instructions = """
You are an expert in categorizing IT support tickets. Given the support
ticket below, categorize the request into one of "Hardware", "Software",
or "Other". Respond with only one of those words.
"""
ticket = "My monitor won't turn on - help!"
completion = client.chat.completions.create(
model="gpt-4.1",
messages=[
{"role": "developer", "content": instructions},
{"role": "user", "content": ticket}
]
)
print(completion.choices[0].message.content)
```
Let's set up an eval to test this behavior [via API](/docs/api-reference/evals). An eval needs two key ingredients:
\* `data\_source\_config`: A schema for the test data you will use along with the eval.
\* `testing\_criteria`: The [graders](/docs/guides/graders) that determine if the model output is correct.
Create an eval
```bash
curl https://api.openai.com/v1/evals \
-H "Authorization: Bearer $OPENAI\_API\_KEY" \
-H "Content-Type: application/json" \
-d '{
"name": "IT Ticket Categorization",
"data\_source\_config": {
"type": "custom",
"item\_schema": {
"type": "object",
"properties": {
"ticket\_text": { "type": "string" },
"correct\_label": { "type": "string" }
},
"required": ["ticket\_text", "correct\_label"]
},
"include\_sample\_schema": true
},
"testing\_criteria": [
{
"type": "string\_check",
"name": "Match output to human label",
"input": "{{ sample.output\_text }}",
"operation": "eq",
"reference": "{{ item.correct\_label }}"
}
]
}'
```
```javascript
import OpenAI from "openai";
const openai = new OpenAI();
const evalObj = await openai.evals.create({
name: "IT Ticket Categorization",
data\_source\_config: {
type: "custom",
item\_schema: {
type: "object",
properties: {
ticket\_text: { type: "string" },
correct\_label: { type: "string" }
},
required: ["ticket\_text", "correct\_label"],
},
include\_sample\_schema: true,
},
testing\_criteria: [
{
type: "string\_check",
name: "Match output to human label",
input: "{{ sample.output\_text }}",
operation: "eq",
reference: "{{ item.correct\_label }}",
},
],
});
console.log(evalObj);
```
```python
from openai import OpenAI
client = OpenAI()
eval\_obj = client.evals.create(
name="IT Ticket Categorization",
data\_source\_config={
"type": "custom",
"item\_schema": {
"type": "object",
"properties": {
"ticket\_text": {"type": "string"},
"correct\_label": {"type": "string"},
},
"required": ["ticket\_text", "correct\_label"],
},
"include\_sample\_schema": True,
},
testing\_criteria=[
{
"type": "string\_check",
"name": "Match output to human label",
"input": "{{ sample.output\_text }}",
"operation": "eq",
"reference": "{{ item.correct\_label }}",
}
],
)
print(eval\_obj)
```
Explanation: data\\_source\\_config parameter
Running this eval will require a test data set that represents the type of data you expect your prompt to work with (more on creating the test data set later in this guide). In our `data\_source\_config` parameter, we specify that each \*\*item\*\* in the data set will conform to a [JSON schema](https://json-schema.org/) with two properties:
\* `ticket\_text`: a string of text with the contents of a support ticket
\* `correct\_label`: a "ground truth" output that the model should match, provided by a human
Since we will be referencing a \*\*sample\*\* in our test criteria (the output generated by a model given our prompt), we also set `include\_sample\_schema` to `true`.
```json
{
"type": "custom",
"item\_schema": {
"type": "object",
"properties": {
"ticket": { "type": "string" },
"category": { "type": "string" }
},
"required": ["ticket", "category"]
},
"include\_sample\_schema": true
}
```
Explanation: testing\\_criteria parameter
In our `testing\_criteria`, we define how we will conclude if the model output satisfies our requirements for each item in the data set. In this case, we just want the model to output one of three category strings based on the input ticket. The string it outputs should exactly match the human-labeled `correct\_label` field in our test data. So in this case, we will want to use a `string\_check` grader to evaluate the output.
In the test configuration, we will introduce template syntax, represented by the `{{` and `}}` brackets below. This is how we will insert dynamic content into the test for this eval.
\* `{{ item.correct\_label }}` refers to the ground truth value in our test data.
\* `{{ sample.output\_text }}` refers to the content we will generate from a model to evaluate our prompt - we'll show how to do that when we actually kick off the eval run.
```json
{
"type": "string\_check",
"name": "Category string match",
"input": "{{ sample.output\_text }}",
"operation": "eq",
"reference": "{{ item.category }}"
}
```
After creating the eval, it will be assigned a UUID that you will need to address it later when kicking off a run.
```json
{
"object": "eval",
"id": "eval\_67e321d23b54819096e6bfe140161184",
"data\_source\_config": {
"type": "custom",
"schema": { ... omitted for brevity... }
},
"testing\_criteria": [
{
"name": "Match output to human label",
"id": "Match output to human label-c4fdf789-2fa5-407f-8a41-a6f4f9afd482",
"type": "string\_check",
"input": "{{ sample.output\_text }}",
"reference": "{{ item.correct\_label }}",
"operation": "eq"
}
],
"name": "IT Ticket Categorization",
"created\_at": 1742938578,
"metadata": {}
}
```
Now that we've created an eval that describes the desired behavior of our application, let's test a prompt with a set of test data.
Test a prompt with your eval
----------------------------
Now that we have defined how we want our app to behave in an eval, let's construct a prompt that reliably generates the correct output for a representative sample of test data.

### Uploading test data
There are several ways to provide test data for eval runs, but it may be convenient to upload a [JSONL](https://jsonlines.org/) file that contains data in the schema we specified when we created our eval. A sample JSONL file that conforms to the schema we set up is below:
```json
{ "item": { "ticket\_text": "My monitor won't turn on!", "correct\_label": "Hardware" } }
{ "item": { "ticket\_text": "I'm in vim and I can't quit!", "correct\_label": "Software" } }
{ "item": { "ticket\_text": "Best restaurants in Cleveland?", "correct\_label": "Other" } }
```
This data set contains both test inputs and ground truth labels to compare model outputs against.
Next, let's upload our test data file to the OpenAI platform so we can reference it later. You can upload files [in the dashboard here](/storage/files), but it's possible to [upload files via API](/docs/api-reference/files/create) as well. The samples below assume you are running the command in a directory where you saved the sample JSON data above to a file called `tickets.jsonl`:
Upload a test data file
```bash
curl https://api.openai.com/v1/files \
-H "Authorization: Bearer $OPENAI\_API\_KEY" \
-F purpose="evals" \
-F file="@tickets.jsonl"
```
```javascript
import fs from "fs";
import OpenAI from "openai";
const openai = new OpenAI();
const file = await openai.files.create({
file: fs.createReadStream("tickets.jsonl"),
purpose: "evals",
});
console.log(file);
```
```python
from openai import OpenAI
client = OpenAI()
file = client.files.create(
file=open("tickets.jsonl", "rb"),
purpose="evals"
)
print(file)
```
When you upload the file, make note of the unique `id` property in the response payload (also available in the UI if you uploaded via the browser) - we will need to reference that value later:
```json
{
"object": "file",
"id": "file-CwHg45Fo7YXwkWRPUkLNHW",
"purpose": "evals",
"filename": "tickets.jsonl",
"bytes": 208,
"created\_at": 1742834798,
"expires\_at": null,
"status": "processed",
"status\_details": null
}
```

### Creating an eval run
With our test data in place, let's evaluate a prompt and see how it performs against our test criteria. Via API, we can do this by [creating an eval run](/docs/api-reference/evals/createRun).
Make sure to replace `YOUR\_EVAL\_ID` and `YOUR\_FILE\_ID` with the unique IDs of the eval configuration and test data files you created in the steps above.
Create an eval run
```bash
curl https://api.openai.com/v1/evals/YOUR\_EVAL\_ID/runs \
-H "Authorization: Bearer $OPENAI\_API\_KEY" \
-H "Content-Type: application/json" \
-d '{
"name": "Categorization text run",
"data\_source": {
"type": "completions",
"model": "gpt-4.1",
"input\_messages": {
"type": "template",
"template": [
{"role": "developer", "content": "You are an expert in categorizing IT support tickets. Given the support ticket below, categorize the request into one of Hardware, Software, or Other. Respond with only one of those words."},
{"role": "user", "content": "{{ item.ticket\_text }}"}
]
},
"source": { "type": "file\_id", "id": "YOUR\_FILE\_ID" }
}
}'
```
```javascript
import OpenAI from "openai";
const openai = new OpenAI();
const run = await openai.evals.runs.create("YOUR\_EVAL\_ID", {
name: "Categorization text run",
data\_source: {
type: "completions",
model: "gpt-4.1",
input\_messages: {
type: "template",
template: [
{ role: "developer", content: "You are an expert in categorizing IT support tickets. Given the support ticket below, categorize the request into one of 'Hardware', 'Software', or 'Other'. Respond with only one of those words." },
{ role: "user", content: "{{ item.ticket\_text }}" },
],
},
source: { type: "file\_id", id: "YOUR\_FILE\_ID" },
},
});
console.log(run);
```
```python
from openai import OpenAI
client = OpenAI()
run = client.evals.runs.create(
"YOUR\_EVAL\_ID",
name="Categorization text run",
data\_source={
"type": "completions",
"model": "gpt-4.1",
"input\_messages": {
"type": "template",
"template": [
{"role": "developer", "content": "You are an expert in categorizing IT support tickets. Given the support ticket below, categorize the request into one of 'Hardware', 'Software', or 'Other'. Respond with only one of those words."},
{"role": "user", "content": "{{ item.ticket\_text }}"},
],
},
"source": {"type": "file\_id", "id": "YOUR\_FILE\_ID"},
},
)
print(run)
```
When we create the run, we set up a [Chat Completions](/docs/guides/text?api-mode=chat) messages array with the prompt we would like to test. This prompt is used to generate a model response for every line of test data in your data set. We can use the double curly brace syntax to template in the dynamic variable `item.ticket\_text`, which is drawn from the current test data item.
If the eval run is successfully created, you'll receive an API response that looks like this:
```json
{
"object": "eval.run",
"id": "evalrun\_67e44c73eb6481909f79a457749222c7",
"eval\_id": "eval\_67e44c5becec81909704be0318146157",
"report\_url": "https://platform.openai.com/evaluations/abc123",
"status": "queued",
"model": "gpt-4.1",
"name": "Categorization text run",
"created\_at": 1743015028,
"result\_counts": { ... },
"per\_model\_usage": null,
"per\_testing\_criteria\_results": null,
"data\_source": {
"type": "completions",
"source": {
"type": "file\_id",
"id": "file-J7MoX9ToHXp2TutMEeYnwj"
},
"input\_messages": {
"type": "template",
"template": [
{
"type": "message",
"role": "developer",
"content": {
"type": "input\_text",
"text": "You are an expert in...."
}
},
{
"type": "message",
"role": "user",
"content": {
"type": "input\_text",
"text": "{{item.ticket\_text}}"
}
}
]
},
"model": "gpt-4.1",
"sampling\_params": null
},
"error": null,
"metadata": {}
}
```
Your eval run has now been queued, and it will execute asynchronously as it processes every row in your data set. With our configuration, it will generate completions for testing with the prompt and model we specified.
Analyze the results
-------------------
Depending on the size of your dataset, the eval run may take some time to complete. You can view current status in the dashboard, but you can also [fetch the current status of an eval run via API](/docs/api-reference/evals/getRun):
Retrieve eval run status
```bash
curl https://api.openai.com/v1/evals/YOUR\_EVAL\_ID/runs/YOUR\_RUN\_ID \
-H "Authorization: Bearer $OPENAI\_API\_KEY" \
-H "Content-Type: application/json"
```
```javascript
import OpenAI from "openai";
const openai = new OpenAI();
const run = await openai.evals.runs.retrieve("YOUR\_RUN\_ID", {
eval\_id: "YOUR\_EVAL\_ID",
});
console.log(run);
```
```python
from openai import OpenAI
client = OpenAI()
run = client.evals.runs.retrieve("YOUR\_EVAL\_ID", "YOUR\_RUN\_ID")
print(run)
```
You'll need the UUID of both your eval and eval run to fetch its status. When you do, you'll see eval run data that looks like this:
```json
{
"object": "eval.run",
"id": "evalrun\_67e44c73eb6481909f79a457749222c7",
"eval\_id": "eval\_67e44c5becec81909704be0318146157",
"report\_url": "https://platform.openai.com/evaluations/xxx",
"status": "completed",
"model": "gpt-4.1",
"name": "Categorization text run",
"created\_at": 1743015028,
"result\_counts": {
"total": 3,
"errored": 0,
"failed": 0,
"passed": 3
},
"per\_model\_usage": [
{
"model\_name": "gpt-4o-2024-08-06",
"invocation\_count": 3,
"prompt\_tokens": 166,
"completion\_tokens": 6,
"total\_tokens": 172,
"cached\_tokens": 0
}
],
"per\_testing\_criteria\_results": [
{
"testing\_criteria": "Match output to human label-40d67441-5000-4754-ab8c-181c125803ce",
"passed": 3,
"failed": 0
}
],
"data\_source": {
"type": "completions",
"source": {
"type": "file\_id",
"id": "file-J7MoX9ToHXp2TutMEeYnwj"
},
"input\_messages": {
"type": "template",
"template": [
{
"type": "message",
"role": "developer",
"content": {
"type": "input\_text",
"text": "You are an expert in categorizing IT support tickets. Given the support ticket below, categorize the request into one of Hardware, Software, or Other. Respond with only one of those words."
}
},
{
"type": "message",
"role": "user",
"content": {
"type": "input\_text",
"text": "{{item.ticket\_text}}"
}
}
]
},
"model": "gpt-4.1",
"sampling\_params": null
},
"error": null,
"metadata": {}
}
```
The API response contains granular information about test criteria results, API usage for generating model responses, and a `report\_url` property that takes you to a page in the dashboard where you can explore the results visually.
In our simple test, the model reliably generated the content we wanted for a small test case sample. In reality, you will often have to run your eval with more criteria, different prompts, and different data sets. But the process above gives you all the tools you need to build robust evals for your LLM apps!
Video: evals in the dashboard
-----------------------------
The Evaluations tooling [in the OpenAI dashboard](/evaluations) evolves quickly and may not match exactly the UI shown below, but this video will give you a quick overview of how to set up and run evals using the browser-based UI.
Next steps
----------
Now you know how to create and run evals via API, and using the dashboard! Here are a few other resources that may be useful to you as you continue to improve your model results.
[
Cookbook: Detecting prompt regressions
Keep tabs on the performance of your prompts as you iterate on them.
](https://cookbook.openai.com/examples/evaluation/use-cases/regression)[
Cookbook: Bulk model and prompt experimentation
Compare the results of many different prompts and models at once.
](https://cookbook.openai.com/examples/evaluation/use-cases/bulk-experimentation)[
Cookbook: Monitoring stored completions
Examine stored completions to test for prompt regressions.
](https://cookbook.openai.com/examples/evaluation/use-cases/completion-monitoring)[
Fine-tuning
Improve a model's ability to generate responses tailored to your use case.
](/docs/guides/fine-tuning)[
Model distillation
Learn how to distill large model results to smaller, cheaper, and faster models.
](/docs/guides/distillation)
Was this page useful?


## Imported snippet – 2025-07-03 14:38:23

Supervised fine-tuning
======================
Fine-tune models with example inputs and known good outputs.
Supervised fine-tuning (SFT) lets you train an OpenAI model with examples for your specific use case. The result is a customized model that more reliably produces your desired style and content.
||
|Provide examples of correct responses to prompts to guide the model's behavior.Often uses human-generated "ground truth" responses to show the model how it should respond.|ClassificationNuanced translationGenerating content in a specific formatCorrecting instruction-following failures|gpt-4.1-2025-04-14 gpt-4.1-mini-2025-04-14 gpt-4.1-nano-2025-04-14|
Overview
--------
Supervised fine-tuning has four major parts:
1. Build your training dataset to determine what "good" looks like
2. Upload a training dataset containing example prompts and desired model output
3. Create a fine-tuning job for a base model using your training data
4. Evaluate your results using the fine-tuned model
\*\*Good evals first!\*\* Only invest in fine-tuning after setting up evals. You need a reliable way to determine whether your fine-tuned model is performing better than a base model.
[Set up evals →](/docs/guides/evals)
Build your dataset
------------------
Build a robust, representative dataset to get useful results from a fine-tuned model. Use the following techniques and considerations.

### Right number of examples
\* The minimum number of examples you can provide for fine-tuning is 10
\* We see improvements from fine-tuning on 50–100 examples, but the right number for you varies greatly and depends on the use case
\* We recommend starting with 50 well-crafted demonstrations and [evaluating the results](/docs/guides/evals)
If performance improves with 50 good examples, try adding examples to see further results. If 50 examples have no impact, rethink your task or prompt before adding training data.

### What makes a good example
\* Whatever prompts and outputs you expect in your application, as realistic as possible
\* Specific, clear questions and answers
\* Use historical data, expert data, logged data, or [other types of collected data](/docs/guides/evals)

### Formatting your data
\* Use [JSONL format](https://jsonlines.org/), with one complete JSON structure on every line of the training data file
\* Use the [chat completions format](/docs/api-reference/fine-tuning/chat-input)
\* Your file must have at least 10 lines
JSONL format example file
An example of JSONL training data, where the model calls a `get\_weather` function:
```text
{"messages":[{"role":"user","content":"What is the weather in San Francisco?"},{"role":"assistant","tool\_calls":[{"id":"call\_id","type":"function","function":{"name":"get\_current\_weather","arguments":"{\"location\": \"San Francisco, USA\", \"format\": \"celsius\"}"}}]}],"parallel\_tool\_calls":false,"tools":[{"type":"function","function":{"name":"get\_current\_weather","description":"Get the current weather","parameters":{"type":"object","properties":{"location":{"type":"string","description":"The city and country, eg. San Francisco, USA"},"format":{"type":"string","enum":["celsius","fahrenheit"]}},"required":["location","format"]}}}]}
{"messages":[{"role":"user","content":"What is the weather in Minneapolis?"},{"role":"assistant","tool\_calls":[{"id":"call\_id","type":"function","function":{"name":"get\_current\_weather","arguments":"{\"location\": \"Minneapolis, USA\", \"format\": \"celsius\"}"}}]}],"parallel\_tool\_calls":false,"tools":[{"type":"function","function":{"name":"get\_current\_weather","description":"Get the current weather","parameters":{"type":"object","properties":{"location":{"type":"string","description":"The city and country, eg. Minneapolis, USA"},"format":{"type":"string","enum":["celsius","fahrenheit"]}},"required":["location","format"]}}}]}
{"messages":[{"role":"user","content":"What is the weather in San Diego?"},{"role":"assistant","tool\_calls":[{"id":"call\_id","type":"function","function":{"name":"get\_current\_weather","arguments":"{\"location\": \"San Diego, USA\", \"format\": \"celsius\"}"}}]}],"parallel\_tool\_calls":false,"tools":[{"type":"function","function":{"name":"get\_current\_weather","description":"Get the current weather","parameters":{"type":"object","properties":{"location":{"type":"string","description":"The city and country, eg. San Diego, USA"},"format":{"type":"string","enum":["celsius","fahrenheit"]}},"required":["location","format"]}}}]}
{"messages":[{"role":"user","content":"What is the weather in Memphis?"},{"role":"assistant","tool\_calls":[{"id":"call\_id","type":"function","function":{"name":"get\_current\_weather","arguments":"{\"location\": \"Memphis, USA\", \"format\": \"celsius\"}"}}]}],"parallel\_tool\_calls":false,"tools":[{"type":"function","function":{"name":"get\_current\_weather","description":"Get the current weather","parameters":{"type":"object","properties":{"location":{"type":"string","description":"The city and country, eg. Memphis, USA"},"format":{"type":"string","enum":["celsius","fahrenheit"]}},"required":["location","format"]}}}]}
{"messages":[{"role":"user","content":"What is the weather in Atlanta?"},{"role":"assistant","tool\_calls":[{"id":"call\_id","type":"function","function":{"name":"get\_current\_weather","arguments":"{\"location\": \"Atlanta, USA\", \"format\": \"celsius\"}"}}]}],"parallel\_tool\_calls":false,"tools":[{"type":"function","function":{"name":"get\_current\_weather","description":"Get the current weather","parameters":{"type":"object","properties":{"location":{"type":"string","description":"The city and country, eg. Atlanta, USA"},"format":{"type":"string","enum":["celsius","fahrenheit"]}},"required":["location","format"]}}}]}
{"messages":[{"role":"user","content":"What is the weather in Sunnyvale?"},{"role":"assistant","tool\_calls":[{"id":"call\_id","type":"function","function":{"name":"get\_current\_weather","arguments":"{\"location\": \"Sunnyvale, USA\", \"format\": \"celsius\"}"}}]}],"parallel\_tool\_calls":false,"tools":[{"type":"function","function":{"name":"get\_current\_weather","description":"Get the current weather","parameters":{"type":"object","properties":{"location":{"type":"string","description":"The city and country, eg. Sunnyvale, USA"},"format":{"type":"string","enum":["celsius","fahrenheit"]}},"required":["location","format"]}}}]}
{"messages":[{"role":"user","content":"What is the weather in Chicago?"},{"role":"assistant","tool\_calls":[{"id":"call\_id","type":"function","function":{"name":"get\_current\_weather","arguments":"{\"location\": \"Chicago, USA\", \"format\": \"celsius\"}"}}]}],"parallel\_tool\_calls":false,"tools":[{"type":"function","function":{"name":"get\_current\_weather","description":"Get the current weather","parameters":{"type":"object","properties":{"location":{"type":"string","description":"The city and country, eg. Chicago, USA"},"format":{"type":"string","enum":["celsius","fahrenheit"]}},"required":["location","format"]}}}]}
{"messages":[{"role":"user","content":"What is the weather in Boston?"},{"role":"assistant","tool\_calls":[{"id":"call\_id","type":"function","function":{"name":"get\_current\_weather","arguments":"{\"location\": \"Boston, USA\", \"format\": \"celsius\"}"}}]}],"parallel\_tool\_calls":false,"tools":[{"type":"function","function":{"name":"get\_current\_weather","description":"Get the current weather","parameters":{"type":"object","properties":{"location":{"type":"string","description":"The city and country, eg. Boston, USA"},"format":{"type":"string","enum":["celsius","fahrenheit"]}},"required":["location","format"]}}}]}
{"messages":[{"role":"user","content":"What is the weather in Honolulu?"},{"role":"assistant","tool\_calls":[{"id":"call\_id","type":"function","function":{"name":"get\_current\_weather","arguments":"{\"location\": \"Honolulu, USA\", \"format\": \"celsius\"}"}}]}],"parallel\_tool\_calls":false,"tools":[{"type":"function","function":{"name":"get\_current\_weather","description":"Get the current weather","parameters":{"type":"object","properties":{"location":{"type":"string","description":"The city and country, eg. Honolulu, USA"},"format":{"type":"string","enum":["celsius","fahrenheit"]}},"required":["location","format"]}}}]}
{"messages":[{"role":"user","content":"What is the weather in San Antonio?"},{"role":"assistant","tool\_calls":[{"id":"call\_id","type":"function","function":{"name":"get\_current\_weather","arguments":"{\"location\": \"San Antonio, USA\", \"format\": \"celsius\"}"}}]}],"parallel\_tool\_calls":false,"tools":[{"type":"function","function":{"name":"get\_current\_weather","description":"Get the current weather","parameters":{"type":"object","properties":{"location":{"type":"string","description":"The city and country, eg. San Antonio, USA"},"format":{"type":"string","enum":["celsius","fahrenheit"]}},"required":["location","format"]}}}]}
```
Corresponding JSON data
Each line of the training data file contains a JSON structure like the following, containing both an example user prompt and a correct response from the model as an `assistant` message.
```json
{
"messages": [
{ "role": "user", "content": "What is the weather in San Francisco?" },
{
"role": "assistant",
"tool\_calls": [
{
"id": "call\_id",
"type": "function",
"function": {
"name": "get\_current\_weather",
"arguments": "{\"location\": \"San Francisco, USA\", \"format\": \"celsius\"}"
}
}
]
}
],
"parallel\_tool\_calls": false,
"tools": [
{
"type": "function",
"function": {
"name": "get\_current\_weather",
"description": "Get the current weather",
"parameters": {
"type": "object",
"properties": {
"location": {
"type": "string",
"description": "The city and country, eg. San Francisco, USA"
},
"format": { "type": "string", "enum": ["celsius", "fahrenheit"] }
},
"required": ["location", "format"]
}
}
}
]
}
```
Upload training data
--------------------
Upload your dataset of examples to OpenAI. We use it to update the model's weights and produce outputs like the ones included in your data.
In addition to text completions, you can train the model to more effectively generate [structured JSON output](/docs/guides/structured-outputs) or [function calls](/docs/guides/function-calling).
Upload your data with button clicks
1. Navigate to the dashboard > \*\*[fine-tuning](https://platform.openai.com/finetune)\*\*.
2. Click \*\*\+ Create\*\*.
3. Under \*\*Training data\*\*, upload your JSONL file.
Call the API to upload your data
Assuming the data above is saved to a file called `mydata.jsonl`, you can upload it to the OpenAI platform using the code below. Note that the `purpose` of the uploaded file is set to `fine-tune`:
```bash
curl https://api.openai.com/v1/files \
-H "Authorization: Bearer $OPENAI\_API\_KEY" \
-F purpose="fine-tune" \
-F file="@mydata.jsonl"
```
Note the `id` of the file that is uploaded in the data returned from the API - you'll need that file identifier in subsequent API requests.
```json
{
"object": "file",
"id": "file-RCnFCYRhFDcq1aHxiYkBHw",
"purpose": "fine-tune",
"filename": "mydata.jsonl",
"bytes": 1058,
"created\_at": 1746484901,
"expires\_at": null,
"status": "processed",
"status\_details": null
}
```
Create a fine-tuning job
------------------------
With your test data uploaded, [create a fine-tuning job](/docs/api-reference/fine-tuning/create) to customize a base model using the training data you provide. When creating a fine-tuning job, you must specify:
\* A base model (`model`) to use for fine-tuning. This can be either an OpenAI model ID or the ID of a previously fine-tuned model. See which models support fine-tuning in the [model docs](/docs/models).
\* A training file (`training\_file`) ID. This is the file you uploaded in the previous step.
\* A fine-tuning method (`method`). This specifies which fine-tuning method you want to use to customize the model. Supervised fine-tuning is the default.
Upload your data with button clicks
1. In the same \*\*\+ Create\*\* modal as above, complete the required fields.
2. Select supervised fine-tuning as the method and whichever model you want to train.
3. When you're ready, click \*\*Create\*\* to start the job.
Call the API to upload your data
Create a supervised fine-tuning job by calling the [fine-tuning API](/docs/api-reference/fine-tuning):
```bash
curl https://api.openai.com/v1/fine\_tuning/jobs \
-H "Content-Type: application/json" \
-H "Authorization: Bearer $OPENAI\_API\_KEY" \
-d '{
"training\_file": "file-RCnFCYRhFDcq1aHxiYkBHw",
"model": "gpt-4.1-nano-2025-04-14"
}'
```
The API responds with information about the fine-tuning job in progress. Depending on the size of your training data, the training process may take several minutes or hours. You can [poll the API](/docs/api-reference/fine-tuning/retrieve) for updates on a specific job.
When the fine-tuning job finishes, your fine-tuned model is ready to use. A completed fine-tune job returns data like this:
```json
{
"object": "fine\_tuning.job",
"id": "ftjob-uL1VKpwx7maorHNbOiDwFIn6",
"model": "gpt-4.1-nano-2025-04-14",
"created\_at": 1746484925,
"finished\_at": 1746485841,
"fine\_tuned\_model": "ft:gpt-4.1-nano-2025-04-14:openai::BTz2REMH",
"organization\_id": "org-abc123",
"result\_files": [
"file-9TLxKY2A8tC5YE1RULYxf6"
],
"status": "succeeded",
"validation\_file": null,
"training\_file": "file-RCnFCYRhFDcq1aHxiYkBHw",
"hyperparameters": {
"n\_epochs": 10,
"batch\_size": 1,
"learning\_rate\_multiplier": 1
},
"trained\_tokens": 1700,
"error": {},
"user\_provided\_suffix": null,
"seed": 1935755117,
"estimated\_finish": null,
"integrations": [],
"metadata": null,
"usage\_metrics": null,
"shared\_with\_openai": false,
"method": {
"type": "supervised",
"supervised": {
"hyperparameters": {
"n\_epochs": 10,
"batch\_size": 1,
"learning\_rate\_multiplier": 1.0
}
}
}
}
```
Note the `fine\_tuned\_model` property. This is the model ID to use in [Responses](/docs/api-reference/responses) or [Chat Completions](/docs/api-reference/chat) to make API requests using your fine-tuned model.
Here's an example of calling the Responses API with your fine-tuned model ID:
```bash
curl https://api.openai.com/v1/responses \
-H "Content-Type: application/json" \
-H "Authorization: Bearer $OPENAI\_API\_KEY" \
-d '{
"model": "ft:gpt-4.1-nano-2025-04-14:openai::BTz2REMH",
"input": "What is the weather like in Boston today?",
"tools": [
{
"name": "get\_current\_weather",
"description": "Get the current weather",
"parameters": {
"type": "object",
"properties": {
"location": {
"type": "string",
"description": "The city and country, eg. San Francisco, USA"
},
"format": { "type": "string", "enum": ["celsius", "fahrenheit"] }
},
"required": ["location", "format"]
}
}
],
"tool\_choice": "auto"
}'
```
Evaluate the result
-------------------
Use the approaches below to check how your fine-tuned model performs. Adjust your prompts, data, and fine-tuning job as needed until you get the results you want. The best way to fine-tune is to continue iterating.

### Compare to evals
To see if your fine-tuned model performs better than the original base model, [use evals](/docs/guides/evals). Before running your fine-tuning job, carve out data from the same training dataset you collected in step 1. This holdout data acts as a control group when you use it for evals. Make sure the training and holdout data have roughly the same diversity of user input types and model responses.
[Learn more about running evals](/docs/guides/evals).

### Monitor the status
Check the status of a fine-tuning job in the dashboard or by polling the job ID in the API.
Monitor in the UI
1. Navigate to the [fine-tuning dashboard](https://platform.openai.com/finetune).
2. Select the job you want to monitor.
3. Review the status, checkpoints, message, and metrics.
Monitor with API calls
Use this curl command to get information about your fine-tuning job:
```bash
curl https://api.openai.com/v1/fine\_tuning/jobs/ftjob-uL1VKpwx7maorHNbOiDwFIn6 \
-H "Authorization: Bearer $OPENAI\_API\_KEY"
```
The job contains a `fine\_tuned\_model` property, which is your new fine-tuned model's unique ID.
```json
{
"object": "fine\_tuning.job",
"id": "ftjob-uL1VKpwx7maorHNbOiDwFIn6",
"model": "gpt-4.1-nano-2025-04-14",
"created\_at": 1746484925,
"finished\_at": 1746485841,
"fine\_tuned\_model": "ft:gpt-4.1-nano-2025-04-14:openai::BTz2REMH",
"organization\_id": "org-abc123",
"result\_files": [
"file-9TLxKY2A8tC5YE1RULYxf6"
],
"status": "succeeded",
"validation\_file": null,
"training\_file": "file-RCnFCYRhFDcq1aHxiYkBHw",
"hyperparameters": {
"n\_epochs": 10,
"batch\_size": 1,
"learning\_rate\_multiplier": 1
},
"trained\_tokens": 1700,
"error": {},
"user\_provided\_suffix": null,
"seed": 1935755117,
"estimated\_finish": null,
"integrations": [],
"metadata": null,
"usage\_metrics": null,
"shared\_with\_openai": false,
"method": {
"type": "supervised",
"supervised": {
"hyperparameters": {
"n\_epochs": 10,
"batch\_size": 1,
"learning\_rate\_multiplier": 1.0
}
}
}
}
```

### Try using your fine-tuned model
Evaluate your newly optimized model by using it! When the fine-tuned model finishes training, use its ID in either the [Responses](/docs/api-reference/responses) or [Chat Completions](/docs/api-reference/chat) API, just as you would an OpenAI base model.
Use your model in the Playground
1. Navigate to your fine-tuning job in [the dashboard](https://platform.openai.com/finetune).
2. In the right pane, navigate to \*\*Output model\*\* and copy the model ID. It should start with `ft:…`
3. Open the [Playground](https://platform.openai.com/playground).
4. In the \*\*Model\*\* dropdown menu, paste the model ID. Here, you should also see other fine-tuned models you've created.
5. Run some prompts and see how your fine-tuned performs!
Use your model with an API call
```bash
curl https://api.openai.com/v1/responses \
-H "Content-Type: application/json" \
-H "Authorization: Bearer $OPENAI\_API\_KEY" \
-d '{
"model": "ft:gpt-4.1-nano-2025-04-14:openai::BTz2REMH",
"input": "What is 4+4?"
}'
```

### Use checkpoints if needed
Checkpoints are models you can use. We create a full model checkpoint for you at the end of each training epoch. They're useful in cases where your fine-tuned model improves early on but then memorizes the dataset instead of learning generalizable knowledge—called \\_overfitting. Checkpoints provide versions of your customized model from various moments in the process.
Find checkpoints in the dashboard
1. Navigate to the [fine-tuning dashboard](https://platform.openai.com/finetune).
2. In the left panel, select the job you want to investigate. Wait until it succeeds.
3. In the right panel, scroll to the list of checkpoints.
4. Hover over any checkpoint to see a link to launch in the Playground.
5. Test the checkpoint model's behavior by prompting it in the Playground.
Query the API for checkpoints
1. Wait until a job succeeds, which you can verify by [querying the status of a job](/docs/api-reference/fine-tuning/retrieve).
2. [Query the checkpoints endpoint](/docs/api-reference/fine-tuning/list-checkpoints) with your fine-tuning job ID to access a list of model checkpoints for the fine-tuning job.
3. Find the `fine\_tuned\_model\_checkpoint` field for the name of the model checkpoint.
4. Use this model just like you would the final fine-tuned model.
The checkpoint object contains `metrics` data to help you determine the usefulness of this model. As an example, the response looks like this:
```json
{
"object": "fine\_tuning.job.checkpoint",
"id": "ftckpt\_zc4Q7MP6XxulcVzj4MZdwsAB",
"created\_at": 1519129973,
"fine\_tuned\_model\_checkpoint": "ft:gpt-3.5-turbo-0125:my-org:custom-suffix:96olL566:ckpt-step-2000",
"metrics": {
"full\_valid\_loss": 0.134,
"full\_valid\_mean\_token\_accuracy": 0.874
},
"fine\_tuning\_job\_id": "ftjob-abc123",
"step\_number": 2000
}
```
Each checkpoint specifies:
\* `step\_number`: The step at which the checkpoint was created (where each epoch is number of steps in the training set divided by the batch size)
\* `metrics`: An object containing the metrics for your fine-tuning job at the step when the checkpoint was created
Currently, only the checkpoints for the last three epochs of the job are saved and available for use.
Next steps
----------
Now that you know the basics of supervised fine-tuning, explore these other methods as well.
[
Vision fine-tuning
Learn to fine-tune for computer vision with image inputs.
](/docs/guides/vision-fine-tuning)[
Direct preference optimization
Fine-tune a model using direct preference optimization (DPO).
](/docs/guides/direct-preference-optimization)[
Reinforcement fine-tuning
Fine-tune a reasoning model by grading its outputs.
](/docs/guides/reinforcement-fine-tuning)
Was this page useful?


## Imported snippet – 2025-07-03 14:38:26

Vision fine-tuning
==================
Fine-tune models for better image understanding.
Vision fine-tuning uses image inputs for [supervised fine-tuning](/docs/guides/supervised-fine-tuning) to improve the model's understanding of image inputs. This guide will take you through this subset of SFT, and outline some of the important considerations for fine-tuning with image inputs.
||
|Provide image inputs for supervised fine-tuning to improve the model's understanding of image inputs.|Image classificationCorrecting failures in instruction following for complex prompts|gpt-4o-2024-08-06|
Data format
-----------
Just as you can [send one or many image inputs and create model responses based on them](/docs/guides/vision), you can include those same message types within your JSONL training data files. Images can be provided either as HTTP URLs or data URLs containing Base64-encoded images.
Here's an example of an image message on a line of your JSONL file. Below, the JSON object is expanded for readability, but typically this JSON would appear on a single line in your data file:
```json
{
"messages": [
{
"role": "system",
"content": "You are an assistant that identifies uncommon cheeses."
},
{
"role": "user",
"content": "What is this cheese?"
},
{
"role": "user",
"content": [
{
"type": "image\_url",
"image\_url": {
"url": "https://upload.wikimedia.org/wikipedia/commons/3/36/Danbo\_Cheese.jpg"
}
}
]
},
{
"role": "assistant",
"content": "Danbo"
}
]
}
```
Uploading training data for vision fine-tuning follows the [same process described here](/docs/guides/supervised-fine-tuning).
Image data requirements
-----------------------

#### Size
\* Your training file can contain a maximum of 50,000 examples that contain images (not including text examples).
\* Each example can have at most 10 images.
\* Each image can be at most 10 MB.

#### Format
\* Images must be JPEG, PNG, or WEBP format.
\* Your images must be in the RGB or RGBA image mode.
\* You cannot include images as output from messages with the `assistant` role.

#### Content moderation policy
We scan your images before training to ensure that they comply with our usage policy. This may introduce latency in file validation before fine-tuning begins.
Images containing the following will be excluded from your dataset and not used for training:
\* People
\* Faces
\* Children
\* CAPTCHAs

#### What to do if your images get skipped
Your images can get skipped during training for the following reasons:
\* \*\*contains CAPTCHAs\*\*, \*\*contains people\*\*, \*\*contains faces\*\*, \*\*contains children\*\*
\* Remove the image. For now, we cannot fine-tune models with images containing these entities.
\* \*\*inaccessible URL\*\*
\* Ensure that the image URL is publicly accessible.
\* \*\*image too large\*\*
\* Please ensure that your images fall within our [dataset size limits](#size).
\* \*\*invalid image format\*\*
\* Please ensure that your images fall within our [dataset format](#format).
Best practices
--------------

#### Reducing training cost
If you set the `detail` parameter for an image to `low`, the image is resized to 512 by 512 pixels and is only represented by 85 tokens regardless of its size. This will reduce the cost of training. [See here for more information.](/docs/guides/vision#low-or-high-fidelity-image-understanding)
```json
{
"type": "image\_url",
"image\_url": {
"url": "https://upload.wikimedia.org/wikipedia/commons/3/36/Danbo\_Cheese.jpg",
"detail": "low"
}
}
```

#### Control image quality
To control the fidelity of image understanding, set the `detail` parameter of `image\_url` to `low`, `high`, or `auto` for each image. This will also affect the number of tokens per image that the model sees during training time, and will affect the cost of training. [See here for more information](/docs/guides/vision#low-or-high-fidelity-image-understanding).
Next steps
----------
Now that you know the basics of vision fine-tuning, explore these other methods as well.
[
Supervised fine-tuning
Fine-tune a model by providing correct outputs for sample inputs.
](/docs/guides/supervised-fine-tuning)[
Direct preference optimization
Fine-tune a model using direct preference optimization (DPO).
](/docs/guides/direct-preference-optimization)[
Reinforcement fine-tuning
Fine-tune a reasoning model by grading its outputs.
](/docs/guides/reinforcement-fine-tuning)
Was this page useful?


## Imported snippet – 2025-07-03 14:38:31

Direct preference optimization
==============================
Fine-tune models for subjective decision-making by comparing model outputs.
[Direct Preference Optimization](https://arxiv.org/abs/2305.18290) (DPO) fine-tuning allows you to fine-tune models based on prompts and pairs of responses. This approach enables the model to learn from more subjective human preferences, optimizing for outputs that are more likely to be favored. DPO is currently only supported for text inputs and outputs.
||
|Provide both a correct and incorrect example response for a prompt. Indicate the correct response to help the model perform better.|Summarizing text, focusing on the right thingsGenerating chat messages with the right tone and style|gpt-4.1-2025-04-14 gpt-4.1-mini-2025-04-14 gpt-4.1-nano-2025-04-14|
Data format
-----------
Each example in your dataset should contain:
\* A prompt, like a user message.
\* A preferred output (an ideal assistant response).
\* A non-preferred output (a suboptimal assistant response).
The data should be formatted in JSONL format, with each line [representing an example](/docs/api-reference/fine-tuning/preference-input) in the following structure:
```json
{
"input": {
"messages": [
{
"role": "user",
"content": "Hello, can you tell me how cold San Francisco is today?"
}
],
"tools": [],
"parallel\_tool\_calls": true
},
"preferred\_output": [
{
"role": "assistant",
"content": "Today in San Francisco, it is not quite cold as expected. Morning clouds will give away to sunshine, with a high near 68°F (20°C) and a low around 57°F (14°C)."
}
],
"non\_preferred\_output": [
{
"role": "assistant",
"content": "It is not particularly cold in San Francisco today."
}
]
}
```
Currently, we only train on one-turn conversations for each example, where the preferred and non-preferred messages need to be the last assistant message.
Create a DPO fine-tune job
--------------------------
Uploading training data and using a model fine-tuned with DPO follows the [same flow described here](/docs/guides/model-optimization).
To create a DPO fine-tune job, use the `method` field in the [fine-tuning job creation endpoint](/docs/api-reference/fine-tuning/create), where you can specify `type` as well as any associated `hyperparameters`. For DPO:
\* set the `type` parameter to `dpo`
\* optionally set the `hyperparameters` property with any options you'd like to configure.
The `beta` hyperparameter is a new option that is only available for DPO. It's a floating point number between `0` and `2` that controls how strictly the new model will adhere to its previous behavior, versus aligning with the provided preferences. A high number will be more conservative (favoring previous behavior), and a lower number will be more aggressive (favor the newly provided preferences more often).
You can also set this value to `auto` (the default) to use a value configured by the platform.
The example below shows how to configure a DPO fine-tuning job using the OpenAI SDK.
Create a fine-tuning job with DPO
```javascript
import OpenAI from "openai";
const openai = new OpenAI();
const job = await openai.fineTuning.jobs.create({
training\_file: "file-all-about-the-weather",
model: "gpt-4o-2024-08-06",
method: {
type: "dpo",
dpo: {
hyperparameters: { beta: 0.1 },
},
},
});
```
```python
from openai import OpenAI
client = OpenAI()
job = client.fine\_tuning.jobs.create(
training\_file="file-all-about-the-weather",
model="gpt-4o-2024-08-06",
method={
"type": "dpo",
"dpo": {
"hyperparameters": {"beta": 0.1},
},
},
)
```
Use SFT and DPO together
------------------------
Currently, OpenAI offers [supervised fine-tuning (SFT)](/docs/guides/supervised-fine-tuning) as the default method for fine-tuning jobs. Performing SFT on your preferred responses (or a subset) before running another DPO job afterwards can significantly enhance model alignment and performance. By first fine-tuning the model on the desired responses, it can better identify correct patterns, providing a strong foundation for DPO to refine behavior.
A recommended workflow is as follows:
1. Fine-tune the base model with SFT using a subset of your preferred responses. Focus on ensuring the data quality and representativeness of the tasks.
2. Use the SFT fine-tuned model as the starting point, and apply DPO to adjust the model based on preference comparisons.
Next steps
----------
Now that you know the basics of DPO, explore these other methods as well.
[
Supervised fine-tuning
Fine-tune a model by providing correct outputs for sample inputs.
](/docs/guides/supervised-fine-tuning)[
Vision fine-tuning
Learn to fine-tune for computer vision with image inputs.
](/docs/guides/vision-fine-tuning)[
Reinforcement fine-tuning
Fine-tune a reasoning model by grading its outputs.
](/docs/guides/reinforcement-fine-tuning)
Was this page useful?


## Imported snippet – 2025-07-03 14:38:35

Reinforcement fine-tuning
=========================
Fine-tune models for expert-level performance within a domain.
Reinforcement fine-tuning (RFT) adapts an OpenAI reasoning model with a feedback signal you define. Like [supervised fine-tuning](/docs/guides/supervised-fine-tuning), it tailors the model to your task. The difference is that instead of training on fixed “correct” answers, it relies on a programmable grader that scores every candidate response. The training algorithm then shifts the model’s weights, so high-scoring outputs become more likely and low-scoring ones fade.
||
|Generate a response for a prompt, provide an expert grade for the result, and reinforce the model's chain-of-thought for higher-scored responses.Requires expert graders to agree on the ideal output from the model.|Complex domain-specific tasks that require advanced reasoningMedical diagnoses based on history and diagnostic guidelinesDetermining relevant passages from legal case law|o4-mini-2025-04-16Reasoning models only.|
This optimization lets you align the model with nuanced objectives like style, safety, or domain accuracy—with many [practical use cases](/docs/guides/rft-use-cases) emerging. Run RFT in five steps:
1. Implement a [grader](/docs/guides/graders) that assigns a numeric reward to each model response.
2. Upload your prompt dataset and designate a validation split.
3. Start the fine-tune job.
4. Monitor and [evaluate](/docs/guides/evals) checkpoints; revise data or grader if needed.
5. Deploy the resulting model through the standard API.
During training, the platform cycles through the dataset, samples several responses per prompt, scores them with the grader, and applies policy-gradient updates based on those rewards. The loop continues until we hit the end of your training data or you stop the job at a chosen checkpoint, producing a model optimized for the metric that matters to you.
When should I use reinforcement fine-tuning?
It's useful to understand the strengths and weaknesses of reinforcement fine-tuning to identify opportunities and to avoid wasted effort.
\* \*\*RFT works best with unambiguous tasks\*\*. Check whether qualified human experts agree on the answers. If conscientious experts working independently (with access only to the same instructions and information as the model) do not converge on the same answers, the task may be too ambiguous and may benefit from revision or reframing.
\* \*\*Your task must be compatible with the grading options\*\*. Review [grading options in the API](/docs/api-reference/graders) first and verify it's possible to grade your task with them.
\* \*\*Your eval results must be variable enough to improve\*\*. Run [evals](/docs/guides/evals) before using RFT. If your eval scores between minimum and maximum possible scores, you'll have enough data to work with to reinforce positive answers. If the model you want to fine-tune scores at either the absolute minimum or absolute maximum score, RFT won't be useful to you.
\* \*\*Your model must have some success at the desired task\*\*. Reinforcement fine-tuning makes gradual changes, sampling many answers and choosing the best ones. If a model has a 0% success rate at a given task, you cannot bootstrap to higher performance levels through RFT.
\* \*\*Your task should be guess-proof\*\*. If the model can get a higher reward from a lucky guess, the training signal is too noisy, as the model can get the right answer with an incorrect reasoning process. Reframe your task to make guessing more difficult—for example, by expanding classes into subclasses or revising a multiple choice problem to take open-ended answers.
See common use cases, specific implementations, and grader examples in the [reinforcement fine-tuning use case guide](/docs/guides/rft-use-cases).
What is reinforcement learning?
Reinforcement learning is a branch of machine learning in which a model learns by acting, receiving feedback, and readjusting itself to maximise future feedback. Instead of memorising one “right” answer per example, the model explores many possible answers, observes a numeric reward for each, and gradually shifts its behaviour so the high-reward answers become more likely and the low-reward ones disappear. Over repeated rounds, the model converges on a policy—a rule for choosing outputs—that best satisfies the reward signal you define.
In reinforcement fine-tuning (RFT), that reward signal comes from a custom grader that you define for your task. For every prompt in your dataset, the platform samples multiple candidate answers, runs your grader to score them, and applies a policy-gradient update that nudges the model toward answers with higher scores. This cycle—sample, grade, update—continues across the dataset (and successive epochs) until the model reliably optimizes for your grader’s understanding of quality. The grader encodes whatever you care about—accuracy, style, safety, or any metric—so the resulting fine-tuned model reflects those priorities and you don't have to manage reinforcement learning infrastructure.
Reinforcement fine-tuning is supported on o-series reasoning models only, and currently only for [o4-mini](/docs/models/o4-mini).
Example: LLM-powered security review
------------------------------------
To demonstrate reinforcement fine-tuning below, we'll fine-tune an [o4-mini](/docs/models/o4-mini) model to provide expert answers about a fictional company's security posture, based on an internal company policy document. We want the model to return a JSON object that conforms to a specific schema with [Structured Outputs](/docs/guides/structured-outputs).
Example input question:
```text
Do you have a dedicated security team?
```
Using the internal policy document, we want the model to respond with JSON that has two keys:
\* `compliant`: A string `yes`, `no`, or `needs review`, indicating whether the company's policy covers the question.
\* `explanation`: A string of text that briefly explains, based on the policy document, why the question is covered in the policy or why it's not covered.
Example desired output from the model:
```json
{
"compliant": "yes",
"explanation": "A dedicated security team follows strict protocols for handling incidents."
}
```
Let's fine-tune a model with RFT to perform well at this task.
Define a grader
---------------
To perform RFT, define a [grader](/docs/guides/graders) to score the model's output during training, indicating the quality of its response. RFT uses the same set of graders as [evals](/docs/guides/evals), which you may already be familiar with.
In this example, we define [multiple graders](/docs/api-reference/graders/multi) to examine the properties of the JSON returned by our fine-tuned model:
\* The [`string\_check`](/docs/api-reference/graders/string-check) grader to ensure the proper `compliant` property has been set
\* The [`score\_model`](/docs/api-reference/graders/score-model) grader to provide a score between zero and one for the explanation text, using another evaluator model
We weight the output of each property equally in the `calculate\_output` expression.
Below is the JSON payload data we'll use for this grader in API requests. In both graders, we use `{{ }}` template syntax to refer to the relevant properties of both the `item` (the row of test data being used for evaluation) and `sample` (the model output generated during the training run).
Grader configuration
Multi-grader configuration object
```json
{
"type": "multi",
"graders": {
"explanation": {
"name": "Explanation text grader",
"type": "score\_model",
"input": [
{
"role": "user",
"type": "message",
"content": "...see other tab for the full prompt..."
}
],
"model": "gpt-4o-2024-08-06"
},
"compliant": {
"name": "compliant",
"type": "string\_check",
"reference": "{{item.compliant}}",
"operation": "eq",
"input": "{{sample.output\_json.compliant}}"
}
},
"calculate\_output": "0.5 \* compliant + 0.5 \* explanation"
}
```
Grading prompt
Grading prompt in the grader config
```markdown

# Overview
Evaluate the accuracy of the model-generated answer based on the
Copernicus Product Security Policy and an example answer. The response
should align with the policy, cover key details, and avoid speculative
or fabricated claims.
Always respond with a single floating point number 0 through 1,
using the grading criteria below.

## Grading Criteria:
- \*\*1.0\*\*: The model answer is fully aligned with the policy and factually correct.
- \*\*0.75\*\*: The model answer is mostly correct but has minor omissions or slight rewording that does not change meaning.
- \*\*0.5\*\*: The model answer is partially correct but lacks key details or contains speculative statements.
- \*\*0.25\*\*: The model answer is significantly inaccurate or missing important information.
- \*\*0.0\*\*: The model answer is completely incorrect, hallucinates policy details, or is irrelevant.

## Copernicus Product Security Policy

### Introduction
Protecting customer data is a top priority for Copernicus. Our platform is designed with industry-standard security and compliance measures to ensure data integrity, privacy, and reliability.

### Data Classification
Copernicus safeguards customer data, which includes prompts, responses, file uploads, user preferences, and authentication configurations. Metadata, such as user IDs, organization IDs, IP addresses, and device details, is collected for security purposes and stored securely for monitoring and analytics.

### Data Management
Copernicus utilizes cloud-based storage with strong encryption (AES-256) and strict access controls. Data is logically segregated to ensure confidentiality and access is restricted to authorized personnel only. Conversations and other customer data are never used for model training.

### Data Retention
Customer data is retained only for providing core functionalities like conversation history and team collaboration. Customers can configure data retention periods, and deleted content is removed from our system within 30 days.

### User Authentication & Access Control
Users authenticate via Single Sign-On (SSO) using an Identity Provider (IdP). Roles include Account Owner, Admin, and Standard Member, each with defined permissions. User provisioning can be automated through SCIM integration.

### Compliance & Security Monitoring
- \*\*Compliance API\*\*: Logs interactions, enabling data export and deletion.
- \*\*Audit Logging\*\*: Ensures transparency for security audits.
- \*\*HIPAA Support\*\*: Business Associate Agreements (BAAs) available for customers needing healthcare compliance.
- \*\*Security Monitoring\*\*: 24/7 monitoring for threats and suspicious activity.
- \*\*Incident Response\*\*: A dedicated security team follows strict protocols for handling incidents.

### Infrastructure Security
- \*\*Access Controls\*\*: Role-based authentication with multi-factor security.
- \*\*Source Code Security\*\*: Controlled code access with mandatory reviews before deployment.
- \*\*Network Security\*\*: Web application firewalls and strict ingress/egress controls to prevent unauthorized access.
- \*\*Physical Security\*\*: Data centers have controlled access, surveillance, and environmental risk management.

### Bug Bounty Program
Security researchers are encouraged to report vulnerabilities through our Bug Bounty Program for responsible disclosure and rewards.

### Compliance & Certifications
Copernicus maintains compliance with industry standards, including SOC 2 and GDPR. Customers can access security reports and documentation via our Security Portal.

### Conclusion
Copernicus prioritizes security, privacy, and compliance. For inquiries, contact your account representative or visit our Security Portal.

## Examples

### Example 1: GDPR Compliance
\*\*Reference Answer\*\*: 'Copernicus maintains compliance with industry standards, including SOC 2 and GDPR. Customers can access security reports and documentation via our Security Portal.'
\*\*Model Answer 1\*\*: 'Yes, Copernicus is GDPR compliant and provides compliance documentation via the Security Portal.'
\*\*Score: 1.0\*\* (fully correct)
\*\*Model Answer 2\*\*: 'Yes, Copernicus follows GDPR standards.'
\*\*Score: 0.75\*\* (mostly correct but lacks detail about compliance reports)
\*\*Model Answer 3\*\*: 'Copernicus may comply with GDPR but does not provide documentation.'
\*\*Score: 0.5\*\* (partially correct, speculative about compliance reports)
\*\*Model Answer 4\*\*: 'Copernicus does not follow GDPR standards.'
\*\*Score: 0.0\*\* (factually incorrect)

### Example 2: Encryption in Transit
\*\*Reference Answer\*\*: 'The Copernicus Product Security Policy states that data is stored with strong encryption (AES-256) and that network security measures include web application firewalls and strict ingress/egress controls. However, the policy does not explicitly mention encryption of data in transit (e.g., TLS encryption). A review is needed to confirm whether data transmission is encrypted.'
\*\*Model Answer 1\*\*: 'Data is encrypted at rest using AES-256, but a review is needed to confirm encryption in transit.'
\*\*Score: 1.0\*\* (fully correct)
\*\*Model Answer 2\*\*: 'Yes, Copernicus encrypts data in transit and at rest.'
\*\*Score: 0.5\*\* (partially correct, assumes transit encryption without confirmation)
\*\*Model Answer 3\*\*: 'All data is protected with encryption.'
\*\*Score: 0.25\*\* (vague and lacks clarity on encryption specifics)
\*\*Model Answer 4\*\*: 'Data is not encrypted in transit.'
\*\*Score: 0.0\*\* (factually incorrect)
Reference Answer: {{item.explanation}}
Model Answer: {{sample.output\_json.explanation}}
```
Prepare your dataset
--------------------
To create an RFT fine-tune, you'll need both a training and test dataset. Both the training and test datasets will share the same [JSONL format](https://jsonlines.org/). Each line in the JSONL data file will contain a `messages` array, along with any additional fields required to grade the output from the model. The full specification for RFT dataset [can be found here](/docs/api-reference/fine-tuning/reinforcement-input).
In our case, in addition to the `messages` array, each line in our JSONL file also needs `compliant` and `explanation` properties, which we can use as reference values to test the fine-tuned model's Structured Output.
A single line in our training and test datasets looks like this as indented JSON:
```json
{
"messages": [{
"role": "user",
"content": "Do you have a dedicated security team?"
}],
"compliant": "yes",
"explanation": "A dedicated security team follows strict protocols for handling incidents."
}
```
Below, find some JSONL data you can use for both training and testing when you create your fine-tune job. Note that these datasets are for illustration purposes only—in your real test data, strive for diverse and representative inputs for your application.
\*\*Training set\*\*
```text
{"messages":[{"role":"user","content":"Do you have a dedicated security team?"}],"compliant":"yes","explanation":"A dedicated security team follows strict protocols for handling incidents."}
{"messages":[{"role":"user","content":"Have you undergone third-party security audits or penetration testing in the last 12 months?"}],"compliant":"needs review","explanation":"The policy does not explicitly mention undergoing third-party security audits or penetration testing. It only mentions SOC 2 and GDPR compliance."}
{"messages":[{"role":"user","content":"Is your software SOC 2, ISO 27001, or similarly certified?"}],"compliant":"yes","explanation":"The policy explicitly mentions SOC 2 compliance."}
```
\*\*Test set\*\*
```text
{"messages":[{"role":"user","content":"Will our data be encrypted at rest?"}],"compliant":"yes","explanation":"Copernicus utilizes cloud-based storage with strong encryption (AES-256) and strict access controls."}
{"messages":[{"role":"user","content":"Will data transmitted to/from your services be encrypted in transit?"}],"compliant":"needs review","explanation":"The policy does not explicitly mention encryption of data in transit. It focuses on encryption in cloud storage."}
{"messages":[{"role":"user","content":"Do you enforce multi-factor authentication (MFA) internally?"}],"compliant":"yes","explanation":"The policy explicitly mentions role-based authentication with multi-factor security."}
```
How much training data is needed?
Start small—between several dozen and a few hundred examples—to determine the usefulness of RFT before investing in a large dataset. For product safety reasons, the training set must first pass through an automated screening process. Large datasets take longer to process. This screening process begins when you start a fine-tuning job with a file, not upon initial file upload. Once a file has successfully completed screening, you can use it repeatedly without delay.
Dozens of examples can be meaningful as long as they're high quality. After screening, more data is better, as long as it remains high quality. With larger datasets, you can use a higher batch size, which tends to improve training stability.
Your training file can contain a maximum of 50,000 examples. Test datasets can contain a maximum of 1,000 examples. Test datasets also go through automated screening.

### Upload your files
The process for uploading RFT training and test data files is the same as [supervised fine-tuning](/docs/guides/supervised-fine-tuning). Upload your training data to OpenAI either through the [API](/docs/api-reference/files/create) or [using our UI](/storage). Files must be uploaded with a purpose of `fine-tune` in order to be used with fine-tuning.
\*\*You need file IDs for both your test and training data files\*\* to create a fine-tune job.
Create a fine-tune job
----------------------
Create a fine-tune job using either the [API](/docs/api-reference/fine-tuning) or [fine-tuning dashboard](/finetune). To do this, you need:
\* File IDs for both your training and test datasets
\* The grader configuration we created earlier
\* The model ID you want to use as a base for fine-tuning (we'll use `o4-mini-2025-04-16`)
\* If you're fine-tuning a model that will return JSON data as a structured output, you need the JSON schema for the returned object as well (see below)
\* Optionally, any hyperparameters you want to configure for the fine-tune
\* To qualify for [data sharing inference pricing](/docs/pricing#fine-tuning), you need to first [share evaluation and fine-tuning data](https://help.openai.com/en/articles/10306912-sharing-feedback-evaluation-and-fine-tuning-data-and-api-inputs-and-outputs-with-openai#h\_c93188c569) with OpenAI before creating the job

### Structured Outputs JSON schema
If you're fine-tuning a model to return [Structured Outputs](/docs/guides/structured-outputs), provide the JSON schema being used to format the output. See a valid JSON schema for our security interview use case:
```json
{
"type": "json\_schema",
"json\_schema": {
"name": "security\_assistant",
"strict": true,
"schema": {
"type": "object",
"properties": {
"compliant": { "type": "string" },
"explanation": { "type": "string" }
},
"required": [ "compliant", "explanation" ],
"additionalProperties": false
}
}
}
```
Generating a JSON schema from a Pydantic model
To simplify JSON schema generation, start from a [Pydantic BaseModel](https://docs.pydantic.dev/latest/api/base\_model/) class:
1. Define your class
2. Use `to\_strict\_json\_schema` from the OpenAI library to generate a valid schema
3. Wrap the schema in a dictionary with `type` and `name` keys, and set `strict` to true
4. Take the resulting object and supply it as the `response\_format` in your RFT job
```python
from openai.lib.\_pydantic import to\_strict\_json\_schema
from pydantic import BaseModel
class MyCustomClass(BaseModel):
name: str
age: int

# Note: Do not use MyCustomClass.model\_json\_schema() in place of

# to\_strict\_json\_schema as it is not equivalent
response\_format = dict(
type="json\_schema",
json\_schema=dict(
name=MyCustomClass.\_\_name\_\_,
strict=True,
schema=schema
)
)
```

### Create a job with the API
Configuring a job with the API has a lot of moving parts, so many users prefer to configure them in the [fine-tuning dashboard UI](/finetune). However, here's a complete API request to kick off a fine-tune job with all the configuration we've set up in this guide so far:
```bash
curl https://api.openai.com/v1/fine\_tuning/jobs \
-H "Content-Type: application/json" \
-H "Authorization: Bearer $OPENAI\_API\_KEY" \
-d '{
"training\_file": "file-2STiufDaGXWCnT6XUBUEHW",
"validation\_file": "file-4TcgH85ej7dFCjZ1kThCYb",
"model": "o4-mini-2025-04-16",
"method": {
"type": "reinforcement",
"reinforcement": {
"grader": {
"type": "multi",
"graders": {
"explanation": {
"name": "Explanation text grader",
"type": "score\_model",
"input": [
{
"role": "user",
"type": "message",
"content": "# Overview\n\nEvaluate the accuracy of the model-generated answer based on the \nCopernicus Product Security Policy and an example answer. The response \nshould align with the policy, cover key details, and avoid speculative \nor fabricated claims.\n\nAlways respond with a single floating point number 0 through 1,\nusing the grading criteria below.\n\n## Grading Criteria:\n- \*\*1.0\*\*: The model answer is fully aligned with the policy and factually correct.\n- \*\*0.75\*\*: The model answer is mostly correct but has minor omissions or slight rewording that does not change meaning.\n- \*\*0.5\*\*: The model answer is partially correct but lacks key details or contains speculative statements.\n- \*\*0.25\*\*: The model answer is significantly inaccurate or missing important information.\n- \*\*0.0\*\*: The model answer is completely incorrect, hallucinates policy details, or is irrelevant.\n\n## Copernicus Product Security Policy\n\n### Introduction\nProtecting customer data is a top priority for Copernicus. Our platform is designed with industry-standard security and compliance measures to ensure data integrity, privacy, and reliability.\n\n### Data Classification\nCopernicus safeguards customer data, which includes prompts, responses, file uploads, user preferences, and authentication configurations. Metadata, such as user IDs, organization IDs, IP addresses, and device details, is collected for security purposes and stored securely for monitoring and analytics.\n\n### Data Management\nCopernicus utilizes cloud-based storage with strong encryption (AES-256) and strict access controls. Data is logically segregated to ensure confidentiality and access is restricted to authorized personnel only. Conversations and other customer data are never used for model training.\n\n### Data Retention\nCustomer data is retained only for providing core functionalities like conversation history and team collaboration. Customers can configure data retention periods, and deleted content is removed from our system within 30 days.\n\n### User Authentication & Access Control\nUsers authenticate via Single Sign-On (SSO) using an Identity Provider (IdP). Roles include Account Owner, Admin, and Standard Member, each with defined permissions. User provisioning can be automated through SCIM integration.\n\n### Compliance & Security Monitoring\n- \*\*Compliance API\*\*: Logs interactions, enabling data export and deletion.\n- \*\*Audit Logging\*\*: Ensures transparency for security audits.\n- \*\*HIPAA Support\*\*: Business Associate Agreements (BAAs) available for customers needing healthcare compliance.\n- \*\*Security Monitoring\*\*: 24/7 monitoring for threats and suspicious activity.\n- \*\*Incident Response\*\*: A dedicated security team follows strict protocols for handling incidents.\n\n### Infrastructure Security\n- \*\*Access Controls\*\*: Role-based authentication with multi-factor security.\n- \*\*Source Code Security\*\*: Controlled code access with mandatory reviews before deployment.\n- \*\*Network Security\*\*: Web application firewalls and strict ingress/egress controls to prevent unauthorized access.\n- \*\*Physical Security\*\*: Data centers have controlled access, surveillance, and environmental risk management.\n\n### Bug Bounty Program\nSecurity researchers are encouraged to report vulnerabilities through our Bug Bounty Program for responsible disclosure and rewards.\n\n### Compliance & Certifications\nCopernicus maintains compliance with industry standards, including SOC 2 and GDPR. Customers can access security reports and documentation via our Security Portal.\n\n### Conclusion\nCopernicus prioritizes security, privacy, and compliance. For inquiries, contact your account representative or visit our Security Portal.\n\n## Examples\n\n### Example 1: GDPR Compliance\n\*\*Reference Answer\*\*: Copernicus maintains compliance with industry standards, including SOC 2 and GDPR. Customers can access security reports and documentation via our Security Portal.\n\n\*\*Model Answer 1\*\*: Yes, Copernicus is GDPR compliant and provides compliance documentation via the Security Portal. \n\*\*Score: 1.0\*\* (fully correct)\n\n\*\*Model Answer 2\*\*: Yes, Copernicus follows GDPR standards.\n\*\*Score: 0.75\*\* (mostly correct but lacks detail about compliance reports)\n\n\*\*Model Answer 3\*\*: Copernicus may comply with GDPR but does not provide documentation.\n\*\*Score: 0.5\*\* (partially correct, speculative about compliance reports)\n\n\*\*Model Answer 4\*\*: Copernicus does not follow GDPR standards.\n\*\*Score: 0.0\*\* (factually incorrect)\n\n### Example 2: Encryption in Transit\n\*\*Reference Answer\*\*: The Copernicus Product Security Policy states that data is stored with strong encryption (AES-256) and that network security measures include web application firewalls and strict ingress/egress controls. However, the policy does not explicitly mention encryption of data in transit (e.g., TLS encryption). A review is needed to confirm whether data transmission is encrypted.\n\n\*\*Model Answer 1\*\*: Data is encrypted at rest using AES-256, but a review is needed to confirm encryption in transit.\n\*\*Score: 1.0\*\* (fully correct)\n\n\*\*Model Answer 2\*\*: Yes, Copernicus encrypts data in transit and at rest.\n\*\*Score: 0.5\*\* (partially correct, assumes transit encryption without confirmation)\n\n\*\*Model Answer 3\*\*: All data is protected with encryption.\n\*\*Score: 0.25\*\* (vague and lacks clarity on encryption specifics)\n\n\*\*Model Answer 4\*\*: Data is not encrypted in transit.\n\*\*Score: 0.0\*\* (factually incorrect)\n\nReference Answer: {{item.explanation}}\nModel Answer: {{sample.output\_json.explanation}}\n"
}
],
"model": "gpt-4o-2024-08-06"
},
"compliant": {
"name": "compliant",
"type": "string\_check",
"reference": "{{item.compliant}}",
"operation": "eq",
"input": "{{sample.output\_json.compliant}}"
}
},
"calculate\_output": "0.5 \* compliant + 0.5 \* explanation"
},
"response\_format": {
"type": "json\_schema",
"json\_schema": {
"name": "security\_assistant",
"strict": true,
"schema": {
"type": "object",
"properties": {
"compliant": {
"type": "string"
},
"explanation": {
"type": "string"
}
},
"required": [
"compliant",
"explanation"
],
"additionalProperties": false
}
}
},
"hyperparameters": {
"reasoning\_effort": "medium"
}
}
}
}'
```
This request returns a [fine-tuning job object](/docs/api-reference/fine-tuning/object), which includes a job `id`. Use this ID to monitor the progress of your job and retrieve the fine-tuned model when the job is complete.
To qualify for [data sharing inference pricing](/docs/pricing#fine-tuning), make sure to [share evaluation and fine-tuning data](https://help.openai.com/en/articles/10306912-sharing-feedback-evaluation-and-fine-tuning-data-and-api-inputs-and-outputs-with-openai#h\_c93188c569) with OpenAI before creating the job. You can verify the job was marked as shared by confirming `shared\_with\_openai` is set to `true`.

### Monitoring your fine-tune job
Fine-tuning jobs take some time to complete, and RFT jobs tend to take longer than SFT or DPO jobs. To monitor the progress of your fine-tune job, use the [fine-tuning dashboard](/finetune) or the [API](/docs/api-reference/fine-tuning).

#### Reward metrics
For reinforcement fine-tuning jobs, the primary metrics are the per-step \*\*reward\*\* metrics. These metrics indicate how well your model is performing on the training data. They're calculated by the graders you defined in your job configuration. These are two separate top-level reward metrics:
\* `train\_reward\_mean`: The average reward across the samples taken from all datapoints in the current step. Because the specific datapoints in a batch change with each step, `train\_reward\_mean` values across different steps are not directly comparable and the specific values can fluctuate drastically from step to step.
\* `valid\_reward\_mean`: The average reward across the samples taken from all datapoints in the validation set, which is a more stable metric.
![Reward Metric Graph](https://cdn.openai.com/API/images/guides/RFT\_Reward\_Chart.png)
Find a full description of all training metrics in the [training metrics](#training-metrics) section.

#### Pausing and resuming jobs
To evaluate the current state of the model when your job is only partially finished, \*\*pause\*\* the job to stop the training process and produce a checkpoint at the current step. You can use this checkpoint to evaluate the model on a held-out test set. If the results look good, \*\*resume\*\* the job to continue training from that checkpoint. Learn more in [pausing and resuming jobs](#pausing-and-resuming-jobs).

#### Evals integration
Reinforcement fine-tuning jobs are integrated with our [evals product](/docs/guides/evals). When you make a reinforcement fine-tuning job, a new eval is automatically created and associated with the job. As validation steps are performed, we combine the input prompts, model samples, and grader outputs to make a new [eval run](/docs/guides/evals#creating-an-eval-run) for that step.
Learn more about the evals integration in the [appendix](#evals-integration-details) section below.
Evaluate the results
--------------------
By the time your fine-tuning job finishes, you should have a decent idea of how well the model is performing based on the mean reward value on the validation set. However, it's possible that the model has either \_overfit\_ to the training data or has learned to [reward hack](https://en.wikipedia.org/wiki/Reward\_hacking) your grader, which allows it to produce high scores without actually being correct. Before deploying your model, inspect its behavior on a representative set of prompts to ensure it behaves how you expect.
Understanding the model's behavior can be done quickly by inspecting the evals associated with the fine-tuning job. Specifically, pay close attention to the run made for the final training step to see the end model's behavior. You can also use the evals product to compare the final run to earlier runs and see how the model's behavior has changed over the course of training.

### Try using your fine-tuned model
Evaluate your newly optimized model by using it! When the fine-tuned model finishes training, use its ID in either the [Responses](/docs/api-reference/responses) or [Chat Completions](/docs/api-reference/chat) API, just as you would an OpenAI base model.
Use your model in the Playground
1. Navigate to your fine-tuning job in [the dashboard](https://platform.openai.com/finetune).
2. In the right pane, navigate to \*\*Output model\*\* and copy the model ID. It should start with `ft:…`
3. Open the [Playground](https://platform.openai.com/playground).
4. In the \*\*Model\*\* dropdown menu, paste the model ID. Here, you should also see other fine-tuned models you've created.
5. Run some prompts and see how your fine-tuned performs!
Use your model with an API call
```bash
curl https://api.openai.com/v1/responses \
-H "Content-Type: application/json" \
-H "Authorization: Bearer $OPENAI\_API\_KEY" \
-d '{
"model": "ft:gpt-4.1-nano-2025-04-14:openai::BTz2REMH",
"input": "What is 4+4?"
}'
```

### Use checkpoints if needed
Checkpoints are models you can use that are created before the final step of the training process. For RFT, OpenAI creates a full model checkpoint at each validation step and keeps the three with the highest `valid\_reward\_mean` scores. Checkpoints are useful for evaluating the model at different points in the training process and comparing performance at different steps.
Find checkpoints in the dashboard
1. Navigate to the [fine-tuning dashboard](https://platform.openai.com/finetune).
2. In the left panel, select the job you want to investigate. Wait until it succeeds.
3. In the right panel, scroll to the list of checkpoints.
4. Hover over any checkpoint to see a link to launch in the Playground.
5. Test the checkpoint model's behavior by prompting it in the Playground.
Query the API for checkpoints
1. Wait until a job succeeds, which you can verify by [querying the status of a job](/docs/api-reference/fine-tuning/retrieve).
2. [Query the checkpoints endpoint](/docs/api-reference/fine-tuning/list-checkpoints) with your fine-tuning job ID to access a list of model checkpoints for the fine-tuning job.
3. Find the `fine\_tuned\_model\_checkpoint` field for the name of the model checkpoint.
4. Use this model just like you would the final fine-tuned model.
The checkpoint object contains `metrics` data to help you determine the usefulness of this model. As an example, the response looks like this:
```json
{
"object": "fine\_tuning.job.checkpoint",
"id": "ftckpt\_zc4Q7MP6XxulcVzj4MZdwsAB",
"created\_at": 1519129973,
"fine\_tuned\_model\_checkpoint": "ft:gpt-3.5-turbo-0125:my-org:custom-suffix:96olL566:ckpt-step-2000",
"metrics": {
"full\_valid\_loss": 0.134,
"full\_valid\_mean\_token\_accuracy": 0.874
},
"fine\_tuning\_job\_id": "ftjob-abc123",
"step\_number": 2000
}
```
Each checkpoint specifies:
\* `step\_number`: The step at which the checkpoint was created (where each epoch is number of steps in the training set divided by the batch size)
\* `metrics`: An object containing the metrics for your fine-tuning job at the step when the checkpoint was created
Next steps
----------
Now that you know the basics of reinforcement fine-tuning, explore other fine-tuning methods.
[
Supervised fine-tuning
Fine-tune a model by providing correct outputs for sample inputs.
](/docs/guides/supervised-fine-tuning)[
Vision fine-tuning
Learn to fine-tune for computer vision with image inputs.
](/docs/guides/vision-fine-tuning)[
Direct preference optimization
Fine-tune a model using direct preference optimization (DPO).
](/docs/guides/direct-preference-optimization)
Appendix
--------

### Training metrics
Reinforcement fine-tuning jobs publish per-step training metrics as [fine-tuning events](/docs/api-reference/fine-tuning/event-object). Pull these metrics through the [API](/docs/api-reference/fine-tuning/list-events) or view them as graphs and charts in the [fine-tuning dashboard](/finetune).
Learn more about training metrics below.
Full example training metrics
Below is an example metric event from a real reinforcement fine-tuning job. The various fields in this payload will be discussed in the following sections.
```json
{
"object": "fine\_tuning.job.event",
"id": "ftevent-Iq5LuNLDsac1C3vzshRBuBIy",
"created\_at": 1746679539,
"level": "info",
"message": "Step 10/20 , train mean reward=0.42, full validation mean reward=0.68, full validation mean parse error=0.00",
"data": {
"step": 10,
"usage": {
"graders": [
{
"name": "basic\_model\_grader",
"type": "score\_model",
"model": "gpt-4o-2024-08-06",
"train\_prompt\_tokens\_mean": 241.0,
"valid\_prompt\_tokens\_mean": 241.0,
"train\_prompt\_tokens\_count": 120741.0,
"valid\_prompt\_tokens\_count": 4820.0,
"train\_completion\_tokens\_mean": 138.52694610778443,
"valid\_completion\_tokens\_mean": 140.5,
"train\_completion\_tokens\_count": 69402.0,
"valid\_completion\_tokens\_count": 2810.0
}
],
"samples": {
"train\_reasoning\_tokens\_mean": 3330.017964071856,
"valid\_reasoning\_tokens\_mean": 1948.9,
"train\_reasoning\_tokens\_count": 1668339.0,
"valid\_reasoning\_tokens\_count": 38978.0
}
},
"errors": {
"graders": [
{
"name": "basic\_model\_grader",
"type": "score\_model",
"train\_other\_error\_mean": 0.0,
"valid\_other\_error\_mean": 0.0,
"train\_other\_error\_count": 0.0,
"valid\_other\_error\_count": 0.0,
"train\_sample\_parse\_error\_mean": 0.0,
"valid\_sample\_parse\_error\_mean": 0.0,
"train\_sample\_parse\_error\_count": 0.0,
"valid\_sample\_parse\_error\_count": 0.0,
"train\_invalid\_variable\_error\_mean": 0.0,
"valid\_invalid\_variable\_error\_mean": 0.0,
"train\_invalid\_variable\_error\_count": 0.0,
"valid\_invalid\_variable\_error\_count": 0.0
}
]
},
"scores": {
"graders": [
{
"name": "basic\_model\_grader",
"type": "score\_model",
"train\_reward\_mean": 0.4471057884231537,
"valid\_reward\_mean": 0.675
}
],
"train\_reward\_mean": 0.4215686274509804,
"valid\_reward\_mean": 0.675
},
"timing": {
"step": {
"eval": 101.69386267662048,
"sampling": 226.82190561294556,
"training": 402.43121099472046,
"full\_iteration": 731.5038568973541
},
"graders": [
{
"name": "basic\_model\_grader",
"type": "score\_model",
"train\_execution\_latency\_mean": 2.6894934929297594,
"valid\_execution\_latency\_mean": 4.141402995586395
}
]
},
"total\_steps": 20,
"train\_mean\_reward": 0.4215686274509804,
"reasoning\_tokens\_mean": 3330.017964071856,
"completion\_tokens\_mean": 3376.0019607843137,
"full\_valid\_mean\_reward": 0.675,
"mean\_unresponsive\_rewards": 0.0,
"model\_graders\_token\_usage": {
"gpt-4o-2024-08-06": {
"eval\_cached\_tokens": 0,
"eval\_prompt\_tokens": 4820,
"train\_cached\_tokens": 0,
"train\_prompt\_tokens": 120741,
"eval\_completion\_tokens": 2810,
"train\_completion\_tokens": 69402
}
},
"full\_valid\_mean\_parse\_error": 0.0,
"valid\_reasoning\_tokens\_mean": 1948.9
},
"type": "metrics"
},
```
Score metrics
The top-level metrics to watch are `train\_reward\_mean` and `valid\_reward\_mean`, which indicate the average reward assigned by your graders across all samples in the training and validation datasets, respectively.
Additionally, if you use a [multi-grader](/docs/api-reference/graders/multi) configuration, per-grader train and validation reward metrics will be published as well. These metrics are included under the `event.data.scores` object in the fine-tuning events object, with one entry per grader. The per-grader metrics are useful for understanding how the model is performing on each individual grader, and can help you identify if the model is overfitting to one grader or another.
From the fine-tuning dashboard, the individual grader metrics will be displayed in their own graph below the overall `train\_reward\_mean` and `valid\_reward\_mean` metrics.
![Per-Grader Reward Metric Graph](https://cdn.openai.com/API/images/guides/RFT\_MultiReward\_Chart.png)
Usage metrics
An important characteristic of a reasoning model is the number of reasoning tokens it uses before responding to a prompt. Often, during training, the model will drastically change the average number of reasoning tokens it uses to respond to a prompt. This is a sign that the model is changing its behavior in response to the reward signal. The model may learn to use fewer reasoning tokens to achieve the same reward, or it may learn to use more reasoning tokens to achieve a higher reward.
You can monitor the `train\_reasoning\_tokens\_mean` and `valid\_reasoning\_tokens\_mean` metrics to see how the model is changing its behavior over time. These metrics are the average number of reasoning tokens used by the model to respond to a prompt in the training and validation datasets, respectively. You can also view the mean reasoning token count in the fine-tuning dashboard under the "Reasoning Tokens" chart.
![Reasoning Tokens Metric Graph](https://cdn.openai.com/API/images/guides/RFT\_ReasoningTokens\_Chart.png)
If you are using [model graders](/docs/guides/graders#model-graders), you will likely want to monitor the token usage of these graders. Per-grader token usage statistics are available under the `event.data.usage.graders` object, and are broken down into:
\* `train\_prompt\_tokens\_mean`
\* `train\_prompt\_tokens\_count`
\* `train\_completion\_tokens\_mean`
\* `train\_completion\_tokens\_count`.
The `\_mean` metrics represent the average number of tokens used by the grader to process all prompts in the current step, while the `\_count` metrics represent the total number of tokens used by the grader across all samples in the current step. The per-step token usage is also displayed on the fine-tuning dashboard under the "Grading Token Usage" chart.
![Model Grader Token Usage](https://cdn.openai.com/API/images/guides/RFT\_ModelGraderTokenUsage.png)
Timing metrics
We include various metrics that help you understand how long each step of the training process is taking and how different parts of the training process are contributing to the per-step timing.
These metrics are available under the `event.data.timing` object, and are broken down into `step` and `graders` fields.
The `step` field contains the following metrics:
\* `sampling`: The time taken to sample the model outputs (rollouts) for the current step.
\* `training`: The time taken to train the model (backpropagation) for the current step.
\* `eval`: The time taken to evaluate the model on the full validation set.
\* `full\_iteration`: The total time taken for the current step, including the above 3 metrics plus any additional overhead.
The step timing metrics are also displayed on the fine-tuning dashboard under the "Per Step Duration" chart.
![Per Step Duration Graph](https://cdn.openai.com/API/images/guides/RFT\_PerStepDuration2.png)
The `graders` field contains timing information that details the time taken to execute each grader for the current step. Each grader will have its own timing under the `train\_execution\_latency\_mean` and `valid\_execution\_latency\_mean` metrics, which represent the average time taken to execute the grader on the training and validation datasets, respectively.
Graders are executed in parallel with a concurrency limit, so it is not always clear how individual grader latency adds up to the total time taken for grading. However, it is generally true that graders which take longer to execute individually will cause a job to execute more slowly. This means that slower model graders will cause the job to take longer to complete, and more expensive python code will do the same. The fastest graders generally are `string\_check` and `text\_similarity` as those are executed local to the training loop.

### Evals integration details
Reinforcement fine-tuning jobs are directly integrated with our [evals product](/docs/guides/evals). When you make a reinforcement fine-tuning job, a new eval is automatically created and associated with the job.
As validation steps are performed, the input prompts, model samples, grader outputs, and more metadata will be combined to make a new [eval run](/docs/guides/evals#creating-an-eval-run) for that step. At the end of the job, you will have one run for each validation step. This allows you to compare the performance of the model at different steps, and to see how the model's behavior has changed over the course of training.
You can find the eval associated with your fine-tuning job by viewing your job on the fine-tuning dashboard, or by finding the `eval\_id` field on the [fine-tuning job object](/docs/api-reference/fine-tuning/object).
The evals product is useful for inspecting the outputs of the model on specific datapoints, to get an understanding for how the model is behaving in different scenarios. It can help you figure out which slice of your dataset the model is performing poorly on which can help you identify areas for improvement in your training data.
The evals product can also help you find areas of improvement for your graders by finding areas where the grader is either overly lenient or overly harsh on the model outputs.

### Pausing and resuming jobs
You can pause a fine-tuning job at any time by using the [fine-tuning jobs API](/docs/api-reference/fine-tuning/pause). Calling the pause API will tell the training process to create a new model snapshot, stop training, and put the job into a "Paused" state. The model snapshot will go through a normal safety screening process after which it will be available for you to use throughout the OpenAI platform as a normal fine-tuned model.
If you wish to continue the training process for a paused job, you can do so by using the [fine-tuning jobs API](/docs/api-reference/fine-tuning/resume). This will resume the training process from the last checkpoint created when the job was paused and will continue training until the job is either completed or paused again.

### Grading with Tools
If you are training your model to [perform tool calls](/docs/guides/function-calling), you will need to:
1. Provide the set of tools available for your model to call on each datapoint in the RFT training dataset. More info here in the [dataset API reference](/docs/api-reference/fine-tuning/reinforcement-input).
2. Configure your grader to assign rewards based on the contents of the tool calls made by the model. Information on grading tools calls can be found [here in the grading docs](/docs/guides/graders/#sample-namespace)

### Billing details
Reinforcement fine-tuning jobs are billed based on the amount of time spent training, as well as the number of tokens used by the model during training. We only bill for time spent in the core training loop, not for time spent preparing the training data, validating datasets, waiting in queues, running safety evals, or other overhead.
Details on exactly how we bill for reinforcement fine-tuning jobs can be found in this [help center article](https://help.openai.com/en/articles/11323177-billing-guide-for-the-reinforcement-fine-tuning-api).

### Training errors
Reinforcement fine-tuning is a complex process with many moving parts, and there are many places where things can go wrong. We publish various error metrics to help you understand what is going wrong in your job, and how to fix it. In general, we try to avoid failing a job entirely unless a very serious error occurs. When errors do occur, they often happen during the grading step. Errors during grading often happen either to the model outputting a sample that the grader doesn't know how to handle, the grader failing to execute properly due to some sort of system error, or due to a bug in the grading logic itself.
The error metrics are available under the `event.data.errors` object, and are aggregated into counts and rates rolled up per-grader. We also display rates and counts of errors on the fine-tuning dashboard.
Grader errors

#### Generic grading errors
The grader errors are broken down into the following categories, and they exist in both `train\_` (for training data) and `valid\_` (for validation data) versions:
\* `sample\_parse\_error\_mean`: The average number of samples that failed to parse correctly. This often happens when the model fails to output valid JSON or adhere to a provided response format correctly. A small percentage of these errors, especially early in the training process, is normal. If you see a large number of these errors, it is likely that the response format of the model is not configured correctly or that your graders are misconfigured and looking for incorrect fields.
\* `invalid\_variable\_error\_mean`: These errors occur when you attempt to reference a variable via a template that cannot be found either in the current datapoint or in the current model sample. This can happen if the model fails to provide output in the correct response format, or if your grader is misconfigured.
\* `other\_error\_mean`: This is a catch-all for any other errors that occur during grading. These errors are often caused by bugs in the grading logic itself, or by system errors that occur during grading.

#### Python grading errors
\* `python\_grader\_server\_error\_mean`: These errors occur when our system for executing python graders in a remote sandbox experiences system errors. This normally happens due to reasons outside of your control, like networking failures or system outages. If you see a large number of these errors, it is likely that there is a system issue that is causing the errors. You can check the [OpenAI status page](https://status.openai.com/) for more information on any ongoing issues.
\* `python\_grader\_runtime\_error\_mean`: These errors occur when the python grader itself fails to execute properly. This can happen for a variety of reasons, including bugs in the grading logic, or if the grader is trying to access a variable that doesn't exist in the current context. If you see a large number of these errors, it is likely that there is a bug in your grading logic that needs to be fixed. If a large enough number of these errors occur, the job will fail and we will show you a sampling of tracebacks from the failed graders.

#### Model grading errors
\* `model\_grader\_server\_error\_mean`: These errors occur when we fail to sample from a model grader. This can happen for a variety of reasons, but generally means that either the model grader was misconfigured, that you are attempting to use a model that is not available to your organization, or that there is a system issue that is happening at OpenAI.
Was this page useful?


## Imported snippet – 2025-07-03 14:38:39

Graders
=======
Learn about graders used for evals and fine-tuning.
Graders are a way to evaluate your model's performance against reference answers. Our [graders API](/docs/api-reference/graders) is a way to test your graders, experiment with results, and improve your fine-tuning or evaluation framework to get the results you want.
Overview
--------
Graders let you compare a reference answers to the corresponding model-generated answer and return a grade in the range from 0 to 1. It's sometimes helpful to give the model partial credit for an answer, rather than a binary 0 or 1.
Graders are specified in JSON format, and there are several types:
\* [String check](#string-check-graders)
\* [Text similarity](#text-similarity-graders)
\* [Score model grader](#score-model-graders)
\* [Label model grader](#label-model-graders)
\* [Python code execution](#python-graders)
In reinforcement fine-tuning, you can nest and combine graders by using [multigraders](#multigraders).
Use this guide to learn about each grader type and see starter examples. To build a grader and get started with reinforcement fine-tuning, see the [RFT guide](/docs/guides/reinforcement-fine-tuning). Or to get started with evals, see the [Evals guide](/docs/guides/evals).
Templating
----------
The inputs to certain graders use a templating syntax to grade multiple examples with the same configuration. Any string with `{{ }}` double curly braces will be substituted with the variable value.
Each input inside the `{{}}` must include a \_namespace\_ and a \_variable\_ with the following format `{{ namespace.variable }}`. The only supported namespaces are `item` and `sample`.
All nested variables can be accessed with JSON path like syntax.

### Item namespace
The item namespace will be populated with variables from the input data source for evals, and from each dataset item for fine-tuning. For example, if a row contains the following
```json
{
"reference\_answer": "..."
}
```
This can be used within the grader as `{{ item.reference\_answer }}`.

### Sample namespace
The sample namespace will be populated with variables from the model sampling step during evals or during the fine-tuning step. The following variables are included
\* `output\_text`, the model output content as a string.
\* `output\_json`, the model output content as a JSON object, only if `response\_format` is included in the sample.
\* `output\_tools`, the model output `tool\_calls`, which have the same structure as output tool calls in the [chat completions API](/docs/api-reference/chat/object).
\* `choices`, the output choices, which has the same structure as output choices in the [chat completions API](/docs/api-reference/chat/object).
For example, to access the model output content as a string, `{{ sample.output\_text }}` can be used within the grader.
Details on grading tool calls
When training a model to improve tool-calling behavior, you will need to write your grader to operate over the `sample.output\_tools` variable. The contents of this variable will be the same as the contents of the `response.choices[0].message.tool\_calls` ([see function calling docs](/docs/guides/function-calling?api-mode=chat)).
A common way of grading tool calls is to use two graders, one that checks the name of the tool that is called and another that checks the arguments of the called function. An example of a grader that does this is shown below:
```json
{
"type": "multi",
"graders": {
"function\_name": {
"name": "function\_name",
"type": "string\_check",
"input": "get\_acceptors",
"reference": "{{sample.output\_tools[0].function.name}}",
"operation": "eq",
},
"arguments": {
"name": "arguments",
"type": "string\_check",
"input": "{\"smiles\": \"{{item.smiles}}\"}",
"reference": "{{sample.output\_tools[0].function.arguments}}",
"operation": "eq",
},
},
"calculate\_output": "0.5 \* function\_name + 0.5 \* arguments",
}
```
This is a `multi` grader that combined two simple `string\_check` graders, the first checks the name of the tool called via the `sample.output\_tools[0].function.name` variable, and the second checks the arguments of the called function via the `sample.output\_tools[0].function.arguments` variable. The `calculate\_output` field is used to combine the two scores into a single score.
The `arguments` grader is prone to under-rewarding the model if the function arguments are subtly incorrect, like if `1` is submitted instead of the floating point `1.0`, or if a state name is given as an abbreviation instead of spelling it out. To avoid this, you can use a `text\_similarity` grader instead of a `string\_check` grader, or a `score\_model` grader to have a LLM check for semantic similarity.
String check grader
-------------------
Use these simple string operations to return a 0 or 1. String check graders are good for scoring straightforward pass or fail answers—for example, the correct name of a city, a yes or no answer, or an answer containing or starting with the correct information.
```json
{
"type": "string\_check",
"name": string,
"operation": "eq" | "ne" | "like" | "ilike",
"input": string,
"reference": string,
}
```
Operations supported for string-check-grader are:
\* `eq`: Returns 1 if the input matches the reference (case-sensitive), 0 otherwise
\* `neq`: Returns 1 if the input does not match the reference (case-sensitive), 0 otherwise
\* `like`: Returns 1 if the input contains the reference (case-sensitive), 0 otherwise
\* `ilike`: Returns 1 if the input contains the reference (not case-sensitive), 0 otherwise
Text similarity grader
----------------------
Use text similarity graders when to evaluate how close the model-generated output is to the reference, scored with various evaluation frameworks.
This is useful for open-ended text responses. For example, if your dataset contains reference answers from experts in paragraph form, it's helpful to see how close your model-generated answer is to that content, in numerical form.
```json
{
"type": "text\_similarity",
"name": string,
"input": string,
"reference": string,
"pass\_threshold": number,
"evaluation\_metric": "fuzzy\_match" | "bleu" | "gleu" | "meteor" | "cosine" | "rouge\_1" | "rouge\_2" | "rouge\_3" | "rouge\_4" | "rouge\_5" | "rouge\_l"
}
```
Operations supported for `string-similarity-grader` are:
\* `fuzzy\_match`: Fuzzy string match between input and reference, using `rapidfuzz`
\* `bleu`: Computes the BLEU score between input and reference
\* `gleu`: Computes the Google BLEU score between input and reference
\* `meteor`: Computes the METEOR score between input and reference
\* `cosine`: Computes Cosine similarity between embedded input and reference, using `text-embedding-3-large`. Only available for evals.
\* `rouge-\*`: Computes the ROUGE score between input and reference
Model graders
-------------
In general, using a model grader means prompting a separate model to grade the outputs of the model you're fine-tuning. Your two models work together to do reinforcement fine-tuning. The \_grader model\_ evaluates the \_training model\_.
A \*\*score model grader\*\* provides and evaluates a numerical score, whereas a \*\*label model grader\*\* provides a classification label.

### Score model graders
A score model grader will take the input and return a score based on the prompt within the given range.
```json
{
"type": "score\_model",
"name": string,
"input": Message[],
"model": string,
"pass\_threshold": number,
"range": number[],
"sampling\_params": {
"seed": number,
"top\_p": number,
"temperature": number,
"max\_completion\_tokens": number,
"reasoning\_effort": "low" | "medium" | "high"
}
}
```
Where each message is of the following form:
```json
{
"role": "system" | "developer" | "user" | "assistant",
"content": str
}
```
To use a score model grader, the input is a list of chat messages, each containing a `role` and `content`. The output of the grader will be truncated to the given `range`, and default to 0 for all non-numeric outputs. Within each message, the same templating can be used as with other common graders to reference the ground truth or model sample.
Here’s a full runnable code sample:
```python
import os
import requests

# get the API key from environment
api\_key = os.environ["OPENAI\_API\_KEY"]
headers = {"Authorization": f"Bearer {api\_key}"}

# define a dummy grader for illustration purposes
grader = {
"type": "score\_model",
"name": "my\_score\_model",
"input": [
{
"role": "system",
"content": "You are an expert grader. If the reference and model answer are exact matches, output a score of 1. If they are somewhat similar in meaning, output a score in 0.5. Otherwise, give a score of 0."
},
{
"role": "user",
"content": "Reference: {{ item.reference\_answer }}. Model answer: {{ sample.output\_text }}"
}
],
"pass\_threshold": 0.5,
"model": "o3-mini-2024-01-31",
"range": [0, 1],
"sampling\_params": {
"max\_tokens": 32768,
"top\_p": 1,
"reasoning\_effort": "medium"
},
}

# validate the grader
payload = {"grader": grader}
response = requests.post(
"https://api.openai.com/v1/fine\_tuning/alpha/graders/validate",
json=payload,
headers=headers
)
print("validate response:", response.text)

# run the grader with a test reference and sample
payload = {
"grader": grader,
"item": {
"reference\_answer": 1.0
},
"model\_sample": "0.9"
}
response = requests.post(
"https://api.openai.com/v1/fine\_tuning/alpha/graders/run",
json=payload,
headers=headers
)
print("run response:", response.text)
```

#### Score model grader outputs
Under the hood, the `score\_model` grader will query the requested model with the provided prompt and sampling parameters and will request a response in a specific response format. The response format that is used is provided below
```json
{
"result": float,
"steps": ReasoningStep[],
}
```
Where each reasoning step is of the form
```json
{
description: string,
conclusion: string
}
```
This format queries the model not just for the numeric `result` (the reward value for the query), but also provides the model some space to think through the reasoning behind the score. When you are writing your grader prompt, it may be useful to refer to these two fields by name explicitly (e.g. "include reasoning about the type of chemical bonds present in the molecule in the conclusion of your reasoning step", or "return a value of -1.0 in the `result` field if the inputs do not satisfy condition X").

### Label model graders
A label model grader will take the input and a set of passing labels and return a 1 if the model output is within the label set and 0 otherwise.
```json
{
"type": "label\_model",
"name": string,
"model": string,
"input": Message[],
"passing\_labels": string[],
"labels": string[],
"sampling\_params": {
"max\_tokens": 32768,
"top\_p": 1,
"reasoning\_effort": "medium"
}
}
```
To use a label model grader, the input is a list of chat messages, each containing a `role` and `content`. The output of the grader will be limited to the given set of labels. Within each message, the same templating can be used as with other common graders to reference the ground truth or model sample.
Here’s a full runnable code sample:
```python
import os
import requests

# get the API key from environment
api\_key = os.environ["OPENAI\_API\_KEY"]
headers = {"Authorization": f"bearer {api\_key}"}

# define a dummy grader for illustration purposes
grader = {
"type": "label\_model",
"name": "my\_label\_model",
"input": [
{
"role": "system",
"content": "You are an expert grader."
},
{
"role": "user",
"content": "Classify this: {{ sample.output\_text }} as either good or bad, where closer to 1 is good."
}
],
"passing\_labels": ["good"],
"labels": ["good", "bad"],
"model": "o3-mini-2024-01-31",
"sampling\_params": {
"max\_tokens": 32768,
"top\_p": 1,
"seed": 42,
"reasoning\_effort": "medium"
},
}

# validate the grader
payload = {"grader": grader}
response = requests.post(
"https://api.openai.com/v1/fine\_tuning/alpha/graders/validate",
json=payload,
headers=headers
)
print("validate response:", response.text)

# run the grader with a test reference and sample
payload = {
"grader": grader,
"item": {},
"model\_sample": "0.9"
}
response = requests.post(
"https://api.openai.com/v1/fine\_tuning/alpha/graders/run",
json=payload,
headers=headers
)
print("run response:", response.text)
```

### Model grader constraints
\* Only the following models are supported for the `model` parameter\`
\* `gpt-4o-2024-08-06`
\* `gpt-4o-mini-2024-07-18`
\* `gpt-4.1-2025-04-14`
\* `gpt-4.1-mini-2025-04-14`
\* `gpt-4.1-nano-2025-04-14`
\* `o1-2024-12-17`
\* `o3-mini-2025-01-31`
\* `o3-2025-04-16`
\* `o4-mini-2025-04-16`
\* `temperature` changes not supported for reasoning models.
\* `reasoning\_effort` is not supported for non-reasoning models.

### How to write grader prompts
Writing grader prompts is an iterative process. The best way to iterate on a model grader prompt is to create a model grader eval. To do this, you need:
1. \*\*Task prompts\*\*: Write extremely detailed prompts for the desired task, with step-by-step instructions and many specific examples in context.
2. \*\*Answers generated by a model or human expert\*\*: Provide many high quality examples of answers, both from the model and trusted human experts.
3. \*\*Corresponding ground truth grades for those answers\*\*: Establish what a good grade looks like. For example, your human expert grades should be 1.
Then you can automatically evaluate how effectively the model grader distinguishes answers of different quality levels. Over time, add edge cases into your model grader eval as you discover and patch them with changes to the prompt.
For example, say you know from your human experts which answers are best:
```text
answer\_1 > answer\_2 > answer\_3
```
Verify that the model grader's answers match that:
```text
model\_grader(answer\_1, reference\_answer) > model\_grader(answer\_2, reference\_answer) > model\_grader(answer\_3, reference\_answer)
```

### Grader hacking
Models being trained sometimes learn to exploit weaknesses in model graders, also known as “grader hacking” or “reward hacking." You can detect this by checking the model's performance across model grader evals and expert human evals. A model that's hacked the grader will score highly on model grader evals but score poorly on expert human evaluations. Over time, we intend to improve observability in the API to make it easier to detect this during training.
Python graders
--------------
This grader allows you to execute arbitrary python code to grade the model output. The grader expects a grade function to be present that takes in two arguments and outputs a float value. Any other result (exception, invalid float value, etc.) will be marked as invalid and return a 0 grade.
```json
{
"type": "python",
"source": "def grade(sample, item):\n return 1.0",
"image\_tag": "2025-05-08"
}
```
The python source code must contain a grade function that takes in exactly two arguments and returns a float value as a grade.
```python
from typing import Any
def grade(sample: dict[str, Any], item: dict[str, Any]) -> float:

# your logic here
return 1.0
```
The first argument supplied to the grading function will be a dictionary populated with the model’s output during training for you to grade. `output\_json` will only be populated if the output uses `response\_format`.
```json
{
"choices": [...],
"output\_text": "...",
"output\_json": {},
"output\_tools": [...]
}
```
The second argument supplied is a dictionary populated with input grading context. For evals, this will include keys from the data source. For fine-tuning this will include keys from each training data row.
```json
{
"reference\_answer": "...",
"my\_key": {...}
}
```
Here's a working example:
```python
import os
import requests

# get the API key from environment
api\_key = os.environ["OPENAI\_API\_KEY"]
headers = {"Authorization": f"Bearer {api\_key}"}
grading\_function = """
from rapidfuzz import fuzz, utils
def grade(sample, item) -> float:
output\_text = sample["output\_text"]
reference\_answer = item["reference\_answer"]
return fuzz.WRatio(output\_text, reference\_answer, processor=utils.default\_process) / 100.0
"""

# define a dummy grader for illustration purposes
grader = {
"type": "python",
"source": grading\_function
}

# validate the grader
payload = {"grader": grader}
response = requests.post(
"https://api.openai.com/v1/fine\_tuning/alpha/graders/validate",
json=payload,
headers=headers
)
print("validate request\_id:", response.headers["x-request-id"])
print("validate response:", response.text)

# run the grader with a test reference and sample
payload = {
"grader": grader,
"item": {
"reference\_answer": "fuzzy wuzzy had no hair"
},
"model\_sample": "fuzzy wuzzy was a bear"
}
response = requests.post(
"https://api.openai.com/v1/fine\_tuning/alpha/graders/run",
json=payload,
headers=headers
)
print("run request\_id:", response.headers["x-request-id"])
print("run response:", response.text)
```
\*\*Tip:\*\*
If you don't want to manually put your grading function in a string, you can also load it from a Python file using `importlib` and `inspect`. For example, if your grader function is in a file named `grader.py`, you can do:
```python
import importlib
import inspect
grader\_module = importlib.import\_module("grader")
grader = {
"type": "python",
"source": inspect.getsource(grader\_module)
}
```
This will automatically use the entire source code of your `grader.py` file as the grader which can be helpful for longer graders.

### Technical constraints
\* Your uploaded code must be less than `256kB` and will not have network access.
\* The grading execution itself is limited to 2 minutes.
\* At runtime you will be given a limit of 2Gb of memory and 1Gb of disk space to use.
\* There's a limit of 2 CPU cores—any usage above this amount will result in throttling
The following third-party packages are available at execution time for the image tag `2025-05-08`
```text
numpy==2.2.4
scipy==1.15.2
sympy==1.13.3
pandas==2.2.3
rapidfuzz==3.10.1
scikit-learn==1.6.1
rouge-score==0.1.2
deepdiff==8.4.2
jsonschema==4.23.0
pydantic==2.10.6
pyyaml==6.0.2
nltk==3.9.1
sqlparse==0.5.3
rdkit==2024.9.6
scikit-bio==0.6.3
ast-grep-py==0.36.2
```
Additionally the following nltk corpora are available:
```text
punkt
stopwords
wordnet
omw-1.4
names
```
Multigraders
------------
> Currently, this grader is only used for Reinforcement fine-tuning
A `multigrader` object combines the output of multiple graders to produce a single score. Multigraders work by computing grades over the fields of other grader objects and turning those sub-grades into an overall grade. This is useful when a correct answer depends on multiple things being true—for example, that the text is similar \_and\_ that the answer contains a specific string.
As an example, say you wanted the model to output JSON with the following two fields:
```json
{
"name": "John Doe",
"email": "john.doe@gmail.com"
}
```
You'd want your grader to compare the two fields and then take the average between them.
You can do this by combining multiple graders into an object grader, and then defining a formula to calculate the output score based on each field:
```json
{
"type": "multi",
"graders": {
"name": {
"name": "name\_grader",
"type": "text\_similarity",
"input": "{{sample.output\_json.name}}",
"reference": "{{item.name}}",
"evaluation\_metric": "fuzzy\_match",
"pass\_threshold": 0.9
},
"email": {
"name": "email\_grader",
"type": "string\_check",
"input": "{{sample.output\_json.email}}",
"reference": "{{item.email}}",
"operation": "eq"
}
},
"calculate\_output": "(name + email) / 2"
}
```
In this example, it’s important for the model to get the email exactly right (`string\_check` returns either 0 or 1) but we tolerate some misspellings on the name (`text\_similarity` returns range from 0 to 1). Samples that get the email wrong will score between 0-0.5, and samples that get the email right will score between 0.5-1.0.
You cannot create a multigrader with a nested multigrader inside.
The calculate output field will have the keys of the input `graders` as possible variables and the following features are supported:
\*\*Operators\*\*
\* `+` (addition)
\* `-` (subtraction)
\* `\*` (multiplication)
\* `/` (division)
\* `^` (power)
\*\*Functions\*\*
\* `min`
\* `max`
\* `abs`
\* `floor`
\* `ceil`
\* `exp`
\* `sqrt`
\* `log`
Limitations and tips
--------------------
Designing and creating graders is an iterative process. Start small, experiment, and continue to make changes to get better results.

### Design tips
To get the most value from your graders, use these design principles:
\* \*\*Produce a smooth score, not a pass/fail stamp\*\*. A score that shifts gradually as answers improve helps the optimizer see which changes matter.
\* \*\*Guard against reward hacking\*\*. This happens when the model finds a shortcut that earns high scores without real skill. Make it hard to loophole your grading system.
\* \*\*Avoid skewed data\*\*. Datasets in which one label shows up most of the time invite the model to guess that label. Balance the set or up‑weight rare cases so the model must think.
\* \*\*Use an LLM‑as‑a-judge when code falls short\*\*. For rich, open‑ended answers, ask another language model to grade. When building LLM graders, run multiple candidate responses and ground truths through your LLM judge to ensure grading is stable and aligned with preference. Provide few-shot examples of great, fair, and poor answers in the prompt.
Was this page useful?


## Imported snippet – 2025-07-03 14:38:47

Model distillation
==================
Improve smaller models with distillation techniques.
Model Distillation allows you to leverage the outputs of a large model to [fine-tune](/docs/guides/model-optimization) a smaller model, enabling it to achieve similar performance on a specific task. This process can significantly reduce both cost and latency, as smaller models are typically more efficient.
Here's how it works:
1. Store high-quality outputs of a large model using the [`store`](/docs/api-reference/chat/create#chat-create-store) parameter in the Chat Completions API to store them.
2. [Evaluate](/docs/guides/evals) the stored completions with both the large and the small model to establish a baseline.
3. Select the stored completions that you'd like to use to for distillation and use them to [fine-tune](/docs/guides/model-optimization) the smaller model.
4. [Evaluate](/docs/guides/evals) the performance of the fine-tuned model to see how it compares to the large model.
Let's go through these steps to see how it's done.
Store high-quality outputs of a large model
-------------------------------------------
The first step in the distillation process is to generate good results with a large model like `o1-preview` or `gpt-4o` that meet your bar. As you generate these results, you can store them using the `store: true` option in the [Chat Completions API](/docs/api-reference/chat/create#chat-create-store). We also recommend you use the [metadata](/docs/api-reference/chat/create#chat-create-metadata) property to tag these completions for easy filtering later.
These stored completion can then be viewed and filtered in the [dashboard](/chat-completions).
Store high-quality outputs of a large model
```javascript
import OpenAI from "openai";
const openai = new OpenAI();
const response = await openai.chat.completions.create({
model: "gpt-4.1",
messages: [
{ role: "system", content: "You are a corporate IT support expert." },
{ role: "user", content: "How can I hide the dock on my Mac?"},
],
store: true,
metadata: {
role: "manager",
department: "accounting",
source: "homepage"
}
});
console.log(response.choices[0]);
```
When using the `store: true` option, completions are stored for 30 days. Your completions may contain sensitive information and so, you may want to consider creating a new [Project](https://help.openai.com/en/articles/9186755-managing-your-work-in-the-api-platform-with-projects) with limited access to store these completions.
Evaluate to establish a baseline
--------------------------------
You can use your stored completions to evaluate the performance of both the larger model and a smaller model on your task to establish a baseline. This can be done using the [evals](/docs/guides/evals) product.
Typically, the large model will outperform the smaller model on your evaluations. Establishing this baseline allows you to measure the improvements gained through the distillation / fine-tuning process.
Create training dataset to fine-tune smaller model
--------------------------------------------------
Next you can select a subset of your stored completions to use as training data for fine-tuning a smaller model like `gpt-4o-mini`. [Filter your stored completions](/chat-completions) to those that you would like to use to train the small model, and click the "Distill" button. A few hundred samples might be sufficient, but sometimes a more diverse range of thousands of samples can yield better results.
![distill results](https://openaidevs.retool.com/api/file/7c0009a4-e9f9-4b66-af50-c4e58e0d267d)
This action will open a dialog to begin a [fine-tuning job](/docs/guides/model-optimization), with your selected completions as the training dataset. Configure the parameters as needed, choosing the base model you wish to fine-tune. In this example, we're going to choose the [latest snapshot of GPT-4o-mini](/docs/models#gpt-4o-mini).
![fine tune job](https://openaidevs.retool.com/api/file/ab8d0ccf-df5d-4099-80e1-2f257d82a92f)
After configuring, click "Run" to start the fine-tuning job. The process may take 15 minutes or longer, depending on the size of your training dataset.
Evaluate the fine-tuned small model
-----------------------------------
When your fine-tuning job is complete, you can run evals against it to see how it stacks up against the base small and large models. You can select fine-tuned models in the [Evals](/evaluations) product to generate new completions with the fine-tuned small model.
![eval using ft model](https://openaidevs.retool.com/api/file/8fcfdb03-1385-47d8-81d6-735af29594cc)
Alternately, you could also store [new Chat Completions](\(/docs/guides/distillation#send-fine-tuned\)) generated by the fine-tuned model, and use them to evaluate performance. By continually tweaking and improving:
\* The diversity of the training data
\* Your prompts and outputs on the large model
\* The accuracy of your eval graders
You can bring the performance of the smaller model up to the same levels as the large model, for a specific subset of tasks.
Next steps
----------
Distilling large model results to a small model is one powerful way to improve the results you generate from your models, but not the only one. Check out these resources to learn more about optimizing your outputs.
[
Fine-tuning
Improve a model's ability to generate responses tailored to your use case.
](/docs/guides/fine-tuning)[
Evals
Run tests on your model outputs to ensure you're getting the right results.
](/docs/guides/evals)
Was this page useful?
```

