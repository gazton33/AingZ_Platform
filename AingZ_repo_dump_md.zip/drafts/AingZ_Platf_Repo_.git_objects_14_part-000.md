---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/14
part_index: 0
files_included: 9
size_bytes_sum: 35451
created_at: 2025-08-31T21:08:15.567980+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/14/296533bf31cc026ef38ce573c1b24607675af4
meta: {size:497, lines:0, sha256:"b49830e3ef374cf4f89d7889fae2393ff3cd9612b0117c9b49a7d648c0e2643e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/14/71ce0bc5622089b83c1f1a64fabf9a577d1834
meta: {size:29727, lines:0, sha256:"fbeec165a842075580c7d260b884a58072fb066bd328c1a735dadf05fbd1578f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/14/7d2326e0070b8bf1d6a9fbecd58a8f324db3cd
meta: {size:1309, lines:0, sha256:"23b4a0910ce54e190d8dd92aab28f9b2930e0f509b1198428b73c0090a3830cf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/14/8aa9d2d53554a37a7c8e680f9f6dd2de7080aa
meta: {size:128, lines:0, sha256:"f1ea176816d31181b89160ad733ebdb39318ba618861f043c0dec871edd8b894", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/14/9959cb454531e75a915c2d431122598dddc584
meta: {size:1908, lines:0, sha256:"5c199992a03606b71e1c956b8d0a728b2298b7cc45c79950f20dee587f759bdf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/14/adf2bbc29e5aa164e9f79cb7681dfbd0061c4f
meta: {size:837, lines:0, sha256:"662a981f47afff311ce295dc8284d882b262db046d1753fac92f1126bdb8d73f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/14/d122288893c67794bbbdd74dd47584e6734666
meta: {size:772, lines:0, sha256:"36db556fea0f2c14bf44bb56582bc2f63420de98332f5a2af5026c89d855d79a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/14/eee82e5942f0251b52ce3127e28a9a8b64dec9
meta: {size:200, lines:0, sha256:"5e1cec17c652df87a3b39dc60238b36aed202fee00e3a39f65d7a11bf4cfe862", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/14/fdfa291d642ff6234ff67819059c41dbfecd5a
meta: {size:73, lines:0, sha256:"e847232b23c49334361fe52e7f6e286479b111f9dfafec471a30abef9295c312", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

