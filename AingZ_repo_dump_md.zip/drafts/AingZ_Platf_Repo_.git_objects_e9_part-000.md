---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/e9
part_index: 0
files_included: 6
size_bytes_sum: 2307
created_at: 2025-08-31T21:08:15.651065+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/e9/0253cb8287646f979b9531c07f0b1928115207
meta: {size:852, lines:0, sha256:"612360a10f2084ce0af9bf6d3fa3378a35fc7be490a6682462dda32c4087f8b0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e9/3fe2cedfc9ac6b8ea6e5154eb53432845d1502
meta: {size:611, lines:0, sha256:"ecdb1599c2d2d4e4588845a53c1f5cde579ebf3e9f63c81929f35fa7c1e05be7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e9/5019bbdfbd9fc4287c999a4aa1ff5c1827aa09
meta: {size:299, lines:0, sha256:"370f23c6729a3c4143519506f31fe412d4c11af33ac992e39c7cd2b6fe904d44", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e9/975eb6ba58c19e5535c033d413c4ba7864d6a4
meta: {size:399, lines:0, sha256:"90935f9014f24843a075d28801baf02d9679932fd6311ada49ebf495bc3826db", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e9/a15c75e05db069ba705c64c574b538b049c25c
meta: {size:51, lines:0, sha256:"1cfcbcd95a3bfe37985ad6aea431013db86a0e000beb023056b25b84f2339cc7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e9/dd6d25903fd4aa1e21dd59928b7ca14f313ac7
meta: {size:95, lines:0, sha256:"b9cdefd6399b884f28a7b3542d0831e56de6adb0a55662f2106da7e51f49831c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

