---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/e5
part_index: 0
files_included: 11
size_bytes_sum: 15888
created_at: 2025-08-31T21:08:15.650756+00:00
integrity:
  sha256_concat: b286454458503c8bb62b8aaddc61afe5ca6645ff744ecf2e054fb2c138622304
---

## AingZ_Platf_Repo/.git/objects/e5/0ca10243b72bf5b0a9650bf1d099d263eddb66
meta: {size:1577, lines:0, sha256:"be6ae6f3a3d00601c5e5f9d2d104041f2499e0df94c47dd03906eabdbf291f3e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e5/1c89556db4a6d2853196f07de40328e66fa9b8
meta: {size:846, lines:0, sha256:"401f057da1898a553e3c08e4d238212e7586705ac0554dbd2a53a6f329320c39", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e5/1cfe46cedb18b40be45f1f720cac87c3e6e343
meta: {size:1165, lines:0, sha256:"243f38ca5b089c128fcb0f9d692251009780cf6413783dd50eefde82cbef495d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e5/2d228d807097b951dcffe1f9f3bcf241c293e8
meta: {size:65, lines:0, sha256:"48f9300cf02c256bb01a954e11ddb3f5e2c6afb48f09656470cbb366af4c0a77", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e5/35e50a0797337365f41cf9eacd8aa31551bfe1
meta: {size:155, lines:2, sha256:"aa022a958063ce9be86a1828be0f6455ff042e9c9b0a74666046f914ef00b751", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎA
Ã @Ñ®=hpf4*Ò«fLI-ÖRÈé3tûáÁÏuß×®â¥7\ §yàX»Bä2)G	çI½¸É³kìH#(V-f,Þ#> I`âO_jÓ3½>ômÙ$/õ+í1ï¼nC®û]wÖïÑè«!cÔYÏÅ.aµñ»«lëE_
```

## AingZ_Platf_Repo/.git/objects/e5/4a4800d1d5e788d508de27d32d778f71c58314
meta: {size:723, lines:0, sha256:"567e6636353b5e1121bd6732f62612f5af6ab82ecd8532b0fd626a3c1a7be001", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e5/5e3e8f2ab42fbe97c7e13ac51b9c778b93b29f
meta: {size:3244, lines:0, sha256:"41de61a837010a1af4d70fbc25f830b1f9a43941ad1f48872bfa5f6af29a3a29", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e5/6ba16d6fa9cb7187e3bcf70480ce9400f22ead
meta: {size:5670, lines:0, sha256:"307f0c763a428ce44109097df81d0906ea549998c7ab366269626c57b007772b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e5/926894e2aead1840446b63bef46d0eba94599a
meta: {size:1009, lines:0, sha256:"e71226542b7792312803fdc91be937eb5170a51789325aeb3cc0de4252e88acf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e5/9dd3b59efa4e7e3a2d6d699698c85b71c73116
meta: {size:582, lines:0, sha256:"532ff4c538723707f4136d80fce9e532a1a60940f8ca872f4204a81d851bb71b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e5/bec4284dbb419b3ca5975ebcf8bfb5158fd5e5
meta: {size:852, lines:4, sha256:"7dbf625db9e27dfb6d24eda4bbf76d191c92c3c3f3241eebadb17921ec6eb5bc", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuSGÏ£VÍ_ñ¤l¡éÒ$
ÕfÓüÙl"Ê£ØÔG1ø×Ì:¹Ë#«{OI»¦©&@<ûË |SäóLs6KøIc(ðDN0ÏÉ4#XYëcÛ	pAÌñH'DìNR:åH@>ËI
ç©ì«¶ÀâûÖ0-»7DM\ÕßÓ®ùÃÒä¥Yð ÛÑýÀ	"pª&}NÀ¶C°¯·¿j*çähE_U¾ý;z:;àzºÿ|rÄ ôÔ80ðµTEIEWrn´P#{2»Ü<3aY¢¸ÁÎUÛCy´«Ö:òp	ÖvøÙó8Ô^ ÒÂ´íÆÛ¹M
_:ÏKäó®ßp¤4j2íó!ß«£glIõºîø+3nä4öeåUÿå®¢üÃ«MòLÿöÍh{-­kò]ò>ªóýäÁü8I|®7Hp÷ßdõÆ|Ýq*·¨N6ü¶%tFúÒÐQ}w¶vÕûÿº9DÚcÞ9$xÙÖbv\îÝrc?^t?D³)?ÈlÖÜÊï7Æ×^î¿~û	]`$éçäNa{ü£*)Ë©î/JÉktk_ÙåaÔCuU&;¸Æ¸o©¹½ºª·0ÐâñY»Õ¢rZÆG6KZmËsÇx~Ò_OùÎ(|0¡I³¬ËËÞò(oÒDÊþõzøkd¥OQôî°5\¼ùb¨®ª\ô[Þ×QÔ<sÕ4Ã{[dÈcÀ.Îæ¥´ÓÎP`ê¬¯m®·@gL«P~xpä§Ô¢YÖÆ'3gÑY§)òtxîJºoÖ×[M¹|²Lj	D3Ü«CâC·ôy·uMáEÁj¡kónïXdk8zº3?éÌ­ËÚkX¨PÓúj»  öÒXþ0@Ø©[æf]uÂÛåeÜ·@U[_#¾=_°óUé8x¤ºËü3ûª£üw#06ÝA6÷uÆÌÕM`jï\\Ãä¨k@½ãSà·_êwûß]µ
```

