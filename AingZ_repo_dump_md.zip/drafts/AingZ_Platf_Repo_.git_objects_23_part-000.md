---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/23
part_index: 0
files_included: 6
size_bytes_sum: 4403
created_at: 2025-08-31T21:08:15.569622+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/23/05ccd560e2c6864d7bef9217630a926d8e059e
meta: {size:361, lines:0, sha256:"a366ed60856e14499b1e0cf311424b45f443909b9ca1df80fd918701e8bab0ba", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/23/11c78664d7b6e5f8f38ca4adbac718265aea9c
meta: {size:886, lines:0, sha256:"85580fb7a14c5673dfea1c7ce1a001522b005d8f30cc002f3355fb64e775d209", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/23/3687782ffa8180d94981d704a482482fc3a297
meta: {size:909, lines:0, sha256:"150d229deda906f07ba7a8d9a7b5cb9c41cb29bada5e85ab0cdcd9278a14f096", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/23/48eee414ce856e093e14895bfe48c9b6180ca7
meta: {size:981, lines:0, sha256:"7531a455e8148596bf0c4350f36bf8c907d507fe01a77f165365f700817d2f76", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/23/4cb00b683dcf0956b51bef4115bce085ef877e
meta: {size:632, lines:0, sha256:"f77e72d7e3381e55f100c8af2f9f723d043a629c5fc44966f1c38d7105ed4af7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/23/f05547d6f7755f273fa4ba6e34c372aee9daa7
meta: {size:634, lines:0, sha256:"ca87166198c346fcf98976616debd69e5e6a10b4902bd03fc7965041ad0148d8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

