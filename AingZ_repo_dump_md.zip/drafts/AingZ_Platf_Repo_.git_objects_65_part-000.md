---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/65
part_index: 0
files_included: 3
size_bytes_sum: 1889
created_at: 2025-08-31T21:08:15.622597+00:00
integrity:
  sha256_concat: c5b7986abd38868dc04b4b56fd2bf7955393874d5eff9bec3bc99b69540b6f69
---

## AingZ_Platf_Repo/.git/objects/65/4ff33f0a0d1314095a4d3af9773fb9b03e4fde
meta: {size:1421, lines:0, sha256:"7c62d95040b78ec14151614706af31510e8b0efd4547667e7edd548af1ad4da1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/65/6427d046e918888a78066a5f18cf9263476952
meta: {size:336, lines:5, sha256:"b9bc48c8fb8a730500eea074803b98bb3f50b0d1736f440890cf25a74bcb57ac", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x]QÁN1õ¼_1Ýà. ÄîA= 8ÒÝw;M[rò#üO~â8ÀF/M;}ïÍ7³gÐë÷ONaü0xß=NÆª<ÃÏÇ'Cð4w(ØFZGàØÃKª8I. MG4'OVlI¼NSxÉ²|ú ÂH+
HÎù´%Ø{ÍeábOuêÍR¿QPRÆ2Äí3vkö±ÁÿY'Qúì»Ñ!ÜÊ¤XMÏÄÕ¤	UÎ»P³C?òØ('nçìkµRÕmw¯ÚýËNVçI2"ÇÁDöÅ.¼òÞ)è&,`Mm6X6¹ÕûÜà~%a9ÓèEÜsY²j
°û=*¤D©µ+ÒÚÈ! Í
,ÈSô©enÔfûm¥TÑ
eÙ/{Õ¨\
```

## AingZ_Platf_Repo/.git/objects/65/71bf0d0bd91f7694b4eee0632fc3a120c2f4db
meta: {size:132, lines:0, sha256:"23d0223bbe69d35c6e13903e72d4e98539b4331a0736d8a17f75195f29bed6db", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

