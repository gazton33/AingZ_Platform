---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/7d
part_index: 0
files_included: 9
size_bytes_sum: 3395
created_at: 2025-08-31T21:08:15.625044+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/7d/0e7e27397208450ff27da30aa45d1de12327db
meta: {size:1063, lines:0, sha256:"c6b5203d7158b9cc8adc864b064e0aecff261c9eafec0ebddc30d8cbb8451916", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7d/134e288d671c18745b1bb3710e70ee73dd33a5
meta: {size:233, lines:0, sha256:"04567536fb61aa1cad1a650196482dfab016462f39e9d9b8fcbd9617ee043c78", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7d/24674281b1e932e7a8a273b8dc309e9626cb9d
meta: {size:52, lines:0, sha256:"b66c72dbc4afc26e36582a79863ef0fbe555b258edb85429916ce8fd66eda546", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7d/6cf8b6c6da052f8045687c60a9aa51556851d8
meta: {size:70, lines:0, sha256:"18ed918ce689679ebf5ae30b7ac2c81bea00ca1516afdf94ec1bf6b92cc64cdc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7d/a24a52d2f968d751c8ed3e684e246bc8e8a97f
meta: {size:447, lines:0, sha256:"0d5fb2ebd4144fd161f12112bc63abd17ece2a445ea2296ba195d565ce95c2fc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7d/a381271f713a47fb5ffc132fc23c1065474d51
meta: {size:484, lines:0, sha256:"06d1fb523a3d9df2445b5caeee52e2291ed11929dbe876b978a30dfe8ad0ab20", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7d/b177ef41961f6fc57426e407354c6d686f4756
meta: {size:154, lines:0, sha256:"dbf5abbdb1362cb494b037a9259655b382122f125e49963cd6974e106cb3d3da", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7d/bd8d22507e8101b727360a24876da12692d111
meta: {size:258, lines:0, sha256:"eded98df8f859fc14a6aa75f858f879185bf7f7f671b492cfb42f4312c55e948", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7d/e11c84b5fe6a14a1e8ad51b9206977449746b8
meta: {size:634, lines:0, sha256:"4ba6e50f5858bba944d4b6100661037e04bbe7adf5a071844060e7be9a581983", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

