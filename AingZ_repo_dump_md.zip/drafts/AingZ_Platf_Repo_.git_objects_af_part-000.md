---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/af
part_index: 0
files_included: 9
size_bytes_sum: 11220
created_at: 2025-08-31T21:08:15.629497+00:00
integrity:
  sha256_concat: 98aea18c92d80cf59359db565a6f8624e267e3435687dc8b1c3997c32feeaed0
---

## AingZ_Platf_Repo/.git/objects/af/07b441c815b92cf04e0ac7370896082e3a97bc
meta: {size:54, lines:0, sha256:"4a105ec0c4f3a8650fedf86c20064b71b879197b017d7ad00410049d1daf4607", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/af/0bb9b1bb76009e82c1a7e24e2d5c78ac4edc9b
meta: {size:844, lines:0, sha256:"59db873f0b3977b4be1bbabe2aad9e8c9779e742cf3c4ce287a43e1e4bb19dc3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/af/4289bed1c740ed4869673422dbc4aaa3c2ca16
meta: {size:88, lines:0, sha256:"13bdf3f57a104619eec21fefecfd672c630732502b9720a49a0366b825a5c17c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/af/63f8124159f871518cd84506c3a19ee5e14c33
meta: {size:861, lines:0, sha256:"449a629933e0645e154ea547f6ec1132a0c97aafd3005848b52c9677e5b25fe9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/af/65878cac08b1fc30537865bb46b14036997365
meta: {size:3532, lines:0, sha256:"d10b65d5b712b0579db2852cb992c0302ccf339b4583ded206e696942c19467d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/af/7051378355eda1ff66b1102c2cdf110299ed7b
meta: {size:1884, lines:0, sha256:"0186ba86edab122ec65af233952f62ac4ef6cf4af80fc62cbdd7653e08de67b7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/af/8f03a21243c2b0a1a2cc87b1101bd382adf414
meta: {size:718, lines:2, sha256:"3fa8a29e5b1a3fa3afb0b74ae533d861438234a99f714a2e7cba8fb4fb57088b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuTÁnÚ@íÙ_1R.Uì@©Ê¡cj5N&`Yºe½kí®Iõþ§þCOýþ$_Ò±!ÐjÙyÞÌÎ¼yÏ#¡FPoÔO^Ày~¸Jü¸ÂóÓzQÐlG0¯;Î;pÝ~¤Wý3×auqÔI£aYþgµüP¾ü-Kdã¸qZ;~[;nÀw
«ô´±[&ý¬vZ­æ8P÷ ÇL1é4¡çU)Ès&-ó*XÃ¾$¹ù¬¬B¯V95Î%0f`6Í¶¤$3Þy~¿$ý÷Ý´ïß1)gÌ6ÄÿÃæëP0"tVäâ`'¦7e²÷7Z£Ù¾Aä9S¬îº=6aIÊ"CqrÈ;Ï[µð7È i"Ùq¯Ëæ=?ºI_Î:cÈÁË¥»üsª¶yO®z­ íöân¹ÙmÝ^ôRjÓ;6hñðÕÑ8jûCÌÀ»ÙývrÙñézÚÁ´{Ùø¨dÓu/DñE?á9ü_27a¡ë?_C+\Z,³AIDq'êÿ[âA¢eHmI3À,è¥¨>®3Kµ8®çv ×¥³AF¸ôçÅâyñ÷Àkû¶d°¬Pz®À_+=õ`à0äT¨òÜ|LTµëÆrªQ(×Ë¨PVi;ÙáãaT¸]FÔ<zÐ)°H;níçUx/¥éºè£6´²Ú·¿_naJîUB]÷¼²6	q¹µ{%ÏÕfqõNwV»2{¨²\ Q5X5V¨x|(ÉòòGI@ÙÌÐÔò9¾)déÌG ¡Ñr×~m4A£_? O
```

## AingZ_Platf_Repo/.git/objects/af/a19219332c16d09085e0fdaf628042296b3d67
meta: {size:76, lines:0, sha256:"e1a1b9b1bc73785163c099cd4ffd9bee67ba40bd55b463b4fb6d2740ed4e7499", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/af/e6f9856a3bfd418bcc50dfe330fd91129f7037
meta: {size:3163, lines:0, sha256:"9377bcc0405bfd1e95c7e4772536b879aeef4e8ef72adddaea50da286823c81a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

