---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ba
part_index: 0
files_included: 9
size_bytes_sum: 4668
created_at: 2025-08-31T21:08:15.630182+00:00
integrity:
  sha256_concat: 4f6cf731545a64a705037b9f6853305e24b697b2236627bf2215d6dffb9e5d37
---

## AingZ_Platf_Repo/.git/objects/ba/0bb16417726a9fa582c25e37af1f96b7ec0db5
meta: {size:60, lines:1, sha256:"13be886dc5e1f352142c46cb5ce66980d595829ba8f8ff19fe64aea4162481a0", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xKÊÉOR0±`¨æRPPJJ,NuËÏ+	Î¬JU²R04Õæ%d¥ú¦æÓsS¹jÑ¶÷
```

## AingZ_Platf_Repo/.git/objects/ba/23f0a86bc68cfe5d2f0eebef58d6b7c1cf566d
meta: {size:723, lines:0, sha256:"df4ac6b4877ac7b1affa6f43e74f61356035433a8b594da420e9d4121f09fccf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ba/2c11c2fbc547a84dfe94dcc124d414cc2f34f8
meta: {size:689, lines:0, sha256:"4c8d843c537fd0845851c5636e4b3fb39f27d27edba88f5db9eb084aabb43d3b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ba/469ec2323fef5604139fd80c5c64af0362bc16
meta: {size:857, lines:0, sha256:"ebb32a0931f3bd66870b312a8e9d3d7498d0deb62416e6ba78d797372212dd5e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ba/49ac5967360cc0bf2116e1dc1f3e41cff0a4a5
meta: {size:178, lines:0, sha256:"d71324b616f1eb436937b75ebefcfa01c63d37d912f5dd59044f813dec7424b9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ba/754f3e2937fc5e18a808cfc4bc920fca8d1f39
meta: {size:968, lines:0, sha256:"d84700e7ba02bdae596b248992e6dfe58c84a291dd1b325ee7a85fbb25318592", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ba/b2765621b39bdb1aca85ae961deb162ba36a2d
meta: {size:842, lines:0, sha256:"d189353e259b4ebaf1ae53bd6973c07968cb3a95a5579babdefebe43fe7dce7b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ba/e20f3b0c878f3db669ed507f3a3937b43c0f65
meta: {size:283, lines:0, sha256:"02663e01b6b48ef6175e287cae5792adae13047162f6c73d7337060b5755c191", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ba/e87f992b047aa63f411a5865b9f58990bcd9ce
meta: {size:68, lines:0, sha256:"c6634aff3edc0b9a176facb312deaf4aaf7c1c81e34d5e4ac6f2075a91fdc8c2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

