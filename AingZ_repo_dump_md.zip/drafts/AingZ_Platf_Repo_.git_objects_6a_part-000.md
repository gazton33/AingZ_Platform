---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/6a
part_index: 0
files_included: 11
size_bytes_sum: 9908
created_at: 2025-08-31T21:08:15.623079+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/6a/02bdc2ed1d5fe1c4dfa91dd26780e94aa4011c
meta: {size:1979, lines:0, sha256:"6a3fdf1462e51aa843a98ba9fd8194a6ed526bf831b18b8b5bc21d7e870845d9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6a/119ac8718753b6eb06567320bc85156868fd1d
meta: {size:645, lines:0, sha256:"fb595037ea97827f46b9619fb6e1ea89e43c1a65800e83122f32457ddf00cf57", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6a/198ff5efeb9095398c32e5847654e2b73c9e83
meta: {size:724, lines:0, sha256:"c9fe5dc833c12b83a04d5d4c48ee94208281adc6cc4c1a8988eac3fd3babe7fd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6a/1d4cc7e5cc3333f1774dd36b71ba26db90cd67
meta: {size:1113, lines:0, sha256:"3c1c4a8d9431552f2b004e34df745d3a05eb44e5d299b25b9b2e5a675e74fd2d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6a/35376456a94749a5c433fbfd63735a5a784d92
meta: {size:199, lines:0, sha256:"04d5323b8210bb9c0a5e501d23d79aff4714d0a80a04b81901dbb28231e16c67", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6a/47732bf7807bbd980b3f4d2ba80f2219226369
meta: {size:1008, lines:0, sha256:"1880f2479205b45645b8838cab4ad49ff7e357d8dd7af0413e8be8b7e28b2e1c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6a/4fbb6896621c25056a22919dab4a6c6c677675
meta: {size:96, lines:0, sha256:"57e066e3345fd5b9f27e97de09c5e3dca05f11192fd1a198bb5ebbec098687ba", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6a/7db33805cf45769f9e97586411d99c1f71d70e
meta: {size:957, lines:0, sha256:"e8be06111f4f3cf88b0534e5f4c20807e45fedf37dd94d95beb75711c0035b60", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6a/946e72f8a195aac60f7baae9fe18b3623d4a3f
meta: {size:752, lines:0, sha256:"77ddd8d74371148c77bf49dd6fe44842b0de9a37f3c70107c722c3cd6263ee4c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6a/ac723a8546fd7fd203350057d96050507f2618
meta: {size:1111, lines:0, sha256:"548f5d0a951ea9fa0e4a1df20316306415ee92522041b4a2f3bf509c82415e0f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6a/f0862f0baed05ccc6aa3f50da8a7cd5f57fa8f
meta: {size:1324, lines:0, sha256:"836c31725628fae8b3f8384a046c203423db68a261461da8228f25d288a25353", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

