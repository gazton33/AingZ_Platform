---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/44
part_index: 0
files_included: 13
size_bytes_sum: 57648
created_at: 2025-08-31T21:08:15.573318+00:00
integrity:
  sha256_concat: 8f0ee183b1da73ec3bb3a27e01929549eadc9ea43ae174b21599cfafca59908a
---

## AingZ_Platf_Repo/.git/objects/44/007e5bc81049ac5ae439c44b8e699708165788
meta: {size:635, lines:0, sha256:"b59d2c53ef3c18a3c7a9b2a57aa5ed3809d9b638295fd64598734a0e1a8457c6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/44/06c2c911cf61e78d3efaf29805726ef4191b63
meta: {size:44352, lines:0, sha256:"83a34e1414af9adafffda156c8ba0b588a1edbe39eaa237321867c8eff7d48cb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/44/313fece4113f1b5ac78fb7866aeece5f8bd8b3
meta: {size:904, lines:0, sha256:"f8a7b155274a07d2c4068636af85ec378273f3b50b280465833092daa7fe67f2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/44/3c88d84b609ac5bb6bae5a95567338daa1ad94
meta: {size:853, lines:0, sha256:"45e3cc3f0b6e1ca2768778cbb7bce255cb984db5188d680f5fa732c147112b4d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/44/470bad6b33e47e0861e7d1e6dff95bacd450a6
meta: {size:210, lines:0, sha256:"58723abd61a868b509ed5a855bcfee1e2ebf031e01a740eca480dffb9748491e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/44/4cc1fb33bd50414331cae080137fae7d3d5e1b
meta: {size:52, lines:0, sha256:"fcf635e5bed0db40ca14a95795d37c8bd45c70936155020b53020720f1fd7233", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/44/6632f3bbb103709bad7ff46591e96d60b2e86b
meta: {size:3262, lines:0, sha256:"387de5643b5b970d337b7f0a133c4d8c94a5d5896354fad180d27645f9d25853", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/44/76b7d8ff0d47c017107705031f5cdad4ba00d6
meta: {size:630, lines:0, sha256:"902347161ef6c669530bb935d0efb7b8c4cc09cd85c5676adde55fb3897d9823", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/44/76fa3b63594edf66c8d705b17d4e77563ddaf4
meta: {size:2260, lines:0, sha256:"e96356af5de006be41529fdf7d996f592a8c9c5349cab0e6654b07ad72911502", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/44/787acb23aa3e510016c557390981fa24b71a5d
meta: {size:644, lines:0, sha256:"692cc9e0723dae7c0081a95587dd3d4ad7e83634200ae5e7afebe9cdf76dffdb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/44/ca8e0935078b60b4d6159d7a6ff89942464213
meta: {size:2720, lines:0, sha256:"07faba5f29f45f244cc6f145da6943f75a761e5c2379ec3e3dfcd89d0a7733a3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/44/da51864bef13fa9946b2556bedf52a7c37c9c1
meta: {size:971, lines:5, sha256:"84a46bf70cbfbf41ad4c4649e91ad6f42f1515244857d2b431db7e2a8b72cfff", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xUÝnâFîµâH¹I¬ÅN²]µÍE%^Øn»Á0dÁcÍÒ]íÅîM âªê+ôª7áIúÍØ&4½ªlÏwÏÏw>fJÏèâß}uB½nöwt4Û½¶Að=á`Ø¾\!MÓ¤ßî&ýa2õÇ?T!×/6LÉËÇ¿3¼<¿|Õ8ÿ¶q~I¨¹)´¹¢³ÌôN(Áïõ0AÐh4àä."ºv³YÍÕ>åFæ¥¹ µ\2|ä.#d,·÷öZ:+Ä¯Ôb&sNö0BÁ[glÎ®h:âA¿~¸âñNÙû-!+åJrv@IaÑVg<#Ø2|Ë¦ã«Mn©Û|sÒþìãêÜTù_FÔ2ÚZ#(®Çò\fK|(ïÄBq^Z.²¹À'|ÇGQHÏ@+aJXrëfëÇ7i<~áOmëç2ËúÄQÇ8f®¨2[VX2þápÒËú1GÙl)ª)ÕæbOÐÌ%jÇ>ñë_	?F[ÈLSñøW.¹ö¹cQÜNÃnÿ¶.ôÐ$t¢@e#Ð/FÐ©ñ©sºmÅ½ô¦óª§¥7FëùYÙ°×jó^Û8¹PòßÓ;ôöíë8¯ìpÎãéÇ(N»irÓí'ÿ"ü8¿(5ËNd$=~13­ùÚFtZjL§SGÏ ¦¼¤ÞBõdÍdûÝn¿û#yì°UøÄÇ.üø>À~÷goÎ
æâÎW=>*ø±ºcÛÃâ)µW¨¼jüVÕBéK§-ÉvÅÿ$çØ¡¶pÜ	RXç¹¥æmxÝ«aÆ¿[ EØBÐÌ³ç
LÝ$fë?ýnOGÃ^:Huºý·3Ð l0Äþ¹u{x'¾UîY-Ë$eT¾¦Ì*ÆU;e\a7[ e^PdrÌ¬Åw ·$µÜ¸"µgÕî<y@6ÂgµB§¼Ä:ÅCÏ<±Û5FgOþài^{­_¢äÚS[\Ëâf%¢RBñ0sMLQ½7¤ @è.ÆìF7-{²ÿíwôWÔ«K·²S(¹×ÿ^ç
®
=Çä[8[çî¦3Âî® Â¼ð´ØdN?7b!t,1ü@x§õ¦*HÎ
```

## AingZ_Platf_Repo/.git/objects/44/e4ac4e8a9f38b7cbe31ecfa2568a05e44e4e5f
meta: {size:155, lines:0, sha256:"5b72da0af639d9bb69123c901c88844fef83d7497181a592ad48c8d5c5247639", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

