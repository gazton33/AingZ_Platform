---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/c8
part_index: 0
files_included: 8
size_bytes_sum: 8696
created_at: 2025-08-31T21:08:15.631232+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/c8/1add3a8f6efdcb4eeefd670fef10dcc1421dfd
meta: {size:1217, lines:0, sha256:"98947d989ba1fe64c23af3160fb42120db8a8336a7f6f5e57cec6dc06447dff2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c8/30434eb7dc7efedd76eb52fbfba548f5bf664b
meta: {size:2400, lines:0, sha256:"5a87d689c36a274f69e7329c90ef39c9926c85449e3a3d44440a1f818c6c745a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c8/39fb84d7184e0d368136c418c048cb37bcab10
meta: {size:908, lines:0, sha256:"c6a627bebe71ed8a48b8899d7c01fb8629d9c9f90513770b40024e0cc42505bf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c8/8378ce24808b475e95cf6d4330d8c6a423d474
meta: {size:85, lines:0, sha256:"d68ce1ed8c060bb0983fa883a2f3112b7647c9ba88b48a9796a278ffe70ae2d0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c8/913cf229277e041844ff5068a179c562028ed7
meta: {size:139, lines:0, sha256:"9a0da08bbb2746156cb7383bf405792ae9c88aa5212720791021ad08b55756ed", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c8/d6861d5362a2a9e841af09c3ba697add48be43
meta: {size:1346, lines:0, sha256:"3bc59be49f6879d7fce85882b1a487d468f4f3843aeee3e40a98b22fd3aa0ad6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c8/da320a160e35558e766d7f8b4a88a4cb52223a
meta: {size:2256, lines:0, sha256:"25353d49df429378979ba9d23b64603618e78d344fc95d88bb168caaa7741453", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c8/fb4fc89ff67133dbd0a30355560964f0fc89c8
meta: {size:345, lines:0, sha256:"10b77b4f4a6e8cab8164df6fc25982b97e5b136c90c2710f651805f3cc2bec07", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

