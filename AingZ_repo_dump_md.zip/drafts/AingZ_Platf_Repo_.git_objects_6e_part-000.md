---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/6e
part_index: 0
files_included: 8
size_bytes_sum: 122767
created_at: 2025-08-31T21:08:15.623635+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/6e/338280b0536f8b3b47eaa1c427a9cbd5355a48
meta: {size:830, lines:0, sha256:"3d5ef88ba0366c249554b6a72c6fcca8ddf8ac227a3f221540801a76eaa702d6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6e/55ffed10d653aaed81471efaca80e3d35a9b8f
meta: {size:1466, lines:0, sha256:"7837672317a03ae0f14409541672ba8cfff4b6c99c16f06bcce22d2146e5b74a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6e/6d33db3e9d23b88aafcab50ebf597a78d28990
meta: {size:484, lines:0, sha256:"638b6be562a29db2627a3f2ad06d9920a193c4dd56db800ab65a3e9135d201c7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6e/70ed8c599bda588a61dd599ae4e72c6a8c3d1c
meta: {size:3312, lines:0, sha256:"3e8374f22c5d140fb7696c54e4e0af7847b61617f149f84a66b9bfb6a57e66e8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6e/82b2e98b746627fc42527388656f47b5e2c8d2
meta: {size:850, lines:0, sha256:"94faa53e15d38a6d989e288ba33576fbeea09f95fd0885900f0892b9acdc3b70", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6e/b2e42dacec969dfa96e2ab9acc428e3cbd1dd3
meta: {size:583, lines:0, sha256:"af3f56a960a223ef2ddfbc737e3e180bd3ed912628be5d4156f36ee21f9325c7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6e/d785822f962bd4fe88f6d22360a05e71de1302
meta: {size:115088, lines:0, sha256:"657d8505670c09996416dd5950d9e259c56bcd9363397dde08d552b8b4e9d5cf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/6e/f8b771ebe4695b2eccf6f6171479022d8ac6d7
meta: {size:154, lines:0, sha256:"18fb9f8bc481aa864a6c341a82760cf17b3425d45b44821801ebcb341407dff5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

