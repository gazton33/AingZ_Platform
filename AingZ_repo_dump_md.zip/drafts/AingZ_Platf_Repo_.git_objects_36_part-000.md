---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/36
part_index: 0
files_included: 11
size_bytes_sum: 22309
created_at: 2025-08-31T21:08:15.571796+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/36/14a6297a373da85d281b514330fc1784db4ac4
meta: {size:978, lines:0, sha256:"55f19db8ed1f4bed297acca9b3898dd2eb5fa49df0b0d6aaa24c4e4906f5c5ac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/36/1566093b20b43d0b4ed7df51e528607397c6e5
meta: {size:3650, lines:0, sha256:"f44bbd1d7e0318f55e57e0c6f0863ac9afae881144fa559d1968d1bc6fc3cda6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/36/229dbd0228cae218d1c2a05318d758d8073269
meta: {size:1399, lines:0, sha256:"afb186360fbab87d72f5718778d4397888f095a917ad8ce02d4dcc54ff405d08", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/36/33b05092b37b95de160c73caee44b4679b2cb7
meta: {size:140, lines:0, sha256:"e5a9ce6946096a95f3b556f05c60d4e397c021f3f2d95769e55af59a27e69703", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/36/48a80bb276a4edddd78bac0143713b9d618c85
meta: {size:844, lines:0, sha256:"94d5d25d18ab84c0775f99770f64cf634553693e36ebc2a93b7ace13ba82fb2b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/36/58c52e2bbbb4d464bdf69f3a77f6add0c81fbc
meta: {size:72, lines:0, sha256:"245153f92255ec2065387b5ed0a0d903126fbb8e1d3f2ef25a90f14864970f69", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/36/62946f0fa0a2b1c7f77bca922bf41e3e9acf48
meta: {size:2028, lines:0, sha256:"3a8a90a31bf4db5d3aa60cc36df348b953036b99b98b6864d851d6917651d437", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/36/768925ec346e39edfb5bb5ec69a584d6701557
meta: {size:1572, lines:0, sha256:"88e1bf5c96294f7c8695b6d567eadb1c888c547ae37836cbeb53b6e96494340e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/36/b5e9d45a28ff13b20776ce1aadfd67ab942743
meta: {size:10098, lines:0, sha256:"d8b9974b551a40d1f6ae8bbdd2dcc893e437a316863827cb3e25546b327edb63", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/36/ce715257f35c8bc3a463e7fb0a792c9f878219
meta: {size:838, lines:0, sha256:"06dc0441e96597f396eecfca7a3564aad91c2ce24ba6505a5d8e67c023217d13", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/36/f4ceed92e0df2e65bc425856c824a0b5bc563a
meta: {size:690, lines:0, sha256:"5aa583f2b05388a5c0d47ae489b43e714a939e43551577b7e7a8ffe75e6c6513", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

