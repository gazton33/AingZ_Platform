---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/55
part_index: 0
files_included: 3
size_bytes_sum: 1663
created_at: 2025-08-31T21:08:15.619975+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/55/e5df6bce2b7b54aac5e5edc3a234be24dbecbb
meta: {size:1322, lines:0, sha256:"ffda5c69177dc3ab64d9b913721a72c1caf65139217dd0e17573230282b5546f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/55/ee656db7e5811503813fa0bbcf1b40bd576abf
meta: {size:52, lines:0, sha256:"cdd9b872032102d56f250e867e699d8ee57f62e4b0032412c24ca6972e220fe0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/55/f0645d9c89160c6ecbe20cf09b31b79b4024a4
meta: {size:289, lines:0, sha256:"245e668311358ed3200c61be3e0ae148f141a0ad8639100387a7a0831867f29f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

