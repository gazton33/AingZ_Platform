---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/V5
part_index: 0
files_included: 9
size_bytes_sum: 31900
created_at: 2025-08-31T21:08:15.671176+00:00
integrity:
  sha256_concat: de761efe19131264f98d4eb92c8d5309b3df028e423247e7bcb3b041b345321b
---

## AingZ_Platf_Repo/V5/buckets_assets_entidades_baseline_v_1_locked_full.md
meta: {size:12366, lines:127, sha256:"e9549a87a472fc0ae0a792d659f515a026efc075421973c3dc5d50943dea43a5", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: core/doc/workbench/AINGZ\_V5\_Buckets\_Assets\_Entidades\_Baseline\_v1\_full.md code: BAMBL name: BucketsAssetsEntidadesBaselineV1 version: v1.0.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: locked referencias:

- source: core/doc/workbench/AINGZ\_V5\_Buckets\_Assets\_Entidades\_Map\_v1.md
- tree\_baseline: BL-2025-08-18-DirTree-v1.4.2 triggers: [TRG\_BASELINE\_LOCK] cambios:
- 2025-08-18: Congelado el mapa maestro real con crossref/wikilinks (snapshot completo). checks:
- Enlaces `[[DIR::<CODE>]]` válidos
- Tablas completas y consistentes
- Tipos normalizados {bucket|asset|entity}

---

# Baseline Lock — Buckets / Assets / Entidades v1.0.0

**Baseline-ID**: BL-2025-08-18-BucketsMap-v1.0.0\
**Árbol**: BL-2025-08-18-DirTree-v1.4.2\
**Origen**: `AINGZ_V5_Buckets_Assets_Entidades_Map_v1.md` (validado 2025-08-18)

> Estado congelado. Cambios futuros en *working copy* y nuevo lock.

---

## 1) Tabla maestra por nodo principal

| CODE  | Nodo (wikilink) | Tipo                   | Función operativa | Entradas                                  | Salidas               | R (owner) / A (aprob)     | Calidad/QMS                |                          |
| ----- | --------------- | ---------------------- | ----------------- | ----------------------------------------- | --------------------- | ------------------------- | -------------------------- | ------------------------ |
| ROOT  | [[DIR::ROOT     | AingZ\_Platform]]      | bucket            | Monorepo raíz. Política, CI/CD, paquetes. | Repos, normas         | Releases, docs            | R: Platform-Ops · A: QMS   | [[CHG::]] [[QMS::]]      |
| MAIN  | [[DIR::MAIN     | main]]                 | bucket            | Código y datos activos.                   | Issues, PRs           | Builds, artefactos        | R: Core Dev Lead · A: Arch | [[VALG::]] [[RULESET::]] |
| DB    | [[DIR::DB       | data\_base]]           | bucket            | Knowledge base de plataforma.             | Ingesta docs/datasets | Conocimiento versionado   | R: Data Stewards · A: Arch | [[VALD::]]               |
| CACT  | [[DIR::CACT     | core\_actv]]           | bucket            | Activos nucleares de operación.           | Specs, plantillas     | Guías, datasets           | R: Core Ops · A: QMS       | [[CHG::]]                |
| DOCS  | [[DIR::DOCS     | docs]]                 | asset             | Medios y documentación evidencia.         | AUD/IMG/VID/LIB       | Evidencia validación      | R: Tech Writers · A: QMS   | [[VALG::]]               |
| DATA  | [[DIR::DATA     | data]]                 | bucket            | Datos estructurados y metadatos.          | CSV/JSON/Parquet      | Tablas, catálogos         | R: Data Eng · A: Arch      | [[VALD::]]               |
| SEM   | [[DIR::SEM      | semantics]]            | entity            | Vocabulario controlado y reglas.          | Términos, reglas      | IDs, contratos            | R: Ontology Lead · A: Arch | [[RULESET::]]            |
| AILE  | [[DIR::AILE     | ai\_learn]]            | bucket            | Entrenamiento, evaluación y feedback IA.  | Datasets, prompts     | Evals, insights           | R: MLE · A: Arch           | [[VALG::]]               |
| DEVP  | [[DIR::DEVP     | develop]]              | bucket            | Config, setup, orquestación desacoplada.  | Config, specs         | Entornos y conectores     | R: DevOps · A: Arch        | [[QMS::]]                |
| OTPL  | [[DIR::OTPL     | out\_template]]        | asset             | Plantillas de salida estándar.            | Reqs, lineamientos    | Documentos estandarizados | R: QMS · A: Arch           | [[VALD::]]               |
| GUID  | [[DIR::GUID     | guides]]               | asset             | Guías operativas y playbooks humanos.     | Procedimientos        | SOPs                      | R: QMS · A: Arch           | [[QMS::]]                |
| WF    | [[DIR::WF       | wf\_playbooks]]        | asset             | Workflows ejecutables.                    | Inputs, triggers      | Runs, logs                | R: Platform-Ops · A: Arch  | [[VALG::]]               |
| KCTX  | [[DIR::KCTX     | kns\_ctx\_vivo]]       | asset             | Contexto vivo y snapshots.                | Snapshots             | Estados reproducibles     | R: Platform-Ops · A: QMS   | [[CHG::]]                |
| CDEV  | [[DIR::CDEV     | core\_dev]]            | bucket            | Desarrollo núcleo.                        | Issues, spikes        | Módulos core              | R: Core Dev Lead · A: Arch | [[VALG::]]               |
| CARC  | [[DIR::CARC     | core\_arch\_platform]] | bucket            | Arquitectura de plataforma.               | ADRs, blueprints      | Artefactos de arq         | R: Architect · A: CTO      | [[ADR::]]                |
| LOG   | [[DIR::LOG      | log]]                  | bucket            | Registros de cambios y validaciones.      | Commits, runs         | CHG, VALG                 | R: QMS · A: Arch           | [[QMS::]]                |
| GIT   | [[DIR::GIT      | .github]]              | asset             | CI/CD y automatizaciones.                 | Workflows             | Checks, deployments       | R: DevOps · A: Arch        | [[QMS::]]                |
| PKG   | [[DIR::PKG      | packages]]             | bucket            | Paquetes y módulos compartidos.           | Código                | Librerías                 | R: Core Dev · A: Arch      | [[VALG::]]               |
| RULE  | [[DIR::RULE     | ruleset]]              | entity            | Políticas y reglas del repo.              | Normas                | Enforcement               | R: QMS · A: Arch           | [[RULESET::]]            |
| SCRIP | [[DIR::SCRIP    | scripts]]              | asset             | Utilidades de mantenimiento.              | Tareas                | Scripts ejecutables       | R: DevOps · A: Arch        | [[VALG::]]               |

---

## 2) Dominios — Semantics (SEM)

| CODE | Nodo        | Tipo              | Función | Entradas                                   | Salidas       | Crossref          |                   |
| ---- | ----------- | ----------------- | ------- | ------------------------------------------ | ------------- | ----------------- | ----------------- |
| GLOS | [[DIR::GLOS | glossary]]        | entity  | Definir términos y definiciones canónicas. | PRs, términos | IDs, definiciones | [[GLOS::MAIN]]    |
| DICT | [[DIR::DICT | dicts]]           | entity  | Diccionarios operativos de términos.       | CSV/MD        | Diccionarios      | [[RULESET::DICT]] |
| CDCT | [[DIR::CDCT | code\_dict]]      | entity  | Mapeos de código a significado/acción.     | Matrices      | Code→Sem          | [[TPL::CODEMAP]]  |
| TDCT | [[DIR::TDCT | trigger\_dict]]   | entity  | Catálogo de triggers y contratos.          | Triggers      | Firmas y rutas    | [[WF::INDEX]]     |
| ADCT | [[DIR::ADCT | app\_dict]]       | entity  | Alias y metadatos de aplicaciones.         | Apps          | Aliases           | [[RULESET::APPS]] |
| PDCT | [[DIR::PDCT | prompt\_dict]]    | entity  | Prompts estandarizados y roles.            | Prompts       | Catálogo          | [[TPL::PROMPTS]]  |
| INGP | [[DIR::INGP | ingest\_prompts]] | asset   | Prompts para ingesta y parsing.            | Docs          | Extractos         | [[WF::INGEST]]    |
| VOC  | [[DIR::VOC  | vocabulary]]      | entity  | Vocabulario controlado y sinónimos.        | Términos      | Lexicón           | [[GLOS::VOC]]     |
| RSET | [[DIR::RSET | ruleset]]         | entity  | Reglas de negocio/técnicas.                | Normas        | Reglas            | [[RULESET::MAIN]] |

---

## 3) Dominios — AI Learn (AILE)

| CODE  | Nodo         | Tipo           | Función | Entradas                                | Salidas     | Crossref         |                   |
| ----- | ------------ | -------------- | ------- | --------------------------------------- | ----------- | ---------------- | ----------------- |
| LEARN | [[DIR::LEARN | learning]]     | asset   | Currícula y objetivos de entrenamiento. | Datasets    | Plan de training | [[WF::TRAIN]]     |
| EVAL  | [[DIR::EVAL  | evaluation]]   | asset   | Evals, métricas y suites.               | Suites      | Reportes         | [[VALG::EVALS]]   |
| INSI  | [[DIR::INSI  | insights]]     | asset   | Hallazgos y análisis.                   | Logs, evals | Insights         | [[CHG::INSIGHTS]] |
| FTUN  | [[DIR::FTUN  | fine\_tuning]] | asset   | Ajuste fino de modelos.                 | Datasets    | Modelos          | [[WF::FT]]        |
| FSHT  | [[DIR::FSHT  | few\_shot]]    | asset   | Ejemplos canónicos.                     | Casos       | Ejemplos         | [[TPL::FS]]       |
| RELV  | [[DIR::RELV  | relevance]]    | asset   | Ranking y recall.                       | Queries     | Scores           | [[WF::RAG]]       |
| TRNG  | [[DIR::TRNG  | training]]     | asset   | Sesiones de entrenamiento.              | Config      | Modelos          | [[WF::TRAIN]]     |
| FDBK  | [[DIR::FDBK  | feedback]]     | asset   | Retroalimentación y bucles.             | Feedback    | Cambios plan     | [[WF::FB]]        |

---

## 4) Dominios — Out Templates (OTPL)

| CODE  | Nodo         | Tipo             | Función | Entradas                      | Salidas      | Crossref   |                  |
| ----- | ------------ | ---------------- | ------- | ----------------------------- | ------------ | ---------- | ---------------- |
| MTX   | [[DIR::MTX   | mtx]]            | asset   | Matrices comparativas.        | Criterios    | Scores     | [[TPL::MTX]]     |
| MATR  | [[DIR::MATR  | matrix]]         | asset   | Scoring reproducible.         | Pesos        | Puntajes   | [[TPL::MTX]]     |
| TBLS  | [[DIR::TBLS  | table]]          | asset   | Tablas estándar.              | Datos        | Tablas     | [[TPL::TABLE]]   |
| RCSH  | [[DIR::RCSH  | record\_sheet]]  | asset   | Planillas registrables.       | Datos        | Planillas  | [[TPL::RCSH]]    |
| MAPP  | [[DIR::MAPP  | mapping]]        | asset   | Mapeos de origen-destino.     | Campos       | Mapas      | [[TPL::MAP]]     |
| RELN  | [[DIR::RELN  | relation]]       | asset   | Relaciones entre entidades.   | Entidades    | Relaciones | [[TPL::REL]]     |
| VALD  | [[DIR::VALD  | validation]]     | asset   | Validaciones y checks.        | Reglas       | Logs       | [[QMS::VAL]]     |
| COMP  | [[DIR::COMP  | comparison]]     | asset   | Comparativas de alternativas. | Alternativas | Reportes   | [[TPL::COMP]]    |
| OTPD  | [[DIR::OTPD  | docs]]           | asset   | Documentos de salida.         | Reqs         | Docs       | [[TPL::DOC]]     |
| WSPC  | [[DIR::WSPC  | workspaces]]     | asset   | Espacios de trabajo.          | Config       | Entornos   | [[RULESET::ENV]] |
| PARCH | [[DIR::PARCH | platform\_arch]] | asset   | Artefactos de arquitectura.   | ADR, BP      | Blueprints | [[ADR::0001]]    |
| ATOOL | [[DIR::ATOOL | ai\_tools]]      | asset   | Herramientas IA empaquetadas. | Specs        | Tools      | [[WF::TOOLS]]    |

---

## 5) Dominios — Guides (GUID)

| CODE | Nodo        | Tipo               | Función | Entradas                 | Salidas | Crossref   |                |
| ---- | ----------- | ------------------ | ------- | ------------------------ | ------- | ---------- | -------------- |
| PLIN | [[DIR::PLIN | planin]]           | asset   | Planeamiento y gobierno. | Reqs    | Planes     | [[TPL::PLAN]]  |
| MPLN | [[DIR::MPLN | mpln]]             | asset   | Master plan.             | Insumos | MPlan      | [[ADR::0001]]  |
| BCRT | [[DIR::BCRT | brainstorm\_crtv]] | asset   | Ideación estructurada.   | Ideas   | Backlog    | [[TPL::BRAIN]] |
| RCTL | [[DIR::RCTL | run\_control]]     | asset   | Control de ejecución/QA. | Reglas  | Checks     | [[QMS::RUN]]   |
| PIPE | [[DIR::PIPE | pipeline]]         | asset   | Flujos/ETL.              | Fuentes | Artefactos | [[WF::PIPE]]   |

---

## OutputTemplate

```yaml
output_example:
  status: BASELINE_LOCKED
  baseline_id: BL-2025-08-18-BucketsMap-v1.0.0
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - files_frozen: [core/doc/workbench/AINGZ_V5_Buckets_Assets_Entidades_Baseline_v1_full.md]
  log:
    - step1: qa_pass
    - step2: checkpoint
    - step3: freeze
```

```

## AingZ_Platf_Repo/V5/buckets_assets_entidades_template_baseline_v_1.md
meta: {size:2814, lines:87, sha256:"42d9ea89bd35e019d135dcc5f3d914e3767ce004fc1ba1022be6fc437ed8d9a1", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: templates/\_baselines/buckets/Buckets\_Assets\_Entidades\_Template\_Baseline\_v1\_1\_locked.md code: BATBL name: BucketsAssetsEntidadesTemplateBaselineV1\_1 version: v1.1.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: locked referencias: [BATPL, BAT11, DTT11, BL-2025-08-18-DirTree-v1.4.2, PCTRL] triggers: [TRG\_BASELINE\_LOCK, TRG\_NEW\_BUCKETS\_MAP] cambios:

- 2025-08-18: Congelada la plantilla con cobertura, router y catálogo de roles. checks:
- coverage\_pct == 100
- `file_links_detected == 0`
- tipos ∈ {bucket, asset, entity}

---

# Template — Buckets / Assets / Entidades (Baseline v1.1 bloqueado)

**Objetivo**: mapear 100% de `tree_export.codes` a funciones operativas, entradas/salidas y R/A, sin enlazar archivos.

**Notas**: usar sólo `DIR::` en wikilinks; roles desde catálogo; crossref a `GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::`.

## Cobertura del Dir Tree

```yaml
coverage:
  source: tree_export.codes   # exportado por DirTree
  required: 100
```

## Catálogo de roles R/A

```yaml
roles_catalog:
  architect: Arch
  core_dev_lead: Core Dev Lead
  devops: DevOps
  qms: QMS
  platform_ops: Platform-Ops
  ontology_lead: Ontology Lead
```

## 1) Tabla maestra (rellenar)

| CODE | Nodo (wikilink) | Tipo | Función operativa | Entradas | Salidas | R (owner) / A (aprob) | Calidad/QMS |   |                                                     |           |
| ---- | --------------- | ---- | ----------------- | -------- | ------- | --------------------- | ----------- | - | --------------------------------------------------- | --------- |
|      | [[DIR::         | ]]   | \<bucket          | asset    | entity> | \<función>            |             |   | R: \<roles\_catalog.key> · A: \<roles\_catalog.key> | [[QMS::]] |

## 2) RULESET — Router declarativo (plantilla)

```yaml
ruleset_router:
  targets:
    platform: [[DIR::RULE]]
    app:      [[DIR::RULE]]
    api:      [[DIR::RULE]]
  routes: []
```

## 3) PIPE — Registro de orquestación (plantilla)

| PIPE\_CODE | Nodo DIR      | Propósito    | Triggers (WF::) | Inputs (DIR::) | Outputs (DIR::) | R/A       |
| ---------- | ------------- | ------------ | --------------- | -------------- | --------------- | --------- |
| P01        | [[DIR::PIPE]] | \<propósito> | [[WF::]]        | [[DIR::]]      | [[DIR::]]       | R:  · A:  |

## Reglas

1. Sólo `DIR::<CODE>` en enlaces.
2. `coverage_pct` debe ser 100.
3. R/A desde `roles_catalog`.

## Checklist

-

## OutputTemplate

```yaml
output_example:
  status: BUCKETS_TEMPLATE_BASELINE_LOCKED
  created_at: 2025-08-18T00:00:00-03:00
  params:
    - coverage_required: 100
  result:
    - sections: [master, ruleset_router, pipe_registry]
  log:
    - step1: author
    - step2: xref_wire
    - step3: validate
    - step4: freeze
```

```

## AingZ_Platf_Repo/V5/context_package_new_thread_v_1.md
meta: {size:3463, lines:97, sha256:"2fb8baa5e6b64539b7e4ab9c62189d7d99646a4dae4f5300cd5e7512e9397b1a", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
file: core/doc/workbench/AINGZ_V5_Context_Package_NewThread_v1.md
code: CTXPKG
name: ContextPackageNewThreadV1
version: v1.0.0
date: 2025-08-18
owner: AingZ_Platform · RwB
status: handoff
referencias:
  - ARBBL (DirTreeV14BaselineLocked)
  - BAMBL (BucketsAssetsEntidadesBaselineV1)
  - GBL (GlossaryBaselineV1)
  - RBL (RulesetBaselineV1)
  - RMBL2 (README_Main_BaselineV1)
  - DTTBL (DirTreeTemplateBaselineV1_1)
  - BATBL (BucketsAssetsEntidadesTemplateBaselineV1_1)
  - GTBL (GlossaryTemplateBaselineV1_1)
  - RSTBL (RulesetTemplateBaselineV1_1)
  - RMBL (README_Main_Template_BaselineV1)
  - RUTPL (README_Universal_TemplateV1)
  - PCTRL (PlatformControlPrinciplesV1)
triggers: [TRG_CONTEXT_PACKAGE]
cambios:
  - 2025-08-18: Paquete de contexto para continuar en hilo nuevo.
checks:
  - Sin enlaces a archivos en el cuerpo
  - Sólo namespaces aprobados cuando se usen wikilinks
---

# Context Package — Nuevo hilo

**Objetivo**: transportar el estado mínimo completo para reanudar trabajo en un hilo nuevo y mantener coherencia de referencias.

## 0) Resumen
- **Cadena router**: README → RULESET → PIPE (ver PCTRL).
- **Política**: anti‑archivo activa; sólo `DIR::, GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::`.
- **Fuente de verdad de códigos**: DirTree baseline (ARBBL). Cobertura en Buckets baseline (BAMBL).

## 1) Artefactos congelados (baselines reales)
| Alias | Artefacto | Código | Versión | Estado |
|---|---|---|---|---|
| 1 | Árbol de Directorios | ARBBL | v1.4.2 | locked |
| 2 | Buckets/Assets/Entidades | BAMBL | v1.0.0 | locked |
| 3 | Glosario | GBL | v1.0.0 | locked |
| 4 | Ruleset | RBL | v1.0.0 | locked |
| 5 | README Main | RMBL2 | v1.0.0 | locked |

## 2) Plantillas baseline (bloqueadas)
| Alias | Plantilla | Código | Versión | Estado |
|---|---|---|---|---|
| A | DirTree Template | DTTBL | v1.1.0 | locked |
| B | Buckets/Assets Template | BATBL | v1.1.0 | locked |
| C | Glossary Template | GTBL | v1.1.0 | locked |
| D | Ruleset Template | RSTBL | v1.1.0 | locked |
| E | README Main Template | RMBL | v1.0.0 | locked |

> Nota: README Universal Template (RUTPL) listo para replicación por carpeta.

## 3) Namespaces
```yaml
namespaces: { dir: "DIR::", glos: "GLOS::", ruleset: "RULESET::", wf: "WF::", tpl: "TPL::", qms: "QMS::", chg: "CHG::" }
```

## 4) Contratos clave
- `ARBBL.tree_export.codes` define el universo de `DIR::<CODE>`.
- `BATBL.coverage.required = 100` obliga mapeo total en BAMBL.
- `RSTBL.ruleset_router` centraliza derivación a [[DIR::RULE]].
- `RMBL` asegura que README delega y no tiene pasos operativos.

## 5) Próximos pasos sugeridos al reanudar
1. Verificar **coverage** Buckets vs DirTree = 100%.
2. Replicar **README Universal** (RUTPL) en buckets críticos.
3. Completar rutas en **Ruleset Real** y registrar ADR si impacta.
4. Completar **Pipelines** y triggers `WF::` con entradas/salidas `DIR::`.
5. Ejecutar **Checklist** en cada baseline y registrar `CHG` si aplica.

## 6) Indicadores
- Broken links = 0; coverage = 100; tiempo de lock ≤ 1 día hábil.

## 7) Cómo reanudar
- Abrir hilo nuevo e iniciar con el **Seed Prompt** de `SEED1`.

## OutputTemplate
```yaml
output_example:
  status: CONTEXT_PACKAGE_READY
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - baselines: [ARBBL, BAMBL, GBL, RBL, RMBL2]
    - templates: [DTTBL, BATBL, GTBL, RSTBL, RMBL]
    - seed: SEED1
  log:
    - step1: author
    - step2: consolidate
    - step3: validate
```

```

## AingZ_Platf_Repo/V5/dir_tree_template_baseline_v_1.md
meta: {size:3383, lines:88, sha256:"fc6290a92b8909a8de15249372c25028f004da95e0cbe655dd1511c57c82e137", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: templates/\_baselines/dir\_tree/DirTree\_Template\_Baseline\_v1\_1\_locked.md code: DTTBL name: DirTreeTemplateBaselineV1\_1 version: v1.1.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: locked referencias: [DTTPL, DTT11, BL-2025-08-18-DirTree-v1.4.2, PCTRL] triggers: [TRG\_BASELINE\_LOCK, TRG\_NEW\_TREE] cambios:

- 2025-08-18: Congelada la plantilla de árbol enlazada (wikilinks + export cobertura). checks:
- ASCII tree correcto y columnas 52/54/60
- `CODE` ≤5, únicos
- `no_file_refs: true`
- Índice de códigos completo y sin duplicados

---

# Template — Árbol de Directorios (Baseline v1.1 bloqueado)

**Objetivo**: proveer estructura mínima y estable para definir jerarquía de buckets con códigos `DIR::<CODE>`, sin enlazar archivos.

**Notas**: mantener independencia tecnológica; usar verbos funcionales; derivar cobertura a Buckets.

## Namespaces y políticas

```yaml
namespaces: { dir: "DIR::", glos: "GLOS::", ruleset: "RULESET::", wf: "WF::", tpl: "TPL::", qms: "QMS::", chg: "CHG::" }
reserved_codes: [ROOT, MAIN, RULE, PIPE]
policies: { no_file_refs: true }
```

## Árbol (plantilla)

```text
<RepositoryName>                                     [ROOT]  — <breve descripción raíz>
├── <module_or_area>                                 [M001]  — <breve descripción>
│   ├── <subarea_a>                                   [A001]  — <breve>
│   │   ├── <sub_a1>                                  [A1]    — <breve>
│   │   └── <sub_a2>                                  [A2]    — <breve>
│   └── <subarea_b>                                   [B001]  — <breve>
├── <module_or_area_2>                               [M002]  — <breve>
└── <ops_or_common>                                  [OPS]   — <scripts/ci/cd/etc>
```

> Alineación: nombre→col 52 · `[CODE]`→col 54 · descripción→col 60.

## Índice de códigos

| CODE | Ruta base relativa                 | Función breve        |
| ---- | ---------------------------------- | -------------------- |
| ROOT | /                                  | Raíz del repositorio |
| M001 | /\<module\_or\_area>               | \<función>           |
| A001 | /\<module\_or\_area>/\<subarea\_a> | \<función>           |
| A1   | ...                                | \<función>           |
| A2   | ...                                | \<función>           |
| B001 | /\<module\_or\_area>/\<subarea\_b> | \<función>           |
| M002 | /\<module\_or\_area\_2>            | \<función>           |
| OPS  | /\<ops\_or\_common>                | \<función>           |

## Wikilinks y crossref

- Página por nodo: `DIR::<CODE>`.
- Wikilink: `[[DIR::<CODE>|Nombre]]`.
- Crossref permitidos: `GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::`.

## Export para cobertura aguas abajo

```yaml
tree_export:
  codes: [ROOT, MAIN, RULE, PIPE, DB, CACT, DOCS, DATA, SEM, AILE, DEVP, OTPL, GUID, WF, KCTX, CDEV, CARC, LOG, GIT, PKG, SCRIP]
  contract: "Cada CODE debe existir en Buckets/Assets/Entidades"
```

## Checklist

-

## OutputTemplate

```yaml
output_example:
  status: TREE_TEMPLATE_BASELINE_LOCKED
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - export_codes: 20
    - codes_policy: { max_len: 5, unique: true }
  log:
    - step1: author
    - step2: align
    - step3: validate
    - step4: freeze
```

```

## AingZ_Platf_Repo/V5/glossary_template_baseline_v_1.md
meta: {size:1513, lines:54, sha256:"ebdcf2c514fa8f739fd9c8191bdfa7d1cd6393c5fe2f15d458d173122b2d0fa2", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: templates/\_baselines/glossary/Glossary\_Template\_Baseline\_v1\_1\_locked.md code: GTBL name: GlossaryTemplateBaselineV1\_1 version: v1.1.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: locked referencias: [GTPL11, DTT11, PCTRL] triggers: [TRG\_BASELINE\_LOCK, TRG\_GLOSSARY] cambios:

- 2025-08-18: Congelada la plantilla enlazada del glosario. checks:
- IDs únicos `GLOS::<ID>` (3–8 alfanum mayúscula)
- Refs sólo `DIR::`
- `no_file_refs: true`

---

# Glosario — Plantilla (Baseline v1.1 bloqueado)

**Objetivo**: registrar definiciones canónicas y sus referencias a buckets.

**Notas**: definiciones ≤ 25 palabras; IDs estables; cambios con impacto → ADR.

## Namespaces y políticas

```yaml
namespaces: { dir: "DIR::", glos: "GLOS::" }
policies: { no_file_refs: true }
```

## Tabla (plantilla)

| ID (GLOS::) | Término    | Definición breve      | Refs (DIR::)         | Sinónimos | Tags      |
| ----------- | ---------- | --------------------- | -------------------- | --------- | --------- |
| GLOS::      | \<término> | \<definición concisa> | [[DIR::]], [[DIR::]] |           | #glosario |

## Reglas mínimas

1. `ID` estable y único.
2. Refs sólo a `DIR::`.
3. Sin anclas ni rutas.

## Checklist

-

## OutputTemplate

```yaml
output_example:
  status: GLOSSARY_TEMPLATE_BASELINE_LOCKED
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - constraints: { id_len: 3-8, refs: DIR:: }
  log:
    - step1: author
    - step2: validate
    - step3: freeze
```

```

## AingZ_Platf_Repo/V5/readme_main_baseline_v_1_locked.md
meta: {size:1615, lines:57, sha256:"f562a41f1e6589fba2aa98bb2f33048b50c9382d92a1b4c8f59d4773d9eddece", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: core/doc/workbench/AINGZ\_V5\_README\_Main\_Baseline\_v1\_locked.md code: RMBL2 name: README\_Main\_BaselineV1 version: v1.0.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: locked referencias:

- RMREAL (README\_Main\_Real\_V1)
- RMBL (README\_Main\_Template\_Baseline\_v1\_Locked)
- DTTBL (DirTree\_Template\_Baseline\_v1.1\_Locked)
- RSTBL (Ruleset\_Template\_Baseline\_v1.1\_Locked)
- PIPLT (Pipelines\_Template\_v1)
- PCTRL (PlatformControlPrinciplesV1) triggers: [TRG\_BASELINE\_LOCK, TRG\_README\_ENTRY] cambios:
- 2025-08-18: Baseline real del README principal bloqueado según template. checks:
- Sin instrucciones operativas
- Enlaces sólo a `DIR::`

---

# Baseline Lock — README Main v1.0.0

**Baseline-ID**: BL-2025-08-18-README-v1.0.0\
**Árbol**: BL-2025-08-18-DirTree-v1.4.2\
**Snapshot**: `AINGZ_V5_README_Main_Real_v1.md` validado 2025-08-18

> Estado congelado. Ediciones futuras en *working copy* del README y nuevo lock.

## Navegación (snapshot)

- Reglas y políticas → [[DIR::RULE|Ruleset]]
- Orquestación y ejecución → [[DIR::PIPE|Pipelines]]
- Árbol del monorepo → [[DIR::ROOT|Monorepo]]

## Garantías

```yaml
no_instructions_here: true
links_only_to_buckets: true
router_chain: [README->RULESET->PIPE]
```

## Checklist

-

## OutputTemplate

```yaml
output_example:
  status: README_BASELINE_LOCKED
  baseline_id: BL-2025-08-18-README-v1.0.0
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - files_frozen: [core/doc/workbench/AINGZ_V5_README_Main_Baseline_v1_locked.md]
  log:
    - step1: qa_pass
    - step2: checkpoint
    - step3: freeze
```

```

## AingZ_Platf_Repo/V5/readme_main_template_baseline_v_1_locked.md
meta: {size:1225, lines:48, sha256:"06947ab38e43ed45c3323713da7ee3d3943cd58123089b7aa78089f29a14fe64", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: templates/\_baselines/readme/README\_Main\_Template\_Baseline\_v1\_locked.md code: RMBL name: README\_Main\_Template\_BaselineV1 version: v1.0.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: locked referencias: [RMTPL, DTT11, RST11, PIPLT, PCTRL] triggers: [TRG\_BASELINE\_LOCK, TRG\_README\_ENTRY] cambios:

- 2025-08-18: Congelada la plantilla de README de entrada. checks:
- Sin instrucciones operativas
- Enlaces sólo a `DIR::`

---

# README — Entrypoint (Template Baseline v1 bloqueado)

**Objetivo**: actuar como landing y derivar a Ruleset y Pipelines.

**Notas**: documento minimalista; no describe pasos; garantiza cadena router.

## Navegación

- Reglas y políticas → [[DIR::RULE|Ruleset]]
- Orquestación y ejecución → [[DIR::PIPE|Pipelines]]
- Árbol del monorepo → [[DIR::ROOT|Monorepo]]

## Garantías

```yaml
no_instructions_here: true
links_only_to_buckets: true
router_chain: [README->RULESET->PIPE]
```

## Checklist

-

## OutputTemplate

```yaml
output_example:
  status: README_TEMPLATE_BASELINE_LOCKED
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - delegates_to: [DIR::RULE, DIR::PIPE]
  log:
    - step1: author
    - step2: validate
    - step3: freeze
```

```

## AingZ_Platf_Repo/V5/readme_universal_template_v_1.md
meta: {size:2957, lines:101, sha256:"c4c0409d9494f37cd9aa11246cc38474aae9c21b79f76c049e01ff8589e23719", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: templates/readme/README\_Universal\_Template\_v1.md code: RUTPL name: README\_Universal\_TemplateV1 version: v1.0.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: template referencias: [DTT11, BAT11, GTPL11, RST11, PIPLT, PCTRL, RMBL] triggers: [TRG\_README\_UNIVERSAL] cambios:

- 2025-08-18: Primera versión del README universal por carpeta/bucket. checks:
- Sin rutas a archivos ni anclas (#...)
- Sólo namespaces aprobados
- `links.parent` y `links.children` coherentes

---

# README Universal de Carpeta/Bucket — Plantilla

**Uso**: colocar una copia en cada carpeta del árbol. Completar metadatos, enlaces a buckets, funciones, interfaces y control de calidad. No incluir pasos operativos específicos ni rutas a archivos.

## 1) Identidad del nodo

```yaml
---
title: <Nombre del bucket>
code: <DIR_CODE>               # p.ej. ROOT, DATA, SEM
path: <ruta_relativa_logica>   # p.ej. /main/data_base/semantics
type: dir_node
level: <0..N>
aliases: [<Nombre corto>]
tags: [dir, node, baseline]
links:
  parent: DIR::<PADRE>
  children: [DIR::<H1>, DIR::<H2>]
  related: []
policies:
  no_file_refs: true
---
```

## 2) Propósito y alcance

Breve descripción (≤ 30 palabras) de la función del bucket y sus límites.

## 3) Funciones operativas

- Lista concisa de capacidades del bucket.
- Evitar detalles de implementación.

## 4) Interfaces (contratos)

- **Entradas (DIR::)**: [[DIR::]], [[DIR::]]
- **Salidas (DIR::)**: [[DIR::]], [[DIR::]]
- **Triggers (WF::)**: [[WF::]]
- **Reglas aplicables (RULESET::)**: [[RULESET::]]
- **Términos clave (GLOS::)**: [[GLOS::]]

## 5) Pipelines asociados

| PIPE\_CODE | Trigger (WF::) | Propósito | Entradas (DIR::) | Salidas (DIR::) | R/A       |
| ---------- | -------------- | --------- | ---------------- | --------------- | --------- |
| Pxx        | [[WF::]]       |           | [[DIR::]]        | [[DIR::]]       | R:  · A:  |

## 6) Métricas SLO/SLI

| Métrica    | Objetivo | Cómo se mide | Fuente       |     |         |
| ---------- | -------- | ------------ | ------------ | --- | ------- |
| \<métrica> |          | \<método>    | [[DIR::\<LOG | QMS | DATA>]] |

## 7) Gobierno y calidad (QMS)

- Validaciones: `VALD/VALG` requeridas
- Cambios: registrar en [[CHG::]]
- Excepciones aprobadas: referencia QMS

## 8) Notas y riesgos

- Riesgos conocidos y mitigaciones propuestas.

## 9) Wikilinks y crossref — reglas

- Sólo `DIR::, GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::`.
- Prohibido enlazar archivos (`*.md`, `*.py`, `*.yml`) o anclas.
- Mantener `parent`↔`children` sin ciclos.

## 10) Checklist local

-

## OutputTemplate

```yaml
output_example:
  status: README_UNIVERSAL_READY
  created_at: 2025-08-18T00:00:00-03:00
  params:
    - namespaces: [DIR::, GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::]
  result:
    - node_defined: true
    - links_consistent: true
  log:
    - step1: author
    - step2: link_dirs
    - step3: validate
```

```

## AingZ_Platf_Repo/V5/seed_prompt_new_thread_v_1.md
meta: {size:2564, lines:80, sha256:"ddbd56ea96e47fdf847e87ba57d796690356ae068f2292d2d3acd8979935a4c6", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: core/doc/workbench/AINGZ\_V5\_Seed\_Prompt\_NewThread\_v1.md code: SEED1 name: SeedPromptNewThreadV1 version: v1.0.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: ready referencias:

- CTXPKG (ContextPackageNewThreadV1)
- ARBBL, BAMBL, GBL, RBL, RMBL2
- DTTBL, BATBL, GTBL, RSTBL, RMBL, RUTPL
- PCTRL triggers: [TRG\_SEED\_PROMPT] cambios:
- 2025-08-18: Seed prompt para reanudar trabajo en hilo nuevo. checks:
- Español técnico
- Anti‑archivo
- Enlaces sólo a buckets cuando aplique

---

# Seed Prompt — Copiar y pegar al iniciar el hilo nuevo

```yaml
role: Arquitecto/a de Plataformas Senior
scope: Continuación proyecto AingZ_Platform_V5.0
style: Español técnico, conciso, sin enlaces a archivos ni anclas
policies:
  anti_file_refs: true
  wikilinks_namespaces: [DIR::, GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::]
router_chain: [README->RULESET->PIPE]
truth_sources:
  baselines_real: [ARBBL, BAMBL, GBL, RBL, RMBL2]
  templates_locked: [DTTBL, BATBL, GTBL, RSTBL, RMBL]
  readme_universal: RUTPL
control_doc: PCTRL
kickoff:
  arch_alias: AINGZ_V5
  work_type: V0
  objective: Consolidar cobertura 100% Buckets vs DirTree y completar rutas Ruleset y Pipelines
  users: devs plataforma y QA/QMS
  horizon: 6-12m
  constraints: [no_file_refs, wikilinks_only, router_chain_enforced]
  weights:
    evolvability: 0.28
    reliability: 0.20
    performance: 0.20
    simplicity: 0.12
    cost: 0.10
    auditability: 0.10
tasks_order:
  - Validar coverage 100% entre ARBBL.codes y BAMBL.mapa
  - Replicar README universal (RUTPL) en buckets clave
  - Completar ruleset_router en RBL/RREAL y registrar ADR si cambia alcance
  - Completar registro de Pipelines (PIPLT) con triggers WF:: y E/S DIR::
  - Ejecutar checklists en todos los baselines y registrar CHG
acceptance:
  coverage_pct: 100
  broken_links: 0
  router_integrity: true
outputs_expected:
  - Informe de cobertura
  - Tabla de rutas activas Ruleset
  - Registro de Pipelines actualizado
  - Lista de CHG/ADR generados
```

## Indicaciones para la primera respuesta del nuevo hilo

- Confirmar presencia en canvas de códigos: ARBBL, BAMBL, GBL, RBL, RMBL2, DTTBL, BATBL, GTBL, RSTBL, RMBL, RUTPL, PCTRL.
- Proponer plan de verificación rápida y ejecutar validaciones estáticas de referencias.
- Si falta algo, crear *working copy* antes de modificar baselines.

## OutputTemplate

```yaml
output_example:
  status: SEED_PROMPT_READY
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - seed_block: included
  log:
    - step1: author
    - step2: finalize
```

```

