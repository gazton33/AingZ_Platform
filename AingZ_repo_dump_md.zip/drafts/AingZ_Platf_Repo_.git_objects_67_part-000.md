---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/67
part_index: 0
files_included: 9
size_bytes_sum: 9412
created_at: 2025-08-31T21:08:15.622840+00:00
integrity:
  sha256_concat: 4df6798f1bfa2a9c9ed227dd1f4b51e040f5a2850ba93d439f2b171d4ba4ad42
---

## AingZ_Platf_Repo/.git/objects/67/137370ab4b52ea9b54b98760a2d60202af3cfa
meta: {size:661, lines:0, sha256:"9f9e324bd4fc07ce3cf24b732475e6f97e14721afbb86f7867f4716606bf909d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/67/6135f30f544348d429d43ce4c896040d74ac10
meta: {size:135, lines:1, sha256:"6c5163b0c074628a3c7792a5ab403aabccd64a557415ae8059437d81e0b40ecb", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU04·`040031Q(*O/JMLÉMOÌ/IÍ-ÈI,I/7ÐËMaÐz]ñ´./'¸úW´ºTXÏY,:3Jsó04ÿä5±ø0! MC_¦)KTòÅ¹N,áv¥äÂìýÛðíóÅÒÈÍ=,æÂG,êrE
```

## AingZ_Platf_Repo/.git/objects/67/67a0f8cdfcb2430331c6a00a37f36f2c6357ff
meta: {size:1480, lines:0, sha256:"ea86c6296f73cb6a01fc952f3d5ce6fa7b5ede3a4ccec4b3fcfc7952f9261db6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/67/6f5a882168ab8e9b4239a0e85f50130e7eef94
meta: {size:694, lines:0, sha256:"63ac06728ef70cee048c33864287f1b0257f2268332e9968cdb7e3bb2927d526", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/67/7c06d54475d0fd91ea2fca6b6e8b8be2ed460b
meta: {size:574, lines:4, sha256:"3b4252e882783592ba8e939abf350fd947e9d84ffead40a01c182e59cd39edf2", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xMÛ@³ö)ñÆÉ?3$cÂdÉc@¦Ô*Ë[Ý¢»ígCäYås$Õlk¼ÉJ ©^õÞëTÆ£×É«.Ì>ÜÍîÖÓÙrµþøéóz¶üº^L¿¬Wãu2J&£Ûd2(2øûóÌ¶¨sR&©¥´G¥ÒX/uGPäÑz¬w¿z¥óûåûÅtÁa1Õxt'~§Çq§ÓíÂxðBÝSn13,xOÑmÅ±´¨°²òù%=YTÃTÐìÂ´-ûLzcãP0¡Q2Ãz¾§'GP=2ï"Ê¸½¥j~ç-Ü,(Î[ÓÞÔ`
é*ÀÌ8Vs °H¥a©«5"ðVæ9Yþt²ì(ü|b.£ÉÛ
B2ô.ôÍ©Ð[¨l M-JíxÏóàSöýÁM 7ÙOXLµ!KZHöa-òJõ±%ZdR|ÂT¿²'=08#ò+WV¿k[}!3ÂÚÓ<»Û(óè×¥VMÀþ_:Ë´nÕ mî%Üe)T¥ªímIìçû¦É9ÀS^/*
¥Vv/N}N¸©"è	ÔF%úðªßáÛïî/ì{ÝrÏÙ°ïÍ¯MÃyÎhõáýÕ^r ÍÀêV»¶\#,É¸¦l¦ÙªÌªFÊúdsjÖý'²
```

## AingZ_Platf_Repo/.git/objects/67/81b2804a28168e96ca2012ef7acfb99d86d2c1
meta: {size:4062, lines:0, sha256:"48d9c0de8c5876554da40ed5076904e9fb07f7edaed093dfa14a462229bae437", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/67/b155b5620210a54154f387902383a3f14b6e72
meta: {size:775, lines:0, sha256:"b6b9c764848ef475319b18b0d5265bc30a1ba30fcf32381d77a6abb2131edc03", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/67/b48a3cc08afa81afdf55977774d74255f978ff
meta: {size:180, lines:0, sha256:"362fab7fb1dba0c9d6f905c7861d950cc3ffc3ab063e1bd5be64317e32d98a2d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/67/cd48ad78c38e352f5596a09934890213b836da
meta: {size:851, lines:0, sha256:"7a2e4604ff75a32576faf4fbb887084b80a1bbfb7898f9c6e70d0d81d57caf27", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

