---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/19
part_index: 0
files_included: 8
size_bytes_sum: 4805
created_at: 2025-08-31T21:08:15.568431+00:00
integrity:
  sha256_concat: 58db32bc547516952f7a9a194074bb8bedf7c0621a035ef9368b952052bd361d
---

## AingZ_Platf_Repo/.git/objects/19/0256bb05a4f51ea1f9b26e038c96038474c1b0
meta: {size:51, lines:0, sha256:"04c7c12f1440511a68496767be8fd330c3d851b897573ec3e090703bd2b4e9cd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/19/2392f31854a959a2d7b64a71278b0ae0cbeeed
meta: {size:178, lines:0, sha256:"72e4c4702e31a3aa4b71ec83100458ba0f4993c68a055ba8c72fd80b58c8f4df", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/19/2dfdd07a62a8d59bbd3a290969c52ff89394c0
meta: {size:1741, lines:0, sha256:"eb8414e0be0dcb9875e16215b8443fd58626e64570ee531e37d4c30de1d780d8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/19/50a2de649b419584a32cea8876500e0eb201d0
meta: {size:572, lines:0, sha256:"373aad435612ad42e3e780f8eebd3a445482f378414dfa2a7fc5a5bd4069c743", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/19/8da1e5ce2d66b828c92734117953db47ef6d6d
meta: {size:442, lines:0, sha256:"9de0b438eb433ff206227569752b22fea261958f168ef11ce9083c7d399a23c8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/19/9ecf7853e1f9ddf7b1c41b7e9c4def8f4679aa
meta: {size:442, lines:0, sha256:"0a219278d21ef68f76c2c748f788047db570ab0a23140f95c87d654493927db9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/19/b54f47a169a330bc93dbaf881f7105a5fa5baf
meta: {size:953, lines:2, sha256:"2e330d8211fcdebd4808c07034b6618effed8efecf15b4475a7fcc88723fef70", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x]RPU_Cr¦$EÔ¹ð3¹îãF¼Æ4jz³·ûØÛØÛw¾}w§Jbz:4zÅ#Áe5åÕ 6ôÊ¬þÐd2§)ôÚmïsÿÝÏçó>?¾C¨1ró)^o64:ÈòaÕ<GÕ[WV-iíÕN¼ÑÉÿºçÆ	 ÇÌ;<JÔøo¾öl[¸§Ì_¶òóó®ýUR{çD!u9v("~½â­½ãÑÕÌÚ±+§6ôò§Ñ!Ä³<-R]d°)Z7æJ·O6EÎuíAc©ÜRA=[±ðSÊðÍð=Á×OÛ=Uä?dú)kÉ6+Õ·ùÄufôÓVûÂZîkÓøû·_kS¶Û¨.áÿªÐÅ/ö}soq¬tã6)Îg8à¢y`xA0êyúõ¹z@3Ä«s±TÐÑ+ûPølöÈJÖw$'ørirDçÞM,Xn"pËwÙþ[ìÃv_¥z`Cõl/7ÏíGzÕ+lêßùÈrr¥«µÜÛö«WRBÝÎèëcU{gdHú[ûuËÒUý}Óß|ûç¸[å(¸Zr*Î/çJ°¹X^`R¢ñ^¤ËÚÚÝ m^N}ÉònÊ3ï?Ú×C¹ Ú#%=2BÉ¸±¿ãØ¬ÝÛªS.5¥v&(¢³À¹ @¢Ñ]»}ó¥âéàéSÜÉßÇÌ!ÓÉÄ2Ò¬,ñyÝHÝèî}â!ôWëË»b#ý¿ER=ÆíOÄaÈñ²}¦ý´xfAíÍ¯OÏ|Ô¯)ÿÀf|G^íÏ1wzx]P$ì"TÊÊöEBæÚå¿<þÎëûJsX¥cÆ	A~Ð^ZÇ[7Ìõ®¼v.ch iÞßÛ><=BÍ=¶þy§Ë3Ü2yÄBÙ4Ïq+JÆ¸1_QzñÞuë|áÆÑSÇ*Ê´¹÷½ù%hÌ8ÕCP&W÷WÙÞ>×±YÝ^ÿÔ§3gF5¶YõÎ$ón"Q¡æ4ëÃ+E¥É]7O^kí
«å;£	¤æWüÓÓX0â° ç9ÃkJI8øì@ýõU4q¾·likÿÏ-þ4Ù¾"
```

## AingZ_Platf_Repo/.git/objects/19/bc3f404de93a4ce231816a3fd5e15bc54e7884
meta: {size:426, lines:0, sha256:"4f0b1c9efaf88a4b90966bae0f5f34b5af78ae6958734ee52a6a3c5a419aa07b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

