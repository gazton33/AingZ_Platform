---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ef
part_index: 0
files_included: 10
size_bytes_sum: 25668
created_at: 2025-08-31T21:08:15.651684+00:00
integrity:
  sha256_concat: 5e2703a3fa82bb259c7e67273b7ccd75869b4546c2ef4dd5ff8ab152754e3aae
---

## AingZ_Platf_Repo/.git/objects/ef/00e318258319d024eacbcb537ce1f5b6285bdb
meta: {size:20103, lines:0, sha256:"9740a3f61009cec9e36deee9656b90e6bdbc947a6c454da1bcb2a192619f29ec", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ef/28f5fced54154e47049bc257b8ea70e2befb07
meta: {size:1440, lines:0, sha256:"26169e97b61a84eb2964a20d88d41f2756c20aa8683748e7466e016a00aaddec", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ef/3445b4413b6b549c1996d2059b925f9329b9d7
meta: {size:47, lines:0, sha256:"6611aef5cfc4d6f7c2c024807f7935fae5920ad1a98fe5f895e7d29dde66b654", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ef/3dd2ccb92ba3d1d1d3964d9aed65a730995a91
meta: {size:80, lines:0, sha256:"8bf9a4ef33b6cef316a4dee954631a95c29698285ebda37f173527efbf9511e0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ef/8c42e012181d554636d3b869599bd554360cbe
meta: {size:116, lines:0, sha256:"9f930658c1ae231431f0265d75574f9e922091af69cab4b620f11efb79aa25d0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ef/95abfba465ff98e9a923b590f1f50d282f68fb
meta: {size:406, lines:2, sha256:"a7b288d2ad7ca9817e76cfeae82083049fb2bf9aabbf077bf66090a62dc4b377", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x}]oÓ0¹Î¯xUtr6$Ä¤VC ¸C\CrìÚÚ!¶;¤uÿc§äû|=ïñ±ÛÞ·¸ºzùÄÉ­ðÆºí'¼µ]÷IºònUCêû¯#ýHb¶Ù#£	Ó¨Ëe³ÓuU4îlÖ»WÞEr1¬0ÔUõÍ·Å¯YcªuÚäb½,STB¤a¦1GªáÊúîS|½Qs[·6SWÙî(*#4ìÆeuÌnûÁÞBz`p?+L ®ëÅÝ¶OmC{¾Q3Js`$îïëY©á;?*ý;ÈÃÉÙÎ¾¾D½ÈÀ÷L¨9ö{ÄxUò~ep8 fRkf,nG ÞáìËæüìQ	¦Ð¾6ç9|À­èO¸g3ÞH;¿ÿ(þM^ÿ%2õ±Ï²ñç8ó!Úy§Ä6²YêjÜ¬¹Y¿ÀÄÿèóÇ³²GydMT$?bÑâ9N5è'?Âó5:[ý
uà¸
```

## AingZ_Platf_Repo/.git/objects/ef/9aaa14dd5f1d35ddb08cf3eb28093e5deff3c7
meta: {size:853, lines:0, sha256:"9e86d9e8826900eda6f89e6a211b7395720a5dc8b2ff0b6eb73245123df80c58", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ef/c2edfc512606192efe0139e52f98ff6e080875
meta: {size:793, lines:0, sha256:"400ffaf29443178fa80081901e1153fc65337adcb59461f933c2625d3dad788e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ef/d213bbf7a26de9e99058493661cb56ccd0b8ab
meta: {size:1526, lines:0, sha256:"4222d46ce2d07895e105433bdce20e4a6f77b466e251b238e0deaa9031eb6ede", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ef/f5343c15c11c6bc6fd5d593658991f475a37c7
meta: {size:304, lines:0, sha256:"34144063f5192a6c253e73500d43af388832ce404fb244e98476c6b1da6897bd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

