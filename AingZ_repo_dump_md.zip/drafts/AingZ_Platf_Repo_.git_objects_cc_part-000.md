---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/cc
part_index: 0
files_included: 9
size_bytes_sum: 16932
created_at: 2025-08-31T21:08:15.648638+00:00
integrity:
  sha256_concat: f4069c18ec406331757d103d5879b4e2f5d76926134437e43ceb2099d22d07ed
---

## AingZ_Platf_Repo/.git/objects/cc/1e97c73c7a26335d2f0f308e9762ca5290f9dc
meta: {size:442, lines:0, sha256:"fa9b4910802d2032a685a156c278fea3378562c9c359123ad4b1dc728484a37b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cc/30fbca8cd391ea352bcbfc1f07e1e100e8c31e
meta: {size:4947, lines:0, sha256:"6fdd4c13c2b59bcc16784ec0f59318a2840fd551b76cd79861364bbcca5d1e9a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cc/311ed7e7c3a64eed8f82dbe28c2d74addf46ad
meta: {size:274, lines:0, sha256:"7edcfa76c0915f165fc2725b3c148ea666696711bf77717995362667e487f41e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cc/48cbe64b7e8a04408eb5ec34769217f311b921
meta: {size:322, lines:0, sha256:"239662fc13e98a854f879478e4375255c333f65d39d527309d12895abe114815", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cc/aeccc46b0e1492fdcf406467432ced498ac8ff
meta: {size:153, lines:3, sha256:"dfaffb030d71fcb46380d19bf830fbb3d175356561683a48b8ff245f6ab9f652", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎ[
Ã @Ñ~»
7ÐàøI ne4c±¥Õ7kèï7ÕR¶®-à­7í¦h<Hòll,4(³OdL²zs£kDA	Nf<[10%A	,§hrúZ^øìõpN?á]ÒZ¿Ò^KámR-OÇ&ÐwãQW½»ü¨fCË
```

## AingZ_Platf_Repo/.git/objects/cc/cef4e561e6f6c89d49c991e11db0baab95ec82
meta: {size:225, lines:0, sha256:"cd64dd66f521f24796c6645fc09da57b139b3b0aee82704b27f39ab92a11dde6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cc/d855fada27cf72427bf052117aebe78d6c0943
meta: {size:5141, lines:0, sha256:"7d4fe78f6c5398ac0ab14728d37e3d3f61a38e3a56940fad20182d8812bcb086", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cc/e3ad736689a4ad8df4ed0f8103cacaf9bf933f
meta: {size:5313, lines:0, sha256:"fcefda7b185690a07430877171342fca3719650dc042f38a63d25c2f8ce9fd99", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cc/ea82152d2a4baa9a05339aecb9871d5fbc19ca
meta: {size:115, lines:0, sha256:"c52f65d0bfd3a8f23705dd325a7d4d4c8cc5777435c2d1fdb55f3c746a95e715", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

