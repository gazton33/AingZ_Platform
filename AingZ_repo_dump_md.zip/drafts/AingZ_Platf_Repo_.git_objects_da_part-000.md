---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/da
part_index: 0
files_included: 8
size_bytes_sum: 9105
created_at: 2025-08-31T21:08:15.649669+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/da/43b02c2a37a082464f8ed9d8e416a699c119d1
meta: {size:289, lines:0, sha256:"729d0cdc30b6c409198ea1204b57b0118a8c3664b71b57ac03c0a8f32d337115", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/da/58fec643cd95c848e9b90a1e29910f7871f58f
meta: {size:1216, lines:0, sha256:"44e419bf7e4d6ec84358417ffa26f17310a136dba0a9c3647578c3ae7161477c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/da/5b6737722172254e946181489000fe506a0ba1
meta: {size:129, lines:0, sha256:"fd28b779b3e296a67592aaa0c00682a2efa1735d11f746050a38eedfd739c23f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/da/631a5cd1cc31cbfd0aad9dacbdd708b930e04d
meta: {size:5042, lines:0, sha256:"2b1f8a511ffe200f759c156e08c3f7f936ac7265e60ded7a79b8144ef0ae2f17", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/da/76fa7164b500014a90dc4c22ec6faeb0387de2
meta: {size:776, lines:0, sha256:"5d179b8943525fc8a7a7bf9529e8edef2f878af9c0c07b46ae1e3a91b4adb640", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/da/a14c738fb4f77f2a86845e22b5cf3716c1966b
meta: {size:681, lines:0, sha256:"55d8ff83d9c19e3c54c7b887259f7a719865d675f29ee7127c75104eb6b7571d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/da/e14409e277bef5dee12793526ec5f1c620845f
meta: {size:721, lines:0, sha256:"c0fa2f5608020633d614fc4223b65a255cb6ccec49c18a655398a7300cf557f0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/da/eaa58bf3ba5d5093ed8bc4b62ff8dd1a2d1164
meta: {size:251, lines:0, sha256:"b34400203a86a431976c6d5e180ab62e942849026a0d222c0387d2df215caf5c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

