---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/b3
part_index: 0
files_included: 1
size_bytes_sum: 4730511
created_at: 2025-08-31T21:08:15.163819+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/b3/308c0699360e0190769c98d4ce284a47bd6108
meta: {size:4730511, lines:0, sha256:"1c641bd7e7b28e0ea245bc038346d410301fdc70782ea3bb225e0056cffd8fa0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

