---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/3f
part_index: 0
files_included: 8
size_bytes_sum: 3613
created_at: 2025-08-31T21:08:15.572668+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/3f/163ec839af45f4df67b67ac6b2341d15c391f3
meta: {size:613, lines:0, sha256:"89c38ebad5440c5b04ab0a9a68bca45503705f83c917ad2f03a9b00920b82017", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3f/5c36e26aff3a1a77a09446a74250361362d1da
meta: {size:58, lines:0, sha256:"78de2bca0495a8004b15742a8b128b0d84e87a26daa0757bb91021d117ea0c90", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3f/5fb007dec06ca00ab8bcd3cf8e9b59e388d802
meta: {size:1510, lines:0, sha256:"81e1e71681c18511011a6d816c6ae78005449c293b79c25a6087086e159b7822", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3f/78a188866c55f5319f4d8befda4499af2a0cf3
meta: {size:52, lines:0, sha256:"df2be2947c8c02368a47016994818d882e633fdb4799c0a7c6ee50d3014977d7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3f/a008cf7dfd0826101370d99ebf31e3c59589ee
meta: {size:679, lines:0, sha256:"4496f7e686e3bb9572e8c97138772c49a21990f07b203af30cd1e8803921d146", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3f/a4c8e4d0e23079d11f23a9ae0b2f094e5674df
meta: {size:534, lines:0, sha256:"7b43d3665393942b5bd77e00ccd6f47d69da8da41a1b708684b2e1b19c296086", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3f/b1fe5dbe9ca3f9ae868b7b77e79cef6499a8a6
meta: {size:113, lines:0, sha256:"9902453fe1e50cbb6b12febf7a2dfc059785226eefea077235976abf77c90167", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3f/c118166aa8b1a101c69240701e5dff5782cddb
meta: {size:54, lines:0, sha256:"19a82b487aecf6462badd4c4ac43baa189c6d59fbf4eebd6945dfb8614d3f285", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

