---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/0d
part_index: 0
files_included: 9
size_bytes_sum: 4364
created_at: 2025-08-31T21:08:15.567593+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/0d/2a0a4a769c33d7216a9188dcd0fb7ba4cc85c2
meta: {size:1048, lines:0, sha256:"92e433f7b8b5ff04352098fb481339b78280f3c16b75d2e90f224dc61e51753b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0d/2f7d286319866ea89d76eac6f33f82173c98ee
meta: {size:51, lines:0, sha256:"3de40cd27f59880e125c78ce7c3588beb3311143060d04488915b8c3605bf17f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0d/49eb7400ceee0c8c18cddd38e5c438208431de
meta: {size:50, lines:0, sha256:"2a5cd0438c7dac040555bd9cfac29b76ca6105906bc7e28cbe7fa823243bcf71", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0d/4c85b291a80496218fd59e2839a7753d12e499
meta: {size:467, lines:0, sha256:"13f090e49e1f68e64040313b60b8560606ff60ca1de26407ae375d01dc19aff2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0d/4de3cec448fdbdb3b67d7e5b5efcc4a9b7c4c9
meta: {size:726, lines:0, sha256:"46b7d25b53f5512b4a90022e6cbfbbb4a01431aa2cb095697a406f7d7ef2bf99", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0d/71bf38db08de9fa41a200d2817acc8f38d2be0
meta: {size:848, lines:0, sha256:"6d635eb6232b863ca3425446a1a97108991845e8e9d23136ffc53bd978f3dc25", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0d/7dd5455e1a998fb30748572bf4673d5a78aed2
meta: {size:71, lines:0, sha256:"3cb4b727fbc6779e7b0a6ce0f8f7b41606b24f5a4f0d0b08c2af82b4ec48e3c1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0d/b4103f1cc3fc03c115197ebe40ed1a11f1069b
meta: {size:847, lines:0, sha256:"ad08678b0473684a2e1249ce3068652807f7ec80aaa21d2c7f3f7a1724d31ada", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0d/be9cacd5a2c66d1ed3d76df005fb4785db36ae
meta: {size:256, lines:0, sha256:"e572648a1fdcb324fd892a4c9d69aa438d0e7e0a67f578eb9fc0f67fa9c967ba", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

