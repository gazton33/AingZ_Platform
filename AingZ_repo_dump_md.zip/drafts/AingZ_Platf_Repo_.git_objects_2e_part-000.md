---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/2e
part_index: 0
files_included: 7
size_bytes_sum: 6700
created_at: 2025-08-31T21:08:15.570620+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/2e/4ad69a1590dc505ccf184e142c4781908d4a48
meta: {size:606, lines:0, sha256:"85c1c363594cd2d9d2864c37e11b4adbcb795797ce74fbba5d290f0c4bf01de8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2e/601d0939e641819aace9305b0385bf16d0f4c7
meta: {size:897, lines:0, sha256:"191bfc1ca62757b95920b679e8c8299a1b911c108ef1cfe5387f2eb2e2d47d1e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2e/7053d7758634ba5065d173dfeed2c5845342a9
meta: {size:590, lines:0, sha256:"56f6b26a6588b190d997d0fb6d1caa11fdf80d8dc26be77313105ad1b81ce6d1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2e/9b7f6f1e43af7a04dcd7d7be79f3a9672b112f
meta: {size:318, lines:0, sha256:"e003a4c968756481bedf4750c4a4c8c3b95502065ed1ca38969af2b3c0a2e58e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2e/a9ee5d37ca886820b6d51fdfe9442e599d9afb
meta: {size:47, lines:0, sha256:"006fda5a98cca7c78cb3d609d7f4be5781e105019a90ab93b396cbfb3e8987fe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2e/d0952c903902b89dc80de2df73df927fff15b3
meta: {size:839, lines:0, sha256:"e379c2e092cb65bd4c0b5176af395619e1a70cb3349798624b19fadbd0a4e160", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2e/ed0d6b3571632f3bf917e4fc220f067504b7a7
meta: {size:3403, lines:0, sha256:"776ce6f2af09ab6b6e53e7856235c83c6ca372a1387d824b364916c4ccf9e7f5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

