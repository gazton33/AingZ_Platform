---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/4e
part_index: 0
files_included: 11
size_bytes_sum: 10551
created_at: 2025-08-31T21:08:15.619339+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/4e/1618a6c3b0572ae2387230707c5700fe8ef5f4
meta: {size:1928, lines:0, sha256:"46dbb6c6c9b5d131715c8037fbd684692a7727dee2d3105bc784b197c699437c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4e/19640c45872d8a090554d89adcd9a6e3962dad
meta: {size:591, lines:0, sha256:"88c76585538daddaa93794a2d5d4235200125960dd22674e2e654b098c458106", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4e/2484a058ce044e42a5575974c77eea5c81532a
meta: {size:172, lines:0, sha256:"067337143d1763084b68f0c09fd4d47922f2ae0fae5392c172b286699ddb1f81", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4e/281c064a987f3618a3b74df73abbec8b17bc80
meta: {size:907, lines:0, sha256:"04229f9a9db1a9f12f80ff8e99b4a787deeba34ddb819560fc4d14841ba2d8ae", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4e/3c46d78c8748d496b593b17d9bd57d023aee20
meta: {size:1390, lines:0, sha256:"04b9bb7526c7ee51a7acbc95be80a602d38979adeac0bd092f2c570fb91a33c9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4e/527ae83f58f83ae5740fdec553a9e44f3e3df8
meta: {size:920, lines:0, sha256:"f640356af3c2febb0632e8ada64f2feb3daeb8d51db0f4723d26fd70d9b95fb0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4e/7a238c1c75d2f07594b239ba65e49a98975a5a
meta: {size:75, lines:0, sha256:"f528fe86932b25e90df4953f2043029c5be5f3cf602d3801e496fd9681ba4a00", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4e/8a715da2121369762ffd405e06f0d79d8ee287
meta: {size:1983, lines:0, sha256:"7fc134309790287cbc90c1cc961eedf95847cf67d3060104d63740b1109992e4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4e/ab2fae0133375626368346193a47ce907e282f
meta: {size:839, lines:0, sha256:"c66cac3429f3001b9ac4b4870face8096bdc583432159a5da3eb7cc1cc580fde", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4e/b728750ae5b1f7312fcab4650b11c7c0c05778
meta: {size:1574, lines:0, sha256:"8b46017f53f590f2aa8ad4243cfc7d1dc762dd59ccdda9592120202f9e0caa55", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4e/e6874b84955dcb6d3a8f05b9433db319f97e1c
meta: {size:172, lines:0, sha256:"21b32d74ad77a9ee5cb9daa6347163ad640a5189e1d2d8631024f29e8aee988b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

