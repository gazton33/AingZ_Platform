---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ff
part_index: 0
files_included: 12
size_bytes_sum: 11780
created_at: 2025-08-31T21:08:15.653000+00:00
integrity:
  sha256_concat: 08ed2585551520741e6eea9d8cf01265461e7fbf5c2ce9cb0295af28dff27f96
---

## AingZ_Platf_Repo/.git/objects/ff/1bbc7c812be6f9e17dd713d8a3bbf3dcb4c3f6
meta: {size:717, lines:0, sha256:"08c232b650d795d43757c7c61f490664e10d14e9e913cf69c39468e7baeab738", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ff/2c9cd5c3715b3f63c34b37889c97097fd77338
meta: {size:1782, lines:0, sha256:"5be69b6e182c20e96676405ebb2437ef12dd2df5b0dc0688c2f9fa9229ee7d18", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ff/356a18f4ba1b8938a7658a83bb68a8d8a61b4b
meta: {size:443, lines:0, sha256:"6e25358af99a6743eb660a43e1f0730834f82a53737e6411a314bed966109218", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ff/7094dae992210ffde716daf61e2a05c926c960
meta: {size:1219, lines:0, sha256:"a441a2be058111c97fe0c5a2d25dc0ce8fe5a7cbff945ae6217b144de8940c64", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ff/86cd1a78a3baa41ea9550543b5761a17bf3b2a
meta: {size:1554, lines:0, sha256:"37520f7dc74790b6aefe27fe13a7c1c1de613d636727c33f6fb03225032ba8d3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ff/87b61dc49f238cc7967fd78d282a0bcbb16e01
meta: {size:1115, lines:0, sha256:"10a5f143abe4a3355aeaef14204207f79dc64416baa8675b32d12e90e175b3d6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ff/8d831aef498ee573aaa8858bd308d8f89d8218
meta: {size:788, lines:0, sha256:"8144a50c4747b8f9f8b9bd5e3b2e60f9736f60dcf20a5a7cfdddc672724c0618", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ff/91acb9e84a0893aa251d3f98d3daa64b09c815
meta: {size:2296, lines:0, sha256:"9d0003e3703547ca833b4197ebc710eddaf3156c543535279d1b33eb7f9c6efb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ff/93a39b58e2c103910ee6a987990b24da8ced4c
meta: {size:154, lines:2, sha256:"c71dd252bfc0b62e057fc53e82a75db2156aaaae74fdae433f4919fc29183e10", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎA
Ã @Ñ®=hMJéUFgL1`)äôÍºýðàçVëÚµ5áÖM6ÚàÐN4IsbElBHÎC²êMì]KDd³/Ñ3'¹ $ ¢xR0O>}iéìmGÔy8e¼´¯¯¹Òº¹Õ§6w#L`AßÔU¯Å.aÅ²©jXE}
```

## AingZ_Platf_Repo/.git/objects/ff/cf65779fa44850d687a7400c9e0bec2be1f2df
meta: {size:1105, lines:0, sha256:"137e5b6f476ba3fa05de8c50c9c606c58de06cb0d02ab76c7f2db55b7e3c29fb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ff/f9dd87f954166a9d11de2365b01c2559078d9b
meta: {size:532, lines:0, sha256:"06ff90ae028f2bc3fd575639dc4db427f1b1cdc626d9c3abef193be16f35fd32", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ff/fa6d0cec9f02e1d97c61bda7c50845684782df
meta: {size:75, lines:0, sha256:"b503b1d5b8742620675348eb984647df8a6c6f9171bd81eefe67e9d3093ddb59", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

