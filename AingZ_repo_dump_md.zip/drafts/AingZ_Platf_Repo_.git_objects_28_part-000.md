---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/28
part_index: 0
files_included: 8
size_bytes_sum: 6246
created_at: 2025-08-31T21:08:15.570209+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/28/10d264f757b08cb06c7530640cc30747605ae1
meta: {size:190, lines:0, sha256:"8e40f760a9ece3adb23f451a96b84ddc68f4bd117cdfd5f4e7b93d4b1429486b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/28/3c305a3260b24a66491a798c96f92fe50fc260
meta: {size:847, lines:0, sha256:"777a4bd5baf53f6fc6482f1d66e3434fe2baccd06c57ac6b2667fef09b5df3df", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/28/50d7f40686f26cd222737175359d588bcf7340
meta: {size:1647, lines:0, sha256:"a63668f5351b12305e81a5cdef20cff4a13220a4bcb0f71685bc30ef9a9f0578", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/28/5b7fde278749d4096d516db8eef394f52ab315
meta: {size:372, lines:0, sha256:"0030710c228851b4a8abe7474d8f7cd6d2382c4117fce3125e9fc8e3487d7655", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/28/6aa5eb0bd8d3e90a7e559cc375c3f18cab279b
meta: {size:719, lines:0, sha256:"2f0c2d4d129beb365bba8d8687ac81ea882ccc9567d4765173725d2f238247e4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/28/7881eebfaf68e1f320c231d20d64b1447ebe4d
meta: {size:1572, lines:0, sha256:"e43c5930b80eb31e83cba04ee53b4b730fa99d1dfd72ae0e17d43ad1d22bdb5c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/28/a454de77c2ff60a773f9f8bd9892f1cf42b1b6
meta: {size:630, lines:0, sha256:"7f3e9837b85881bce1daa2859ce5fb6c79352be5ffbd219700031380ecefc004", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/28/d562adc9938800e0d183d1e8c1d943694ce4c0
meta: {size:269, lines:0, sha256:"a1a59661a386006af47ee3eb5a53027657e3b46a036e1fece00f9ef4c9a85b60", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

