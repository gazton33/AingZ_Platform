---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/cb
part_index: 0
files_included: 14
size_bytes_sum: 34639
created_at: 2025-08-31T21:08:15.648505+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/cb/046b729411720aa753172298bc58e73b4f8681
meta: {size:863, lines:0, sha256:"085d9298a2465463a622ea379260d534f53b8312293537390478192585cd10dc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/37addc39a60d93abd11f1e6eaf24d493fb48af
meta: {size:1631, lines:0, sha256:"c7eb30615868e1f452764b6b096682429f5e74a0089b380f56b8fdf511c4aeb6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/38bc7953f5b089970e24f18158594cf2942555
meta: {size:132, lines:0, sha256:"5a93322f9c8af84853e4b69f4c7c0055fd7355a0dd868385ded7d86b36d42831", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/3fbff846c0534401ac2334fa26210ed2bf9f29
meta: {size:874, lines:0, sha256:"ec0b8f958a76f46e30b808e28bb203aba51f302dd7526e14dad769ca97626d04", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/4b5612d69515bc53abb1b3fc94405b0ed6dc96
meta: {size:66, lines:0, sha256:"6d9489529eb0ddc525c83aabf936721465caa2dcaa76a20d3fa845755f980204", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/68b47246484cd8818127bf71dfd4dd0f193761
meta: {size:1051, lines:0, sha256:"00d8edc7e725d25701d01061bea83ecdc77c125a013707bcd0da0f38722fcc55", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/7672c6a36c8427c41d8e15e26fcc35f004a276
meta: {size:905, lines:0, sha256:"a7cb017223a92c02177c3954dc1ffa0d07ad5f982b21edee220d1b15d4c42fb7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/831c8a917ea9bf6b5b0a44f0f2b3f6e2e86a28
meta: {size:702, lines:0, sha256:"43320b3302814c677e0c7c70f99b49b31550371a3ec3182f53c25d7d9a65b3bf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/97052e1379836f158130808608ef95782f270b
meta: {size:225, lines:0, sha256:"796ab6616b3e984e5ad6739b091595ec184e395077eb01f889931a3e93acf1bf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/a0f2b0170c1625291e582c34c4fedbeb15ce5f
meta: {size:103, lines:0, sha256:"adb088c0d38109b4d6e71f6c253d34bdbe84219460eb012c60c76491e8a2a0a3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/c49e8c562503af11d6b2aa12cb9885d42aa1e9
meta: {size:19925, lines:0, sha256:"90e35ac657d4aaa0f98ec8fbd1d13232ea1ec15ce49cda5176c65a78b96f6463", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/d8004b94b6d7d38b734612b13665aa763be9a4
meta: {size:7590, lines:0, sha256:"c050c6e740ac565ab239881acb6bdb8f3e6f3da770543f6c2e539e00d523b9e1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/ec12b1adff5146826e62686bb15a9553ad14f2
meta: {size:82, lines:0, sha256:"745709d0ff73bc41a65059a816aa97bdfd4eea12e1113d59821eccf2140cd41d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cb/f433e702e2fbf649196633e89696af289298dd
meta: {size:490, lines:0, sha256:"a3d936be0800af46cc8c8abf7aac01153d3cd6414a89559d7511ae7b76fe3351", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

