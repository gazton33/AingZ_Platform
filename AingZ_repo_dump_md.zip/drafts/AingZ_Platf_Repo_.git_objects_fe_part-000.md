---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/fe
part_index: 0
files_included: 10
size_bytes_sum: 11427
created_at: 2025-08-31T21:08:15.652932+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/fe/0ea500466e1e9ae4f25a7aad101c3e2c6bff65
meta: {size:1703, lines:0, sha256:"194bf1e010164fcb1068ef7abc2c8953560f5f15a0bfe77fb88ee514aa29f2b7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fe/0fe24d348671083a4f3b8d84417a6590568224
meta: {size:91, lines:0, sha256:"e049402ef9ebb24e8167b316b648e98e91eb535ac6c0480fba5f5957b1fcea02", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fe/4481e70cc480a355380c715d366d248e3eff0b
meta: {size:1403, lines:0, sha256:"a76a9f3bc23458e1597b91386e4216e2a1bd98063bd528bef3a8cf5366ca3866", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fe/4b356ab7176d4e921dc2278f534262740fc521
meta: {size:2268, lines:0, sha256:"0d9997c11acec533e1c9fa09b1ec4ad21d149fd2acee0f6828584b6585280937", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fe/61570a9d2a2ba53db686fee5e721ac31aed0d9
meta: {size:2596, lines:0, sha256:"ce6b5425e7c73b94a0f636e21784acfae42c20fc6e9fa5d4fa3153184c97a4aa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fe/821f859158f1099dc5f944f7040ec9638668e7
meta: {size:721, lines:0, sha256:"84631511b4d765ff1b85a92aeec8ffc516a9d82430dedf4c483139030384e67c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fe/a007c59b97fd171eaf0ba087c21460ee5fd2b4
meta: {size:204, lines:0, sha256:"cef65d8ff85afbe0552bfd2ec054ff1cb4aeae46c7a303df5e2414f2da5554bd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fe/e8af804bddf70595083cf9270d8a9d9498a9ab
meta: {size:105, lines:0, sha256:"a141d610a3b6afbb339f7ff0fd266245a57ed84e81217221b9f704d9eef7373f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fe/f20ecbfc9ace9eeca4d56d16474565274615a9
meta: {size:1290, lines:0, sha256:"df0db76c56c1179ed3543a7e84dc719a596bcc375805d786c0d8b924f81ae191", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fe/ff5520270ab00bf8e9b707f3a5e2d4c55f3999
meta: {size:1046, lines:0, sha256:"a170e1f173f6a36654ea667dc2fda22e7da590948ab17eb46738fdec3bdeb42f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

