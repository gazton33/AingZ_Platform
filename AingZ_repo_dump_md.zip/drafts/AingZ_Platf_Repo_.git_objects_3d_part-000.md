---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/3d
part_index: 0
files_included: 10
size_bytes_sum: 14485
created_at: 2025-08-31T21:08:15.572262+00:00
integrity:
  sha256_concat: 68ccce7329f2053a4d4b5d28f2cf70e21ff52a23d3fdc7bf7ba7191bc3f2fb9b
---

## AingZ_Platf_Repo/.git/objects/3d/1c3bc9c5fb453513819145aaad6be961d4258f
meta: {size:1210, lines:0, sha256:"f4b8592d6d634196bbe942c732301e0194fe4b952dbbd4a6960b3014efda3103", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3d/23a4ba76d45de96820c17b01fa861f72570175
meta: {size:525, lines:0, sha256:"70f83f643129fb25dd30e11b23c08fdb59fb0305130b728d4ce0d57073a43eb3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3d/3a09c5cca3bf6b0816612fa85659e688fee487
meta: {size:1424, lines:0, sha256:"5dc0f56e5ab50a71332e7bd4e6acb02ca74abd60c126facef30a6d9c0d1761d9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3d/5ac53fac55318fab270cf1bd19f58da4420c92
meta: {size:181, lines:3, sha256:"aa49fe2fc7d1c147c7ef1ed8fb46d502b79c87285e5f9471d8c28588e30b29a0", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x5;jAÏ)(Ès1NÊõö´Ö-f§Ùãø>.¦AØé+^ÕlÂëáíeÏlßIâ,x¿àäv®øÈEç¯ZB8·Er5D)U3EÁmÕD$ÌjY
huÉQ#lÁ¦"Þéq¢.(Íç'Í)WA"H·ÔXï¿yøV·mômÎã®~ÿÛb£wag%típmu
´ÿ6,r³±îÃôT
```

## AingZ_Platf_Repo/.git/objects/3d/8127dca1d7ee5505241737a5d7789457c9fea3
meta: {size:717, lines:0, sha256:"ff83ee27f19a3a477f74628362dae8b00ce981b0d0d17fa860101569eecb4809", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3d/984b07f9390e5dade9e29dd15307f7b8e7c36b
meta: {size:415, lines:3, sha256:"279f84d88c41af3fe4be9e64ab9627ff7b73dce1f57f4b425cb63db732725a1f", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xUR;1%ö)T51½	²»UD{¬±5=ZÜí¡f"Á56âsNÜ=[Ýjéé}¼O²ïß½ÙÁ¾Pnøú;Ã½]s	"+&Ê>J¨wpÖ^T@G>Ù¥(çÀUJR²
BAµ^ÎEªM{hÝJO?>MÎ½_æûçç/x
gåè½ii·M¯C4'\×J!½i8I¸àGëL8Rø¸¶×Á/vÇhìqÓ,i£=²i¾¾ Yx¾®(³éF³ã¶üC`É£2Xg\8ÏÐ3H+&x/¹öÔÐª¼°ù+_o¸§%úmo¥¹³%8¤þ,W¤bnm¹üÏÅívðøL¡o?­·h§=Vç>gfûrnf¹7bææeä0¢Z»¹Úu)^_.ö,¶"u(gùè÷ÞÐ®p±ô¢Ù³ºÛaöHj8áðy0¯A¹4ðÛYï,ÎbLå<hé{gR8ôõ`o²`ãË¦qr8÷
```

## AingZ_Platf_Repo/.git/objects/3d/9e7c8b38e793e4899b38600ed3352752d47262
meta: {size:6874, lines:0, sha256:"410d00200068ffdd787b64c4353e6478ee1420de1f0fc32e8fe1c3fd840ad061", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3d/b7a6c1cb488b3a2ff7d4ba8d07d41755959244
meta: {size:2098, lines:0, sha256:"46ce78baada2c836a9470607cd878a460c0b5512ff6daace9ff0629ad11bad75", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3d/ba6023700809384a03eb504d5ae2f85ddf144d
meta: {size:917, lines:3, sha256:"f9c2c5e4b424c0e1017ff654eb57f7786c3a7b33e52e420dbfe7a7dca1ff936b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x}I¯£F³æWM"äg¦bhu¢ÁÆ¢,ª ÑÏ6¿>t¿Þå%%ÕæÒ­«ûÝ¨.Ë¬,'À_úÀ@&CÇG8"Yf+Ï@(ñÏV¢ÔªU"!â$`I ÒU²d
0ÒáyAâ(4ôiÝUÉ8CÉáºÿkº¯EVä9Hæ:ÒvoUÝ¦x½%Yø-ªË?+AA+³`ÆðCMêô¡´ÀÌzkÀàëÏØ·ÿ%MÒe	}?n®¶À3=°_[õøúxtF¤©ª¶PÕ¶[×¥çÁ¢40Hu2Â|§ZãæÌosÐÜ!fu×÷w=)6wègi?õcÖ/Ç(¸lí§Ó.{¡¯D×kñ¢éé|É$­ö®Àùðèt¤Ày+h7Þm}o/E\öïê)Í÷èµMÖ>©/&1õ.+·ÐR0´ùÑ>ìTeÝ²Ú|»üÂbUZ÷UïÙa¬~Äs;nÉ¬¹jÚEÜØC^gô=ï<ý]#à|»÷£Þ,ýêºÐhêAÙ»Sv÷éªekçâYKH%×ÖsÀªëD/áR ÇËû'¥k×ã³$¡­ì¸ÓsáÔ2s«vLdÝóla}mÖÃs^/{HV ÝÛÍ[á(Ì+$X£WôÜ`<U
têoûdKï¤¼°U6Ö.z¹Ì7ñnr=èå>sÑaO©Ð4{lsgû³?W¾í£QY³¸×Î|ëõ#0ØÞéA²:ûj.å}Ò.£!°ÔË!7äiÞ=]{ÎwÒ¨i]þr;¸tÕJ«éó¶}ðØÝÒLÛbµ*ÖbÁsa&)s§ÄF¸Ï­Õ3d7b­B)xðôº÷xÑ)ÓDÑG7jQ¸§_é¤3RÙ	×îyñÎ­8G]OÃjÃñ ÊÜðú3íuä%0JVðÏ´¡4ãxZ'&ÆGñF?SLèÛåçDPêw¿ºRÒõSdö.ß~ùß)jQÏ>¸'ñ¿¾g(ê³ºê~Â?Ñ«ÈÌÑ¸ÿþ¿ÞV§Ír_·$Jëi¿%%Êâ.
```

## AingZ_Platf_Repo/.git/objects/3d/f3e47483822a3876c87d402ee18e911d424037
meta: {size:124, lines:0, sha256:"190d1f39555e7023b0b8c47d8d78fd3a70b76e3fddfb85e1eb79a5a9141d767f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

