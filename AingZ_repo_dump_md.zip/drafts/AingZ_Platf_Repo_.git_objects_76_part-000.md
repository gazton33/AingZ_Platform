---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/76
part_index: 0
files_included: 6
size_bytes_sum: 2553
created_at: 2025-08-31T21:08:15.624221+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/76/475ec82e7aa0729683ed53de92986e5bf92cd5
meta: {size:858, lines:0, sha256:"a574e9711e64cf1398580be5f069c5a23d403b60cc2fbf2f57abce91b3769b5e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/76/48bcbeed8bd4daafa38476445f3e7a5a3b3a51
meta: {size:247, lines:0, sha256:"3d942f044598ba693c39c949bd83ba8a3342b362b1d9e88d2259cc4ce9fa54b2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/76/6d6d4ac27393594923c5a6b2abc1bca74bff93
meta: {size:155, lines:0, sha256:"44363db3f26ad22d7493de65047e80df1325ff5cc563528891a9c1f412becd1d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/76/9361d8fc83d50dd6528c5b6a38c0006d9a44a7
meta: {size:79, lines:0, sha256:"71a2eb08b43c38b9988e1a796bdcaadbc90e3e802d64ff0485e42f601f66d38e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/76/bf61f6534295220670e2c64a9c68ca474cc8c5
meta: {size:246, lines:0, sha256:"93046ced9f912adbbe53813c699485fc8e98765efb77658fe6aa00bc3c2f2d30", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/76/d178ca28be62c025d0bb15f851fe580970e3d2
meta: {size:968, lines:0, sha256:"a891242693b735a44bb705239c39455a2bc83d72bed73df911a5433f16ffe5bd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

