---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/refs/remotes/origin
part_index: 0
files_included: 2
size_bytes_sum: 71
created_at: 2025-08-31T21:08:15.653306+00:00
integrity:
  sha256_concat: 7edbeda0bbcb07bf74eae342bd134b0f4bebffeb946a96c73265c60dea1bc917
---

## AingZ_Platf_Repo/.git/refs/remotes/origin/HEAD
meta: {size:30, lines:1, sha256:"2bb6a24aa0fc6c484100f5d51a29bbad841cd2c755f5d93faa204e5dbb4eb2b4", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
ref: refs/remotes/origin/main
```

## AingZ_Platf_Repo/.git/refs/remotes/origin/main
meta: {size:41, lines:1, sha256:"30014953767dccd56ddfbd69085271e93fa7d525ec6e7adfd4bc90e68f8ac9da", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
6c958c44161094ff15e8501bcfd1f5f94d8e6d08
```

