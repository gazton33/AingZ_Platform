---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/7e
part_index: 0
files_included: 9
size_bytes_sum: 5414
created_at: 2025-08-31T21:08:15.625148+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/7e/04e398e25a9234d23bf61f23c98b32e40cb9b2
meta: {size:802, lines:0, sha256:"9ba2c9ec6929a4bd81b7a4bec8e077c27e8c0bd7dfc87bdfc7bf6a7369a38d06", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7e/050fb0f3c7190b901b9f4dbff15248f4c9c390
meta: {size:52, lines:0, sha256:"2f4dade694079e8b9886f01680c5cfee04e35c56c8e6bdb997abcd0972a4697f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7e/262a282b00a437c6515e3ecb698c9aea4fe74c
meta: {size:60, lines:0, sha256:"c18b20bf81baa19490c80eb60d87db3092c5629aa31b6ab19ff2d49ccd4e5c2b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7e/38aee88792b1dfdd175e02381eb02c6446b4e7
meta: {size:2438, lines:0, sha256:"9d87bfba9eb9f6874df0379b46da09512e71523b66a5c36f5446053564d53a10", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7e/4ed30b8efce6baa1c27dea395b6221def6bfd0
meta: {size:923, lines:0, sha256:"f7435cea282172e961e8e7a6cb711e81d68f1c85a63371991dc0fc6c57405cce", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7e/51fc405843b2bcb33696f337bc31367427f5a1
meta: {size:847, lines:0, sha256:"9f3bd85fbff9c919c4f447c9193b31ae474b433c656c919249608965d4301bb8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7e/61b2a1a5324fab872d1af7403ac3e36a78e9ce
meta: {size:112, lines:0, sha256:"3b9ee468f440c6659c10376182ebc6cadfd69100219dc46c4a2b6b253bbf9b36", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7e/9af75fc9ca8887b8ed17e6fb067ba8019f9dc1
meta: {size:126, lines:0, sha256:"a2a1bd8114b268b308afb3ec11a41d23fa619f657813f6ebbec757f4b19851fd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7e/9f888041f46a093adb30eb6f2261b0c937e960
meta: {size:54, lines:0, sha256:"fa8ada70aad2f3c83798bc911614273543b54eab4810df775f5110a80ad9ba35", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

