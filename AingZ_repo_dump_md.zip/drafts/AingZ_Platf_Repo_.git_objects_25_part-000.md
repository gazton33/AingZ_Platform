---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/25
part_index: 0
files_included: 12
size_bytes_sum: 11701
created_at: 2025-08-31T21:08:15.569785+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/25/1eca43d9ced9b19c5a227ffd183193b23773cf
meta: {size:342, lines:0, sha256:"3c3aad7fff7ed579be4b81208e8475e0bacd74bf5db10cfb9031565f963fa2f1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/25/206c0d0e624d09f0c9e6f1496559360a7ee305
meta: {size:2918, lines:0, sha256:"7adb58d94adb3508317657dbf22ef273d4af4a45a018a6f54621a958d7f117f8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/25/246728fba64ce7e114ce7d6c7e71ddab452912
meta: {size:172, lines:0, sha256:"10da54d239f4465216ff33a26f3841d191cf58dcb42818c5f796e97bc1a773d7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/25/2b5389f75958a8708302df6d3d83d5d49e1d60
meta: {size:285, lines:0, sha256:"88fe724dee3e25a79c5cd8a1d804952f853672d44850d3380104e26eb21fd393", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/25/4f6f7949ea0055af817020aac89c22133115e2
meta: {size:847, lines:0, sha256:"89b888444be80ef0ac5bfd546743393b785bc30eec026326e96a142e795de2f7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/25/58b298568e0a5a089bff7474edb3878f59493c
meta: {size:98, lines:0, sha256:"088049d9beb5be6f8f8c6ec7ea642e205089e0da7d53b93c4ceb2aba7fc262e7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/25/855cf105ad1e7b8405361d6ee8c39fc8f10593
meta: {size:939, lines:0, sha256:"2abb1c269c04d134a3acd6b800155a5575f0b590b7261ed10b425df309313f17", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/25/8e2b8eabe093ec3d0575bf2dd6b7bfed2b6f9a
meta: {size:156, lines:0, sha256:"7ff26b6589717b2c549100cd7cf535868cf9d3dcd44dc804fcd72b4a3721dc94", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/25/c389187e942fcbea48dc1d2b3ea71c77892d89
meta: {size:557, lines:0, sha256:"fb920d832eebb3037336eabefac679493cfc9543ba6e120b599cecd8e137ee88", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/25/dea32696d6344cd5151b146ebe0fe37ceb45c0
meta: {size:1927, lines:0, sha256:"f03f691e43e38922a3eb669c7ab602f29536c60fa8b997019e3815e47907eff9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/25/ece1da1ef696677e1452452af5f816c451917f
meta: {size:2942, lines:0, sha256:"d22f7263edea04588a42a1e2e8139524a97bdd824be3448946a0b7d4334a6bab", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/25/f6d620a84c1376acd3f89a4a2d3932dd9c5208
meta: {size:518, lines:0, sha256:"abae6e4d59612c337257c33b6042cff9b24ed9df70ca709e58e7eb257341eb0e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

