---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/cf
part_index: 0
files_included: 9
size_bytes_sum: 5707
created_at: 2025-08-31T21:08:15.648876+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/cf/18b9ae184a081f959678c9469765e888782472
meta: {size:155, lines:0, sha256:"2b63ecd8e044437637b30945c825bca9c51b4f2aa78b6f90bcb12a068d65eea3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cf/1d98868a1039ce769f7ac719c0006a77f39c7b
meta: {size:846, lines:0, sha256:"117901598df4286c56965f18ef06860b3eb3e01e89e5bdedfac067a51c337698", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cf/33483368cbbecaedef4ec4f0e3589c7fe31c4a
meta: {size:210, lines:0, sha256:"4aaa7b431576c00298436034429ae3760efb0e465a3f2f236f25dec15b1dcefa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cf/565d750a95eb5816c55c8bc40e8407c189e7be
meta: {size:1180, lines:0, sha256:"d4bc5f9c8ca5d554d0f7046154dd514e43c1b8b53fb93d7aa097c1d00dd99529", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cf/a5bcd90cd9c1c3c402151661993ec8196e4bc9
meta: {size:234, lines:0, sha256:"2f76d959329cb9a515b094a789e20227de9ca20dc8ee274ded5589239ee1ef95", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cf/af2435b1f77e7bbb3ba78caec2e4a5c19c303c
meta: {size:136, lines:0, sha256:"87128e039186251bdf11ce5ca33b2c09f8810d4d13af7d556f4ac44f08a28003", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cf/b94bf27a02332ef09a71035ebeae7a2bbb0f30
meta: {size:1112, lines:0, sha256:"5fa076886f63721972bd67d63629b1fe824419f2e9e7128b2ca2fd70dd5509aa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cf/e47ec1417ad780d002f4b72d36bdd8f338000d
meta: {size:916, lines:0, sha256:"c4d98ce032d1b94319c8d30999fcdc34f76798bef284435d14c94d37fdc31141", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cf/ed761326c7d76cd88357d7a0284ec0393deb2a
meta: {size:918, lines:0, sha256:"a036a757085290f2e6aeadfa332477e1cf0ef8fd7dd41893759f965c2920d264", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

