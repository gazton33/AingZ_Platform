---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/75
part_index: 0
files_included: 1
size_bytes_sum: 948
created_at: 2025-08-31T21:08:15.071104+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/75/0694e6005bbf817f8d2f71eb729cb982a232e3
meta: {size:948, lines:0, sha256:"3c0184ade92744ed6c0ff3228028bceb2f10924adbcd5e52cc624209eeacdd79", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

