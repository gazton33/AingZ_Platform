---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/fb
part_index: 0
files_included: 9
size_bytes_sum: 11449
created_at: 2025-08-31T21:08:15.652638+00:00
integrity:
  sha256_concat: 474a0dde42fbe9583856b74c9e95bd200bec1235bddc141eaa56b20ac9d9072b
---

## AingZ_Platf_Repo/.git/objects/fb/04951074a5d13fd9c848ff5999fdbd180d14c1
meta: {size:1052, lines:0, sha256:"3a84f8c0281c00ed5e6e84735bafa424c1fadf570431958a72fd37d0125b5252", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fb/109f4f84a8d0bbe5f4fb5db4aa23ebc36b93bb
meta: {size:2630, lines:0, sha256:"f7387bd5f1790039ada10379d4c94bc82c24684e0a36cd1ba51711b54e34cd7f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fb/9e7912c9996e77655f60b8da61387678c408fc
meta: {size:151, lines:0, sha256:"314fd7357fee9de9df9848921ce1a9f3f018ddd0d9186d2e496627ded3265bd8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fb/a0a133ed33e2019ca4bad9171345a2425585d3
meta: {size:861, lines:2, sha256:"925665fa3cccb6ad9607c383d462debaaa8b54a12d71873086247963dbfa65f4", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuSÉÎâFÌÙOÑR.Ðí6Þ¤I4Þù1¾Ùíö7¼b>$¹&u¬Ò÷©Tª"MUå`¡,ü2tXDT6áDäXFâEQÞ 0D¡ AÆ¼HLv´ÌÊ!/HÄ³B³ñ±@å`DÅÆ	Ç!k:ó:ÀôûdÍL»iæåwÒTVäÚ°ß !óa?Ú=1?ê¦£m¹üLó!£ÿ9KÛ´ÏSðíolUÝ´ÁI?©ÛØ½Õx0`î5²Åx»ÃØÙ:VÓ|wÞ±¡##ÍJñju0NÐÛIâZT[¾n Pùù:¡r¶Yw?Ýz=a¶zI}ÝóÜnÈ'YÑz2ìRx-ÆdÉkèÏ[Àúf³	¼èà¬Û5iº÷rõâ¢Dv¹y¨6wVY÷ö£Ey,¿·®óòr1ÎÐÅz8¬ª·¿)ÞdóV²i
¹E$nºá¹À>VËÍznlÚÙ7;(¼ñÝì¦"öª=a¤³y1K·¯GcÊCV¬£÷ë¡êja¢J^kÇ²Xí]CJö¬Å/È^±^scûk~uÝ5TÝÙÚ¤ýÚöVÀ³QL[9Oiö%ÚLÈ÷Àî1jîÏÁMEõU.AÄ{è¯¿^jµ~:äµÇ)|ÉâþbÑÙü$yÞèqï­GòF.yQÕ5#n+gå]gë	#¯YÆ/k*VbÂße{§`L½ém8,xÏÅµNq?´ÓtU¨]ÐcèöyâÓà¸:w²VZÖv,y=j¯¶°g3Ô6µSwçZ+ñp(ª~Î-ÉÉE¼ræJg_&®ªãwX?ã¾!ÕWí·@lð¸ß;áañféT¤	f÷¨;;ÔË§+Í©8zo=S_;Q$ÊP.´÷ìKÌºU.g$X7¡ÚÊ/ÁÉò&ê4Éâ¼£dhºö ¬cÐÑ²!áGÐØüö+¹ßæ/Ü\n
```

## AingZ_Platf_Repo/.git/objects/fb/bd98b5ad90da76c040ccf81b184509c0777349
meta: {size:153, lines:0, sha256:"d0b3918aba1c96708f58f964ca4dccbc131afd6a5adcc5ca1df83aa2bff36945", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fb/bea73c5ddbb6cf4e5bbc85189f89504592e745
meta: {size:200, lines:0, sha256:"ab52215b8321c6a738c75ef210c4df0203dfa02ec44fa62b567bb555ebabb274", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fb/bebac2284e3540dea3c73a9f7d0d8cca24a856
meta: {size:474, lines:0, sha256:"28c739ca25d87164b648857f004a8f22b5d9fe3165eb70fff0e350ee45b89860", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fb/c38b7d09ea23adbad61360497643a4300c66be
meta: {size:1799, lines:0, sha256:"982b8f8a1ff65a2aa828b1321b6070b1c4e50c5c0c4ac37deb078c9771b816e0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fb/d4750b7c77daaa0f3bc70ef73187854ed5bb11
meta: {size:4129, lines:0, sha256:"7426aed3cd2e18d4882f90446126f64a3f4b7927010e5f9d5599525c02aac53e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

