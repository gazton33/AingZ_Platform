---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/5e
part_index: 0
files_included: 13
size_bytes_sum: 21901
created_at: 2025-08-31T21:08:15.621379+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/5e/0060347fe01c20cc3ccce80c66879285b276bf
meta: {size:301, lines:0, sha256:"e8b0af961d364f7e154ea770a8db285afcdb226c69c77d4b7c4c963a9f998184", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5e/2f9ac46355cabdec54d0488636b028d3dbcbe3
meta: {size:959, lines:0, sha256:"b9a099b169df833344d966a1254cc925401209a879ba6c99f7272469e1f1cb81", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5e/553f2385c03ef3101fff15f977d59ee1af2723
meta: {size:1132, lines:0, sha256:"321efd3a17611e0cc1153b17ab2e3239c1b9234d3bcd56a07055d4eedcdd352e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5e/61738a7c63b53229406bf3629b04d2785940c2
meta: {size:1478, lines:0, sha256:"8097067785ed0b15bf02d75c3ebfb87f06547a96a98fb8dc7fc864dfe5258bf9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5e/68f6b805b6f3de90cfc1e945b7584ad5abd440
meta: {size:644, lines:0, sha256:"845cb93ca891d03a1a70c5f6fca7fb93f06cf6971abc57fb4f2d3313abba6744", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5e/8a723822fac2423adca3b7fc545024330b821f
meta: {size:3289, lines:0, sha256:"06e878feb18d58d98ec393265901c01476e662cf986403db00962ae4623479f4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5e/8d5b5b2aaebb39e72cc7d8cff8d09c5cf1ae45
meta: {size:910, lines:0, sha256:"2aa4836f4f08c8241ddceaebfe2f21adb36af43f9acdaf6fb9b3d7a8c85a2fce", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5e/9cc172860e045fdbe9ae48c8b8862a04f015a9
meta: {size:5459, lines:0, sha256:"b1af53c97dd6e49b1b551b343c263ab4656ddf022c63923819ec3e8111c3341d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5e/9d07d349461ee4387f54e93a66c68470a2ac06
meta: {size:188, lines:0, sha256:"c64b9322a135f9c7a2433bef71b879fbf831e2bf6a57f22019fb4c2e7e10f1cc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5e/abce8db9b50f19861249cc3a40cc756539affd
meta: {size:1905, lines:0, sha256:"88d06bb28e63b9cf95666698d5dd1afac3498744a05d8901f4e0881115d07c6d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5e/c2588b049e30890f089ac3d13bd388b5d57177
meta: {size:4740, lines:0, sha256:"0458b50f73436a5917407da3d69426e7891f1acf4b3f0657396e6a66994f413b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5e/f549eb17c41326623418d81d36782951df2b5a
meta: {size:48, lines:0, sha256:"e41a4ec077a381bd6688ba7afbc9f164a60c897fa18c5f7a4531cb2682247de6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5e/fa42d9463bc90d5722f5b0690e9cf69af02cfa
meta: {size:848, lines:0, sha256:"518020b908f81ad151fd3b7937a871851e8de7bf999a26837f19e48069193c1a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

