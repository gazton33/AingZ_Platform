---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/64
part_index: 0
files_included: 8
size_bytes_sum: 4504
created_at: 2025-08-31T21:08:15.622458+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/64/715557bc5f9edf75f07a51b098d803bd519519
meta: {size:1016, lines:0, sha256:"1bca0e72bd2c1b47cb242d9008c30bbd30a4b8d669a3764fdbf75b0e54db5379", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/64/83c1911b0dc6e357db3d43f86d3c7188ddf85c
meta: {size:59, lines:0, sha256:"e4cf3d80e0f1b32602c5278ada1155b1ac8fb5d7532fc94e90905394822d0b77", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/64/aa75c7e456b14809009058668763095fe8973d
meta: {size:407, lines:0, sha256:"9ee6af7a95331ff14a4cf2a72d52ad54c74dc73fc39f0de46fa3691eddd57a19", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/64/b3193dc3b6bb9fc9b8b66b754b5de1eb91977b
meta: {size:343, lines:0, sha256:"c0d6a1b7784309ea488f2a529fbeb86a416bf06aab3f0e05e91f203d65a5ee87", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/64/c3f65e87e623088fec1c7d6b4babacee94013f
meta: {size:630, lines:0, sha256:"cd4dd53baefff21c32036661a604cf3d9c20b4d0dd0866a1ed7b6b69546d4b5a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/64/cbdd1c9c63ec41e8be8f3ab6874ab5682df1c9
meta: {size:263, lines:0, sha256:"8deb3a621e4c681ad1d52afc7ed3d38b7d2f5dc662d006d34e0c18a8da3451cb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/64/d0d6fc10433d5c7e5cd6dffd970bf9d814a327
meta: {size:1607, lines:0, sha256:"7d67de51bf35a77fb8c96d73ffec26b8254a0496197854d34dd1502476d3c1c9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/64/d416e76efb7d699c94e598eaabef2ac54ce5b1
meta: {size:179, lines:0, sha256:"0eeeb6688fdb6b67308d8eff287b3ee813e415ae6bb7e7bfbe85dadc08da28a7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

