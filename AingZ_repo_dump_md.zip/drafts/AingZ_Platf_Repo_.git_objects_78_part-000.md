---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/78
part_index: 0
files_included: 11
size_bytes_sum: 11462
created_at: 2025-08-31T21:08:15.624390+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/78/2f764bcb68183ed8c2fc8d0a350c349d7dcd7f
meta: {size:2680, lines:0, sha256:"4a65ee41b84a3fd0c503d10c4a004fb45d693c1a6a2f6b5bbd481d15005441f8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/78/307149357d095bbf1c48bb4b6374eb84443da9
meta: {size:103, lines:0, sha256:"52f3f35fc90c370ead2055b1c64b0acc4588b491f2c7898f46ae84efe0c77e7c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/78/3296a44eaa5e93512c431e82e27cc4fe03fbde
meta: {size:76, lines:0, sha256:"ff7fc8eaf6967563bf823e784ec134a90cd03f9831c59651ae7d58e2d86aa327", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/78/3be54ec76a97bb9de08273bad72e7417149932
meta: {size:109, lines:0, sha256:"1671f97e83e91b3a0f973e51209c5fd0da702f497d5c862cd980ef5e7966cbe1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/78/463033a91f1f4eaa42c2f70e586afba820b145
meta: {size:156, lines:0, sha256:"0857c842cabc0a4b9200b69687c68730bd6cd8cfa6dee4a2ebec03fa21efefb8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/78/5ee06c4b564b77e6f859ff6ffc99fd3d21875a
meta: {size:144, lines:0, sha256:"b7fed7838fa6516f2bba668554a328b1710b4a7728497cfa2484fd0a61bf9b24", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/78/6fb561430d23eb573e27a978a2f6166c476fbc
meta: {size:4898, lines:0, sha256:"455672454ee5a8becab0b590147f85b97745266bcd4851c8499aad1b52bc6956", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/78/7214485d72b1782ec93799b31c8e2220295c33
meta: {size:140, lines:0, sha256:"b27055a6935918c10fe338d55beb73055df8e4664d20f789a82fa5d3a3a037ba", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/78/728f4680bae4d55135b1f71936dd2054b53b97
meta: {size:1680, lines:0, sha256:"d7d5b621c36c5a5c7b40c2ae1e69dda49ffc5bb13097acc2cfbe941a4cb11d68", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/78/aca0ee473f377a5bee1094a824645e10c5404a
meta: {size:66, lines:0, sha256:"90605c6690d16a4c7abff96101497c5d45af9f67233c4e262ef5c8dccdd7ad0f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/78/beb0350968b2a28ae74d3bdae20225293e7765
meta: {size:1410, lines:0, sha256:"71a7744af15b7ff1ea4c808f4ea967033f74a4007ebde437bf70fc6b605f4a72", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

