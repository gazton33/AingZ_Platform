---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/34
part_index: 0
files_included: 7
size_bytes_sum: 4801
created_at: 2025-08-31T21:08:15.571609+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/34/11fc39318b9cfda5397bec078bc61b62d9f269
meta: {size:1478, lines:0, sha256:"31913d755483fbf666ceb227c4d26a40714b96c934f4e9ce9594d5867dcd2b47", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/34/4e1b9d239451f2e16936099162d296b5129aeb
meta: {size:416, lines:0, sha256:"5830b30f437c9c81e4ab43a7ab7406bc7c511bc9ea43935a0c6e6d27c821ecdd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/34/6d50218631e8a94a4577ddd446e39fb6df368b
meta: {size:212, lines:0, sha256:"5a194f9c3759f2686b8c2028a5081a7ce17d645e40c1d04fe52e6098d27f0e41", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/34/6fe9b70d034a23f24a9a2be5029de456391010
meta: {size:1314, lines:0, sha256:"90b2fc7e9e04875a78ed45be84cadc6ca556f13b27e8d7f7e607eb1295533d9f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/34/b5b0f5c2462cff5ad2e9e94fa83118282d9f75
meta: {size:80, lines:0, sha256:"46767595fb1bd0a209bb262da8464f25d4e903c6b5c470d9d0f956ba32de1f7d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/34/d1086b7505e649012ac43a628d9a70dfeddea9
meta: {size:295, lines:0, sha256:"b55a924691a7b28a4055df111b91f459524839c8677c5abf3a79e04214d333a9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/34/f10e2bf6ae9e328bea2943e40690a165545065
meta: {size:1006, lines:0, sha256:"b8f1d332f508d4567d3da0427f8ae285e0f3a66c68308acc6338af68888ed2b2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

