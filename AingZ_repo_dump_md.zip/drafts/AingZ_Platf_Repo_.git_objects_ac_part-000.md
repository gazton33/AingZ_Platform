---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ac
part_index: 0
files_included: 6
size_bytes_sum: 3227
created_at: 2025-08-31T21:08:15.629339+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/ac/1de75c0067be135da63db4d0a530b12326b7a8
meta: {size:499, lines:0, sha256:"252145961ba15f1cff3f956273232a025137a3dac70cdf08fadce68f9745e73a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ac/453418de1c98e01805bc5c8d68d45415219d34
meta: {size:318, lines:0, sha256:"094ed97edc9b6ab03766366fc6adc37bcd9d5be702e356d2ba7899b894af90d8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ac/5ea5ce403e3af248007a064957416819cd7137
meta: {size:996, lines:0, sha256:"796b5f996652ee89e0f1845f0cfefb4aba92e97c8eca95443e77ab3705118763", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ac/697971948113632ab0abbf52dbe80879780399
meta: {size:289, lines:0, sha256:"c1c40f2f13b5fe4efbd8d85465a96816f44a6d26e543148c46ed9a074b5e5176", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ac/a2a644c3af2e911ab8f084fccca9c83ccdbf8a
meta: {size:1071, lines:0, sha256:"b21682153ff1a7fc1040af2e126823239b4269ed86c8c33ae7871b5d065a09b8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ac/c14888ad37086ea77d9f08ff5a4f8eb29920b7
meta: {size:54, lines:0, sha256:"ac0f9426943dd647bd0fbe416b45a285d27ea0da047d89fecd1f5f4b385bee3f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

