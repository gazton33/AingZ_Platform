---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/70
part_index: 0
files_included: 9
size_bytes_sum: 27736
created_at: 2025-08-31T21:08:15.623753+00:00
integrity:
  sha256_concat: 739227b89982ad3ab2278986e506046e19d75c83becca6f92ecae60d3e142c6f
---

## AingZ_Platf_Repo/.git/objects/70/214c9067f393b3a67617dec5f63ed8a86bd89e
meta: {size:1780, lines:0, sha256:"1018513102f95933455e2513efa42498705837fb0cf1b33895deee2d8c9ea059", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/70/28330f3c13e9a94aabb1599127bb6938706864
meta: {size:809, lines:0, sha256:"8f297c88dcb1025ac590385e85f2d06b852c211571a46459aaca3ca2408cb73c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/70/3516639e649ac0f6352c2e2f6ec9e9e0964064
meta: {size:129, lines:0, sha256:"ff07ac4b83804cb347a5ddf682b33c712c4c8b048f698520cba92814efde4c54", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/70/6081570a9f1ed4f9815935a0dca0c37ee27142
meta: {size:51, lines:0, sha256:"28bfb3bc11108e54471ae1ade3e051bf3b95007d646a3f7cffda45ad1e29ec85", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/70/613277d26a08397f851e8900c80227119342a8
meta: {size:471, lines:1, sha256:"261b43b25859a83cc5a7c9a41f03ea6fecc9bfb620953e1d7c370136f0dc826f", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xUÝnÚ@{í§©7)ªÙ´RS©w°eLÓ!¯tËz×ÙHó6}^åx±®M©Ò[{Î7çÙRê®>¾õ2Ê	)J8,%A!3ºn`è­Ó5Üd°öûOâNGQ¯?È½f¹²$4êS¯ËmJC{ªI9Ó@s|¶Âéó«6h[´Ùm¥>ta',]Ù¢`£A1`·iþåzÞ²y2\äãâ-æI'ß26ÉM>(Æé%_;VÖÏ¹8>+hÈX­P'¬0ð£h³ÙDËÄr#Êàüñ7.ÄKn¨;É[à^T¨*Jõ¤¶ðîÃå%ðPwdÈÒx@ÿ­í|¬ºµ!sæø«&gKÜSç)q%tQ×ÚÔØuÚ»Æ;¸ø<ñ¦#v7NÞØ^CoôØHÁ±ÛÐJªùÕ¨<Jþt´¶Á¡âmÜ*´×.§èxja[BçCÕE¿ÏvJ$U÷d¬XÓ£#U*ÖçÁ5ÿî¾qëóùúuÕÚ[~ðÂþ;kG¬4güô#®±!9ñé	ÙNýëùì¿
```

## AingZ_Platf_Repo/.git/objects/70/7b1e82aff2e8655ba5eae63b847e1144cd65f8
meta: {size:223, lines:0, sha256:"d580169edb8ff306d636aea4540803c5582113ac09318bb8ce7861a2c93101fd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/70/87b8e63d8ad4886773d64a3b80fae1e181be1f
meta: {size:21955, lines:0, sha256:"db5769fac8b9814af2300ff3781aca711194f9a858a277af4bb791cedce9a2d3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/70/a9290596baf2ee0319c5e32b956941c585295a
meta: {size:1246, lines:0, sha256:"5325f16a5b8306cb97facd8159f5de4b6bb74c3eb042be6934fc682e9fa981be", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/70/b0b467bca2affcd14ad19f39f528c11bc8b5a9
meta: {size:1072, lines:0, sha256:"6e37a722ecc3123924f566da3056828639126f667ffc5fa73f6e4b5148624211", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

