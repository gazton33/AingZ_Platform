---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/e4
part_index: 0
files_included: 10
size_bytes_sum: 7004
created_at: 2025-08-31T21:08:15.650648+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/e4/495243550f6127f3afabc1b6f2bb521e88c78d
meta: {size:1535, lines:0, sha256:"b819d71e97caf8153aa4387faadb1e1fe9662ee5f906ff8e4fd3e8999b330fe9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e4/7a97515eab15e6af5d1b7a91faf5d6db6ec1d9
meta: {size:75, lines:0, sha256:"0de5b2227f08f82dd5d6704f44ffd5e7df1f8611b3626d0f21677b0c3863c403", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e4/80fc9fd76241cd5ea2f1d393910b216b86569c
meta: {size:1139, lines:0, sha256:"3af8da3c3f2d8527de94603498a8e3b8df50130483ce9600760e3cad2667d483", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e4/9d5a708d6ebe90c0f9c991dc0ed0d0c1e7c6f1
meta: {size:2518, lines:0, sha256:"4092a41bd8137363fd9ab5aabc3c414943058485dd9967abb3c98e5b1ae250a7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e4/c8ac6f4a1868ecd280d26909579142f0a450d4
meta: {size:333, lines:0, sha256:"35e8774d9110fbb00d616fb97d0f796fc2f2499387e7a625242baadc54d166c1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e4/cd52471110991f3db9fdd6d86f16a1dc70209c
meta: {size:608, lines:0, sha256:"5c449cd3ff76382b234a8b83bd9d0cc54bbd2bda1070e6036aa5c811e0bc70c0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e4/d3f6fbc877449831ee9debe8a90a7a8755441b
meta: {size:534, lines:0, sha256:"95305b75c89b8fcf739d9031559731353b35625f4627986529c019b9ccc149aa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e4/d3f76e1557a9cd0a072e5c836faf29b00b5021
meta: {size:79, lines:0, sha256:"dc5611b7626f4d6927fb336c9cc47e9ed5c16964bb1686c9e5a847b5b9897d4e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e4/e46a59a87bd4a3a01df984fd87332f19a97824
meta: {size:54, lines:0, sha256:"e5c42ffda80095d500053793935a9b273fe1dc1595ff73c1492cc3d1040c8284", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e4/e5a7b85ba841864c4ca79d2211ce95a17c9259
meta: {size:129, lines:0, sha256:"3f5e9c91cab95495ea68b80e7cfc826c7801843e42aeeec4fd3344eb6e688aed", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

