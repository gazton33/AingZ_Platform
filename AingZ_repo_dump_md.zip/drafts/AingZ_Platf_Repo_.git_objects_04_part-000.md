---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/04
part_index: 0
files_included: 10
size_bytes_sum: 12417
created_at: 2025-08-31T21:08:15.565937+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/04/024f2afca01b5e963d8bf194d476f43ed68bf0
meta: {size:85, lines:0, sha256:"ca652dde3b1c237bff65789f8d390dc252ba34b17148ad218d775bce34619b12", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/04/18748a6d38bc903f7ea094e4188df1753a91ca
meta: {size:889, lines:0, sha256:"bcaf4d730ee4a772dadc57ddb5de6072de5a3e64ad7745fed612c35c1ab0d7d2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/04/1a435531d888350c5e88f30492c302539ad4ea
meta: {size:161, lines:0, sha256:"b654205b1dd698f8321ba1d1fcdac09aa9bd75e346f149a29939a90169a8d409", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/04/54f88d2d8940d86245856101689fdb7b89c74f
meta: {size:124, lines:0, sha256:"5b1ee93c49d5c514da1c4fd7a479acd0c16689f94737a6a057b5f6529b95c6d4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/04/591da6645302e248c01f9a4c1fe6f6becd376d
meta: {size:590, lines:0, sha256:"bfd6c1f9e9c7f068cfcf4ac98909038152bcc1e74bfbb1262f0b3e13ab653604", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/04/68c06b51a059491426200777228cd4b5678498
meta: {size:5151, lines:0, sha256:"5c31406c527c7d95ce647ae8a582902dcc12beb029819cf0c72649ef8657d652", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/04/714b73dbacd0488599742311ae8b122e7c2f59
meta: {size:2713, lines:0, sha256:"18eb70b7a38d3afd05c98878a1444bf518d66666f142afc324a82bf41d492815", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/04/86f955c970773818c0c8b2c9a647381005d408
meta: {size:722, lines:0, sha256:"dc257633d35faad316b3ecc25a546fb86bff2efe45f165bd42aa46506927f775", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/04/d297b75917619f3c8b3d32916fc2f1813c88d6
meta: {size:1693, lines:0, sha256:"9e8fb003aeccb21db6b86170c0d0a02a8cafeb5ebac570b1faca743a4a7956b9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/04/d8e528cd7565128acb879022c54659f6047a2b
meta: {size:289, lines:0, sha256:"c431986e22d06d94d9c7bb051b3c3e6c3f12693cc9d394ecf1aedf0d9f434040", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

