---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/46
part_index: 0
files_included: 4
size_bytes_sum: 4538
created_at: 2025-08-31T21:08:15.573500+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/46/24881a2b72d594e88ef61502a11dda7fabbf00
meta: {size:312, lines:0, sha256:"d6eaa9c293ba61eddacec70ebb694fc5f3ce13a904ab80cb4acf8da6b826c8f3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/46/386314bee6eec7e9cdf86fb64d90429fad0689
meta: {size:1487, lines:0, sha256:"73b901cb9cd8858c18b4948dadb27d8fc63fe7737a8f2403006ee962966655f6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/46/613f4fa98ec7977071549e1685d205c8adc7d8
meta: {size:2520, lines:0, sha256:"4289f766d525a3ffa118bb65cf620a20f3b3f741499993f17b67d06a736ba1e2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/46/f7b71ce87fd5d644f2d75bdceaa23a0cbeeeda
meta: {size:219, lines:0, sha256:"68ab754451b0deebd86a3e3fd9f7f6f71ffb91283acca2a135eb72c5295ffbdb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

