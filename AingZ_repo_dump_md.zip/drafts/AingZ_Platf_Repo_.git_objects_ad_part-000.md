---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ad
part_index: 0
files_included: 6
size_bytes_sum: 5015
created_at: 2025-08-31T21:08:15.629386+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/ad/137ad77ede28e00e923e9b7104001cf27b89db
meta: {size:2295, lines:0, sha256:"df936549b9f7b0643ec563293ee967bf563c0c867616638e1e83e082c9205472", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ad/353a62ac8b52859e1f71fa12057a3158674699
meta: {size:127, lines:0, sha256:"28bef0ebbaed87c501cdae52e9b271e1aa40e9a305dd1fd8fc80dc87f2c5d259", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ad/3ef3461f77762d06e62edf74eb5db50f721295
meta: {size:1232, lines:0, sha256:"cd8977b6733199925175a4ce126173b95ae8f6791c445a6ef876682b92fb0a03", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ad/89209871504fb796444954d3115d9605fe3b52
meta: {size:849, lines:0, sha256:"914b125e773f9a121dca28093e1dbddaebc0fb8e4d2b304ab666460bb7ba23d2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ad/8ab87145916aac5a1350d03787018a9d303a5f
meta: {size:224, lines:0, sha256:"842805135a00cdcaaef9fc61608e2f29e83f9ca81f83f4dd1a4c3fff0ed9fa52", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ad/e68311310274e01a1264c6e0c4cda693d18000
meta: {size:288, lines:0, sha256:"37156471291601a282546a7f159d24a811da1b6f87003870990498d854ec763c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

