---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/be
part_index: 2
files_included: 1
size_bytes_sum: 506
created_at: 2025-08-31T21:08:15.630544+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/be/f46eb7a43667d0984be771a79458a5ef948189
meta: {size:506, lines:0, sha256:"0c419edeef98bd4a02379df1f1f8d36ee67a4bf1057a7c6a1b4262020d1201ac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

