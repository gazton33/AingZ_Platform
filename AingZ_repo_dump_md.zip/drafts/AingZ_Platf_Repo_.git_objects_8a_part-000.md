---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/8a
part_index: 0
files_included: 3
size_bytes_sum: 1181
created_at: 2025-08-31T21:08:15.626789+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/8a/426a1791374f3157bb99e162a115c6039bd7c4
meta: {size:119, lines:0, sha256:"4d2860e719ff37b554b4b5748e0643c53a69dccf9ceccb1701e8659254161a66", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8a/689a5473d9fabee62a3b88da3071620b63c7d1
meta: {size:759, lines:0, sha256:"62b64f17d2cabe7fcc80dba9019c35b175fdfbf64f337785cab4fd28221caa98", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8a/d3c3af54a9ef6d9a7b04acab4d1312f0040d3f
meta: {size:303, lines:0, sha256:"d8f63d599987514ae616a794a492455e812a7b525baa1e93089ed80a3ef986be", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

