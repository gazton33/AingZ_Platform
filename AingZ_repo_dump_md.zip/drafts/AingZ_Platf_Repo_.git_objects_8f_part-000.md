---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/8f
part_index: 0
files_included: 15
size_bytes_sum: 11653
created_at: 2025-08-31T21:08:15.627296+00:00
integrity:
  sha256_concat: 5c063cd656564af6469838d96c25282b8cb4003f50df1dbe4f69e3e813e4ede0
---

## AingZ_Platf_Repo/.git/objects/8f/069ea7fe49488fc3126276e56d1db7fef820d8
meta: {size:51, lines:0, sha256:"358e9317aaeba5aaa404492a200034f662133ff1ab5cf3fe083b9212720e1593", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8f/1bfc69d419e69ec130985d2d0d284bd9f99a2e
meta: {size:416, lines:0, sha256:"71cd294d43d2e9780a84790690b011cce03469434d3de8d1e801f6e1f454f86a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8f/2acdc48c70da75aa2fcdd18bccd2d211654f7b
meta: {size:159, lines:0, sha256:"b525c89b278a0fca228e62c067ad96a74cfd9fc18ec2b9c7227b35dfb58c1af8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8f/2fe9f2a21d60880e4710712d624861e43be12f
meta: {size:796, lines:0, sha256:"e90c11ce551ef79276cceed367b10d5f6d1511b71fa56917a77744d03acb433c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8f/30b112f95b4438699544e49d7e7a3c7a7ea3fe
meta: {size:51, lines:0, sha256:"daa2a639cc02af2fb63f746744d55219ba9d1646e1336f6dc8f0112e193dc6e5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8f/484b7ed9cc488143bf18f2d4aca4ab36810608
meta: {size:5683, lines:0, sha256:"57bc9a4ccc00f10894d7c3aa3a266c879af7c858b4a5eb64b7a3f6c0458f766c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8f/4924d773d6b649f86be1ad544aaec9bae1ffe4
meta: {size:508, lines:1, sha256:"de0977c355520257f91fa1056338e5768f3d7bb7c2676e544a4b13a7c7af8711", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x}Mo19çW¼RÃn8l/*q@|J ywg·mù#!P~Wïü2lïGwô²g¿3y·ªÄb±|ùäT ßp·õåü Ìm#ÔÁÎkÁÝa]2KKZïWùq'fíÂWøß÷xsýá3^w>­fJ3 Z×Üjæªm¿fÌ[Ë´ªt$-`Õ!À*ríùF	mD0^Ú,/½t>Ìu)eéDG.CÛåÕª[å["&¼¥P­+3¯ºôå~4"q£hÅÐPh>«I0wX¯ÿ×x{t[%iL'ärÿb Në´D¶'ÇSà|/ç'õ®¥uLvì Ràn8­²4×àÝ,ózcXM1z¢ûÎËvö@¤ñ4®#ÌY²ÿ«¢´ÛÊpíì<ù%Iäú»»®%ñ4Îp¥4gáNÁ,oªI2½)AF©¼ÁWdÍäÝãÛÜ6°Æcc½V/Â1ê¥×2ÁC´æ²¦ïùUr¬÷W.jGº½w>j¡Xfo!ö9õOXÖcYµõüô§k?î`ÑÉc¿`2Ñó7Ï$yúÈIò_SøÞb^Å
```

## AingZ_Platf_Repo/.git/objects/8f/75e9e156f8e0f8b17f824bf0e86462672cbf89
meta: {size:862, lines:0, sha256:"6334a7a49d4cfe211b49fe2608d49e0cf022d4482a928149975f42738d891f4f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8f/8b9998ac566b63a3a1360ff18ff1c35510c8ba
meta: {size:634, lines:0, sha256:"a083d1eb5734cfffefe2a577eae5e5777095745e76b1f08cb9fcc6f400ee9365", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8f/8f68763be16f0099e42614c9ba49d0bc8bba2b
meta: {size:98, lines:0, sha256:"25d658dd6db422e06cf14fc4697cefdf0312f6539657406dd34238a310d6065e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8f/93de2227b6e9d4f40eb73985c6c5adc33e355e
meta: {size:467, lines:3, sha256:"47735bdad8b84bc71d5b8b889b0319e0e5ab0220e33345e85792f5b8091d5b67", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x­ÏNÛ@Æ{æ)VâBÆhE¯Hñ)R©·ÑÄ»vì3^'ªé³ôÅ:vBS
©µÖz~3úæñ¢¤¿DñÓS5ÃÚÂÖSõë§·©³$J>Ñep}<Y«ûÖ£³j­&¦ñÖªêVÎ¤ÖòMr7<åíêëdNoç)Äá&nÙÖaNÉw³ù7ÈúM­jßWZhwéÍä:½§CÿeZ×xn³Ì3G>F~j-Â±Ñ9>.Ñu¨^_r  ~h§«'· dm]E7ZÛûôj2KG'ááØWß ¼d¶q5ºª¿±ÂJMy.·¨ÛÜqX>±ÕÖïLÝ·rEü´jjñ·K¥X~ýpEÉ§ôk6ÑÆeÿÚñH*ôl»W¹/}aMBÑûÜÒ\ÔyKýxC¸Ø¢Ñ»tàáB5g<i7c¿L@e*b|·²åTÞ1¢Ã¦î
oêÝ¡ån»·oïxz[lÖG5@ß?C¡[ [¥e¬óþw!ùÑj¼à?;º§¾&þ ïfÛ
```

## AingZ_Platf_Repo/.git/objects/8f/c91caa8567665fedf0dd4851b77db397d2253a
meta: {size:962, lines:0, sha256:"0ecdc13eaa8572de974c1b16eee62afd849ab9d6ac790de45e680751b3b7bbb3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8f/cdf7d8dc463b361110e794bd60210aa5629275
meta: {size:62, lines:0, sha256:"db50af66b9d21c559657d07a24e13f7dbe807a13b46e091150bce69eb3577784", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8f/da37ae6e827ccc3262cca2bb6fd6e8a52d0a0b
meta: {size:643, lines:0, sha256:"2121756d8ccd852d47ad47d7dfae608e11c60b4f79e41c11972906740622b03c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8f/db221f94e32a2d96c9f5e46139f8c4fa460bd1
meta: {size:261, lines:0, sha256:"bd3fb58bd52c3e77621973195781e521021f734a83c5c6953455651e31c1e957", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

