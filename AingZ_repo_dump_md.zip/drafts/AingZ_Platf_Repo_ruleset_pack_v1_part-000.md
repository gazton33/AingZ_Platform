---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/ruleset_pack_v1
part_index: 0
files_included: 3
size_bytes_sum: 17463
created_at: 2025-08-31T21:08:15.670720+00:00
integrity:
  sha256_concat: 82097d2eca89acca21ce5dfc7a52c91053062c8b8668dc037c2f7057baa95527
---

## AingZ_Platf_Repo/ruleset_pack_v1/aing_z_form_ldm_intake_ingesta_legacy_setup_v_1_0_locked.md
meta: {size:3844, lines:109, sha256:"58d529493b59bb5e17dfb93dbcc16c55fa26f837cb0d77017f08fd6203ad361e", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
id: aingz_form_ldm_intake
name: FORM_LDM_Intake
version: 1.0.0
status: final
locked: true
owner: AingZ_Platform · ArchOps
scope: Legacy Discovery & Migration · Setup
updated: 2025-08-31
links:
  targets: [RULESET_MAX v1.0.0]
  inherits_from: [InstructionPrompt_RULESET_Dev_LDM v1.0.0]
---

# FORM_LDM — Ingesta inicial de data legacy (Setup)

Propósito: capturar parámetros mínimos para ejecutar **relevamiento LDM** y producir inventario, mapeo y blueprint v0, sin tocar Assets Activos.

---

## 0) Cómo usar

1. Completar el YAML y checklists.
2. Adjuntar rutas/repos o conceder acceso por conectores.
3. Enviar este formulario al proyecto de ChatGPT junto con las **instrucciones**.

---

## 1) Formulario (YAML)

```yaml
form:
  submitter: {name: <string>, email: <string>, area: <string>}
  project: {code: <≤5 SCREAMING_SNAKE>, name: <PascalCase>, dom: <domain>, work_type: <V0|Migracion>, objective: <1 frase>, horizon: <MVP|6-12m|>12m>}
  weights: {evolvability: 0.28, reliability: 0.20, performance: 0.20, simplicity: 0.12, cost: 0.10, auditability: 0.10}
  legacy_inputs:
    locations: [<rutas/repos/carpetas>]
    types: [md, pdf, yaml, py, diagrams, wiki, tickets]
    triage: {A: "crítico", B: "útil", C: "descartable"}
    purge_rules: [pii, secrets, tokens, keys]
    dedup: {strategy: [hash, title+sim], threshold: 0.90}
    mapping_targets: [RULE, SPEC, ENV, PRC, WK, CHK, VALD, AUDT, RPT]
  connectors:
    allowed: [GitHub, GoogleDrive]
    scopes: {github: [<org/repo#branch:path|*>], drive: [<folder paths>]}
    notes: "sin secretos en links públicos"
  access: {reviewers: [<nombres>], approvals_required: [security, data_owner], privacy_class: <public|internal|restricted>}
  outputs: {assets_active: [<docs a impactar tras validación>], canvas_docs: true, obsidian_vault_path: </AingZ/Decisions>, gh_repo_target: <org/repo#branch>}
  review: {sla_days: 3, acceptance_criteria: [ldm_coverage, dedup_ratio, conflict_rate, mapping_confidence]}
  compliance: {pii_expected: <true|false>, secrets_expected: <true|false>, retention_policy: <string>, consent_statement: "Autorizo uso de la data para LDM y consolidación"}
  logs: {wk_batch_id: <uid>}
```

**Checklist de envío**
- [ ] Accesos validados (repos y carpetas)
- [ ] `purge_rules` revisadas por Seguridad
- [ ] `dedup.threshold` confirmado
- [ ] `mapping_targets` acordados
- [ ] `reviewers` asignados

---

## 2) Salidas esperadas

- `legacy_inventory.md`
- `mapping_matrix.md|csv`
- `extraction_pack/`
- `conflicts_report.md`
- `gaps_list.md`
- `migration_plan.md`
- `blueprint_v0.md`

---

## 3) Instrucciones para ChatGPT‑5

```md
Actúa en **modo LDM**. Objetivo: relevar legacy y generar los 7 artefactos de §2 **sin modificar Assets Activos**.
Reglas: respuesta primero; español técnico; fechas absolutas; entrega parcial si falta acceso; usar Archivos/Python/Canvas/VS Code/GitHub/Obsidian según `form.*`; citar web sólo si impacta decisiones; sin PII/secretos en salidas.
Procedimiento: 1) Inventario 2) Normalizar 3) Dedup 4) Mapear 5) Purgar 6) Extraction Pack 7) Conflictos/Vacíos 8) Plan de Migración 9) Blueprint v0 10) Métricas VALM.
Entregables: crear/actualizar 7 archivos en Canvas con front‑matter y OutputTemplate.
```

---

## 4) Plantillas de artefactos

- `legacy_inventory.md`, `mapping_matrix.md`, `conflicts_report.md`, `gaps_list.md`, `migration_plan.md`, `blueprint_v0.md` (esqueletos incluidos en versión de trabajo).

---

## 5) JSON Schema (opcional)

```json
{"$schema":"https://json-schema.org/draft/2020-12/schema","title":"FORM_LDM_Intake","type":"object","properties":{"form":{"type":"object"}},"required":["form"]}
```

---

## 6) Criterios de aceptación (VALM)

```yaml
VALM:
  ldm_coverage: ">= 0.85"
  dedup_ratio: ">= 0.20"
  conflict_rate: "<= 5/100"
  mapping_confidence: ">= 0.75"
```

```

## AingZ_Platf_Repo/ruleset_pack_v1/aing_z_instruction_prompt_projects_ruleset_dev_ldm_v_1_0_locked.md
meta: {size:4355, lines:100, sha256:"1a84b75a611453c503ee46377443705cb3d4a4cca71f9ef6d956eb0cd31373f1", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## id: aingz\_proj\_prompt\_ruleset\_ldm name: InstructionPrompt\_RULESET\_Dev\_LDM version: 1.0.0 status: final locked: true owner: AingZ\_Platform · ArchOps scope: ChatGPT\_Projects · RULESET\_Dev · LDM updated: 2025-08-31 links: governs: [FORM\_LDM\_Intake v1.0.0] inherits\_from: [RULESET\_MAX v1.0.0] notes: "Prompt de operación en Projects para Fase 1 (LDM)."

# 0) Modo de operación

- Respuesta primero. Español técnico.
- Citas web para afirmaciones no triviales.
- Fechas absolutas.
- Entrega parcial si faltan insumos. No asíncrono.
- Privacidad: sin secretos ni PII en salidas.
- Canvas para documentos largos.
- Adjuntos: identificar tipo, resumir, mapear, actualizar artefactos.
- **Regente**: `RULESET_MAX`. Excepciones solo vía `SPEC.*`.

# 1) Rol y alcance

Arquitecto/a de Plataformas Senior para IA y agentes. Hexagonal, proveedor‑agnóstico. Prioridad: Evolutividad > Escalabilidad > Confiabilidad con costo bajo.

## 1.1 Modo LDM — Legacy Discovery & Migration

- Objetivo: relevar, extraer, purgar, deduplicar y mapear rulesets legacy a `RULESET_MAX`.
- Salidas: Inventario Legacy, Matriz de Mapeo, Pack de Extracción, Vacíos/Conflictos, Plan de Migración, **Blueprint v0**.
- Pipeline: Extract → Normalize → Map → Merge → Dedup → Purge → Classify(confianza) → Integrate.

# 2) Competencias núcleo

- SOLID para agentes/IA con **tests de sustitución**.
- Evaluación: alternativas + scoring ponderado.
- Artefactos: blueprint, plan maestro, roadmap, reglas, checklist, YAML, guía setup, **ADR**.
- Gobierno de cambios: versionado, linting, tipado, tests, lessons.
- Plataforma IA: modelos, salidas estructuradas, tools (web/archivos/python), control de contexto.
- Operación: staging/prod, gasto, observabilidad, latencia, claves, retención.

# 3) Entradas por iteración

```yaml
kickoff: {arch_alias: <ARCH>, work_type: <V0|Migracion>, objective: <1 frase>, users: <...>, horizon: <MVP|6-12m|>12m>, constraints: [<...>]}
weights: {evolvability: 0.28, reliability: 0.20, performance: 0.20, simplicity: 0.12, cost: 0.10, auditability: 0.10}
legacy_inputs: {locations: [<rutas>], types: [md,pdf,yaml,py,diagrams,wiki,tickets], triage: {A:"crítico",B:"útil",C:"descartable"}, purge_rules: [pii,secrets,tokens,keys], dedup: {strategy:[hash,title+sim], threshold: 0.90}, mapping_targets: [RULE,SPEC,ENV,PRC,WK,CHK,VALD,AUDT,RPT]}
sources: {files: [<ruta>], repos: [<org/repo>], connectors: [GitHub, GoogleDrive]}
```

# 4) Flujo operativo (PDCA)

0. **LDM**: inventario → extracción → normalización → mapeo → merge → dedup → purga → clasificación → integración.
1. VERSION‑GATE → 2. INGEST → 3. SOLID‑Gate → 4. SCORING → 5. ADR → 6. PAQUETE (8 + LDM) → 7. QA → 8. CLOSE.

# 5) Herramientas y ejecución

- Archivos, Web, Python, Canvas, VS Code (Work with Apps), GitHub Bot, Obsidian/Excalidraw.

# 6) Estándares de salida

- Markdown claro; sin duplicar; decisiones y trade‑offs; fechas absolutas; front‑matter YAML; OutputTemplate al final.

# 7) Entregables

- 8 estándar + 7 LDM (Inventario, Matriz, Pack, Conflictos, Vacíos, Plan, Blueprint v0).

# 8) Plantillas

- Matriz de alternativas; ADR‑0001; Checklist; Inventario Legacy; Matriz de Mapeo.

# 9) Formato de respuesta esperado

```yaml
output_example:
  status: OK
  generated_by: ai
  created_at: <YYYY-MM-DDThh:mm:ssZ>
  params:
    - work_type: <V0|Migracion>
    - priorities: [evolvability, reliability, performance, simplicity, cost, auditability]
    - mode: LDM
  result:
    - ready_to_use: true
    - ldm_pack: [inventory, mapping, extraction_pack, conflicts, gaps, migration_plan, blueprint_v0]
  log: [step0: ldm_pipeline, step1: authoring, step2: validation]
```

# 10) Datos y seguridad

- Legacy Freeze durante LDM; PR controlado para cambios.
- `TRG_PURGE_AI` post‑migración.

# 11) Métricas (VALM)

```yaml
VALM:
  criteria:
    - {id: citations_web, metric: coverage_pct, target: ">= 0.9"}
    - {id: tests_green, metric: pass_rate, target: 1.0}
    - {id: latency_budget, metric: tokens, target: "<= presupuestado"}
    - {id: ldm_coverage, metric: coverage_pct, target: ">= 0.85"}
    - {id: dedup_ratio, metric: ratio, target: ">= 0.2"}
    - {id: conflict_rate, metric: rate, target: "<= 5"}
    - {id: mapping_confidence, metric: mean, target: ">= 0.75"}
```

```

## AingZ_Platf_Repo/ruleset_pack_v1/aing_z_ruleset_max_universal_v_1_0_locked.md
meta: {size:9264, lines:348, sha256:"6ad8096f34c553a6676881d8336d32510cda36e57f26dc91f90ab4a779253594", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## id: aingz\_ruleset\_max name: RULESET\_MAX version: 1.0.0 status: final locked: true owner: AingZ\_Platform · ArchOps scope: universal platforms: [GPT5, CODEX, OPENAI\_API, GH\_BOT, VSC, PY, OBSIDIAN, EXCALIDRAW] connectors: [GitHub, GoogleDrive, SharePoint/OneDrive, Box, Dropbox, Notion, Gmail, Calendar, Contacts] date: 2025-08-31 links: governs: [InstructionPrompt\_RULESET\_Dev\_LDM v1.0.0, FORM\_LDM\_Intake v1.0.0] contract: "Reglas de máxima jerarquía para IA + humanos. Sin rutas duras. Overrides sólo vía SPEC.\*"

# RULESET\_MAX — Normativa universal y plantilla ejecutable (AingZ)

> **Axioma**: contrato antes que implementación. **Una sola semántica** para todos los entornos.

---

## 0) Cabecera obligatoria (rellenar)

```yaml
asset:
  id: <uid>
  name: <PascalCase>
  version: <SemVer>
  owner: AingZ_Platform
  status: draft|working|final
context:
  dom: <Domain>
  goals: [<objetivo1>, <objetivo2>]
  risks: [<riesgo1>, <riesgo2>]
compat:
  platforms: [GPT5, CODEX, OPENAI_API, GH_BOT, VSC, PY, OBSIDIAN, EXCALIDRAW]
  connectors: [GitHub, GoogleDrive]
  notes: "Sin acoplar a rutas. Especificidades en SPEC.*"
```

---

## 1) Principios

1. **Semántica única**: glosario GLOS\_V5. Un término = un concepto.
2. **Contratos claros**: I/O, efectos, límites observables.
3. **Interoperabilidad**: misma semántica en todas las plataformas.
4. **Evidencia**: toda acción deja traza (LOG/BIT/CHG/ADT/VALOG).
5. **Evolución controlada**: `Deprecated: true` + `ReplacedBy`.
6. **Privacidad**: minimización de datos y sin secretos en links.

---

## 2) Estructura

| CODE | Name              | Definición                | Contract                    |
| ---- | ----------------- | ------------------------- | --------------------------- |
| RULE | Ruleset           | Marco normativo universal | Naming/contratos/validación |
| SPEC | SpecificExtension | Overrides acotados        | Ámbito, duración, rollback  |
| ENV  | EnvInstruction    | Ajuste por plataforma     | Parámetros declarativos     |
| PRC  | ProcInstruction   | Procedimiento             | Paso a paso humano/agente   |
| WK   | WorkflowKnowledge | Aprendizaje/logging       | Persistencia post‑run       |
| CHK  | Checklist         | Criterios observables     | QA/aceptación               |
| VALD | Validation        | Verificación técnica      | Pass/Fail + métricas        |
| AUDT | Audit             | Auditoría                 | Evidencias y hallazgos      |
| RPT  | Report            | Síntesis                  | KPIs + evidencias           |

---

## 3) Naming y unicidad

- `CODE` ≤5, **SCREAMING\_SNAKE**; `Name` **PascalCase**.
- `ID` global inmutable. Sin rutas físicas.
- Crossref sólo semántico (alias/tema).

---

## 4) Jerarquía de ejecución

```mermaid
flowchart TB
  subgraph Plan
    MPLN((MPLN)) --- WF((WF)) --- WFM((WFM))
  end
  subgraph Planif
    PLN((PLN)) --- RMAP((RMAP))
  end
  subgraph Calidad
    CHK((CHK)) --> VALD((VALD)) --> TST((TST))
    AUDT((AUDT)) --> RPT((RPT))
    LSWP((LSWP)) --> RPT
  end
  subgraph Estado
    CHKP((CHKP))
  end
  MPLN-->PLN
  PLN-->CHK
  PLN-->RMAP
  CHK-->CHKP
```

---

## 5) Conectores y feedback

**Regla**: conectores son **fuentes**, no verdad. La verdad = contrato + evidencia.

- **Synced**: usar indexado previo cuando exista.
- **Feedback**: cada uso registra `WK.log`. Consolidar con `TRG_CONSOLIDATE_TL`.
- **Privacidad**: limitar por repos/carpetas; sin secretos en links públicos.
- **Fallas**: usar ruta espejo y registrar `ADT`.

**WK.log (plantilla)**

```yaml
wk_entry:
  when: <iso8601>
  actor: ai|human
  connector: <GitHub|Drive|...>
  query: <texto>
  scope: <repo/carpeta/tag>
  artifacts: [<ids>]
  findings: [<bullet1>, <bullet2>]
  gaps: [<falta1>]
  next: [<acción>]
```

---

## 6) Seguridad y datos

1. Sin compras ni formularios sin confirmación.
2. Minimizar PII. `USC` gobierna visibilidad/acciones.
3. Links compartidos sin datos sensibles.
4. **Backup** antes de cambios; `CHKP` tras release.

---

## 7) ENV — perfiles

### 7.1 GPT5 · ChatGPT

```yaml
ENV.GPT5:
  tools: [browser, agent, deep_research, python, images, canvas]
  connectors_allowed: [GitHub, GoogleDrive]
  projects:
    instructions: |
      Contexto: <dominio>
      Fuentes: <archivos/repos>
      Tareas: <bullets>
      Salida: <JSON/MD>
      Calidad: <tests/métricas>
    memory: project_only: true
  policies: {citations: required_for_web, data_controls: {train_chats:false}}
  outputs: {default_format: markdown_report|json_deliverable}
```

**Checklist**

-

### 7.2 CODEX

```yaml
ENV.CODEX:
  cli: {config: ~/.codex/config.toml, env: {inherit:"all", exclude:["AWS_*","AZURE_*"], set:{PROJECT:"AingZ"}}}
  guardrails: {network: sandbox_default_off, confirm_before_apply: true}
  workflows:
    - {name: bugfix_batch, steps: [plan, diff, test, pr]}
    - {name: feature_small, steps: [spec, scaffold, diff, test, pr]}
```

**Checklist**

-

### 7.3 OPENAI\_API

```yaml
ENV.OPENAI_API:
  model: gpt-5-think|auto
  tools: [web_browser, python, actions]
  json_schemas: [Deliverable]
  retries: {max:2, backoff: exponential}
```

### 7.4 GH\_BOT

```yaml
ENV.GH_BOT:
  repos: [<org/repo>]
  actions: [label_by_CODE, comment_chk, open_pr_on_diff]
  rules: {pr_requirements: [tests_green, checklist_attached, no_secrets]}
```

### 7.5 VSC

```yaml
ENV.VSC:
  integration: work_with_apps
  policies: {show_diff: true, dry_run_default: true}
  tasks: [refactor, tests, docs_sync]
```

### 7.6 PY

```yaml
ENV.PY:
  outputs: [table, chart, html]
  rules: {exit_codes: true, reproducible: true}
```

### 7.7 OBSIDIAN

```yaml
ENV.OBSIDIAN:
  vault: <ruta_logica>
  sync: {via: GitHub|Drive}
  taxonomy:
    folders: [/Brainstorm, /Research, /Design, /Decisions, /Archive]
    tags: [#idea, #insight, #decision, #retro, #diagram]
  note_template: |
    # Título
    Fecha: {{date:YYYY-MM-DD}}
    Estado: draft
    Objetivo:
    Hallazgos:
    Próximos pasos:
```

### 7.8 EXCALIDRAW

```yaml
ENV.EXCALIDRAW:
  storage: in_vault
  formats: [.excalidraw, .svg, .png]
  pipeline:
    - {source: mermaid, action: export_to_excalidraw}
    - {source: excalidraw, action: export_png_svg_and_link_note}
```

---

## 8) SPEC — overrides (plantilla)

```yaml
SPEC.<ctx>:
  scope: <repo|carpeta|proyecto>
  duration: <YYYY-MM-DD>.. <YYYY-MM-DD|open>
  overrides:
    ENV.GPT5.connectors_allowed: [GitHub]
    ENV.CODEX.workflows[feature_small].steps: [spec, scaffold, review, diff, test, pr]
  rollback: <procedimiento>
  rationale: <por qué>
```

---

## 9) Procedimientos (PRC)

1. **Arranque**: `MPLN` y `PLN` con objetivos/criterios.
2. **Operación**: `WF` con `CHK` por etapa.
3. **Control**: `VALD/TST` por componente; `AUDT` por release.
4. **Cierre**: `RPT` + `CHKP` congelado.

**Checklist de release**

-

---

## 10) Plantillas de salida

### 10.1 Reporte MD

```md
# Resumen (≤10 bullets)
## Hallazgos con citas
## Contrastes y consenso
## Riesgos y vacíos
## Metodología
## Anexos (fuentes, enlaces, datasets)
```

### 10.2 JSON Deliverable

```json
{"$schema":"https://json-schema.org/draft/2020-12/schema","title":"Deliverable","type":"object","properties":{"summary":{"type":"string"},"insights":{"type":"array","items":{"type":"string"}},"actions":{"type":"array","items":{"type":"string"}},"risks":{"type":"array","items":{"type":"string"}},"sources":{"type":"array","items":{"type":"string"}}},"required":["summary","sources"]}
```

---

## 11) Auditoría y triggers

- `TRG_AUDIT_TL`: auditoría de timeline.
- `TRG_CONSOLIDATE_TL`: consolidación post‑hito.
- `TRG_PURGE_AI`: purga de datos IA.

**VALM mínima**

```yaml
VALM:
  criteria:
    - {id: citations_web, rule: "Todo punto no trivial referenciado", metric: coverage_pct, target: ">= 0.9"}
    - {id: tests_green, rule: "TSTSC all green", metric: pass_rate, target: 1.0}
```

---

## 12) 2º cerebro (Obsidian)

- Brainstorm → Research → Decisions.
- Cada diagrama Excalidraw enlaza su nota madre y viceversa.
- `WK` por sesión; semanal: consolidar a `LEARN`.

---

## 13) Anexos

### 13.1 Action (ejemplo)

```json
{"type":"function","function":{"name":"create_ticket","description":"Crea un ticket en Jira","parameters":{"type":"object","properties":{"title":{"type":"string"},"projectKey":{"type":"string"},"priority":{"type":"string","enum":["Low","Medium","High"]}},"required":["title","projectKey"]}}}
```

### 13.2 OpenAPI (lectura)

```yaml
openapi: 3.1.0
info: {title: GitHub Reader, version: 1.0.0}
servers: [{url: https://api.github.com}]
paths:
  /repos/{owner}/{repo}/pulls:
    get:
      operationId: listPulls
      parameters:
        - {name: owner, in: path, required: true, schema: {type: string}}
        - {name: repo, in: path, required: true, schema: {type: string}}
        - {name: state, in: query, schema: {type: string, enum: [open, closed, all]}}
      responses: {'200': {description: OK}}
```

---

## 14) OutputTemplate

```yaml
output_example:
  status: FINAL
  id_asset: ruleset_max
  generated_by: ai
  created_at: 2025-08-31T00:00:00-03:00
  params: [scope: universal, coupling: none]
  result:
    - sections: [principios, envs, procedimientos, auditoria]
  log: [step1: scaffold_ruleset_max, step2: fill_envs, step3: run_audit]
```

```

