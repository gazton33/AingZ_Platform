---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/95
part_index: 0
files_included: 6
size_bytes_sum: 6499
created_at: 2025-08-31T21:08:15.627887+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/95/0996362a51b31f8aec791277629fc152fb8010
meta: {size:2184, lines:0, sha256:"6cf237f89e5512903938cd5d6d8e5d4f2a175cd1707a6d04d917f20acf5a9c6a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/95/0ce217d0a6dd927ff98ec1593f57d8190d13b2
meta: {size:1740, lines:0, sha256:"7416f80b8c6bba15c254e1e5fd71dd7aa1cb5345b1cdaf437bf15716323a48bc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/95/71f89b8465ec1c04cb99c79569938a126745da
meta: {size:800, lines:0, sha256:"554b4429596a8bef58176b5ea96783b0dfbcbc76b181b96bedb4a485d7bdb79d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/95/8188cbdfbe142d3c75d51b0e708c93ffab0029
meta: {size:138, lines:0, sha256:"08d7d0ea78b215775bcafbaf8dcf67f030c83ba96ef3f384eb3046837af0a037", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/95/bdd816e50bfd614e57b214a75605aef0ed4768
meta: {size:1115, lines:0, sha256:"8c959e6822982c909582ccbd680d47deb5e250970782540a575c2726a0ab33d7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/95/c6ba6a98e270cbdb6d2ed62eee7c791e117aa1
meta: {size:522, lines:0, sha256:"4e574159d519beaafbb502436d62d542ffb0419de4c4d22882186ecfcb362d83", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

