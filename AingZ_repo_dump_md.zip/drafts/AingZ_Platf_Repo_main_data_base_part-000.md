---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/main/data_base
part_index: 0
files_included: 2
size_bytes_sum: 12597
created_at: 2025-08-31T21:08:15.670322+00:00
integrity:
  sha256_concat: db2c35020a405969e6f1d25cbc49b16bc2c2880c506c760520aa79f73c139e9f
---

## AingZ_Platf_Repo/main/data_base/dir_tree_v_1_4_baseline_locked.md
meta: {size:8024, lines:111, sha256:"fbac6dcebb4d65106fe3946fbb85c804f16574fafc26a407ea1e34a0f54d907e", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: core/doc/workbench/dir_tree_v_1_4_baseline_locked.md code: ARBBL name: DirTreeV14BaselineLocked version: v1.4.2 date: 2025-08-18 owner: AingZ\_Platform · RwB status: locked referencias: [DirTreeV14Aligned, aing\_z\_v\_5\_dir\_tree\_v\_1.md] triggers: [TRG\_BASELINE\_LOCK] cambios:

- 2025-08-18: Freeze de la vista alineada con notas y códigos. checks:
- Vista ASCII con columnas fijas
- Índice de códigos presente
- Descripciones breves coherentes

---

# Baseline Lock — Árbol de Directorios v1.4.2

**Baseline-ID**: BL-2025-08-18-DirTree-v1.4.2\
**Origen**: DirTreeV14Aligned (v1.4.2)\
**Alcance**: Estructura visual con [CODE] y descripción alineados.

> Estado congelado. Cualquier cambio futuro debe realizarse en un *working copy* y proponer nuevo lock.

## Árbol congelado

```text
AingZ_Platform                                        [ROOT]  — raíz del repositorio
├── main                                              [MAIN]  — código y datos activos
│   ├── data_base                                     [DB]    — base de conocimiento
│   │   ├── core_actv                                 [CACT]  — activos nucleares
│   │   │   ├── docs                                  [DOCS]  — media y documentación
│   │   │   │   ├── audio                             [AUD]   — insumos de audio
│   │   │   │   ├── image                             [IMG]   — insumos de imagen
│   │   │   │   ├── video                             [VID]   — insumos de video
│   │   │   │   ├── library                           [LIB]   — papers y libros
│   │   │   │   └── onboard                           [ONB]   — materiales de onboarding
│   │   │   ├── data                                  [DATA]  — datasets y metadatos
│   │   │   │   ├── semantics                         [SEM]   — semántica de plataforma
│   │   │   │   │   ├── glossary                      [GLOS]  — glosarios
│   │   │   │   │   ├── dicts                         [DICT]  — diccionarios
│   │   │   │   │   ├── code_dict                     [CDCT]  — mapeos de código
│   │   │   │   │   ├── trigger_dict                  [TDCT]  — dicc. de triggers
│   │   │   │   │   ├── app_dict                      [ADCT]  — apps y aliases
│   │   │   │   │   ├── prompt_dict                   [PDCT]  — prompts estándar
│   │   │   │   │   ├── ingest_prompts                [INGP]  — prompts de ingesta
│   │   │   │   │   ├── vocabulary                    [VOC]   — vocabulario controlado
│   │   │   │   │   └── ruleset                        [RSET]  — reglas y políticas
│   │   │   │   ├── ai_learn                          [AILE]  — aprendizaje de la IA
│   │   │   │   │   ├── learning                      [LEARN] — currícula
│   │   │   │   │   ├── evaluation                    [EVAL]  — evals y métricas
│   │   │   │   │   ├── insights                      [INSI]  — hallazgos
│   │   │   │   │   ├── fine_tuning                   [FTUN]  — ajustes finos
│   │   │   │   │   ├── few_shot                      [FSHT]  — ejemplos canónicos
│   │   │   │   │   ├── relevance                     [RELV]  — ranking/recall
│   │   │   │   │   ├── training                      [TRNG]  — sesiones de training
│   │   │   │   │   └── feedback                      [FDBK]  — retroalimentación
│   │   │   │   ├── develop                           [DEVP]  — desarrollo de plataforma
│   │   │   │   │   ├── ruleset                       [RDEV]  — reglas de dev
│   │   │   │   │   ├── config                        [CNFG]  — configuración
│   │   │   │   │   ├── setup                         [SETUP] — instalación
│   │   │   │   │   ├── customization                 [CSTM]  — personalización
│   │   │   │   │   ├── specs                         [SPECS] — especificaciones
│   │   │   │   │   ├── preferences                   [PREF]  — preferencias
│   │   │   │   │   ├── connectors                    [CNTR]  — puertos/adaptadores
│   │   │   │   │   └── orchestrator                  [ORCH]  — orquestador/wf
│   │   │   │   ├── out_template                      [OTPL]  — plantillas de salida
│   │   │   │   │   ├── mtx                           [MTX]   — matrices comparativas
│   │   │   │   │   │   ├── matrix                    [MATR]  — scoring
│   │   │   │   │   │   ├── table                     [TBLS]  — tablas
│   │   │   │   │   │   ├── record_sheet              [RCSH]  — planillas
│   │   │   │   │   │   ├── mapping                   [MAPP]  — mapeos
│   │   │   │   │   │   ├── relation                  [RELN]  — relaciones
│   │   │   │   │   │   ├── validation                [VALD]  — validaciones
│   │   │   │   │   │   └── comparison                [COMP]  — comparativas
│   │   │   │   │   ├── docs                          [OTPD]  — docs para outputs
│   │   │   │   │   ├── workspaces                    [WSPC]  — espacios de trabajo
│   │   │   │   │   ├── platform_arch                 [PARCH] — arq de plataforma
│   │   │   │   │   └── ai_tools                      [ATOOL] — herramientas IA
│   │   │   │   └── guides                            [GUID]  — guías operativas
│   │   │   │       ├── planin                        [PLIN]  — planeamiento
│   │   │   │       │   ├── mpln                      [MPLN]  — master plan
│   │   │   │       │   └── brainstorm_crtv           [BCRT]  — ideación
│   │   │   │       ├── run_control                   [RCTL]  — ejecución/QA
│   │   │   │       └── pipeline                      [PIPE]  — flujos/ETL
│   │   │   ├── wf_playbooks                          [WF]    — playbooks de workflows
│   │   │   └── kns_ctx_vivo                          [KCTX]  — contexto vivo
│   │   ├── core_dev                                  [CDEV]  — desarrollo núcleo
│   │   └── core_arch_platform                         [CARC]  — arq. de plataforma
├── log                                               [LOG]   — cambios y calidad
│   ├── changelog                                     [CHG]   — registro de cambios
│   ├── validation                                    [VALG]  — logs de validación
│   └── qms                                           [QMS]   — calidad y normas
├── .github                                           [GIT]   — CI/CD y workflows
├── packages                                          [PKG]   — paquetes y módulos
├── ruleset                                           [RULE]  — políticas del repo
└── scripts                                           [SCRIP] — utilidades y tareas
```

---

## OutputTemplate

```yaml
output_example:
  status: BASELINE_LOCKED
  baseline_id: BL-2025-08-18-DirTree-v1.4.2
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - files_frozen: [core/doc/workbench/dir_tree_v_1_4_baseline_locked.md]
  log:
    - step1: qa_pass
    - step2: checkpoint
    - step3: freeze
```

```

## AingZ_Platf_Repo/main/data_base/glossary_baseline_v_1_locked.md
meta: {size:4573, lines:63, sha256:"e3f0f5a1a31d02ecc6b061934ed82909400185f2ef11900a7f704579b8aed9ee", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: core/doc/workbench/glossary_baseline_v_1_locked.md code: GBL name: GlossaryBaselineV1 version: v1.0.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: locked referencias:

- GREAL (GlossaryRealV1)
- GTBL (Glossary\_Template\_Baseline\_v1.1\_Locked)
- DTTBL (DirTree\_Template\_Baseline\_v1.1\_Locked)
- PCTRL (PlatformControlPrinciplesV1) triggers: [TRG\_BASELINE\_LOCK, TRG\_GLOSSARY] cambios:
- 2025-08-18: Baseline real del glosario bloqueado según template. checks:
- IDs únicos prefijo GLOS::
- Refs sólo a buckets DIR::
- Sin rutas de archivos ni anclas

---

# Baseline Lock — Glosario v1.0.0

**Baseline-ID**: BL-2025-08-18-Glossary-v1.0.0\
**Árbol**: BL-2025-08-18-DirTree-v1.4.2\
**Snapshot**: `AINGZ_V5_Glossary_Real_v1.md` validado 2025-08-18

> Estado congelado. Ediciones futuras en *working copy* del glosario y nuevo lock.

## Tabla (snapshot)

| ID (GLOS::)    | Término             | Definición breve                                          | Refs (DIR::)                                 | Sinónimos           | Tags            |
| -------------- | ------------------- | --------------------------------------------------------- | -------------------------------------------- | ------------------- | --------------- |
| GLOS::MAIN     | Glosario principal  | Conjunto de términos canónicos del monorepo.              | [[DIR::SEM]], [[DIR::ROOT]]                  | vocabulario         | #glosario       |
| GLOS::BUCKET   | Bucket              | Agrupador lógico de carpetas y assets para un dominio.    | [[DIR::ROOT]], [[DIR::DB]]                   | carpeta lógica      | #estructura     |
| GLOS::ASSET    | Asset               | Artefacto tangible y versionable bajo control QMS.        | [[DIR::DOCS]], [[DIR::OTPL]], [[DIR::SCRIP]] | artefacto           | #artefacto      |
| GLOS::ENTITY   | Entidad             | Contrato semántico aplicable a datos o procesos.          | [[DIR::SEM]]                                 | concepto            | #semantica      |
| GLOS::RULESET  | Ruleset             | Conjunto de reglas con router por plataforma/app/api.     | [[DIR::RULE]]                                | políticas           | #gobierno       |
| GLOS::PIPE     | Pipeline            | Orquestación declarativa disparada por triggers.          | [[DIR::PIPE]], [[DIR::WF]]                   | flujo               | #orquestacion   |
| GLOS::WFTRIG   | Trigger de workflow | Evento que inicia una ejecución o cambio de estado.       | [[DIR::WF]]                                  | disparador          | #workflow       |
| GLOS::BASELOCK | Baseline lock       | Estado congelado e inmutable de un artefacto.             | [[DIR::LOG]]                                 | freeze              | #qms            |
| GLOS::VREVIEW  | Version review      | Evaluación de deltas, riesgos y recomendación de versión. | [[DIR::OTPD]]                                | revisión de versión | #qms            |
| GLOS::QMS      | QMS                 | Sistema de gestión de calidad, validaciones y normas.     | [[DIR::QMS]]                                 | calidad             | #qms            |
| GLOS::KCTX     | Contexto vivo       | Estado operativo actual para continuidad de procesos.     | [[DIR::KCTX]]                                | estado activo       | #operacion      |
| GLOS::AILE     | AI Learn            | Área de aprendizaje, evaluación y feedback de IA.         | [[DIR::AILE]]                                | mlops               | #ia             |
| GLOS::DEVP     | Develop             | Configuración, conectores y orquestación desacoplada.     | [[DIR::DEVP]]                                | devops              | #plataforma     |
| GLOS::OTPL     | Out Templates       | Plantillas de salida estandarizadas para entregables.     | [[DIR::OTPL]]                                | templates           | #documentacion  |
| GLOS::GUID     | Guides              | Guías operativas y SOPs de la plataforma.                 | [[DIR::GUID]]                                | manuales            | #procedimientos |

## Reglas y Checklist

- Namespaces aprobados.
- Sin enlaces a archivos ni anclas.

## OutputTemplate

```yaml
output_example:
  status: GLOSSARY_BASELINE_LOCKED
  baseline_id: BL-2025-08-18-Glossary-v1.0.0
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - files_frozen: [core/doc/workbench/glossary_baseline_v_1_locked.md]
  log:
    - step1: qa_pass
    - step2: checkpoint
    - step3: freeze
```

```

