---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/3e
part_index: 0
files_included: 8
size_bytes_sum: 5550
created_at: 2025-08-31T21:08:15.572398+00:00
integrity:
  sha256_concat: 1d983754c638b5bf9cc67164c3ca5fe2b3f9a7ecc3e1790b1517cb2b9d75b0ef
---

## AingZ_Platf_Repo/.git/objects/3e/1244051b37b435a63a6518cc2c996e8ace304a
meta: {size:229, lines:0, sha256:"4d25240ab81c16a32d0e197a63ec91bb89c9a78266856ebd4105ee25e28c6864", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3e/17cdef90b1ead46f89d5364a7cad08b6a458bd
meta: {size:128, lines:0, sha256:"d77fbea25624cb40907d3a1d0ff11e86784dab288b61ab82c5d54d8dfd21ad74", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3e/26b2a250513958060388ac7c7273989c1037e4
meta: {size:643, lines:1, sha256:"c38f8b117fd389d257db2a8cc9fd7bd107f8a7b3f3f621c2f3f943f96f192f95", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU070g040031QÐKÏ,I,))ÊL*-I-f¸ÿ EeÓÂùëªäö²~ñÕ¯Iefz^~Q*Ãí?]»ó.¨KÎm¼W5YëÞÃÅöî&@ àêÂÀtcÏé©B¼³²Ú©g7möëöIM,ÊcpPiï;8á¾l>O^úOÜ:µÄ×18Ä5(>ÀÇÑ/ÞÑÓÏ=*ÞÓÏ-(êäªÂà­¹O1üï)ÝÏ¯Ô$.õî²º	ÕäêèâVtk¡OqÿïõZm-qJ[Ï¢(ÞÙÃ1Ä= dâó»¢Û*w2ªyÍ¹=¥Í6ìÁ-ÃÝfÿ² ßm­ª`ÃÇ3êB>«÷AMJÎÏKZ^A%Ãqv	ÇâÝ©.çÕ«~¥¸¾ürÄe)ùÉQ2W7ÉfKw1íøìø«íßË!²Ùyùå9©)éÀÀO;ùÍ÷í®ç%VVªTî?½/k?DQn"0Jx÷ÍYsuÑ±\¹Ë×s?°þvo½m¶ê¢üÊÔäüøÄÌ¼ôøªøÄ¼ÄÌâÌâøÔø¢ÔüâÌü¢Ì|EteÇØWj{ï°¯òÉby(Ð|jJQyXu|JfÈ´¢ÊøÄ¼ø²xCN4£Ï»72Ì^[ÿ%uâËÜM/²!N,N.Ê,()fÝ/æ*#Ç·øuÅ×g½·jöuÔ\ Q%©?/×h:·BsÏÓ;8BTÏÿø-µ¾<5'9?75>?/)?±(äô*ÅGvWØ$+©nÔ_¾$íô.¿¿ÏX!Ç
```

## AingZ_Platf_Repo/.git/objects/3e/2c0adbf3326b4488cb29300f1dcf60a31fd7c1
meta: {size:1463, lines:0, sha256:"b925c709936cbc9c5f3283f9b70f2e6e9598cbf032bfce99bb53228b529f757e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3e/309ba72c9634f123207437cd7a4546ec8d8dd3
meta: {size:2176, lines:0, sha256:"7be6cea3d5dd35a415e4a0f90b35b7bdf27da3df654d8235470fb95ccac2493a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3e/42ffdb5077856ef753b3671d7702d61c5c31de
meta: {size:266, lines:0, sha256:"9d2e07665753781f74ae16779653aea2987515bc0a44b16bec1e4288b2f0e53c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3e/776523d83ff280a3a88a92a3013e1f5a7e948d
meta: {size:362, lines:0, sha256:"122934cbd2cb6b04fe4c81a19f52b60ca110e8e4f12a6b6dafa66417e12e0290", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3e/c57af1a28bba5a57f8b383ef976bb849351da7
meta: {size:283, lines:0, sha256:"2d60f2fd58f0f7cb1cb20c555594512ac03b69e1e60d05764a2e5331ae22e80a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

