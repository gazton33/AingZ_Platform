---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/1f
part_index: 0
files_included: 7
size_bytes_sum: 4217
created_at: 2025-08-31T21:08:15.569140+00:00
integrity:
  sha256_concat: 46ee36e466c7d285a3ea6a6c0e3a92c43a57da2f6110b2e33baf61b324dcffab
---

## AingZ_Platf_Repo/.git/objects/1f/4d11665ecbba59205e3dd2d92ed98f12dab4dc
meta: {size:507, lines:0, sha256:"1ce77c7bfcf33eca92cfdc1c68822fbdab8489d964af6fef0204d6eb13bf7fa5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1f/6970fd0da8795463363419afecd519a2fff584
meta: {size:1067, lines:0, sha256:"30881c011b4d09377d73a0b2923e69f566680783e5b5ceba02a31fc8f41d4127", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1f/779932996520b1b2ea2b370bf795cbbaa37d8c
meta: {size:752, lines:0, sha256:"0384b5dd263dc10b14e67aef0ce1834292e017cfc8c2bd6a993836f35de6a362", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1f/80445710e503236c924de219af6e2824078b51
meta: {size:271, lines:3, sha256:"4537670ad166916991bb32e444542681b77b6d0e69dd7e06613537d2f5807c8d", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuPËNÃ0äÜ¯r¦(Np«à8Nël«m­ÊCü;¶£F7ïÌîÌxv¨wIÁÖß$IFäÆÂ²èÒ¤åhá2p8ÞCi:Î½><ñÎÎ<¸qþs½làYXïÐ=é¹
'ÑrãéÁÌ5#qÄ_^c²é¬Ö ÿ<³ÚéÃuðáîx:iPÆ¿gQMé¶òkN±H¡TÿQSV?¡}5@[G :Í®
Vl¯«ºÌV,êðdy¼éþ=&ÙßJë¸àóbÜµc½AV×¬ª¢¬ó¢jèPøâç¶À}
```

## AingZ_Platf_Repo/.git/objects/1f/82125e201ac52282ecd351e4d76654071e91ff
meta: {size:970, lines:0, sha256:"b9452e56946141663887da825b8e5a16a768798f4665cb7665bcac96d3572a85", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1f/87cde4df8ae4f067f92ada6e894132a84127d0
meta: {size:59, lines:0, sha256:"5622640e935fb2da73dd82a411c8a33913dc9a03ed15ed5384653f018c6db6f8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1f/d0ece9fbd4356ca8bcbc1514dbe3b6ba0e149a
meta: {size:591, lines:0, sha256:"fd9ffd0cd67f1486cc38bd8cf4c6b24858ecc4e5e0e3d45dc5ad3f09b30cf34f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

