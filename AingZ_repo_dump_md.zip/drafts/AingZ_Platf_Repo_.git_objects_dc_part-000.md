---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/dc
part_index: 0
files_included: 12
size_bytes_sum: 8637
created_at: 2025-08-31T21:08:15.649778+00:00
integrity:
  sha256_concat: 8c79af58ec13ae2e229f99e7bd35511b905b6fb3474c2aa84b03f2e4ff42b396
---

## AingZ_Platf_Repo/.git/objects/dc/4308bb2718d94849a5db2f1db952e63898be13
meta: {size:4705, lines:0, sha256:"f235d915aca59fd329516c9521f0008b158e1977b49290f28c3a5c896ceaae00", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dc/4e582dba6919092ac3c05974f1785e2924a65b
meta: {size:1564, lines:0, sha256:"daea61995b8218f762079fe62e595b41da131b65a2144c3cacdb08027a8b04a4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dc/774ecd00fb723c8a85f2e453437e19b9699d95
meta: {size:82, lines:0, sha256:"506626ee6cd7d990ac2c5f5c9fa26fb6590b681793e00f4fd88bba5e717bf112", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dc/9dce1af11c84ab2aac80903b0ff3d4e5591757
meta: {size:320, lines:0, sha256:"e9d748da38534b9347784def35088ea81703d80957020ca9bbdca5c3d529ddf7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dc/ba8c55ae1a71bea513b704090740e8126cb8b9
meta: {size:219, lines:0, sha256:"9d3df73da8b66f5bc896620d87e4a521402262f16c5fd23ef9418290ba848494", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dc/c1d51e750a6dc3fc69845d162a1edbf0d7ada9
meta: {size:136, lines:0, sha256:"1c737e960dedda8b3a364321922dd888ca696f8202024b9cb7f6bdd5a3d82a78", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dc/d22bff3706d6675fadd8f1c6f50b2318369585
meta: {size:177, lines:3, sha256:"50d3834a906c478ef373a7f3aeee966a9374372d81c70d46369f73def753583b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÁ
@E[ûâ:1hW&!IPÛ£/ÞÌÈ8ý{V·ÕênîáÀá¤¸=ö¼ÁÝ²m'ÕJTU`Ë¬F*%ÂÁàùy$
gnËhø:ë+pàÔ`¥Kià>`kPe¡Às½	¸3p§Ê¡òù-'dEÅ~{Èj*Êä?ºoñ·0Wn¨FÃvû8`»u74Iv]ú"ÖÃz7n
```

## AingZ_Platf_Repo/.git/objects/dc/d8a6c78074bfbfa368a2450484ad9bb29907bb
meta: {size:97, lines:0, sha256:"8dd0d8539cfc6b37d50b77a311f98f54300cc40e2f2041c3a23271701a88c0ff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dc/f1fbc7de77faf3f972ecf72883824e70376bf5
meta: {size:273, lines:2, sha256:"260bca202b182257604a99d651d549ecf064107745058e3945c99bcfa77d52a1", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xeANÄ0EY÷º¶ª@-V°µibR3r2Í;p
ÎÁM8	ngØ%ñóûv¸lÚ³V»Ûg¸G#w18¢xÀu20ÑdÀF)ENç@ÈYOYq>ÁìhØã|©¢,áq;X#Ì&ÐY^÷ðõö®&k)2&0Avä6)4Ì)0iJþüðdãÊ2g9AOJÄ!oØ/*;ú_èg6ðÈ(&è+|A·º¢	 p2B¡¯ªúã. óê¹¤µ}-»nèN`g£ÃnêÚ®mÚ«æº½©Ö®×P£e¿Å7ËÆ?Þ,ä=Jú'©oZÀ+
```

## AingZ_Platf_Repo/.git/objects/dc/f2c804da5e19d617a03a6c68aa128d1d1f89a0
meta: {size:30, lines:0, sha256:"c0c61ce560c581ef2964fda1e548664d1ab38a6c0560547f9ab1ebdc54269276", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dc/f4076d26f8d954e05040e7ef88771e0b3d6285
meta: {size:896, lines:0, sha256:"d07b838f558f176bf5756220cc6b30debfbafc693afa6014696235e60c180197", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dc/fef287667f0e35e8f23c2a6fabc3dbc3b5cda5
meta: {size:138, lines:0, sha256:"1bcb26c0d9d4a7bf9aae53faa90ec81c61d7c5968e5b679725f6121a8ed79e5e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

