---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/61
part_index: 0
files_included: 12
size_bytes_sum: 12360
created_at: 2025-08-31T21:08:15.621954+00:00
integrity:
  sha256_concat: 5c29a0be329ea39fe59d59d7b3890b2a80b373422ddd862d6b529618a9a4c783
---

## AingZ_Platf_Repo/.git/objects/61/0df470c5ec56ffe93421b56ea416ff37097f48
meta: {size:136, lines:0, sha256:"ea2ca0d70539dc5944177c1229474f5ff24512092c9a991039f32b7a6d05bd3c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/61/170388d4367a2d7ed732955d2bdb2d50df0cff
meta: {size:124, lines:2, sha256:"b6aa6848f41d5327a38414f61c36cc0c9b2b144d752c09bc96c5b60da765c97b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xM10Sû+WIH(E
ÞøQdÎè|Fâ÷9+ÛÎîìÓgûºxïûtJ²boUliam:÷¡	RøzÃ½CVy;X¤Eú%X'¨r3Á¬ØNöê«cù/ÏÏõ½ûQ0V
```

## AingZ_Platf_Repo/.git/objects/61/3650991d76e6a663dd73b3ea6dd141cf37f21a
meta: {size:186, lines:0, sha256:"b1031cae59bfe205a4eec067dd0d5fc7950b6f8e85801210865ad67dd45ac0d7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/61/457272d3a0b6ea0a3a5e762f9929d30b7468c7
meta: {size:51, lines:0, sha256:"9d9d2df7518ba51ce8bd4093bb7ab197cb979716c7c437100e015a7cc44b53f8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/61/59e64d9cb2334429f98c648a3da88562fd3e78
meta: {size:153, lines:3, sha256:"8f4747100f5cf33b2378cb34f59efbe1eac278d3eb1cfbfb07b4f13c0f3477c9", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎA
Ã @Ñ®=hQ'*Ò«è¨I Æ"BNß¡Û>·Z·!Î·ÑsØ+Ed¹@
=â\ÄlJ)wèù²Ä¼ìÌ`¹8èg°ÖjãEøµu¹s´CkùX¦3ï×öÍýµÔ°í·úhÉxå¬¼W½Gþ%~0!C6
```

## AingZ_Platf_Repo/.git/objects/61/87925f9a0777ae5896be39372eaec8311e8ad7
meta: {size:167, lines:0, sha256:"e9fe7b3fe78fe91eae14a25ff05ad39d411c5f0605926d9dc653be3fafe75fbf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/61/96b0ffc1156870f5916b26c52974694a945718
meta: {size:3235, lines:0, sha256:"87548af129f572794020a98f4460b7133c81ce8dd51cd45738419d8c9407155a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/61/de93b2b5b3ad644d6aeb0602583c90e1f7309d
meta: {size:731, lines:0, sha256:"f8a8f67b2192f8ac43448fe58429351b72933d14ab2409a3169e8dbf078338d3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/61/e347085dc2c5cffc79c85f3257713e327a02e1
meta: {size:1378, lines:0, sha256:"27f2a112c19be10be21e0a3556952a94fc74e9493cd904ff2a970da9260bd4bb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/61/e5b708c00e3acdbb30af73875a2c862431ed0a
meta: {size:485, lines:0, sha256:"38cd424839595c01da71fbee46beb47e27405543f1d94ab89b53641a53359989", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/61/e6ed071081889b8c161ea7651984138dee2bec
meta: {size:186, lines:0, sha256:"d671372fd50d62b25de4328c9e68baa3efa2c858a6437f1f2120bfd87be5b64b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/61/ffabfa8bae3d151c8e79a0aea1aef3d762d69e
meta: {size:5528, lines:0, sha256:"6744747884fe43149d761932fdc3524d0311569a6831ce06637afd6524022490", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

