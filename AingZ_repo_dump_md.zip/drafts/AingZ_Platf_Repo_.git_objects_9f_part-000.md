---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/9f
part_index: 0
files_included: 4
size_bytes_sum: 1712
created_at: 2025-08-31T21:08:15.628483+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/9f/15b11061c961460b47f1d4402e65d477b8cccb
meta: {size:848, lines:0, sha256:"bd7dc448924999af9f9f6dd81d65edb441aa8cc36a521da7b2650c342f1b0284", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9f/3d2720720ba7a74d57d946de98473afd040706
meta: {size:54, lines:0, sha256:"91c8aa17053c240874f7235e3eabd935f5742e618bb006fb0a00bc4b039a93b4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9f/4a75f579d789f9c8d5f0a087ae8fac4c53b0e3
meta: {size:71, lines:0, sha256:"0aa20a87bffe9049fd07f6621c577b14ed528e7f649a916e292d9d0b30f87d8d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9f/c3de18b0560c32d3f09e17f2067157950294eb
meta: {size:739, lines:0, sha256:"b2d02b12553e2250f7e33ae55dc2e7b6d92899275aaa1fba4c2ce7f4a6d1cc0a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

