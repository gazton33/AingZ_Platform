---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/02
part_index: 0
files_included: 13
size_bytes_sum: 10943
created_at: 2025-08-31T21:08:15.565808+00:00
integrity:
  sha256_concat: 9cf65cd6369346c511b4c92280442f2cfd1525f00a284794022457e5454a9121
---

## AingZ_Platf_Repo/.git/objects/02/076651224553b2990d5e55537c3f0197b31b28
meta: {size:122, lines:0, sha256:"4fa475154a001dd9a95f39395aa31341077e645f230f962443f74efcab0a1a3a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/02/1a19fd59c05ee1fdc94fc5d892ae621d3b5b1f
meta: {size:77, lines:0, sha256:"0b2f9fde067cd631462639430e3f598ba1970186e18afc6ee440d49ca7ecf1da", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/02/1d2213c3d6c5b6aa11da696ce605657c3f8c1f
meta: {size:1486, lines:0, sha256:"a41e3361afa8176a1302a126b404aa467ff11992bf07b540ed6886780d67a8cc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/02/1dba9c52bd83c9e85c196b3a60a68707c920db
meta: {size:1761, lines:0, sha256:"bf52a0e20f0ca829061ebc0ed0fcd1d538050fbe8efc450b4bbf27ea281dc99e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/02/34cd11266b9bbdcb5aaaedc2f778d38d1361b3
meta: {size:1693, lines:0, sha256:"ed595269c0440bc10d3d5425748a1f89ed072a90e845d5d9dbde7775872142aa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/02/56f2f61b4f5dd67f44178204134a67b128aba4
meta: {size:83, lines:0, sha256:"204549374cb5dc34c077239bf4d0d4ab0f5229d64b3a7cc1b8f7cff62054a9dc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/02/7b133d6cb3e6cbc228b82972d30cae9000bee8
meta: {size:192, lines:2, sha256:"e331ab99d3b4b0e17c97dcae5450856e662895f41f20d752c6868e03c3d7cb2c", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x]=nASÏ),¥E8@TtIÚë}B¼öh~@á69GàbÎ~zú¾7©Oô¶Û½¼ÒÞü¬ h
ÁÌôCKQîh)}´±ÀºLùÂõöKÊî5Ú3AÜH½¥Ë'ÔÆåÏ÷ï-}FÏÿ`+¡òQÅ!ãc¯Ñ<¶Mê¤g³BY²Ïñ¬jN%d<`oW#>±]¢±Mw¿èbS
```

## AingZ_Platf_Repo/.git/objects/02/8c220f96990a6f154198c7bb3d2ab941ba1f06
meta: {size:2456, lines:0, sha256:"9f950271b208605639721742d5f7cf2a2709ab36960d2ba12d3372ec35b9d092", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/02/91d87218f1b2da6be102fd724ca3a3cfaa6213
meta: {size:413, lines:0, sha256:"96b91805282f618a33a5652c9718aafcac12bd1a6e631fd6e31c2050e09afb5f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/02/d06109625cf56b50a0399fe6457a1f407951ac
meta: {size:1274, lines:0, sha256:"4af2e54d8e0f8b570d9046d03f88a1aac0b60fb83791be220b938dde994df704", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/02/d8bccb95120d9ae5053e276b5782b6534b9d4f
meta: {size:533, lines:0, sha256:"f29876fd3d010ae6bf636e01fa5ee452e0856f1899e8087fd09454dd0858d56d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/02/e8c24974bdae877e86bb0f25a75a7d007f63d7
meta: {size:218, lines:0, sha256:"a8387d90ef613d8c9e0e9a4aed92983620c5db719c2231a36abe129684adda92", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/02/f5d92082ad9ef0adbc2cf0b4071d499ea0bf2f
meta: {size:635, lines:0, sha256:"ad27521b7666503d026ea7332245e3ad9336693452614d2f75559237cc2a6248", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

