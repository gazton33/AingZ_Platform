---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/b1
part_index: 0
files_included: 11
size_bytes_sum: 63638
created_at: 2025-08-31T21:08:15.629624+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/b1/0dc0dad3c04477eb2e3c25a94adae60fd3d9a8
meta: {size:153, lines:0, sha256:"9db7df707757b2c846e66cb96798494f77df9c8a94b7229d99839a2c5f0752f7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b1/1357b71def032eef975272e47cfa1bfb2b11ee
meta: {size:767, lines:0, sha256:"84de2ac8cf21c3e6dda0e7daacadb173c59aca0df67dc4e68d8971833821ce56", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b1/25d19396638c799ff90f13b9e10c0545f05a47
meta: {size:89, lines:0, sha256:"3f06dc454fd57c5c2e83d31c20199ac28691671089de4d9d5dddefca6084ae9c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b1/2d62069410b54cde92896518b68d791bcc6614
meta: {size:1127, lines:0, sha256:"0ad6a395e0594b46d50eec1cdbff55bb3ca1d4ae3cec51386cfe9fe6896b5b63", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b1/609c320e58ed95ef98f7ebd1cf6cd090ee815a
meta: {size:1073, lines:0, sha256:"ec96ec3c438d5e8f2e4ba3aa6ec121575b63b5b89eb88e362348520ad56e1ff8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b1/6344fc16dabfe9ed5dc05e101b50892a84a662
meta: {size:1010, lines:0, sha256:"f4f9d645cc969f94cf96b31b9e3058ff796b2aa19b189335a1a6624c4bd903cf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b1/887590cfa6a11ca7f647aa372781f593b84770
meta: {size:326, lines:0, sha256:"7df042e2c5fbd3cadc0494a711d719426c22dc97a8ccbd341ea9a376c7cb6f86", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b1/8cf4f94b22d824cdbbfd48ef46bf5cec1cd22a
meta: {size:851, lines:0, sha256:"b27a2ddc70daea66e6e294eb47d9a41705220216680a19ac3e3dd7cd6ac08f1a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b1/9c7285a39a4b74e7f45e51ed6407f033a50472
meta: {size:154, lines:0, sha256:"285e66e4fb18947765a6d778fb44edf5413fdeb9d262bacd67bffff9ed0537bf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b1/a4641064be6027cff12a9db67d5dc1eabc846f
meta: {size:1756, lines:0, sha256:"84c8acb2b0a28f3a2736759d21efbbae95b446ed4f3803b1b85280e0aaa6b93e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b1/c1b4eb66ec862d8e430a0a55bb92d2afb97e9f
meta: {size:56332, lines:0, sha256:"cb328a3f75f63b1f82f1389b7b4d3da1f954b9d0ad3c153fa7ec14f23e80ce39", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

