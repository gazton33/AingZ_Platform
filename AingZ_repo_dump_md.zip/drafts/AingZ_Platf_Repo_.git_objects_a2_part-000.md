---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/a2
part_index: 0
files_included: 13
size_bytes_sum: 55911
created_at: 2025-08-31T21:08:15.628675+00:00
integrity:
  sha256_concat: 547b8c56d5725343524f78015f84e674333e57dcc6eb523c3d7c44692cf75f75
---

## AingZ_Platf_Repo/.git/objects/a2/00c25f030f9d6fc80257d57f27cb0c6c1b2ac7
meta: {size:41820, lines:0, sha256:"bef72b5062f286fde224113d617893d7783da1d2b81f745d5aa840588b72e230", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a2/07be7f7d5a4c736ba8b4d711f7519d6da1b1de
meta: {size:719, lines:0, sha256:"eafd69f19720722b271dcf0a51a97f6b06f97378ad6c0588026130c97ea4b908", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a2/15efbd1b972b71ebabe1b8b62ce70c914405cc
meta: {size:51, lines:0, sha256:"3d414582bd4927e0226c2cfe9bb4c02a1b35c243ed6a6d1ccb0fa41db12a51c1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a2/193e4c30b333fc14326d8fb779dea7ba1aba69
meta: {size:240, lines:0, sha256:"201634390fbf3b9de7ac9b40727b4a0d5a089b45df192649d9663d7798019084", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a2/2bafebe0031b013dc04301f6b0c34ecd973ed1
meta: {size:558, lines:0, sha256:"4af9837ff987de9fe34b9f47a9fd67864a497c55869dad705dddaf4c5f1d5254", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a2/3464cb702d2717619dd69bead51cbea17c72cf
meta: {size:314, lines:0, sha256:"8f25a8a15920691bb81b72370b8d9f2ba1f1e15e2f75d26bd5c6ce5c6e2e048f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a2/413fae50351b8a5ef113962a2a8a60a588f642
meta: {size:2069, lines:0, sha256:"8e3dbbdc2017d96438199ec454d6fcf3070306912fe73f162e5f2f6144f438bd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a2/4d640761018eb0e0234c9ed0b74f3bba84a78c
meta: {size:1179, lines:0, sha256:"db917a08d96bb9b0e95c3fea0d5a29f2cf797cf4fd1e67137bbdef379455d742", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a2/8e049b11fe248953e5425d802cb89c2eeeeebe
meta: {size:3421, lines:0, sha256:"295885d1a2697ba8a975129cc54ce2e1e1b9c267b57e7f49d3de95a7332313c5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a2/999fa66cb31f0431346e8679539dd191f3e6a1
meta: {size:542, lines:2, sha256:"83e70df7d5e4d8db5d985e7b185b4f2586b8bd4a48bc26065b1febb9acfe07ed", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuOÛ0Æ»ö)Mvþ.
i(eh×¤C1Ï²âÈäL³ë!z «!7éIúÛ½èÊ ¤ïýÞ÷}N¥Ja1ß¾A=n>%«u¼M>?~IÖñs­¾&ÛEÎÃåü>\Nþþø	±FQ2©r%Ó¼à¥Eé­/ç'ÜUÞÃöÉmâÑjãÃq8Õ`~ËçAày£,¦u§N³7§(Ó¢bâü§),×(g½kNp«VÑ±b	«ôù7ÎÑ))2l¥²>­DßÐLãÎT¦Öü²ÀÄ{wÏ±Zµ\>ì8ÏRdBÕ¼RÚ:gR´lïô¡¹næù:ÁtÆ®5wöB*òMïÜèX<çÚ¸klÏÙA	!·^÷çcmUqþe#PfHYYÞ!êñþÅ¬=³3qlLµ!¿*}ØIõj4ZÇYÜæà×n\ÑÒÝPÔÒJ¢Å9ýl»tcA4tø]oùëMìüê;CEìËß(:òvft}§°¾R©ä0fX§ª¨Ðº£ÀË÷oÿë.%ÐtÕ*ãþööMùRp*õYÖ"S¦}³¥ü*1SÃ?¯À+h	Û»Çìj¼JUåzë·«þHiç
```

## AingZ_Platf_Repo/.git/objects/a2/aee740c12e136fb648300c294431791391c674
meta: {size:4082, lines:0, sha256:"0e09297120afb5a588d11b876277614bb8e6423ccba0718cb0cfe6fa91763af7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a2/bc59d48cea70ca2f72c6c7fa56a15b0252706a
meta: {size:286, lines:0, sha256:"2abdbc76877bdc34512f091565d2fd6c3865304b528e0dbab0a92007b84e8de7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a2/cfda5d4025718fff71f26521fcba570cd187c3
meta: {size:630, lines:0, sha256:"df3be9022a471997640d0c6bed84d04d913561c6e4a995bae8f6977c29367353", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

