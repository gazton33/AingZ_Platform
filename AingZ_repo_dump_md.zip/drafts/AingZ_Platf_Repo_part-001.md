---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo
part_index: 1
files_included: 1
size_bytes_sum: 526277
created_at: 2025-08-31T21:08:15.560400+00:00
integrity:
  sha256_concat: e6a9f6c04024c754a87aabc929acf786a68c51a8716ddd41d985816f51429814
---

## AingZ_Platf_Repo/platform_arch_v5.excalidraw
meta: {size:526277, lines:21635, sha256:"e6a9f6c04024c754a87aabc929acf786a68c51a8716ddd41d985816f51429814", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```excalidraw
{
  "type": "excalidraw",
  "version": 2,
  "source": "https://excalidraw.com",
  "elements": [
    {
      "id": "8zficlcqpxQfT2DVKt6oP",
      "type": "diamond",
      "x": -8629.785461780655,
      "y": -230.89750640108332,
      "width": 517.6666666666672,
      "height": 243.66666666666677,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffa94d",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 2,
      "opacity": 100,
      "groupIds": [
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b651",
      "roundness": {
        "type": 2
      },
      "seed": 1501478662,
      "version": 419,
      "versionNonce": 384925501,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "Hprletx_A2kamjFyHCbg8"
        },
        {
          "id": "JeEv-Ebmmp63O623F2thu",
          "type": "arrow"
        },
        {
          "id": "xjRZ8RTIT9UOxKH1AxkJP",
          "type": "arrow"
        },
        {
          "id": "9Hf-eQBUmjCPAxHsdJCCi",
          "type": "arrow"
        },
        {
          "id": "C6i9rXdxST3JdwSnOxHi2",
          "type": "arrow"
        }
      ],
      "updated": 1755217088968,
      "link": null,
      "locked": false
    },
    {
      "id": "Hprletx_A2kamjFyHCbg8",
      "type": "text",
      "x": -8489.668721871802,
      "y": -131.48083973441658,
      "width": 237.599853515625,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b652",
      "roundness": null,
      "seed": 446492230,
      "version": 383,
      "versionNonce": 1918406557,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088968,
      "link": null,
      "locked": false,
      "text": "/data_base/.",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "8zficlcqpxQfT2DVKt6oP",
      "originalText": "/data_base/.",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "1TvSZyz5fXmTzdLARXHx1",
      "type": "rectangle",
      "x": -9315.567536530654,
      "y": -500.93917440108316,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b654",
      "roundness": {
        "type": 3
      },
      "seed": 1428871430,
      "version": 2007,
      "versionNonce": 723135869,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "Rui1tiZRRA2tURyENmuzy"
        },
        {
          "id": "_T8hSo2CFsXVJRoXWlvir",
          "type": "arrow"
        },
        {
          "id": "BL8eFcSVHLNZ30ZDNdOuF",
          "type": "arrow"
        },
        {
          "id": "o9vv-apO9X3dlYMMUGvN2",
          "type": "arrow"
        },
        {
          "id": "uCauUVVPZul3SIgEkvbQB",
          "type": "arrow"
        },
        {
          "id": "9Hf-eQBUmjCPAxHsdJCCi",
          "type": "arrow"
        }
      ],
      "updated": 1755217088971,
      "link": null,
      "locked": false
    },
    {
      "id": "Rui1tiZRRA2tURyENmuzy",
      "type": "text",
      "x": -9272.417481599014,
      "y": -473.43917440108316,
      "width": 178.19989013671875,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b655",
      "roundness": null,
      "seed": 1035323462,
      "version": 2022,
      "versionNonce": 1372681693,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088971,
      "link": null,
      "locked": false,
      "text": "./states/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "1TvSZyz5fXmTzdLARXHx1",
      "originalText": "./states/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "G6Rsx2XrXGIN7C99WY4X-",
      "type": "rectangle",
      "x": -9680.067536530654,
      "y": -800.9391744010832,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b656",
      "roundness": {
        "type": 3
      },
      "seed": 29717318,
      "version": 30,
      "versionNonce": 561556509,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "_T8hSo2CFsXVJRoXWlvir",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "UrmK-vsYHOhldEJntSJiv"
        }
      ],
      "updated": 1755217088975,
      "link": null,
      "locked": false
    },
    {
      "id": "UrmK-vsYHOhldEJntSJiv",
      "type": "text",
      "x": -9594.017518220107,
      "y": -768.4391744010832,
      "width": 92.39996337890625,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b658",
      "roundness": null,
      "seed": 1171517062,
      "version": 37,
      "versionNonce": 19341437,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088975,
      "link": null,
      "locked": false,
      "text": "/actv/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "G6Rsx2XrXGIN7C99WY4X-",
      "originalText": "/actv/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "_T8hSo2CFsXVJRoXWlvir",
      "type": "arrow",
      "x": -9320.567536530654,
      "y": -450.9291744010832,
      "width": 90,
      "height": 300,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b659",
      "roundness": null,
      "seed": 2113063962,
      "version": 71,
      "versionNonce": 518841661,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088975,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          -45,
          0
        ],
        [
          -45,
          -300
        ],
        [
          -90,
          -300
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "1TvSZyz5fXmTzdLARXHx1",
        "focus": -0.9410096426545561,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "G6Rsx2XrXGIN7C99WY4X-",
        "focus": -1.0453686200378074,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "ek6G5K8Jocx_nGOiEaUJA",
      "type": "rectangle",
      "x": -9680.067536530654,
      "y": -600.9391744010832,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65A",
      "roundness": {
        "type": 3
      },
      "seed": 1187859034,
      "version": 30,
      "versionNonce": 1912026525,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "BL8eFcSVHLNZ30ZDNdOuF",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "iiTV1QcIk9vHFrRZrMIw_"
        }
      ],
      "updated": 1755217088975,
      "link": null,
      "locked": false
    },
    {
      "id": "iiTV1QcIk9vHFrRZrMIw_",
      "type": "text",
      "x": -9647.917496857803,
      "y": -568.4391744010832,
      "width": 200.19992065429688,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65C",
      "roundness": null,
      "seed": 1101586886,
      "version": 39,
      "versionNonce": 605583869,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088975,
      "link": null,
      "locked": false,
      "text": "/development/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "ek6G5K8Jocx_nGOiEaUJA",
      "originalText": "/development/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "BL8eFcSVHLNZ30ZDNdOuF",
      "type": "arrow",
      "x": -9320.567536530654,
      "y": -450.9291744010832,
      "width": 90,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65D",
      "roundness": null,
      "seed": 1330028614,
      "version": 71,
      "versionNonce": 762699453,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088976,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          -45,
          0
        ],
        [
          -45,
          -100
        ],
        [
          -90,
          -100
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "1TvSZyz5fXmTzdLARXHx1",
        "focus": -0.784397163120574,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "ek6G5K8Jocx_nGOiEaUJA",
        "focus": -1.0453686200378074,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "xHdlrY3rON9320EH28TdW",
      "type": "rectangle",
      "x": -9680.067536530654,
      "y": -400.93917440108316,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65E",
      "roundness": {
        "type": 3
      },
      "seed": 487259654,
      "version": 30,
      "versionNonce": 136642333,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "o9vv-apO9X3dlYMMUGvN2",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "ZpTkrtfg8Ycd-6fPCsQ5s"
        }
      ],
      "updated": 1755217088976,
      "link": null,
      "locked": false
    },
    {
      "id": "ZpTkrtfg8Ycd-6fPCsQ5s",
      "type": "text",
      "x": -9609.417512116592,
      "y": -368.43917440108316,
      "width": 123.199951171875,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65G",
      "roundness": null,
      "seed": 2107117978,
      "version": 34,
      "versionNonce": 349246333,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088976,
      "link": null,
      "locked": false,
      "text": "/legacy/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "xHdlrY3rON9320EH28TdW",
      "originalText": "/legacy/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "o9vv-apO9X3dlYMMUGvN2",
      "type": "arrow",
      "x": -9320.567536530654,
      "y": -450.9291744010832,
      "width": 90,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65H",
      "roundness": null,
      "seed": 1269845338,
      "version": 71,
      "versionNonce": 821434429,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088977,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          -45,
          0
        ],
        [
          -45,
          100
        ],
        [
          -90,
          100
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "1TvSZyz5fXmTzdLARXHx1",
        "focus": 0.7843971631205614,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "xHdlrY3rON9320EH28TdW",
        "focus": 1.0453686200378072,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "ODZgHLhi9zLpyJAFEehew",
      "type": "rectangle",
      "x": -9680.067536530654,
      "y": -200.93917440108316,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65I",
      "roundness": {
        "type": 3
      },
      "seed": 825447322,
      "version": 30,
      "versionNonce": 1919027357,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "uCauUVVPZul3SIgEkvbQB",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "L7lbWkrszfWzZNI0G6lwS"
        }
      ],
      "updated": 1755217088977,
      "link": null,
      "locked": false
    },
    {
      "id": "L7lbWkrszfWzZNI0G6lwS",
      "type": "text",
      "x": -9609.417512116592,
      "y": -168.43917440108316,
      "width": 123.199951171875,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65K",
      "roundness": null,
      "seed": 851565766,
      "version": 35,
      "versionNonce": 363916541,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088977,
      "link": null,
      "locked": false,
      "text": "/backup/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "ODZgHLhi9zLpyJAFEehew",
      "originalText": "/backup/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "uCauUVVPZul3SIgEkvbQB",
      "type": "arrow",
      "x": -9320.567536530654,
      "y": -450.9291744010832,
      "width": 90,
      "height": 300,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "VXs9i_UpTSkGWnvh4D2RF",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65L",
      "roundness": null,
      "seed": 756075270,
      "version": 71,
      "versionNonce": 1405981117,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088977,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          -45,
          0
        ],
        [
          -45,
          300
        ],
        [
          -90,
          300
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "1TvSZyz5fXmTzdLARXHx1",
        "focus": 0.941009642654569,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "ODZgHLhi9zLpyJAFEehew",
        "focus": 1.0453686200378072,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "QrCAnXg1_kokl5IM2dxC3",
      "type": "rectangle",
      "x": -9315.56753728065,
      "y": 387.8108272655834,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65M",
      "roundness": {
        "type": 3
      },
      "seed": 426892422,
      "version": 1439,
      "versionNonce": 252596765,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "YYCOsGZfJ8DA5UKhdDWjr"
        },
        {
          "id": "h5PtTYLFa2lROKAk3snug",
          "type": "arrow"
        },
        {
          "id": "HicmNx2PxaEis1EYnVUZI",
          "type": "arrow"
        },
        {
          "id": "0geUhC7aYEH-NTpryr71D",
          "type": "arrow"
        },
        {
          "id": "gINJtYNplCvzVSphkaLhu",
          "type": "arrow"
        },
        {
          "id": "C6i9rXdxST3JdwSnOxHi2",
          "type": "arrow"
        }
      ],
      "updated": 1755217088977,
      "link": null,
      "locked": false
    },
    {
      "id": "YYCOsGZfJ8DA5UKhdDWjr",
      "type": "text",
      "x": -9302.117464038463,
      "y": 415.3108272655834,
      "width": 237.599853515625,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65O",
      "roundness": null,
      "seed": 2035309510,
      "version": 1437,
      "versionNonce": 957875837,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088977,
      "link": null,
      "locked": false,
      "text": "./categorys/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "QrCAnXg1_kokl5IM2dxC3",
      "originalText": "./categorys/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "Z9JxqPiaySXinuO15kIuB",
      "type": "rectangle",
      "x": -9680.06753728065,
      "y": 87.81082726558338,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65P",
      "roundness": {
        "type": 3
      },
      "seed": 1654100570,
      "version": 30,
      "versionNonce": 822232253,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "h5PtTYLFa2lROKAk3snug",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "zSHPymuCx3kp0l8NiHzzn"
        }
      ],
      "updated": 1755217088980,
      "link": null,
      "locked": false
    },
    {
      "id": "zSHPymuCx3kp0l8NiHzzn",
      "type": "text",
      "x": -9632.517503711315,
      "y": 120.31082726558338,
      "width": 169.39993286132812,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65Q",
      "roundness": null,
      "seed": 1468742406,
      "version": 41,
      "versionNonce": 1765057821,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088980,
      "link": null,
      "locked": false,
      "text": "/semantycs/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "Z9JxqPiaySXinuO15kIuB",
      "originalText": "/semantycs/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "h5PtTYLFa2lROKAk3snug",
      "type": "arrow",
      "x": -9320.56753728065,
      "y": 437.8208272655834,
      "width": 90,
      "height": 300,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65S",
      "roundness": null,
      "seed": 1646581830,
      "version": 71,
      "versionNonce": 1637466589,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088980,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          -45,
          0
        ],
        [
          -45,
          -300
        ],
        [
          -90,
          -300
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "QrCAnXg1_kokl5IM2dxC3",
        "focus": -0.9410096426545695,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "Z9JxqPiaySXinuO15kIuB",
        "focus": -1.0453686200378052,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "fk6-DLtiIJRirpu0az08E",
      "type": "rectangle",
      "x": -9680.06753728065,
      "y": 287.8108272655834,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65T",
      "roundness": {
        "type": 3
      },
      "seed": 1962161670,
      "version": 32,
      "versionNonce": 1344241213,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "HicmNx2PxaEis1EYnVUZI",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "xEe6rN8ZXU9i5M_lYGKaO"
        }
      ],
      "updated": 1755217088980,
      "link": null,
      "locked": false
    },
    {
      "id": "xEe6rN8ZXU9i5M_lYGKaO",
      "type": "text",
      "x": -9609.417512866588,
      "y": 320.3108272655834,
      "width": 123.199951171875,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65U",
      "roundness": null,
      "seed": 367163462,
      "version": 35,
      "versionNonce": 1936633501,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088980,
      "link": null,
      "locked": false,
      "text": "/guides/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "fk6-DLtiIJRirpu0az08E",
      "originalText": "/guides/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "HicmNx2PxaEis1EYnVUZI",
      "type": "arrow",
      "x": -9320.56753728065,
      "y": 437.8208272655834,
      "width": 90,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65V",
      "roundness": null,
      "seed": 739677530,
      "version": 70,
      "versionNonce": 1090480989,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088980,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          -45,
          0
        ],
        [
          -45,
          -100
        ],
        [
          -90,
          -100
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "QrCAnXg1_kokl5IM2dxC3",
        "focus": -0.7843971631205745,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "fk6-DLtiIJRirpu0az08E",
        "focus": -1.0453686200378052,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "eKu367miOLhPevqqWGdeh",
      "type": "rectangle",
      "x": -9680.06753728065,
      "y": 487.8108272655834,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65W",
      "roundness": {
        "type": 3
      },
      "seed": 752786330,
      "version": 30,
      "versionNonce": 1477703613,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "0geUhC7aYEH-NTpryr71D",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "ypyrxePyPD17G7JtEB-GO"
        }
      ],
      "updated": 1755217088980,
      "link": null,
      "locked": false
    },
    {
      "id": "ypyrxePyPD17G7JtEB-GO",
      "type": "text",
      "x": -9624.817506763073,
      "y": 520.3108272655834,
      "width": 153.99993896484375,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65X",
      "roundness": null,
      "seed": 24789402,
      "version": 36,
      "versionNonce": 1234696221,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088980,
      "link": null,
      "locked": false,
      "text": "/ai_learn/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "eKu367miOLhPevqqWGdeh",
      "originalText": "/ai_learn/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "0geUhC7aYEH-NTpryr71D",
      "type": "arrow",
      "x": -9320.56753728065,
      "y": 437.8208272655834,
      "width": 90,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65Z",
      "roundness": null,
      "seed": 178127622,
      "version": 71,
      "versionNonce": 696538333,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088981,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          -45,
          0
        ],
        [
          -45,
          100
        ],
        [
          -90,
          100
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "QrCAnXg1_kokl5IM2dxC3",
        "focus": 0.7843971631205753,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "eKu367miOLhPevqqWGdeh",
        "focus": 1.0453686200378058,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "manRzaEutenTkHUU11WAD",
      "type": "rectangle",
      "x": -9680.06753728065,
      "y": 687.8108272655834,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65a",
      "roundness": {
        "type": 3
      },
      "seed": 2008307910,
      "version": 30,
      "versionNonce": 54505789,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "gINJtYNplCvzVSphkaLhu",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "Kx2VtLH9qSYKw_NGgOeLF"
        }
      ],
      "updated": 1755217088981,
      "link": null,
      "locked": false
    },
    {
      "id": "Kx2VtLH9qSYKw_NGgOeLF",
      "type": "text",
      "x": -9647.9174976078,
      "y": 720.3108272655834,
      "width": 200.19992065429688,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65b",
      "roundness": null,
      "seed": 1843442502,
      "version": 39,
      "versionNonce": 1511031197,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088981,
      "link": null,
      "locked": false,
      "text": "/development/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "manRzaEutenTkHUU11WAD",
      "originalText": "/development/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "gINJtYNplCvzVSphkaLhu",
      "type": "arrow",
      "x": -9320.56753728065,
      "y": 437.8208272655834,
      "width": 90,
      "height": 300,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "bTt6cNFyNms2wnUXJXyTu",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65d",
      "roundness": null,
      "seed": 1324285594,
      "version": 71,
      "versionNonce": 1904770653,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088981,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          -45,
          0
        ],
        [
          -45,
          300
        ],
        [
          -90,
          300
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "QrCAnXg1_kokl5IM2dxC3",
        "focus": 0.9410096426545571,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "manRzaEutenTkHUU11WAD",
        "focus": 1.0453686200378056,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "q95NuADMWKxmMPuHvWiMX",
      "type": "rectangle",
      "x": -7690.836719697323,
      "y": 362.8108272655836,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65e",
      "roundness": {
        "type": 3
      },
      "seed": 1320367494,
      "version": 1340,
      "versionNonce": 1543678653,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "LwnUTY_vyoVGRf6-pm4-1"
        },
        {
          "id": "vlGEsaWyKcT1oYtccyKXW",
          "type": "arrow"
        },
        {
          "id": "HBWZB3sF4GjpMDU4cy4OR",
          "type": "arrow"
        },
        {
          "id": "q62G5jQe8HBAiQWgRytnm",
          "type": "arrow"
        },
        {
          "id": "S8SSg1OvE-Bz_eiatij_P",
          "type": "arrow"
        },
        {
          "id": "2K3QHw90aQ4h_0tqZlHFF",
          "type": "arrow"
        },
        {
          "id": "xjRZ8RTIT9UOxKH1AxkJP",
          "type": "arrow"
        }
      ],
      "updated": 1755217088981,
      "link": null,
      "locked": false
    },
    {
      "id": "LwnUTY_vyoVGRf6-pm4-1",
      "type": "text",
      "x": -7637.786670869198,
      "y": 390.3108272655836,
      "width": 158.39990234375,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65f",
      "roundness": null,
      "seed": 251565254,
      "version": 1339,
      "versionNonce": 1664633629,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088981,
      "link": null,
      "locked": false,
      "text": "./layer/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "q95NuADMWKxmMPuHvWiMX",
      "originalText": "./layer/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "toXUabLuQKztR5nOUKPO_",
      "type": "rectangle",
      "x": -7326.336719697323,
      "y": -37.18917273441639,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65h",
      "roundness": {
        "type": 3
      },
      "seed": 2012246490,
      "version": 48,
      "versionNonce": 1338924477,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "vlGEsaWyKcT1oYtccyKXW",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "_t8kDSB68VRIJElHqdCDq"
        },
        {
          "id": "4ZfGEDIs3h7iMpJnm6K-A",
          "type": "arrow"
        }
      ],
      "updated": 1755217088984,
      "link": null,
      "locked": false
    },
    {
      "id": "_t8kDSB68VRIJElHqdCDq",
      "type": "text",
      "x": -7240.286701386776,
      "y": -4.689172734416388,
      "width": 92.39996337890625,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65i",
      "roundness": null,
      "seed": 1911024986,
      "version": 47,
      "versionNonce": 1763024413,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088984,
      "link": null,
      "locked": false,
      "text": "/docs/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "toXUabLuQKztR5nOUKPO_",
      "originalText": "/docs/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "vlGEsaWyKcT1oYtccyKXW",
      "type": "arrow",
      "x": -7421.336719697323,
      "y": 412.8208272655836,
      "width": 90,
      "height": 400,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65j",
      "roundness": null,
      "seed": 317436102,
      "version": 241,
      "versionNonce": 261560125,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088985,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          45,
          0
        ],
        [
          45,
          -400
        ],
        [
          90,
          -400
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "q95NuADMWKxmMPuHvWiMX",
        "focus": 0.9650959860383931,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "toXUabLuQKztR5nOUKPO_",
        "focus": 1.0453686200378052,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "76A7XzDkmmJDNTN3nynmZ",
      "type": "rectangle",
      "x": -7326.336719697323,
      "y": 162.8108272655836,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65l",
      "roundness": {
        "type": 3
      },
      "seed": 307486342,
      "version": 48,
      "versionNonce": 1921722269,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "HBWZB3sF4GjpMDU4cy4OR",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "eENSTlCiBSB4ZCgNB0ZiV"
        },
        {
          "id": "cpjJombvpLen4SIZfClc5",
          "type": "arrow"
        }
      ],
      "updated": 1755217088985,
      "link": null,
      "locked": false
    },
    {
      "id": "eENSTlCiBSB4ZCgNB0ZiV",
      "type": "text",
      "x": -7240.286701386776,
      "y": 195.3108272655836,
      "width": 92.39996337890625,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65m",
      "roundness": null,
      "seed": 2045214618,
      "version": 58,
      "versionNonce": 291384317,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088985,
      "link": null,
      "locked": false,
      "text": "/data/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "76A7XzDkmmJDNTN3nynmZ",
      "originalText": "/data/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "HBWZB3sF4GjpMDU4cy4OR",
      "type": "arrow",
      "x": -7421.336719697323,
      "y": 412.8208272655836,
      "width": 90,
      "height": 200,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65n",
      "roundness": null,
      "seed": 1413723354,
      "version": 241,
      "versionNonce": 238022941,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088986,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          45,
          0
        ],
        [
          45,
          -200
        ],
        [
          90,
          -200
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "q95NuADMWKxmMPuHvWiMX",
        "focus": 0.8962722852512202,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "76A7XzDkmmJDNTN3nynmZ",
        "focus": 1.0453686200378067,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "upVqvfSJ0IDDaEsqZyYZ9",
      "type": "rectangle",
      "x": -7326.336719697323,
      "y": 362.8108272655836,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65p",
      "roundness": {
        "type": 3
      },
      "seed": 2018896666,
      "version": 46,
      "versionNonce": 1085130109,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "q62G5jQe8HBAiQWgRytnm",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "PWjSYO6UClOOi6Snp0XpR"
        },
        {
          "id": "eRJISUchTcl2RJEUVxy1-",
          "type": "arrow"
        }
      ],
      "updated": 1755217088986,
      "link": null,
      "locked": false
    },
    {
      "id": "PWjSYO6UClOOi6Snp0XpR",
      "type": "text",
      "x": -7301.886676972714,
      "y": 395.3108272655836,
      "width": 215.59991455078125,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65q",
      "roundness": null,
      "seed": 1726541638,
      "version": 55,
      "versionNonce": 556928477,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088986,
      "link": null,
      "locked": false,
      "text": "/kns_ctx_vivo/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "upVqvfSJ0IDDaEsqZyYZ9",
      "originalText": "/kns_ctx_vivo/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "q62G5jQe8HBAiQWgRytnm",
      "type": "arrow",
      "x": -7421.336719697323,
      "y": 412.8208272655836,
      "width": 90,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65r",
      "roundness": null,
      "seed": 1353018246,
      "version": 241,
      "versionNonce": 2091163389,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088987,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          90,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "q95NuADMWKxmMPuHvWiMX",
        "focus": 0,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "upVqvfSJ0IDDaEsqZyYZ9",
        "focus": 0.000310581855168583,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "2pzTn07KjcPiEK0gmKVK3",
      "type": "rectangle",
      "x": -7326.336719697323,
      "y": 562.8108272655836,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65t",
      "roundness": {
        "type": 3
      },
      "seed": 1163825478,
      "version": 52,
      "versionNonce": 1007794013,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "kvXI4_oPy7u-4KvOu4xHs"
        },
        {
          "id": "2K3QHw90aQ4h_0tqZlHFF",
          "type": "arrow"
        },
        {
          "id": "t2WwOkRd0Ofgc-RhpnwgY",
          "type": "arrow"
        }
      ],
      "updated": 1755217088987,
      "link": null,
      "locked": false
    },
    {
      "id": "kvXI4_oPy7u-4KvOu4xHs",
      "type": "text",
      "x": -7232.586704438534,
      "y": 595.3108272655836,
      "width": 76.99996948242188,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65u",
      "roundness": null,
      "seed": 979133382,
      "version": 52,
      "versionNonce": 1392296893,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088987,
      "link": null,
      "locked": false,
      "text": "/ctx/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "2pzTn07KjcPiEK0gmKVK3",
      "originalText": "/ctx/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "2K3QHw90aQ4h_0tqZlHFF",
      "type": "arrow",
      "x": -7421.336719697323,
      "y": 412.8208272655836,
      "width": 90,
      "height": 200,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65v",
      "roundness": null,
      "seed": 847416858,
      "version": 244,
      "versionNonce": 1393598685,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088987,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          45,
          0
        ],
        [
          45,
          200
        ],
        [
          90,
          200
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "q95NuADMWKxmMPuHvWiMX",
        "focus": -0.8962722852512149,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "2pzTn07KjcPiEK0gmKVK3",
        "focus": -1.0453686200378056,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "IAEZQ6rN_TVKrUoUCdwKT",
      "type": "rectangle",
      "x": -7326.336719697323,
      "y": 762.8108272655836,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65x",
      "roundness": {
        "type": 3
      },
      "seed": 1771850842,
      "version": 46,
      "versionNonce": 1298300221,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "S8SSg1OvE-Bz_eiatij_P",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "c5zBwZeLNTw95njOj0pP7"
        },
        {
          "id": "cRSVrvS3C1jN66-wbsoIX",
          "type": "arrow"
        }
      ],
      "updated": 1755217088987,
      "link": null,
      "locked": false
    },
    {
      "id": "c5zBwZeLNTw95njOj0pP7",
      "type": "text",
      "x": -7271.086689179745,
      "y": 795.3108272655836,
      "width": 153.99993896484375,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b65z",
      "roundness": null,
      "seed": 1960468998,
      "version": 55,
      "versionNonce": 1845087645,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088987,
      "link": null,
      "locked": false,
      "text": "/mem_viva/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "IAEZQ6rN_TVKrUoUCdwKT",
      "originalText": "/mem_viva/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "S8SSg1OvE-Bz_eiatij_P",
      "type": "arrow",
      "x": -7421.336719697323,
      "y": 412.8208272655836,
      "width": 90,
      "height": 400,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66",
      "roundness": null,
      "seed": 1180745286,
      "version": 241,
      "versionNonce": 140474045,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088988,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          45,
          0
        ],
        [
          45,
          400
        ],
        [
          90,
          400
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "q95NuADMWKxmMPuHvWiMX",
        "focus": -0.9650959860383951,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "IAEZQ6rN_TVKrUoUCdwKT",
        "focus": -1.0453686200378076,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "bU4ULKbPFOaf-fPR5D-xT",
      "type": "rectangle",
      "x": -6961.836719697323,
      "y": -37.18917273441639,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b662",
      "roundness": {
        "type": 3
      },
      "seed": 1518540826,
      "version": 51,
      "versionNonce": 35362589,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "4ZfGEDIs3h7iMpJnm6K-A",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "EPfmdGdCsnwVYAvM4iWWY"
        }
      ],
      "updated": 1755217088988,
      "link": null,
      "locked": false
    },
    {
      "id": "EPfmdGdCsnwVYAvM4iWWY",
      "type": "text",
      "x": -6929.686680024472,
      "y": -22.18917273441639,
      "width": 200.19992065429688,
      "height": 70,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b664",
      "roundness": null,
      "seed": 822280858,
      "version": 65,
      "versionNonce": 1144302461,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088988,
      "link": null,
      "locked": false,
      "text": "data full, no\neditable",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "bU4ULKbPFOaf-fPR5D-xT",
      "originalText": "data full, no editable",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "4ZfGEDIs3h7iMpJnm6K-A",
      "type": "arrow",
      "x": -7056.836719697323,
      "y": 12.820827265583603,
      "width": 90,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b668",
      "roundness": null,
      "seed": 1424854662,
      "version": 240,
      "versionNonce": 1582542909,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088988,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          90,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "toXUabLuQKztR5nOUKPO_",
        "focus": 0,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "bU4ULKbPFOaf-fPR5D-xT",
        "focus": 0.000310581855162335,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "L9KsARaCLCzzsRULtCOaN",
      "type": "rectangle",
      "x": -6961.836719697323,
      "y": 162.8108272655836,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66A",
      "roundness": {
        "type": 3
      },
      "seed": 686329798,
      "version": 45,
      "versionNonce": 1347199133,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "cpjJombvpLen4SIZfClc5",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "0Q7eEHGpbc0uNL4dmvXL2"
        }
      ],
      "updated": 1755217088988,
      "link": null,
      "locked": false
    },
    {
      "id": "0Q7eEHGpbc0uNL4dmvXL2",
      "type": "text",
      "x": -6945.086673920956,
      "y": 177.8108272655836,
      "width": 230.99990844726562,
      "height": 70,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66C",
      "roundness": null,
      "seed": 368688154,
      "version": 71,
      "versionNonce": 176719101,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088988,
      "link": null,
      "locked": false,
      "text": "data full actv,\neditable",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "L9KsARaCLCzzsRULtCOaN",
      "originalText": "data full actv, editable",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "cpjJombvpLen4SIZfClc5",
      "type": "arrow",
      "x": -7056.836719697323,
      "y": 212.8208272655836,
      "width": 90,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66G",
      "roundness": null,
      "seed": 595441562,
      "version": 240,
      "versionNonce": 2040474045,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088989,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          90,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "76A7XzDkmmJDNTN3nynmZ",
        "focus": 0,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "L9KsARaCLCzzsRULtCOaN",
        "focus": 0.0003105818551745823,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "cTfx_pvnAoXcBCEHzNzSz",
      "type": "rectangle",
      "x": -6961.836719697323,
      "y": 362.8108272655836,
      "width": 264.50000000000006,
      "height": 115,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66I",
      "roundness": {
        "type": 3
      },
      "seed": 696799834,
      "version": 47,
      "versionNonce": 921496093,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "eRJISUchTcl2RJEUVxy1-",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "9D4ir3ZO1Conl7drkAK9v"
        }
      ],
      "updated": 1755217088989,
      "link": null,
      "locked": false
    },
    {
      "id": "9D4ir3ZO1Conl7drkAK9v",
      "type": "text",
      "x": -6937.386676972714,
      "y": 367.8108272655836,
      "width": 215.59991455078125,
      "height": 105,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66K",
      "roundness": null,
      "seed": 381198150,
      "version": 108,
      "versionNonce": 425959037,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088989,
      "link": null,
      "locked": false,
      "text": "data full actv\ntkn opt, ctx\nfull",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "cTfx_pvnAoXcBCEHzNzSz",
      "originalText": "data full actv tkn opt, ctx full",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "eRJISUchTcl2RJEUVxy1-",
      "type": "arrow",
      "x": -7056.836719697323,
      "y": 412.8208272655836,
      "width": 90,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66O",
      "roundness": null,
      "seed": 1335892038,
      "version": 240,
      "versionNonce": 1419895613,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088989,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          90,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "upVqvfSJ0IDDaEsqZyYZ9",
        "focus": 0,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "cTfx_pvnAoXcBCEHzNzSz",
        "focus": 0.000310581855156549,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "L5Jkp2Ssa-urCi9o_QiOe",
      "type": "rectangle",
      "x": -6961.836719697323,
      "y": 562.8108272655836,
      "width": 264.50000000000006,
      "height": 115,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66Q",
      "roundness": {
        "type": 3
      },
      "seed": 1534239642,
      "version": 48,
      "versionNonce": 1683780509,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "t2WwOkRd0Ofgc-RhpnwgY",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "XjDWfbgCjFe8Pe_0DlcRi"
        }
      ],
      "updated": 1755217088989,
      "link": null,
      "locked": false
    },
    {
      "id": "XjDWfbgCjFe8Pe_0DlcRi",
      "type": "text",
      "x": -6929.686680024472,
      "y": 567.8108272655836,
      "width": 200.19992065429688,
      "height": 105,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66S",
      "roundness": null,
      "seed": 785645190,
      "version": 84,
      "versionNonce": 1394997245,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088989,
      "link": null,
      "locked": false,
      "text": "full data,\nsnaphots ctx,\ntkn opt",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "L5Jkp2Ssa-urCi9o_QiOe",
      "originalText": "full data, snaphots ctx, tkn opt",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "t2WwOkRd0Ofgc-RhpnwgY",
      "type": "arrow",
      "x": -7056.836719697323,
      "y": 612.8208272655836,
      "width": 90,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66V",
      "roundness": null,
      "seed": 1160674054,
      "version": 240,
      "versionNonce": 968613053,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088990,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          90,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "2pzTn07KjcPiEK0gmKVK3",
        "focus": 0,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "L5Jkp2Ssa-urCi9o_QiOe",
        "focus": 0.0003105818551626193,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "8hIrWXHit0VLjFUH9qF5y",
      "type": "rectangle",
      "x": -6961.836719697323,
      "y": 762.8108272655836,
      "width": 264.50000000000006,
      "height": 150,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66X",
      "roundness": {
        "type": 3
      },
      "seed": 151449754,
      "version": 47,
      "versionNonce": 1459305757,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "cRSVrvS3C1jN66-wbsoIX",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "fGGmdMb07QjvoLRqhsVJx"
        }
      ],
      "updated": 1755217088990,
      "link": null,
      "locked": false
    },
    {
      "id": "fGGmdMb07QjvoLRqhsVJx",
      "type": "text",
      "x": -6952.786670869198,
      "y": 767.8108272655836,
      "width": 246.39990234375,
      "height": 140,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66Z",
      "roundness": null,
      "seed": 634962310,
      "version": 105,
      "versionNonce": 1781502333,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088990,
      "link": null,
      "locked": false,
      "text": "memoria chatgpt,\ncustoms, system,\ninstruction\nprompts",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "8hIrWXHit0VLjFUH9qF5y",
      "originalText": "memoria chatgpt, customs, system, instruction prompts",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "cRSVrvS3C1jN66-wbsoIX",
      "type": "arrow",
      "x": -7056.836719697323,
      "y": 812.8208272655836,
      "width": 90,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "yezsZQXQTUiwEXNRk0YCi",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66d",
      "roundness": null,
      "seed": 596737542,
      "version": 240,
      "versionNonce": 1129125437,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088990,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          90,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "IAEZQ6rN_TVKrUoUCdwKT",
        "focus": 0,
        "gap": 6,
        "fixedPoint": [
          1.0189035916824194,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "8hIrWXHit0VLjFUH9qF5y",
        "focus": 0.0003105818551564601,
        "gap": 6,
        "fixedPoint": [
          -0.018903591682419656,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "ctZe23-4v1lgXhw61mIa0",
      "type": "rectangle",
      "x": -7690.836719613992,
      "y": -500.93917373441764,
      "width": 287.00000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66f",
      "roundness": {
        "type": 3
      },
      "seed": 520657734,
      "version": 1650,
      "versionNonce": 1562986141,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "dzISjabPYskNPEg6YvWD5",
          "type": "text"
        },
        {
          "id": "iB6IJJFo3WDDdsvlnDsew",
          "type": "arrow"
        },
        {
          "id": "2Oa0Be8hr7TQleE58cmVC",
          "type": "arrow"
        },
        {
          "id": "QUF_NZ5UMSaVhZAGMiD1U",
          "type": "arrow"
        },
        {
          "id": "CAvbg8seH-0HE9IHOyDbV",
          "type": "arrow"
        },
        {
          "id": "JeEv-Ebmmp63O623F2thu",
          "type": "arrow"
        }
      ],
      "updated": 1755217088990,
      "link": null,
      "locked": false
    },
    {
      "id": "dzISjabPYskNPEg6YvWD5",
      "type": "text",
      "x": -7616.636676889382,
      "y": -473.43917373441764,
      "width": 138.59991455078125,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66h",
      "roundness": null,
      "seed": 52511366,
      "version": 1654,
      "versionNonce": 1625320189,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088990,
      "link": null,
      "locked": false,
      "text": "./type/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "ctZe23-4v1lgXhw61mIa0",
      "originalText": "./type/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "8mSlnp9g6EpApROcYYcQI",
      "type": "rectangle",
      "x": -7303.836719613992,
      "y": -800.9391737344176,
      "width": 287.00000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66l",
      "roundness": {
        "type": 3
      },
      "seed": 2104530566,
      "version": 113,
      "versionNonce": 1028999485,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "iB6IJJFo3WDDdsvlnDsew",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "rJ2Vk1oSKKnHB5gK-WiE_"
        },
        {
          "id": "iocLsN8Q-4PXpUfinPNPO",
          "type": "arrow"
        }
      ],
      "updated": 1755217088992,
      "link": null,
      "locked": false
    },
    {
      "id": "rJ2Vk1oSKKnHB5gK-WiE_",
      "type": "text",
      "x": -7214.236698251687,
      "y": -768.4391737344176,
      "width": 107.79995727539062,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66n",
      "roundness": null,
      "seed": 1948997510,
      "version": 124,
      "versionNonce": 1840454045,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088992,
      "link": null,
      "locked": false,
      "text": "/clase/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "8mSlnp9g6EpApROcYYcQI",
      "originalText": "/clase/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "iB6IJJFo3WDDdsvlnDsew",
      "type": "arrow",
      "x": -7398.836719613991,
      "y": -450.92917373441765,
      "width": 90,
      "height": 300,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66p",
      "roundness": null,
      "seed": 1080982746,
      "version": 485,
      "versionNonce": 1921794749,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088993,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          44.99999999999909,
          0
        ],
        [
          44.99999999999909,
          -300
        ],
        [
          90,
          -300
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ctZe23-4v1lgXhw61mIa0",
        "focus": 0.9452054794520593,
        "gap": 6,
        "fixedPoint": [
          1.0174216027874594,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "8mSlnp9g6EpApROcYYcQI",
        "focus": 1.0418118466898898,
        "gap": 6,
        "fixedPoint": [
          -0.017421602787453274,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "ehIiSabeUmALZ2956xMYA",
      "type": "rectangle",
      "x": -7303.836719613992,
      "y": -600.9391737344176,
      "width": 287.00000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66t",
      "roundness": {
        "type": 3
      },
      "seed": 806728474,
      "version": 113,
      "versionNonce": 617538333,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "2Oa0Be8hr7TQleE58cmVC",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "h5ruN3HI70v0LzOXzJq3q"
        },
        {
          "id": "4QV8eqJ4Kh1bzKwY-r5WO",
          "type": "arrow"
        }
      ],
      "updated": 1755217088993,
      "link": null,
      "locked": false
    },
    {
      "id": "h5ruN3HI70v0LzOXzJq3q",
      "type": "text",
      "x": -7245.036686044656,
      "y": -568.4391737344176,
      "width": 169.39993286132812,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b66x",
      "roundness": null,
      "seed": 379079834,
      "version": 126,
      "versionNonce": 1251899261,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088993,
      "link": null,
      "locked": false,
      "text": "/extension/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "ehIiSabeUmALZ2956xMYA",
      "originalText": "/extension/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "2Oa0Be8hr7TQleE58cmVC",
      "type": "arrow",
      "x": -7398.836719613991,
      "y": -450.92917373441765,
      "width": 90,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b67",
      "roundness": null,
      "seed": 1269179270,
      "version": 485,
      "versionNonce": 1224338589,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088994,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          44.99999999999909,
          0
        ],
        [
          44.99999999999909,
          -100
        ],
        [
          90,
          -100
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ctZe23-4v1lgXhw61mIa0",
        "focus": 0.7973333333333363,
        "gap": 6,
        "fixedPoint": [
          1.0174216027874594,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "ehIiSabeUmALZ2956xMYA",
        "focus": 1.0418118466898898,
        "gap": 6,
        "fixedPoint": [
          -0.017421602787453274,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "ES1lrU3DugFEkTKcKkUVF",
      "type": "rectangle",
      "x": -7301.336719613992,
      "y": -400.93917373441764,
      "width": 287.00000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b674",
      "roundness": {
        "type": 3
      },
      "seed": 1786399046,
      "version": 116,
      "versionNonce": 397168893,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "QUF_NZ5UMSaVhZAGMiD1U",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "zs9Qwpn2kgJsaZjawajZK"
        },
        {
          "id": "5PwkWByTJrhO04jRJJtAK",
          "type": "arrow"
        }
      ],
      "updated": 1755217088994,
      "link": null,
      "locked": false
    },
    {
      "id": "zs9Qwpn2kgJsaZjawajZK",
      "type": "text",
      "x": -7227.136692148171,
      "y": -368.43917373441764,
      "width": 138.59994506835938,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b678",
      "roundness": null,
      "seed": 1592693446,
      "version": 124,
      "versionNonce": 1062414685,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088994,
      "link": null,
      "locked": false,
      "text": "/formato/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "ES1lrU3DugFEkTKcKkUVF",
      "originalText": "/formato/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "QUF_NZ5UMSaVhZAGMiD1U",
      "type": "arrow",
      "x": -7398.836719613991,
      "y": -450.92917373441765,
      "width": 92.5,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b67G",
      "roundness": null,
      "seed": 1209947674,
      "version": 486,
      "versionNonce": 4287101,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088995,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          46.24999999999909,
          0
        ],
        [
          46.24999999999909,
          100
        ],
        [
          92.5,
          100
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ctZe23-4v1lgXhw61mIa0",
        "focus": -0.7973333333333354,
        "gap": 6,
        "fixedPoint": [
          1.0174216027874594,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "ES1lrU3DugFEkTKcKkUVF",
        "focus": -1.0418118466898898,
        "gap": 6,
        "fixedPoint": [
          -0.017421602787453274,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "HEVgX87klBScOMR3dn7JT",
      "type": "rectangle",
      "x": -7303.836719613992,
      "y": -200.93917373441764,
      "width": 287.00000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b67K",
      "roundness": {
        "type": 3
      },
      "seed": 342692954,
      "version": 113,
      "versionNonce": 1493766877,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "CAvbg8seH-0HE9IHOyDbV",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "1UoJ1ksh9YQqPLrN0oNWx"
        },
        {
          "id": "qujaVCavyGwJL1lFM2bpg",
          "type": "arrow"
        }
      ],
      "updated": 1755217088995,
      "link": null,
      "locked": false
    },
    {
      "id": "1UoJ1ksh9YQqPLrN0oNWx",
      "type": "text",
      "x": -7260.43667994114,
      "y": -168.43917373441764,
      "width": 200.19992065429688,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b67O",
      "roundness": null,
      "seed": 9358682,
      "version": 132,
      "versionNonce": 528265021,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088995,
      "link": null,
      "locked": false,
      "text": "/procedencia/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "HEVgX87klBScOMR3dn7JT",
      "originalText": "/procedencia/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "CAvbg8seH-0HE9IHOyDbV",
      "type": "arrow",
      "x": -7398.836719613991,
      "y": -450.92917373441765,
      "width": 90,
      "height": 300,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b67V",
      "roundness": null,
      "seed": 65041990,
      "version": 485,
      "versionNonce": 834550877,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088995,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          44.99999999999909,
          0
        ],
        [
          44.99999999999909,
          300
        ],
        [
          90,
          300
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ctZe23-4v1lgXhw61mIa0",
        "focus": -0.9452054794520464,
        "gap": 6,
        "fixedPoint": [
          1.0174216027874594,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "HEVgX87klBScOMR3dn7JT",
        "focus": -1.041811846689891,
        "gap": 6,
        "fixedPoint": [
          -0.017421602787453274,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "fzi9_JPzg1E3uS9veA0DB",
      "type": "rectangle",
      "x": -6916.836719613992,
      "y": -800.9391737344176,
      "width": 287.00000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b67Z",
      "roundness": {
        "type": 3
      },
      "seed": 1969236762,
      "version": 114,
      "versionNonce": 1255188669,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "iocLsN8Q-4PXpUfinPNPO",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "IqOKLKK_X7rnl6qJWZ0tq"
        }
      ],
      "updated": 1755217088995,
      "link": null,
      "locked": false
    },
    {
      "id": "IqOKLKK_X7rnl6qJWZ0tq",
      "type": "text",
      "x": -6904.236667734109,
      "y": -785.9391737344176,
      "width": 261.7998962402344,
      "height": 70,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b67d",
      "roundness": null,
      "seed": 28715846,
      "version": 200,
      "versionNonce": 60197149,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088995,
      "link": null,
      "locked": false,
      "text": "txt, img, codigo,\npaqueta, etc",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "fzi9_JPzg1E3uS9veA0DB",
      "originalText": "txt, img, codigo,   paqueta, etc",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "iocLsN8Q-4PXpUfinPNPO",
      "type": "arrow",
      "x": -7011.836719613991,
      "y": -750.9291737344176,
      "width": 90,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b67l",
      "roundness": null,
      "seed": 811543430,
      "version": 485,
      "versionNonce": 802334173,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088996,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          90,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "8mSlnp9g6EpApROcYYcQI",
        "focus": 0,
        "gap": 6,
        "fixedPoint": [
          1.0174216027874594,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "fzi9_JPzg1E3uS9veA0DB",
        "focus": 0.000335846755036255,
        "gap": 6,
        "fixedPoint": [
          -0.017421602787453274,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "ToxjAz7BRvrImNvdx97eS",
      "type": "rectangle",
      "x": -6916.836719613992,
      "y": -600.9391737344176,
      "width": 287.00000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b67p",
      "roundness": {
        "type": 3
      },
      "seed": 1403967322,
      "version": 112,
      "versionNonce": 765190717,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "4QV8eqJ4Kh1bzKwY-r5WO",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "aX-QgknmuVABgXCiBaDDS"
        }
      ],
      "updated": 1755217088996,
      "link": null,
      "locked": false
    },
    {
      "id": "aX-QgknmuVABgXCiBaDDS",
      "type": "text",
      "x": -6896.536670785867,
      "y": -585.9391737344176,
      "width": 246.39990234375,
      "height": 70,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b67t",
      "roundness": null,
      "seed": 1618654918,
      "version": 139,
      "versionNonce": 733909661,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088996,
      "link": null,
      "locked": false,
      "text": ".md; .json; .py;\n.pdf; etc.",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "ToxjAz7BRvrImNvdx97eS",
      "originalText": ".md; .json; .py; .pdf; etc.",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "4QV8eqJ4Kh1bzKwY-r5WO",
      "type": "arrow",
      "x": -7011.836719613991,
      "y": -550.9291737344176,
      "width": 90,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b68",
      "roundness": null,
      "seed": 617636678,
      "version": 485,
      "versionNonce": 161894237,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088996,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          90,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ehIiSabeUmALZ2956xMYA",
        "focus": 0,
        "gap": 6,
        "fixedPoint": [
          1.0174216027874594,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "ToxjAz7BRvrImNvdx97eS",
        "focus": 0.000335846755036255,
        "gap": 6,
        "fixedPoint": [
          -0.017421602787453274,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "U16Ffdy7xFejvRG1u0mL8",
      "type": "rectangle",
      "x": -6914.336719613992,
      "y": -400.93917373441764,
      "width": 287.00000000000006,
      "height": 150,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b688",
      "roundness": {
        "type": 3
      },
      "seed": 783122458,
      "version": 114,
      "versionNonce": 842947517,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "5PwkWByTJrhO04jRJJtAK",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "jY8DaXTPu3hkZmPPRMt_3"
        }
      ],
      "updated": 1755217088996,
      "link": null,
      "locked": false
    },
    {
      "id": "jY8DaXTPu3hkZmPPRMt_3",
      "type": "text",
      "x": -6901.736667734109,
      "y": -395.93917373441764,
      "width": 261.7998962402344,
      "height": 140,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b68G",
      "roundness": null,
      "seed": 1865189894,
      "version": 177,
      "versionNonce": 953539613,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088996,
      "link": null,
      "locked": false,
      "text": "Matriz, tabla,\nficha, hoja de\ncalculo, informe,\nauditoria, etc",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "U16Ffdy7xFejvRG1u0mL8",
      "originalText": "Matriz, tabla, ficha, hoja de calculo, informe, auditoria, etc",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "5PwkWByTJrhO04jRJJtAK",
      "type": "arrow",
      "x": -7009.336719613991,
      "y": -350.92917373441765,
      "width": 90,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b68V",
      "roundness": null,
      "seed": 2096998022,
      "version": 485,
      "versionNonce": 1167669469,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088997,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          90,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ES1lrU3DugFEkTKcKkUVF",
        "focus": 0,
        "gap": 6,
        "fixedPoint": [
          1.0174216027874594,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "U16Ffdy7xFejvRG1u0mL8",
        "focus": 0.00033584675503650114,
        "gap": 6,
        "fixedPoint": [
          -0.017421602787453274,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "U04_wZqyMpqR1pWYXvwGG",
      "type": "rectangle",
      "x": -6916.836719613992,
      "y": -200.93917373441764,
      "width": 287.00000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b68d",
      "roundness": {
        "type": 3
      },
      "seed": 1889577178,
      "version": 112,
      "versionNonce": 320345405,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "qujaVCavyGwJL1lFM2bpg",
          "type": "arrow"
        },
        {
          "type": "text",
          "id": "XNXp-ga9G3NZPuWpujINA"
        }
      ],
      "updated": 1755217088997,
      "link": null,
      "locked": false
    },
    {
      "id": "XNXp-ga9G3NZPuWpujINA",
      "type": "text",
      "x": -6904.236667734109,
      "y": -168.43917373441764,
      "width": 261.7998962402344,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b68l",
      "roundness": null,
      "seed": 1775361350,
      "version": 138,
      "versionNonce": 423388573,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088997,
      "link": null,
      "locked": false,
      "text": "Interna / externa",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "U04_wZqyMpqR1pWYXvwGG",
      "originalText": "Interna / externa",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "qujaVCavyGwJL1lFM2bpg",
      "type": "arrow",
      "x": -7011.836719613991,
      "y": -150.92917373441765,
      "width": 90,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "Ww88rNfBWohRn3QNMjHKj",
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b69",
      "roundness": null,
      "seed": 1706977734,
      "version": 485,
      "versionNonce": 973824605,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088997,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          90,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "HEVgX87klBScOMR3dn7JT",
        "focus": 0,
        "gap": 6,
        "fixedPoint": [
          1.0174216027874594,
          0.5001
        ]
      },
      "endBinding": {
        "elementId": "U04_wZqyMpqR1pWYXvwGG",
        "focus": 0.00033584675503650114,
        "gap": 6,
        "fixedPoint": [
          -0.017421602787453274,
          0.5001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "JeEv-Ebmmp63O623F2thu",
      "type": "arrow",
      "x": -8123.312894096129,
      "y": -109.16417306774997,
      "width": 427.47617448213714,
      "height": 347.85833299999945,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b69G",
      "roundness": null,
      "seed": 245717722,
      "version": 106,
      "versionNonce": 1518931645,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088997,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          221.8351367321393,
          0
        ],
        [
          221.8351367321393,
          -347.85833299999945
        ],
        [
          427.47617448213714,
          -347.85833299999945
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "8zficlcqpxQfT2DVKt6oP",
        "focus": -0.0008207934336527171,
        "gap": 21.188873225472733,
        "fixedPoint": [
          0.9783758551536238,
          0.4995896032831736
        ]
      },
      "endBinding": {
        "elementId": "ctZe23-4v1lgXhw61mIa0",
        "focus": 0.1216666466666363,
        "gap": 5,
        "fixedPoint": [
          -0.01742160278745644,
          0.4391666766666822
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "xjRZ8RTIT9UOxKH1AxkJP",
      "type": "arrow",
      "x": -8123.312894096129,
      "y": -109.16417306774997,
      "width": 427.4761743988056,
      "height": 527.1416670000006,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b69V",
      "roundness": null,
      "seed": 1770045850,
      "version": 102,
      "versionNonce": 189935389,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088997,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          221.83513669047352,
          0
        ],
        [
          221.83513669047352,
          527.1416670000006
        ],
        [
          427.4761743988056,
          527.1416670000006
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "8zficlcqpxQfT2DVKt6oP",
        "focus": -0.0008207934336527171,
        "gap": 21.188873225472733,
        "fixedPoint": [
          0.9783758551536238,
          0.4995896032831736
        ]
      },
      "endBinding": {
        "elementId": "q95NuADMWKxmMPuHvWiMX",
        "focus": -1.0378071833648388,
        "gap": 5,
        "fixedPoint": [
          -0.018903591682419656,
          0.5516666666666697
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "9Hf-eQBUmjCPAxHsdJCCi",
      "type": "arrow",
      "x": -8618.591362798516,
      "y": -109.16417306775008,
      "width": 427.4761737321387,
      "height": 341.8750013333331,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b6A",
      "roundness": null,
      "seed": 543391450,
      "version": 130,
      "versionNonce": 450380669,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088997,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          -221.83513635714007,
          0
        ],
        [
          -221.83513635714007,
          -341.8750013333331
        ],
        [
          -427.4761737321387,
          -341.8750013333331
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "8zficlcqpxQfT2DVKt6oP",
        "focus": 0.0008207934336527171,
        "gap": 21.188873225472737,
        "fixedPoint": [
          0.021624144846374004,
          0.4995896032831731
        ]
      },
      "endBinding": {
        "elementId": "1TvSZyz5fXmTzdLARXHx1",
        "focus": -0.0019999999999958163,
        "gap": 5,
        "fixedPoint": [
          1.0189035916824194,
          0.4989999999999998
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "C6i9rXdxST3JdwSnOxHi2",
      "type": "arrow",
      "x": -8618.591362798516,
      "y": -109.16417306775008,
      "width": 427.4761744821353,
      "height": 546.8750003333334,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "PwXDmi5KFN8G6UeefGCKi"
      ],
      "frameId": null,
      "index": "b6B",
      "roundness": null,
      "seed": 430182042,
      "version": 96,
      "versionNonce": 224185309,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755217088997,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          -221.83513673213747,
          0
        ],
        [
          -221.83513673213747,
          546.8750003333334
        ],
        [
          -427.4761744821353,
          546.8750003333334
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "8zficlcqpxQfT2DVKt6oP",
        "focus": 0.0008207934336527171,
        "gap": 21.188873225472737,
        "fixedPoint": [
          0.021624144846374004,
          0.4995896032831731
        ]
      },
      "endBinding": {
        "elementId": "QrCAnXg1_kokl5IM2dxC3",
        "focus": -0.001999999999995532,
        "gap": 5,
        "fixedPoint": [
          1.0189035916824194,
          0.4989999999999998
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "0OKSg18q5MJE1uhDTSl1C",
      "type": "rectangle",
      "x": -429.80555555555657,
      "y": 499.3960323650823,
      "width": 140.00000000000003,
      "height": 58,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8F",
      "roundness": {
        "type": 3
      },
      "seed": 1171852386,
      "version": 1365,
      "versionNonce": 1811798215,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "gHxjaAbTS9EPa2bkIIDv9"
        },
        {
          "id": "Ax2jbmApwKAxxMy15cxan",
          "type": "arrow"
        },
        {
          "id": "MJY4NTY8tFzMAgMdUk--m",
          "type": "arrow"
        }
      ],
      "updated": 1755262053128,
      "link": null,
      "locked": false
    },
    {
      "id": "gHxjaAbTS9EPa2bkIIDv9",
      "type": "text",
      "x": -392.80555555555657,
      "y": 515.8960323650823,
      "width": 66,
      "height": 25,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8G",
      "roundness": null,
      "seed": 1769812002,
      "version": 1379,
      "versionNonce": 1040071465,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "/mpln/",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "0OKSg18q5MJE1uhDTSl1C",
      "originalText": "/mpln/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "k21Ko6DaobI6ThyaD96nu",
      "type": "rectangle",
      "x": -124.63293655555702,
      "y": 360.89603236508236,
      "width": 232.66666666666694,
      "height": 335,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8H",
      "roundness": {
        "type": 3
      },
      "seed": 342285282,
      "version": 613,
      "versionNonce": 1416964071,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "dt2_XD2DhsW7A_x9_qMUK"
        },
        {
          "id": "MJY4NTY8tFzMAgMdUk--m",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "dt2_XD2DhsW7A_x9_qMUK",
      "type": "text",
      "x": -96.29960322222355,
      "y": 365.89603236508236,
      "width": 176,
      "height": 325,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#b2f2bb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8I",
      "roundness": null,
      "seed": 1420103586,
      "version": 1029,
      "versionNonce": 918482441,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "Mplan\nBLueprint\nBaseline\n/plans\n/roadmaps\n/task\n/checklist\n/checkpoint\n/feedback\n/validacion\n/update objetive\n..\n...",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "k21Ko6DaobI6ThyaD96nu",
      "originalText": "Mplan\nBLueprint\nBaseline\n/plans\n/roadmaps\n/task\n/checklist\n/checkpoint\n/feedback\n/validacion\n/update objetive\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "aZhjdKeOwAjr99KOpf2Bf",
      "type": "rectangle",
      "x": -429.80555588889047,
      "y": 836.1857143650822,
      "width": 218.00000000000006,
      "height": 60,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8J",
      "roundness": {
        "type": 3
      },
      "seed": 12327422,
      "version": 1398,
      "versionNonce": 1265996551,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "SOdZx-NbC0l9wpBuf4qMP"
        },
        {
          "id": "2eEQAbjo6MgjvGwHsaGV5",
          "type": "arrow"
        },
        {
          "id": "3eHDBUU_T1JsI0n9h0IuT",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "SOdZx-NbC0l9wpBuf4qMP",
      "type": "text",
      "x": -414.30555588889047,
      "y": 853.6857143650822,
      "width": 187,
      "height": 25,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8K",
      "roundness": null,
      "seed": 1885612606,
      "version": 1453,
      "versionNonce": 2124825833,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "/brainstorm_crtv/",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "aZhjdKeOwAjr99KOpf2Bf",
      "originalText": "/brainstorm_crtv/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "yRv7fGjL-Ifu89ImRK5P_",
      "type": "rectangle",
      "x": -124.63293655555702,
      "y": 723.6857143650822,
      "width": 232.66666666666694,
      "height": 285,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8L",
      "roundness": {
        "type": 3
      },
      "seed": 1219606654,
      "version": 665,
      "versionNonce": 1501272615,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "OIIBbXPHVrX-LXOQL-z-u"
        },
        {
          "id": "3eHDBUU_T1JsI0n9h0IuT",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "OIIBbXPHVrX-LXOQL-z-u",
      "type": "text",
      "x": -79.79960322222355,
      "y": 741.1857143650822,
      "width": 143,
      "height": 250,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#b2f2bb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8M",
      "roundness": null,
      "seed": 354547902,
      "version": 1221,
      "versionNonce": 1094696905,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "Barinstorm\ninsights\nideas\ndraft\nnotas\nnodo (chkpnt)\nnodo_changes\nsnaphots\n..\n...",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "yRv7fGjL-Ifu89ImRK5P_",
      "originalText": "Barinstorm\ninsights\nideas\ndraft\nnotas\nnodo (chkpnt)\nnodo_changes\nsnaphots\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "ShlnvCC3MUCM2hylriOTD",
      "type": "rectangle",
      "x": -1721.0912695079364,
      "y": -1710.236110539679,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8N",
      "roundness": {
        "type": 3
      },
      "seed": 383876745,
      "version": 1050,
      "versionNonce": 1131658567,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "dnOH-qm64xIAJoxZyPEzA"
        },
        {
          "id": "L07NE-Vqsj-vfGEN6sx6h",
          "type": "arrow"
        },
        {
          "id": "kdLX0Y6HZXJ3LVPfYv7xA",
          "type": "arrow"
        },
        {
          "id": "taTQwCX_C94WNDsA21xy8",
          "type": "arrow"
        },
        {
          "id": "NirnVQfEub7oZhifsylnL",
          "type": "arrow"
        },
        {
          "id": "EJ3fRC6X2bwyEmeK2NZa0",
          "type": "arrow"
        },
        {
          "id": "k1m6oBcyg5DVWEdJLjpFV",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "dnOH-qm64xIAJoxZyPEzA",
      "type": "text",
      "x": -1676.4912481456317,
      "y": -1691.986110539679,
      "width": 107.79995727539062,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8O",
      "roundness": null,
      "seed": 1294124393,
      "version": 1056,
      "versionNonce": 749133481,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "./docs/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "ShlnvCC3MUCM2hylriOTD",
      "originalText": "./docs/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "G9DCvwo2Pjdx_n9m4v19x",
      "type": "rectangle",
      "x": -1281.2162702579362,
      "y": -2313.361110539679,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8P",
      "roundness": {
        "type": 3
      },
      "seed": 1695572809,
      "version": 1073,
      "versionNonce": 2092596327,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "ISJCymLF5v3aajRD6C9x4"
        },
        {
          "id": "L07NE-Vqsj-vfGEN6sx6h",
          "type": "arrow"
        },
        {
          "id": "md1OA8BVZLoDTje51fhob",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "ISJCymLF5v3aajRD6C9x4",
      "type": "text",
      "x": -1244.3162458438737,
      "y": -2295.111110539679,
      "width": 123.199951171875,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8Q",
      "roundness": null,
      "seed": 473776231,
      "version": 1093,
      "versionNonce": 528949641,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "./audio/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "G9DCvwo2Pjdx_n9m4v19x",
      "originalText": "./audio/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "NGO8qg4BAOIZ6nbD-G7xS",
      "type": "rectangle",
      "x": -832.6746035079364,
      "y": -2410.111110539679,
      "width": 197.00000000000003,
      "height": 265,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8R",
      "roundness": {
        "type": 3
      },
      "seed": 563885481,
      "version": 1059,
      "versionNonce": 1495029639,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "-QWJfediGd7ewpWOpNcVW"
        },
        {
          "id": "md1OA8BVZLoDTje51fhob",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "-QWJfediGd7ewpWOpNcVW",
      "type": "text",
      "x": -826.5745668868426,
      "y": -2400.111110539679,
      "width": 184.7999267578125,
      "height": 245,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8S",
      "roundness": null,
      "seed": 431593609,
      "version": 1200,
      "versionNonce": 387713129,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "notas de voz\nreuniones\nentrevistas\npodcast\naudio/videos\n..\n...",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "NGO8qg4BAOIZ6nbD-G7xS",
      "originalText": "notas de voz\nreuniones\nentrevistas\npodcast\naudio/videos\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "x3x3wlGs5V_DUv_ZJ4m2v",
      "type": "rectangle",
      "x": -1281.2162702579362,
      "y": -2011.798610539679,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8T",
      "roundness": {
        "type": 3
      },
      "seed": 784456009,
      "version": 1087,
      "versionNonce": 2127941287,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "yTUYIYvjW4Tt2tagW3oPo"
        },
        {
          "id": "kdLX0Y6HZXJ3LVPfYv7xA",
          "type": "arrow"
        },
        {
          "id": "VUvBHa3OYDFNUWV8nmjWJ",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "yTUYIYvjW4Tt2tagW3oPo",
      "type": "text",
      "x": -1244.3162458438737,
      "y": -1993.548610539679,
      "width": 123.199951171875,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8U",
      "roundness": null,
      "seed": 631883817,
      "version": 1121,
      "versionNonce": 1563497289,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "./image/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "x3x3wlGs5V_DUv_ZJ4m2v",
      "originalText": "./image/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "cUeZQ3_m1O9-AXD-lZp4Q",
      "type": "rectangle",
      "x": -832.6746035079364,
      "y": -2125.423610539679,
      "width": 197.00000000000003,
      "height": 337.49999999999994,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8V",
      "roundness": {
        "type": 3
      },
      "seed": 1115634409,
      "version": 1133,
      "versionNonce": 412312007,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "v1aG4SKIQ4U5p2Y2we5pB"
        },
        {
          "id": "VUvBHa3OYDFNUWV8nmjWJ",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "v1aG4SKIQ4U5p2Y2we5pB",
      "type": "text",
      "x": -818.8745699386004,
      "y": -2114.173610539679,
      "width": 169.39993286132812,
      "height": 315,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8W",
      "roundness": null,
      "seed": 1250555337,
      "version": 1366,
      "versionNonce": 1981923881,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "fotos\nimagenes\ngraficos\nesquemas\ndiagramas\nplanos\nexplosiones\n..\n...",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "cUeZQ3_m1O9-AXD-lZp4Q",
      "originalText": "fotos\nimagenes\ngraficos\nesquemas\ndiagramas\nplanos\nexplosiones\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "mtkkIfuqh6OQYp7gUPjX8",
      "type": "rectangle",
      "x": -1281.2162702579362,
      "y": -1710.236110539679,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8X",
      "roundness": {
        "type": 3
      },
      "seed": 680130919,
      "version": 1127,
      "versionNonce": 1198624999,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "GNgYf_gHnjw980FrUyJAI"
        },
        {
          "id": "taTQwCX_C94WNDsA21xy8",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "GNgYf_gHnjw980FrUyJAI",
      "type": "text",
      "x": -1244.3162458438737,
      "y": -1691.986110539679,
      "width": 123.199951171875,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8Y",
      "roundness": null,
      "seed": 938751111,
      "version": 1171,
      "versionNonce": 1322882313,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "./video/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "mtkkIfuqh6OQYp7gUPjX8",
      "originalText": "./video/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "r9IEdsOB9Z1wupfxlPMvg",
      "type": "rectangle",
      "x": -832.6746035079364,
      "y": -1768.236110539679,
      "width": 197.00000000000003,
      "height": 244.99999999999994,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8Z",
      "roundness": {
        "type": 3
      },
      "seed": 430068457,
      "version": 1244,
      "versionNonce": 1425857543,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "1t6P_Lglrwtgj25cMXcfd"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "1t6P_Lglrwtgj25cMXcfd",
      "type": "text",
      "x": -818.8745699386004,
      "y": -1750.736110539679,
      "width": 169.39993286132812,
      "height": 210,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8a",
      "roundness": null,
      "seed": 2106199497,
      "version": 1553,
      "versionNonce": 718539753,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "videos\nyoutube\nanimaciones\npresentac.\n..\n...",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "r9IEdsOB9Z1wupfxlPMvg",
      "originalText": "videos\nyoutube\nanimaciones\npresentac.\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "Cf6GhQxETVoyteNi0XCjL",
      "type": "rectangle",
      "x": -1281.2162702579362,
      "y": -1408.673610539679,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8b",
      "roundness": {
        "type": 3
      },
      "seed": 1951456489,
      "version": 1211,
      "versionNonce": 624018215,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "7xSmJGpbTGnECNMiq3JaW"
        },
        {
          "id": "NirnVQfEub7oZhifsylnL",
          "type": "arrow"
        },
        {
          "id": "SRs_ULvdeyoNPQE7zTIvl",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "7xSmJGpbTGnECNMiq3JaW",
      "type": "text",
      "x": -1259.716239740358,
      "y": -1390.423610539679,
      "width": 153.99993896484375,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8c",
      "roundness": null,
      "seed": 1440176073,
      "version": 1266,
      "versionNonce": 1377609417,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "./library/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "Cf6GhQxETVoyteNi0XCjL",
      "originalText": "./library/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "giTX4q8kOsUa-Pwjpx6d2",
      "type": "rectangle",
      "x": -832.6746035079364,
      "y": -1503.5486105396792,
      "width": 197.00000000000003,
      "height": 290,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8d",
      "roundness": {
        "type": 3
      },
      "seed": 2055960233,
      "version": 1452,
      "versionNonce": 1753007687,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "MDp1Tc_BTQeNo3Ti4JCE8"
        },
        {
          "id": "SRs_ULvdeyoNPQE7zTIvl",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "MDp1Tc_BTQeNo3Ti4JCE8",
      "type": "text",
      "x": -803.474576042116,
      "y": -1498.5486105396792,
      "width": 138.59994506835938,
      "height": 280,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8e",
      "roundness": null,
      "seed": 1964554633,
      "version": 1709,
      "versionNonce": 2135877033,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "libros\nmanuales\nguias\narticulos\npappers\n..\n...\n",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "giTX4q8kOsUa-Pwjpx6d2",
      "originalText": "libros\nmanuales\nguias\narticulos\npappers\n..\n...\n",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "lIclep3QMQoBFPx8llqwy",
      "type": "rectangle",
      "x": -1281.2162702579365,
      "y": -1107.111110539679,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8f",
      "roundness": {
        "type": 3
      },
      "seed": 2069585607,
      "version": 1334,
      "versionNonce": 230319463,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "_rbjLIQQj5BadsyJzBZzG"
        },
        {
          "id": "EJ3fRC6X2bwyEmeK2NZa0",
          "type": "arrow"
        },
        {
          "id": "tKlEbvaQ-01I82De6jG_r",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "_rbjLIQQj5BadsyJzBZzG",
      "type": "text",
      "x": -1259.7162397403583,
      "y": -1088.861110539679,
      "width": 153.99993896484375,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8g",
      "roundness": null,
      "seed": 1781657063,
      "version": 1403,
      "versionNonce": 227952777,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "./onboard/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "lIclep3QMQoBFPx8llqwy",
      "originalText": "./onboard/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "qg7AALmCkoKwH0JQWuc4E",
      "type": "rectangle",
      "x": -832.6746035079364,
      "y": -1193.8611105396792,
      "width": 197.00000000000003,
      "height": 244.99999999999994,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8h",
      "roundness": {
        "type": 3
      },
      "seed": 654683815,
      "version": 1368,
      "versionNonce": 1949769863,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "ZPDU92U_FH7xo9pw8_vbH"
        },
        {
          "id": "tKlEbvaQ-01I82De6jG_r",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "ZPDU92U_FH7xo9pw8_vbH",
      "type": "text",
      "x": -795.7745790938739,
      "y": -1158.8611105396792,
      "width": 123.199951171875,
      "height": 175,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "L_2gMvmfnyQumT_08WVVZ",
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8i",
      "roundness": null,
      "seed": 1875329479,
      "version": 1794,
      "versionNonce": 1722699625,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "notas\nmensajes\nobserv.\n..\n...",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "qg7AALmCkoKwH0JQWuc4E",
      "originalText": "notas\nmensajes\nobserv.\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "L07NE-Vqsj-vfGEN6sx6h",
      "type": "arrow",
      "x": -1519.0912695079362,
      "y": -1674.5861105396789,
      "width": 232.87499924999995,
      "height": 603.125,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8j",
      "roundness": null,
      "seed": 969842249,
      "version": 1324,
      "versionNonce": 1571780519,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          116.43749962499997,
          0
        ],
        [
          116.43749962499997,
          -603.125
        ],
        [
          232.87499924999995,
          -603.125
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ShlnvCC3MUCM2hylriOTD",
        "focus": -0.002797202797204035,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "G9DCvwo2Pjdx_n9m4v19x",
        "focus": 1.0507614213197964,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "kdLX0Y6HZXJ3LVPfYv7xA",
      "type": "arrow",
      "x": -1519.0912695079362,
      "y": -1674.5861105396789,
      "width": 232.87499924999995,
      "height": 301.5625,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8k",
      "roundness": null,
      "seed": 1243068327,
      "version": 1314,
      "versionNonce": 820148809,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          116.43749962499997,
          0
        ],
        [
          116.43749962499997,
          -301.5625
        ],
        [
          232.87499924999995,
          -301.5625
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ShlnvCC3MUCM2hylriOTD",
        "focus": -0.002797202797202923,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "x3x3wlGs5V_DUv_ZJ4m2v",
        "focus": 1.0507614213197964,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "taTQwCX_C94WNDsA21xy8",
      "type": "arrow",
      "x": -1519.0912695079362,
      "y": -1674.5861105396789,
      "width": 232.87499924999995,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8l",
      "roundness": null,
      "seed": 951074823,
      "version": 1300,
      "versionNonce": 542108359,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          232.87499924999995,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ShlnvCC3MUCM2hylriOTD",
        "focus": -0.002797202797202923,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "mtkkIfuqh6OQYp7gUPjX8",
        "focus": 0.0027972027972034325,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49860139860139857
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "NirnVQfEub7oZhifsylnL",
      "type": "arrow",
      "x": -1519.0912695079362,
      "y": -1674.5861105396789,
      "width": 232.87499924999995,
      "height": 301.5625,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8m",
      "roundness": null,
      "seed": 884676231,
      "version": 1302,
      "versionNonce": 1024346409,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          116.43749962499997,
          0
        ],
        [
          116.43749962499997,
          301.5625
        ],
        [
          232.87499924999995,
          301.5625
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ShlnvCC3MUCM2hylriOTD",
        "focus": -0.002797202797202923,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "Cf6GhQxETVoyteNi0XCjL",
        "focus": -1.0507614213197969,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013984
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "EJ3fRC6X2bwyEmeK2NZa0",
      "type": "arrow",
      "x": -1519.0912695079362,
      "y": -1674.5861105396789,
      "width": 232.87499924999992,
      "height": 603.125,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8n",
      "roundness": null,
      "seed": 1788638247,
      "version": 1311,
      "versionNonce": 414513639,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          116.43749962499996,
          0
        ],
        [
          116.43749962499996,
          603.125
        ],
        [
          232.87499924999992,
          603.125
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ShlnvCC3MUCM2hylriOTD",
        "focus": -0.002797202797204035,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "lIclep3QMQoBFPx8llqwy",
        "focus": -1.050761421319797,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "md1OA8BVZLoDTje51fhob",
      "type": "arrow",
      "x": -1079.2162702579362,
      "y": -2277.711110539679,
      "width": 241.54166675,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8o",
      "roundness": null,
      "seed": 709787497,
      "version": 1311,
      "versionNonce": 882719753,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          241.54166675,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "G9DCvwo2Pjdx_n9m4v19x",
        "focus": -0.0027972027972046854,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "NGO8qg4BAOIZ6nbD-G7xS",
        "focus": 0.0007547169811309938,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49962264150943386
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "VUvBHa3OYDFNUWV8nmjWJ",
      "type": "arrow",
      "x": -1079.2162702579362,
      "y": -1981.5277772063455,
      "width": 241.54166675,
      "height": 24.754166666666492,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8p",
      "roundness": null,
      "seed": 1356879303,
      "version": 1303,
      "versionNonce": 1542137095,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          120.770833375,
          0
        ],
        [
          120.770833375,
          24.754166666666492
        ],
        [
          241.54166675,
          24.754166666666492
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "x3x3wlGs5V_DUv_ZJ4m2v",
        "focus": -0.15326340326339954,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4233682983683004
        ]
      },
      "endBinding": {
        "elementId": "cUeZQ3_m1O9-AXD-lZp4Q",
        "focus": 0.0005925925925922078,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4997037037037037
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "BEPEwGc-ls7SQaKfaEmQM",
      "type": "arrow",
      "x": -1079.2162702579362,
      "y": -1674.5861105396789,
      "width": 241.54166675,
      "height": 28.749999999999915,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8q",
      "roundness": null,
      "seed": 538206857,
      "version": 440,
      "versionNonce": 126538473,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          120.770833375,
          0
        ],
        [
          120.770833375,
          28.749999999999915
        ],
        [
          241.54166675,
          28.749999999999915
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": null,
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "SRs_ULvdeyoNPQE7zTIvl",
      "type": "arrow",
      "x": -1079.2162702579362,
      "y": -1373.0236105396789,
      "width": 241.54166675,
      "height": 14.374999999999801,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8r",
      "roundness": null,
      "seed": 1159311433,
      "version": 1293,
      "versionNonce": 695135271,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          120.770833375,
          0
        ],
        [
          120.770833375,
          14.374999999999801
        ],
        [
          241.54166675,
          14.374999999999801
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "Cf6GhQxETVoyteNi0XCjL",
        "focus": -0.0027972027972024594,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4986013986013988
        ]
      },
      "endBinding": {
        "elementId": "giTX4q8kOsUa-Pwjpx6d2",
        "focus": 0.0006896551724138405,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49965517241379315
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "tKlEbvaQ-01I82De6jG_r",
      "type": "arrow",
      "x": -1079.2162702579362,
      "y": -1076.5277772063455,
      "width": 241.54166675,
      "height": 5.066666666666265,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "r1IJkbA0fh5uC2Q-1mIF0",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8s",
      "roundness": null,
      "seed": 1946910281,
      "version": 1296,
      "versionNonce": 442666441,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          120.770833375,
          0
        ],
        [
          120.770833375,
          5.066666666666265
        ],
        [
          241.54166675,
          5.066666666666265
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "lIclep3QMQoBFPx8llqwy",
        "focus": -0.14452214452214088,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.4277389277389298
        ]
      },
      "endBinding": {
        "elementId": "qg7AALmCkoKwH0JQWuc4E",
        "focus": 0.0008163265306124035,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49959183673469393
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "tBYM43jj8mYuY-EWvf3Bh",
      "type": "rectangle",
      "x": -1721.0912698412694,
      "y": -242.22896820634526,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8t",
      "roundness": {
        "type": 3
      },
      "seed": 1418728967,
      "version": 878,
      "versionNonce": 489475911,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "y3OtnAnkfmfM7LedpuNRz"
        },
        {
          "id": "ayhkDHDiq5F37e0EY9A3R",
          "type": "arrow"
        },
        {
          "id": "X76ATHhk2Ef087rwxXO5X",
          "type": "arrow"
        },
        {
          "id": "z8vSDanQpDqARkE58F-fh",
          "type": "arrow"
        },
        {
          "id": "OPJZh0HcYpLAfE6FuZYvM",
          "type": "arrow"
        },
        {
          "id": "hTfe_w4iv0b8ScPrZrIu1",
          "type": "arrow"
        },
        {
          "id": "0x8ftoO3_ZbXaH1dT91sp",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "y3OtnAnkfmfM7LedpuNRz",
      "type": "text",
      "x": -1676.4912484789647,
      "y": -223.97896820634526,
      "width": 107.79995727539062,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8u",
      "roundness": null,
      "seed": 38649127,
      "version": 888,
      "versionNonce": 876604585,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "./data/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "tBYM43jj8mYuY-EWvf3Bh",
      "originalText": "./data/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "ChPL_8u0ia_qPxqBkLJLa",
      "type": "rectangle",
      "x": -1281.2162705912694,
      "y": -845.3539682063451,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8v",
      "roundness": {
        "type": 3
      },
      "seed": 1946779719,
      "version": 903,
      "versionNonce": 562122343,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "qWDV0wsPjjOfBBb-8-hZg"
        },
        {
          "id": "ayhkDHDiq5F37e0EY9A3R",
          "type": "arrow"
        },
        {
          "id": "U0cJZ9SGk8tFicskGGEvL",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "qWDV0wsPjjOfBBb-8-hZg",
      "type": "text",
      "x": -1275.1162339701757,
      "y": -827.1039682063451,
      "width": 184.7999267578125,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8w",
      "roundness": null,
      "seed": 1000333159,
      "version": 939,
      "versionNonce": 751726473,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "./semantics/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "ChPL_8u0ia_qPxqBkLJLa",
      "originalText": "./semantics/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "lGNGGysmCotfoVtZJpB4V",
      "type": "rectangle",
      "x": -1281.2162705912694,
      "y": -543.7914682063453,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8x",
      "roundness": {
        "type": 3
      },
      "seed": 716154055,
      "version": 917,
      "versionNonce": 557377927,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "uXH5H1Yz4qNNjqvDAAi7Y"
        },
        {
          "id": "X76ATHhk2Ef087rwxXO5X",
          "type": "arrow"
        },
        {
          "id": "giDPe_XBBRBny-0sIPgfX",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "uXH5H1Yz4qNNjqvDAAi7Y",
      "type": "text",
      "x": -1267.4162370219335,
      "y": -525.5414682063453,
      "width": 169.39993286132812,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8y",
      "roundness": null,
      "seed": 1930261479,
      "version": 962,
      "versionNonce": 1514772073,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "./ai_learn/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "lGNGGysmCotfoVtZJpB4V",
      "originalText": "./ai_learn/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "U1xEvCCCjglTOvEIgpLiV",
      "type": "rectangle",
      "x": -1281.2162705912694,
      "y": -242.22896820634526,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b8z",
      "roundness": {
        "type": 3
      },
      "seed": 618629447,
      "version": 953,
      "versionNonce": 2039488679,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "6YgnQSrMXSgH010-9bvOI"
        },
        {
          "id": "z8vSDanQpDqARkE58F-fh",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "6YgnQSrMXSgH010-9bvOI",
      "type": "text",
      "x": -1259.7162400736913,
      "y": -223.97896820634526,
      "width": 153.99993896484375,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b90",
      "roundness": null,
      "seed": 1456261223,
      "version": 1011,
      "versionNonce": 1065148745,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "./develop/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "U1xEvCCCjglTOvEIgpLiV",
      "originalText": "./develop/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "5VCsqmFs7gkobcGoqbffw",
      "type": "rectangle",
      "x": -832.6746038412695,
      "y": -336.47896820634526,
      "width": 197.00000000000003,
      "height": 260,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b91",
      "roundness": {
        "type": 3
      },
      "seed": 1392845703,
      "version": 1197,
      "versionNonce": 741569479,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "lrwyU_ipWrksPnoskOGze"
        },
        {
          "id": "k8S5e1wXWhJrLuzMa1NR3",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "lrwyU_ipWrksPnoskOGze",
      "type": "text",
      "x": -794.6746038412695,
      "y": -331.47896820634526,
      "width": 121,
      "height": 250,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b92",
      "roundness": null,
      "seed": 1506089639,
      "version": 1482,
      "versionNonce": 2042875945,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "rulset\nconfig\nsetup\ncustom\nspec\npreference\nconectors\norquestador\n..\n...",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "5VCsqmFs7gkobcGoqbffw",
      "originalText": "rulset\nconfig\nsetup\ncustom\nspec\npreference\nconectors\norquestador\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "PKT9slJPXabSMz9vDMoij",
      "type": "rectangle",
      "x": -1281.2162705912694,
      "y": 59.33353179365474,
      "width": 247.00000000000003,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b93",
      "roundness": {
        "type": 3
      },
      "seed": 1874406855,
      "version": 1075,
      "versionNonce": 1363108583,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "o2UQ0gcjBpkCYWmGXkHu2"
        },
        {
          "id": "hTfe_w4iv0b8ScPrZrIu1",
          "type": "arrow"
        },
        {
          "id": "yWn_D-XJBiR2-DsDDTgaF",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "o2UQ0gcjBpkCYWmGXkHu2",
      "type": "text",
      "x": -1273.2162248149023,
      "y": 81.83353179365474,
      "width": 230.99990844726562,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b94",
      "roundness": null,
      "seed": 1342037223,
      "version": 1161,
      "versionNonce": 1862918921,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "./out_template/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "PKT9slJPXabSMz9vDMoij",
      "originalText": "./out_template/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "GpbJ8YFEWv5hvSyQbsM8l",
      "type": "rectangle",
      "x": -1281.2162705912694,
      "y": 360.89603179365474,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b95",
      "roundness": {
        "type": 3
      },
      "seed": 140284487,
      "version": 1164,
      "versionNonce": 1228959239,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "8eSf3x-daCr0L9sqiIHHD"
        },
        {
          "id": "OPJZh0HcYpLAfE6FuZYvM",
          "type": "arrow"
        },
        {
          "id": "FwSwA6YXE4TubMyFuMt1X",
          "type": "arrow"
        },
        {
          "id": "7BX3UUdPMMayWd219Ygap",
          "type": "arrow"
        },
        {
          "id": "QdyQtEBHAuktKO5InCulw",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "8eSf3x-daCr0L9sqiIHHD",
      "type": "text",
      "x": -1252.0162431254491,
      "y": 379.14603179365474,
      "width": 138.59994506835938,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b96",
      "roundness": null,
      "seed": 935375207,
      "version": 1257,
      "versionNonce": 1003133417,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "./guides/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "GpbJ8YFEWv5hvSyQbsM8l",
      "originalText": "./guides/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "ayhkDHDiq5F37e0EY9A3R",
      "type": "arrow",
      "x": -1519.0912698412694,
      "y": -206.57896820634517,
      "width": 232.87499924999995,
      "height": 603.125,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b97",
      "roundness": null,
      "seed": 1542043335,
      "version": 934,
      "versionNonce": 791876903,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          116.43749962499997,
          0
        ],
        [
          116.43749962499997,
          -603.125
        ],
        [
          232.87499924999995,
          -603.125
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "tBYM43jj8mYuY-EWvf3Bh",
        "focus": -0.002797202797204035,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "ChPL_8u0ia_qPxqBkLJLa",
        "focus": 1.0507614213197964,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "X76ATHhk2Ef087rwxXO5X",
      "type": "arrow",
      "x": -1519.0912698412694,
      "y": -206.57896820634517,
      "width": 232.87499924999995,
      "height": 301.5625,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b98",
      "roundness": null,
      "seed": 1463109095,
      "version": 924,
      "versionNonce": 1628533961,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          116.43749962499997,
          0
        ],
        [
          116.43749962499997,
          -301.5625
        ],
        [
          232.87499924999995,
          -301.5625
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "tBYM43jj8mYuY-EWvf3Bh",
        "focus": -0.002797202797202923,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "lGNGGysmCotfoVtZJpB4V",
        "focus": 1.0507614213197964,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "z8vSDanQpDqARkE58F-fh",
      "type": "arrow",
      "x": -1519.0912698412694,
      "y": -206.57896820634517,
      "width": 232.87499924999995,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b99",
      "roundness": null,
      "seed": 2088890631,
      "version": 908,
      "versionNonce": 176412743,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          232.87499924999995,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "tBYM43jj8mYuY-EWvf3Bh",
        "focus": -0.002797202797202923,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "U1xEvCCCjglTOvEIgpLiV",
        "focus": 0.0027972027972034325,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49860139860139857
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "hTfe_w4iv0b8ScPrZrIu1",
      "type": "arrow",
      "x": -1519.0912698412694,
      "y": -206.57896820634517,
      "width": 232.87499924999995,
      "height": 305.8006118881117,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9A",
      "roundness": null,
      "seed": 625752103,
      "version": 943,
      "versionNonce": 846853033,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          116.43749962499997,
          0
        ],
        [
          116.43749962499997,
          305.8006118881117
        ],
        [
          232.87499924999995,
          305.8006118881117
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "tBYM43jj8mYuY-EWvf3Bh",
        "focus": -0.002797202797202923,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "PKT9slJPXabSMz9vDMoij",
        "focus": -1.0507614213197969,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013984
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "OPJZh0HcYpLAfE6FuZYvM",
      "type": "arrow",
      "x": -1519.0912698412694,
      "y": -206.57896820634517,
      "width": 232.87499924999995,
      "height": 603.125,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9B",
      "roundness": null,
      "seed": 1199610695,
      "version": 919,
      "versionNonce": 1091516263,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          116.43749962499997,
          0
        ],
        [
          116.43749962499997,
          603.125
        ],
        [
          232.87499924999995,
          603.125
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "tBYM43jj8mYuY-EWvf3Bh",
        "focus": -0.002797202797204035,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "GpbJ8YFEWv5hvSyQbsM8l",
        "focus": -1.050761421319797,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "SNPZQhzhDD1iYw5KEZhcl",
      "type": "rectangle",
      "x": -831.0079371746027,
      "y": -909.461111063488,
      "width": 197.00000000000003,
      "height": 235,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "5g81oUlBkJkOCkEDE2oPW",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9C",
      "roundness": {
        "type": 3
      },
      "seed": 2069715591,
      "version": 1588,
      "versionNonce": 70227593,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "7GhhHB75viaRn-TGFbIda"
        },
        {
          "id": "U0cJZ9SGk8tFicskGGEvL",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "7GhhHB75viaRn-TGFbIda",
      "type": "text",
      "x": -798.5079371746027,
      "y": -904.461111063488,
      "width": 132,
      "height": 225,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "5g81oUlBkJkOCkEDE2oPW",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9D",
      "roundness": null,
      "seed": 1476293031,
      "version": 1481,
      "versionNonce": 1226945159,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "glossary\ndict_trigger\ndict_code\ndict_app\ndict_prompt\ning_prompt\nvocabulary\n..\n...",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "SNPZQhzhDD1iYw5KEZhcl",
      "originalText": "glossary\ndict_trigger\ndict_code\ndict_app\ndict_prompt\ning_prompt\nvocabulary\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "U0cJZ9SGk8tFicskGGEvL",
      "type": "arrow",
      "x": -1079.2162705912694,
      "y": -809.7039682063452,
      "width": 243.20833341666673,
      "height": 17.654177897574073,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "5g81oUlBkJkOCkEDE2oPW",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9E",
      "roundness": null,
      "seed": 1736153703,
      "version": 1635,
      "versionNonce": 418241897,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          121.60416670833342,
          0
        ],
        [
          121.60416670833342,
          17.654177897574073
        ],
        [
          243.20833341666673,
          17.654177897574073
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ChPL_8u0ia_qPxqBkLJLa",
        "focus": -0.0027972027972046854,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "SNPZQhzhDD1iYw5KEZhcl",
        "focus": 0.0007547169811309938,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49962264150943386
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "JWwKqb2sAu1aL0abITXlM",
      "type": "rectangle",
      "x": -835.6746038412695,
      "y": -643.5335052063452,
      "width": 197.00000000000003,
      "height": 285,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "WGeaI0XDMtNVl2yoRVQoA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9F",
      "roundness": {
        "type": 3
      },
      "seed": 153378567,
      "version": 1104,
      "versionNonce": 460835239,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "dPVoUGtNjzX6w1X_7tUf5"
        },
        {
          "id": "giDPe_XBBRBny-0sIPgfX",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "dPVoUGtNjzX6w1X_7tUf5",
      "type": "text",
      "x": -781.1746038412695,
      "y": -638.5335052063452,
      "width": 88,
      "height": 275,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "WGeaI0XDMtNVl2yoRVQoA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9G",
      "roundness": null,
      "seed": 259057191,
      "version": 1414,
      "versionNonce": 1342195785,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "learn\neval\ninsi\ntune\nshot\nrel\ntrn\nfeedback\n..\n...\n",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "JWwKqb2sAu1aL0abITXlM",
      "originalText": "learn\neval\ninsi\ntune\nshot\nrel\ntrn\nfeedback\n..\n...\n",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "giDPe_XBBRBny-0sIPgfX",
      "type": "arrow",
      "x": -1079.2162705912694,
      "y": -513.5206348730118,
      "width": 238.54166675,
      "height": 12.40268522222209,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "WGeaI0XDMtNVl2yoRVQoA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9H",
      "roundness": null,
      "seed": 1242150279,
      "version": 1039,
      "versionNonce": 1698561223,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          119.270833375,
          0
        ],
        [
          119.270833375,
          12.40268522222209
        ],
        [
          238.54166675,
          12.40268522222209
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "lGNGGysmCotfoVtZJpB4V",
        "focus": -0.15326340326339954,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4233682983683004
        ]
      },
      "endBinding": {
        "elementId": "JWwKqb2sAu1aL0abITXlM",
        "focus": 0.0005925925925922078,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4997037037037037
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "k8S5e1wXWhJrLuzMa1NR3",
      "type": "arrow",
      "x": -1079.2162705912694,
      "y": -206.57896820634517,
      "width": 241.54166675,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9I",
      "roundness": null,
      "seed": 1718054055,
      "version": 555,
      "versionNonce": 323114793,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          241.54166675,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": null,
      "endBinding": {
        "elementId": "5VCsqmFs7gkobcGoqbffw",
        "focus": 0.0007692307692313104,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49961538461538496
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "P87_G3JXA_r_NB6kkzCdJ",
      "type": "rectangle",
      "x": -832.6746038412695,
      "y": -53.04146820634526,
      "width": 197.00000000000003,
      "height": 260,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "w_GHaaK8dF-zjB3zh2EWa",
        "E0n6PFwLqwREAUJtWivqi",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9J",
      "roundness": {
        "type": 3
      },
      "seed": 505391111,
      "version": 1568,
      "versionNonce": 2047921127,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "fhG6s-2gipEomZ5Pv-zqj"
        },
        {
          "id": "yWn_D-XJBiR2-DsDDTgaF",
          "type": "arrow"
        },
        {
          "id": "zfBTLF7DoDrbnxh9A46JF",
          "type": "arrow"
        }
      ],
      "updated": 1755262053129,
      "link": null,
      "locked": false
    },
    {
      "id": "fhG6s-2gipEomZ5Pv-zqj",
      "type": "text",
      "x": -800.1746038412695,
      "y": -48.04146820634526,
      "width": 132,
      "height": 250,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "w_GHaaK8dF-zjB3zh2EWa",
        "E0n6PFwLqwREAUJtWivqi",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9K",
      "roundness": null,
      "seed": 1478168359,
      "version": 1774,
      "versionNonce": 85953033,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053129,
      "link": null,
      "locked": false,
      "text": "h_calculo\nmatrix\ntablas\nfichas\nresearche\ndosc\nentornos\narchitecture\n..\n...",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "P87_G3JXA_r_NB6kkzCdJ",
      "originalText": "h_calculo\nmatrix\ntablas\nfichas\nresearche\ndosc\nentornos\narchitecture\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "yWn_D-XJBiR2-DsDDTgaF",
      "type": "arrow",
      "x": -1029.2162705912694,
      "y": 99.22164368176675,
      "width": 191.54166675,
      "height": 22.35276706052582,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "w_GHaaK8dF-zjB3zh2EWa",
        "E0n6PFwLqwREAUJtWivqi",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9L",
      "roundness": null,
      "seed": 406929351,
      "version": 1135,
      "versionNonce": 100448007,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          95.770833375,
          0
        ],
        [
          95.770833375,
          -22.35276706052582
        ],
        [
          191.54166675,
          -22.35276706052582
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "PKT9slJPXabSMz9vDMoij",
        "focus": -0.0027972027972024594,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4986013986013988
        ]
      },
      "endBinding": {
        "elementId": "P87_G3JXA_r_NB6kkzCdJ",
        "focus": 0.0006896551724138405,
        "gap": 1,
        "fixedPoint": [
          -0.025380710659898473,
          0.49965517241379315
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "EVKUlxNqQZtOXzAKu76D8",
      "type": "rectangle",
      "x": -557.424603507937,
      "y": 47.958531793657016,
      "width": 140.00000000000003,
      "height": 58,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffd8a8",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "E0n6PFwLqwREAUJtWivqi",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9M",
      "roundness": {
        "type": 3
      },
      "seed": 1526977351,
      "version": 1305,
      "versionNonce": 1855152361,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "mG-6A-VI3R0_4eQ4JcdcW"
        },
        {
          "id": "zfBTLF7DoDrbnxh9A46JF",
          "type": "arrow"
        },
        {
          "id": "iynpiyxXj3HY3oGRPgDrp",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "mG-6A-VI3R0_4eQ4JcdcW",
      "type": "text",
      "x": -520.424603507937,
      "y": 64.45853179365702,
      "width": 66,
      "height": 25,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "E0n6PFwLqwREAUJtWivqi",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9N",
      "roundness": null,
      "seed": 366465639,
      "version": 1287,
      "versionNonce": 2138979879,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "matrix",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "EVKUlxNqQZtOXzAKu76D8",
      "originalText": "matrix",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "Xd-q144yaK5f7vQ9mI1Tp",
      "type": "rectangle",
      "x": -358.0912705079372,
      "y": -45.541467539676546,
      "width": 166.66666666666697,
      "height": 244.99999999999994,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "E0n6PFwLqwREAUJtWivqi",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9O",
      "roundness": {
        "type": 3
      },
      "seed": 1344204167,
      "version": 661,
      "versionNonce": 1831427017,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "sN8nU3BCKtyl4vEbgwmbE"
        },
        {
          "id": "iynpiyxXj3HY3oGRPgDrp",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "sN8nU3BCKtyl4vEbgwmbE",
      "type": "text",
      "x": -329.75793717460374,
      "y": -35.541467539676546,
      "width": 110,
      "height": 225,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#b2f2bb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "E0n6PFwLqwREAUJtWivqi",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9P",
      "roundness": null,
      "seed": 1695917223,
      "version": 837,
      "versionNonce": 1501684039,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "matrix\ntabla\nficha\nmapping\nrelation\nvalidation\nversus\n..\n...",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "Xd-q144yaK5f7vQ9mI1Tp",
      "originalText": "matrix\ntabla\nficha\nmapping\nrelation\nvalidation\nversus\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "zfBTLF7DoDrbnxh9A46JF",
      "type": "arrow",
      "x": -630.6746038412696,
      "y": 76.85853179365483,
      "width": 68.25000033333254,
      "height": 2.2737367544323206e-12,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "E0n6PFwLqwREAUJtWivqi",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9Q",
      "roundness": null,
      "seed": 709976359,
      "version": 929,
      "versionNonce": 1627191977,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          68.25000033333254,
          2.2737367544323206e-12
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "P87_G3JXA_r_NB6kkzCdJ",
        "focus": -0.0007692307692293573,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598978,
          0.49961538461538496
        ]
      },
      "endBinding": {
        "elementId": "EVKUlxNqQZtOXzAKu76D8",
        "focus": 0.0034482758620594718,
        "gap": 5,
        "fixedPoint": [
          -0.035714285714285705,
          0.49827586206896707
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "iynpiyxXj3HY3oGRPgDrp",
      "type": "arrow",
      "x": -412.42460350793704,
      "y": 76.85853179365711,
      "width": 49.33333299999981,
      "height": 6.666664376098197e-7,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "E0n6PFwLqwREAUJtWivqi",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9R",
      "roundness": null,
      "seed": 1241429705,
      "version": 1120,
      "versionNonce": 1969496167,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          49.33333299999981,
          6.666664376098197e-7
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "EVKUlxNqQZtOXzAKu76D8",
        "focus": -0.0034482758620594718,
        "gap": 5,
        "fixedPoint": [
          1.0357142857142856,
          0.49827586206896707
        ]
      },
      "endBinding": {
        "elementId": "Xd-q144yaK5f7vQ9mI1Tp",
        "focus": 0.0008163265306116783,
        "gap": 5,
        "fixedPoint": [
          -0.029999999999999947,
          0.4995918367346944
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "2Ave9sIpOY_nWkm61hBBn",
      "type": "diamond",
      "x": -4300.257936507929,
      "y": -391.9563492063446,
      "width": 631.666666666667,
      "height": 401.66666666666674,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffa94d",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 2,
      "opacity": 100,
      "groupIds": [
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9S",
      "roundness": {
        "type": 2
      },
      "seed": 1606806874,
      "version": 241,
      "versionNonce": 448380297,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "_XUIvC8ZI2ysW8IxLEpm0"
        },
        {
          "id": "3_G8yJtQtYqe5L4Bs86YZ",
          "type": "arrow"
        },
        {
          "id": "H9ynHjyI8m0F3xP8Yu83i",
          "type": "arrow"
        },
        {
          "id": "V1ywEwlhLrINiWsCZXNFg",
          "type": "arrow"
        },
        {
          "id": "rkaKx9n3L0a1PUEbjn24L",
          "type": "arrow"
        },
        {
          "id": "RggJrR1ZjcyCulsXz9ioG",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "_XUIvC8ZI2ysW8IxLEpm0",
      "type": "text",
      "x": -4132.841178288528,
      "y": -236.03968253967793,
      "width": 296.99981689453125,
      "height": 90,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9T",
      "roundness": null,
      "seed": 542396762,
      "version": 184,
      "versionNonce": 1425111943,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "AingZ_Platform/\nmain/.",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "2Ave9sIpOY_nWkm61hBBn",
      "originalText": "AingZ_Platform/main/.",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "pQyMbvwRVSB1miWHHnPK6",
      "type": "rectangle",
      "x": -4116.67460250793,
      "y": -948.8611105396778,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "ZNXv6gFV4YuIRgxY1khsf",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9U",
      "roundness": {
        "type": 3
      },
      "seed": 2080389958,
      "version": 903,
      "versionNonce": 1234904169,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "zJEXTapZ-Zk2-CPGDMWwo"
        },
        {
          "id": "3_G8yJtQtYqe5L4Bs86YZ",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "zJEXTapZ-Zk2-CPGDMWwo",
      "type": "text",
      "x": -4083.424541472774,
      "y": -921.3611105396778,
      "width": 197.9998779296875,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "ZNXv6gFV4YuIRgxY1khsf",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9V",
      "roundness": null,
      "seed": 539288198,
      "version": 915,
      "versionNonce": 208040615,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./ruleset/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "pQyMbvwRVSB1miWHHnPK6",
      "originalText": "./ruleset/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "3_G8yJtQtYqe5L4Bs86YZ",
      "type": "arrow",
      "x": -3984.5246044635046,
      "y": -384.393085795915,
      "width": 0.0000019555745893740095,
      "height": 459.46802474376284,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffa94d",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "ZNXv6gFV4YuIRgxY1khsf",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9W",
      "roundness": null,
      "seed": 941505434,
      "version": 44,
      "versionNonce": 694988617,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          0.0000019555745893740095,
          -459.46802474376284
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "2Ave9sIpOY_nWkm61hBBn",
        "focus": -0.0004979268400778008,
        "gap": 17.56305718575779,
        "fixedPoint": [
          0.4998416866138644,
          0.01882970143675422
        ]
      },
      "endBinding": {
        "elementId": "pQyMbvwRVSB1miWHHnPK6",
        "focus": 0.0007561418960273611,
        "gap": 5,
        "fixedPoint": [
          0.49962192816635187,
          1.05
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "FhTpCYFogvSEcG_JO_XYE",
      "type": "rectangle",
      "x": -3263.341270507937,
      "y": -241.12301620634568,
      "width": 287.00000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "PxeA0BDx7Xjhpj80cDlbu",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9X",
      "roundness": {
        "type": 3
      },
      "seed": 886105671,
      "version": 1145,
      "versionNonce": 1953465799,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "NJgFg_zvyAzzYRgjbJ5QA"
        },
        {
          "id": "H9ynHjyI8m0F3xP8Yu83i",
          "type": "arrow"
        },
        {
          "id": "jFpd1Y876XO7BSFLE0xM-",
          "type": "arrow"
        },
        {
          "id": "Az5leZiibfMFwwN0ketGJ",
          "type": "arrow"
        },
        {
          "id": "tdwrNAiDtVrpQjef8Cy2Q",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "NJgFg_zvyAzzYRgjbJ5QA",
      "type": "text",
      "x": -3238.6411972657497,
      "y": -213.62301620634568,
      "width": 237.599853515625,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "PxeA0BDx7Xjhpj80cDlbu",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9Y",
      "roundness": null,
      "seed": 2055898471,
      "version": 1132,
      "versionNonce": 1888083497,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./data_base/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "FhTpCYFogvSEcG_JO_XYE",
      "originalText": "./data_base/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "H9ynHjyI8m0F3xP8Yu83i",
      "type": "arrow",
      "x": -3683.344236152146,
      "y": -191.22301587301124,
      "width": 415.0029656442084,
      "height": 3.3333444093841536e-7,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffa94d",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "PxeA0BDx7Xjhpj80cDlbu",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9Z",
      "roundness": null,
      "seed": 929918150,
      "version": 53,
      "versionNonce": 472462567,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          415.0029656442084,
          -3.3333444093841536e-7
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "2Ave9sIpOY_nWkm61hBBn",
        "focus": -0.0004979239639415234,
        "gap": 24.751026458952268,
        "fixedPoint": [
          0.976644380510474,
          0.49975103734439835
        ]
      },
      "endBinding": {
        "elementId": "FhTpCYFogvSEcG_JO_XYE",
        "focus": 0.002000002380922646,
        "gap": 5,
        "fixedPoint": [
          -0.017421602787458027,
          0.49900000000000005
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "f5wn4TaH6M_fIjJaC0kgy",
      "type": "rectangle",
      "x": -4965.841269507929,
      "y": -552.3730162063446,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "uAQH1QaQOiNh-1FP_QOUk",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9a",
      "roundness": {
        "type": 3
      },
      "seed": 332142214,
      "version": 933,
      "versionNonce": 2111713545,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "8dE70rB3T2SRdePjGeBWC"
        },
        {
          "id": "rkaKx9n3L0a1PUEbjn24L",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "8dE70rB3T2SRdePjGeBWC",
      "type": "text",
      "x": -4942.491202369257,
      "y": -524.8730162063446,
      "width": 217.79986572265625,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "uAQH1QaQOiNh-1FP_QOUk",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9b",
      "roundness": null,
      "seed": 1616074182,
      "version": 946,
      "versionNonce": 2065694727,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./packages/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "f5wn4TaH6M_fIjJaC0kgy",
      "originalText": "./packages/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "-z_FrefnpkgBVfhjfYH_V",
      "type": "rectangle",
      "x": -4970.007936174595,
      "y": 70.12698379365554,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "uAQH1QaQOiNh-1FP_QOUk",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9c",
      "roundness": {
        "type": 3
      },
      "seed": 766697734,
      "version": 898,
      "versionNonce": 1189423081,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "mvXceK9YAJuS367o7yWap"
        },
        {
          "id": "RggJrR1ZjcyCulsXz9ioG",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "mvXceK9YAJuS367o7yWap",
      "type": "text",
      "x": -4936.7578751394385,
      "y": 97.62698379365554,
      "width": 197.9998779296875,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "uAQH1QaQOiNh-1FP_QOUk",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9d",
      "roundness": null,
      "seed": 1476186182,
      "version": 910,
      "versionNonce": 1666213671,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./scripts/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "-z_FrefnpkgBVfhjfYH_V",
      "originalText": "./scripts/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "rkaKx9n3L0a1PUEbjn24L",
      "type": "arrow",
      "x": -4285.504970197046,
      "y": -191.22301587301124,
      "width": 410.8362993108831,
      "height": 311.25000033333333,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffa94d",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "uAQH1QaQOiNh-1FP_QOUk",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9e",
      "roundness": null,
      "seed": 357859334,
      "version": 66,
      "versionNonce": 95044297,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          -215.29463281088283,
          0
        ],
        [
          -215.29463281088283,
          -311.25000033333333
        ],
        [
          -410.8362993108831,
          -311.25000033333333
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "2Ave9sIpOY_nWkm61hBBn",
        "focus": 0.0004979253112032911,
        "gap": 24.751026458952268,
        "fixedPoint": [
          0.02335561948952531,
          0.49975103734439835
        ]
      },
      "endBinding": {
        "elementId": "f5wn4TaH6M_fIjJaC0kgy",
        "focus": -0.002000000000001691,
        "gap": 5,
        "fixedPoint": [
          1.0189035916824194,
          0.4989999999999998
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "RggJrR1ZjcyCulsXz9ioG",
      "type": "arrow",
      "x": -4285.504970197046,
      "y": -191.22301587301124,
      "width": 415.00296597754914,
      "height": 311.2499996666668,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffa94d",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "uAQH1QaQOiNh-1FP_QOUk",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9f",
      "roundness": null,
      "seed": 928330202,
      "version": 61,
      "versionNonce": 858188359,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          -217.37796614421677,
          0
        ],
        [
          -217.37796614421677,
          311.2499996666668
        ],
        [
          -415.00296597754914,
          311.2499996666668
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "2Ave9sIpOY_nWkm61hBBn",
        "focus": 0.0004979253112032911,
        "gap": 24.751026458952268,
        "fixedPoint": [
          0.02335561948952531,
          0.49975103734439835
        ]
      },
      "endBinding": {
        "elementId": "-z_FrefnpkgBVfhjfYH_V",
        "focus": -0.0019999999999954607,
        "gap": 5,
        "fixedPoint": [
          1.0189035916824194,
          0.49900000000000005
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "sEYV8RtrK4nOSYFnpNUiv",
      "type": "rectangle",
      "x": -4116.674602507928,
      "y": 466.61507946032214,
      "width": 264.50000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9g",
      "roundness": {
        "type": 3
      },
      "seed": 933318662,
      "version": 932,
      "versionNonce": 650707369,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "TvCFoYI6CVeI2kKrEfIY3"
        },
        {
          "id": "V1ywEwlhLrINiWsCZXNFg",
          "type": "arrow"
        },
        {
          "id": "vSCkgUUQ4ojrYABwfdd-G",
          "type": "arrow"
        },
        {
          "id": "Mjrm35e2nQDDkPugGA9ZM",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "TvCFoYI6CVeI2kKrEfIY3",
      "type": "text",
      "x": -4043.8245658868345,
      "y": 494.11507946032214,
      "width": 118.7999267578125,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9h",
      "roundness": null,
      "seed": 407199558,
      "version": 932,
      "versionNonce": 1199573351,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./log/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "sEYV8RtrK4nOSYFnpNUiv",
      "originalText": "./log/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "V1ywEwlhLrINiWsCZXNFg",
      "type": "arrow",
      "x": -3984.5246044616733,
      "y": 2.1470540499071262,
      "width": 0.0000019537451407813933,
      "height": 459.46802541041495,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffa94d",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9i",
      "roundness": null,
      "seed": 1249278662,
      "version": 55,
      "versionNonce": 2003625097,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          0.0000019537451407813933,
          459.46802541041495
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "2Ave9sIpOY_nWkm61hBBn",
        "focus": 0.0004979268400845937,
        "gap": 17.563057185757835,
        "fixedPoint": [
          0.49984168661676354,
          0.9811702985632822
        ]
      },
      "endBinding": {
        "elementId": "sEYV8RtrK4nOSYFnpNUiv",
        "focus": -0.000756141897684761,
        "gap": 5,
        "fixedPoint": [
          0.49962192816635187,
          -0.05000000000000057
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "uvvfz-IUO4ZJ5vZsldx8R",
      "type": "rectangle",
      "x": -4396.504969549602,
      "y": 1051.9920631269888,
      "width": 221.99999954960188,
      "height": 179,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "aosGC9B-3i1lvQu-9sZ2D",
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9j",
      "roundness": {
        "type": 3
      },
      "seed": 48305351,
      "version": 998,
      "versionNonce": 766002311,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "tRZ0gzeIRLwQepd34z_Lu"
        },
        {
          "id": "V1qHEQiKanAmDMVanRhK-",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "tRZ0gzeIRLwQepd34z_Lu",
      "type": "text",
      "x": -4357.004969774801,
      "y": 1066.4920631269888,
      "width": 143,
      "height": 150,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#b2f2bb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "aosGC9B-3i1lvQu-9sZ2D",
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9k",
      "roundness": null,
      "seed": 596698087,
      "version": 1403,
      "versionNonce": 324103017,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "changelog\nlogbook\nauditlog\nvalidationlog\n..\n...",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "uvvfz-IUO4ZJ5vZsldx8R",
      "originalText": "changelog\nlogbook\nauditlog\nvalidationlog\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "CZD6rK0K9eH38p6Q_uwMK",
      "type": "rectangle",
      "x": -4396.504969841265,
      "y": 875.5436507936556,
      "width": 222.00000000000003,
      "height": 79.00000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "aosGC9B-3i1lvQu-9sZ2D",
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9l",
      "roundness": {
        "type": 3
      },
      "seed": 146521754,
      "version": 687,
      "versionNonce": 358357927,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "UH1GGsBfCUW6APlqKwJaX"
        },
        {
          "id": "V1qHEQiKanAmDMVanRhK-",
          "type": "arrow"
        },
        {
          "id": "vSCkgUUQ4ojrYABwfdd-G",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "UH1GGsBfCUW6APlqKwJaX",
      "type": "text",
      "x": -4377.904933220171,
      "y": 897.5436507936556,
      "width": 184.7999267578125,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "aosGC9B-3i1lvQu-9sZ2D",
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9m",
      "roundness": null,
      "seed": 1119673178,
      "version": 700,
      "versionNonce": 314709577,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./changelog/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "CZD6rK0K9eH38p6Q_uwMK",
      "originalText": "./changelog/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "V1qHEQiKanAmDMVanRhK-",
      "type": "arrow",
      "x": -4285.604969841265,
      "y": 959.5436507936555,
      "width": 6.646405381616205e-8,
      "height": 87.4484123333333,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "aosGC9B-3i1lvQu-9sZ2D",
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9n",
      "roundness": null,
      "seed": 1385098586,
      "version": 135,
      "versionNonce": 46665415,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          6.646405381616205e-8,
          87.4484123333333
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "CZD6rK0K9eH38p6Q_uwMK",
        "focus": 0.0009009012053634067,
        "gap": 5,
        "fixedPoint": [
          0.49954954954954783,
          1.0632911392405047
        ]
      },
      "endBinding": {
        "elementId": "uvvfz-IUO4ZJ5vZsldx8R",
        "focus": -0.0009009000632293554,
        "gap": 5,
        "fixedPoint": [
          0.49954954954863395,
          -0.02127659574468085
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "QndZn33Lrjkdj_qFivzzg",
      "type": "rectangle",
      "x": -3794.3442355496018,
      "y": 1051.9920631269886,
      "width": 221.99999954960188,
      "height": 155,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "sM51dW6d9MxShCIuuqZkA",
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9o",
      "roundness": {
        "type": 3
      },
      "seed": 1624832327,
      "version": 1140,
      "versionNonce": 2023384361,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "qnLpc-357NnldKEbrYs6E"
        },
        {
          "id": "Is8oGX7RxvZTba82eJ4Gy",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "qnLpc-357NnldKEbrYs6E",
      "type": "text",
      "x": -3727.344235774801,
      "y": 1066.9920631269886,
      "width": 88,
      "height": 125,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#b2f2bb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "sM51dW6d9MxShCIuuqZkA",
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9p",
      "roundness": null,
      "seed": 840448103,
      "version": 1530,
      "versionNonce": 1082695143,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "trace\ncrossref\nversion\n..\n...",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "QndZn33Lrjkdj_qFivzzg",
      "originalText": "trace\ncrossref\nversion\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "0h6ETNTApGPBelQeCrMdg",
      "type": "rectangle",
      "x": -3794.344235841265,
      "y": 875.5436507936556,
      "width": 222.00000000000003,
      "height": 79.00000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "sM51dW6d9MxShCIuuqZkA",
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9q",
      "roundness": {
        "type": 3
      },
      "seed": 1886884550,
      "version": 722,
      "versionNonce": 1615190025,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "SRCC-5OpmrvsNYd021USo"
        },
        {
          "id": "Is8oGX7RxvZTba82eJ4Gy",
          "type": "arrow"
        },
        {
          "id": "Mjrm35e2nQDDkPugGA9ZM",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "SRCC-5OpmrvsNYd021USo",
      "type": "text",
      "x": -3729.544217530718,
      "y": 897.5436507936556,
      "width": 92.39996337890625,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "sM51dW6d9MxShCIuuqZkA",
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9r",
      "roundness": null,
      "seed": 1254443526,
      "version": 774,
      "versionNonce": 296372487,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./qms/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "0h6ETNTApGPBelQeCrMdg",
      "originalText": "./qms/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "Is8oGX7RxvZTba82eJ4Gy",
      "type": "arrow",
      "x": -3683.444235841265,
      "y": 959.5436507936555,
      "width": 6.646405381616205e-8,
      "height": 87.44841233333307,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "sM51dW6d9MxShCIuuqZkA",
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9s",
      "roundness": null,
      "seed": 1928534810,
      "version": 217,
      "versionNonce": 1807740649,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          6.646405381616205e-8,
          87.44841233333307
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "0h6ETNTApGPBelQeCrMdg",
        "focus": 0.000900901205352174,
        "gap": 5,
        "fixedPoint": [
          0.4995495495495499,
          1.0632911392405047
        ]
      },
      "endBinding": {
        "elementId": "QndZn33Lrjkdj_qFivzzg",
        "focus": -0.0009009000632215144,
        "gap": 2.148688630641023,
        "fixedPoint": [
          0.499549549548636,
          -0.02127659574468085
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "vSCkgUUQ4ojrYABwfdd-G",
      "type": "arrow",
      "x": -3984.524602507928,
      "y": 571.615079460322,
      "width": 301.0803673333371,
      "height": 298.9285713333336,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9t",
      "roundness": null,
      "seed": 933450010,
      "version": 51,
      "versionNonce": 598315047,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          0,
          149.4642856666669
        ],
        [
          -301.0803673333371,
          149.4642856666669
        ],
        [
          -301.0803673333371,
          298.9285713333336
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "sEYV8RtrK4nOSYFnpNUiv",
        "focus": 0.000756143667297094,
        "gap": 5,
        "fixedPoint": [
          0.49962192816635187,
          1.049999999999999
        ]
      },
      "endBinding": {
        "elementId": "CZD6rK0K9eH38p6Q_uwMK",
        "focus": -1.1265822784810116,
        "gap": 5,
        "fixedPoint": [
          0.49954954954954783,
          -0.06329113924050632
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "Mjrm35e2nQDDkPugGA9ZM",
      "type": "arrow",
      "x": -3984.524602507928,
      "y": 571.615079460322,
      "width": 301.0803666666634,
      "height": 298.9285713333336,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "djt1SHcYflP8pEm41uiic",
        "X3rFQrr1bbIs7aUbOqNHA",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9u",
      "roundness": null,
      "seed": 1002143322,
      "version": 49,
      "versionNonce": 1905535433,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          0,
          149.4642856666669
        ],
        [
          301.0803666666634,
          149.4642856666669
        ],
        [
          301.0803666666634,
          298.9285713333336
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "sEYV8RtrK4nOSYFnpNUiv",
        "focus": 0.000756143667297094,
        "gap": 5,
        "fixedPoint": [
          0.49962192816635187,
          1.049999999999999
        ]
      },
      "endBinding": {
        "elementId": "0h6ETNTApGPBelQeCrMdg",
        "focus": 1.1265822784810116,
        "gap": 5,
        "fixedPoint": [
          0.4995495495495499,
          -0.06329113924050632
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "WeS9hbEYAHliuay6ipZ6g",
      "type": "rectangle",
      "x": -2523.674603174599,
      "y": -948.861110539679,
      "width": 377.000000174599,
      "height": 79.00000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "19gKvSxi25TVmlUvad24K",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9v",
      "roundness": {
        "type": 3
      },
      "seed": 451901033,
      "version": 944,
      "versionNonce": 1081275207,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "3HS4VjZjnM1XpKH3C0PSr"
        },
        {
          "id": "jFpd1Y876XO7BSFLE0xM-",
          "type": "arrow"
        },
        {
          "id": "k1m6oBcyg5DVWEdJLjpFV",
          "type": "arrow"
        },
        {
          "id": "0x8ftoO3_ZbXaH1dT91sp",
          "type": "arrow"
        },
        {
          "id": "1HXtps0d7zgihkJinATeN",
          "type": "arrow"
        },
        {
          "id": "ZM25nw-oJ51iV9Fs8jytm",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "3HS4VjZjnM1XpKH3C0PSr",
      "type": "text",
      "x": -2427.5745664662054,
      "y": -926.861110539679,
      "width": 184.7999267578125,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "19gKvSxi25TVmlUvad24K",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9w",
      "roundness": null,
      "seed": 812040521,
      "version": 923,
      "versionNonce": 1792936105,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./core_actv/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "WeS9hbEYAHliuay6ipZ6g",
      "originalText": "./core_actv/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "61Ljd3nD5TU9wvBuM_rtz",
      "type": "rectangle",
      "x": -2523.674603174599,
      "y": 477.6269844603216,
      "width": 377.00000017459894,
      "height": 79.00000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "19gKvSxi25TVmlUvad24K",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9x",
      "roundness": {
        "type": 3
      },
      "seed": 310631578,
      "version": 1610,
      "versionNonce": 1080226407,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "5Sj90xUZT9vwSNreVt2DR"
        },
        {
          "id": "Az5leZiibfMFwwN0ketGJ",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "5Sj90xUZT9vwSNreVt2DR",
      "type": "text",
      "x": -2419.874569517963,
      "y": 499.6269844603216,
      "width": 169.39993286132812,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "19gKvSxi25TVmlUvad24K",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9y",
      "roundness": null,
      "seed": 1506883930,
      "version": 1616,
      "versionNonce": 558435209,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./core_dev/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "61Ljd3nD5TU9wvBuM_rtz",
      "originalText": "./core_dev/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "PuknUGO2vcGhZsRl3t0vK",
      "type": "rectangle",
      "x": -2523.674603174599,
      "y": 1150.9920634603216,
      "width": 377.0000000000003,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "19gKvSxi25TVmlUvad24K",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "b9z",
      "roundness": {
        "type": 3
      },
      "seed": 40493146,
      "version": 1083,
      "versionNonce": 1011223943,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "eR-FcRrCRp-RoAIAvKxzw"
        },
        {
          "id": "tdwrNAiDtVrpQjef8Cy2Q",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "eR-FcRrCRp-RoAIAvKxzw",
      "type": "text",
      "x": -2496.8745390876848,
      "y": 1173.4920634603216,
      "width": 323.3998718261719,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "19gKvSxi25TVmlUvad24K",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bA0",
      "roundness": null,
      "seed": 767608090,
      "version": 1105,
      "versionNonce": 487633513,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./core_arch_platform/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "PuknUGO2vcGhZsRl3t0vK",
      "originalText": "./core_arch_platform/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "jFpd1Y876XO7BSFLE0xM-",
      "type": "arrow",
      "x": -2971.3412705079377,
      "y": -191.22301620634568,
      "width": 442.6666673333384,
      "height": 718.2380943333333,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "19gKvSxi25TVmlUvad24K",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bA1",
      "roundness": null,
      "seed": 732194118,
      "version": 73,
      "versionNonce": 2136523943,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          221.33333366666966,
          0
        ],
        [
          221.33333366666966,
          -718.2380943333333
        ],
        [
          442.6666673333384,
          -718.2380943333333
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "FhTpCYFogvSEcG_JO_XYE",
        "focus": -0.001999999999996025,
        "gap": 4.999999999999545,
        "fixedPoint": [
          1.0174216027874547,
          0.49900000000000005
        ]
      },
      "endBinding": {
        "elementId": "WeS9hbEYAHliuay6ipZ6g",
        "focus": 1.026525198926711,
        "gap": 5,
        "fixedPoint": [
          -0.013262599463354955,
          0.4987341772151895
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "Az5leZiibfMFwwN0ketGJ",
      "type": "arrow",
      "x": -2971.3412705079377,
      "y": -191.22301620634568,
      "width": 442.66666733333886,
      "height": 708.2500006666673,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "19gKvSxi25TVmlUvad24K",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bA2",
      "roundness": null,
      "seed": 175567002,
      "version": 79,
      "versionNonce": 1392541001,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          221.33333366666966,
          0
        ],
        [
          221.33333366666966,
          708.2500006666673
        ],
        [
          442.66666733333886,
          708.2500006666673
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "FhTpCYFogvSEcG_JO_XYE",
        "focus": -0.0019999999999959018,
        "gap": 4.999999999999545,
        "fixedPoint": [
          1.0174216027874547,
          0.49900000000000005
        ]
      },
      "endBinding": {
        "elementId": "61Ljd3nD5TU9wvBuM_rtz",
        "focus": -1.0265251989267086,
        "gap": 5,
        "fixedPoint": [
          -0.013262599463353751,
          0.4987341772151902
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "tdwrNAiDtVrpQjef8Cy2Q",
      "type": "arrow",
      "x": -2971.3412705079377,
      "y": -191.22301620634568,
      "width": 442.66666733333886,
      "height": 1382.1150796666673,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "19gKvSxi25TVmlUvad24K",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bA3",
      "roundness": null,
      "seed": 1356579482,
      "version": 209,
      "versionNonce": 960993223,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          221.33333366666966,
          0
        ],
        [
          221.33333366666966,
          1382.1150796666673
        ],
        [
          442.66666733333886,
          1382.1150796666673
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "FhTpCYFogvSEcG_JO_XYE",
        "focus": -0.0020000000000017382,
        "gap": 4.999999999999545,
        "fixedPoint": [
          1.0174216027874547,
          0.49900000000000005
        ]
      },
      "endBinding": {
        "elementId": "PuknUGO2vcGhZsRl3t0vK",
        "focus": -1.0265251989389887,
        "gap": 5,
        "fixedPoint": [
          -0.013262599469496011,
          0.49875000000000114
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "-Qo7fAcawoztpotaWfJZG",
      "type": "rectangle",
      "x": -1721.091269507929,
      "y": 786.1857144603216,
      "width": 277.00000000000006,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "VmyOf2n22gbGaimnwzC5w",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bA4",
      "roundness": {
        "type": 3
      },
      "seed": 2044480666,
      "version": 1104,
      "versionNonce": 309586985,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "I8YfzZ2R2Zzex91Y8SoB0"
        },
        {
          "id": "1HXtps0d7zgihkJinATeN",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "I8YfzZ2R2Zzex91Y8SoB0",
      "type": "text",
      "x": -1698.0912237315617,
      "y": 808.6857144603216,
      "width": 230.99990844726562,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "VmyOf2n22gbGaimnwzC5w",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bA5",
      "roundness": null,
      "seed": 479963482,
      "version": 1357,
      "versionNonce": 1882130151,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./kns/ctx_vivo/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "-Qo7fAcawoztpotaWfJZG",
      "originalText": "./kns/ctx_vivo/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "LkNyKCSEACOimTrwt8mzp",
      "type": "rectangle",
      "x": -1726.0912695079292,
      "y": 1382.3948975719968,
      "width": 277.9999995079292,
      "height": 78,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "f1_znDTHFgTM6e_7RJuzV",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bA6",
      "roundness": {
        "type": 3
      },
      "seed": 311584858,
      "version": 1017,
      "versionNonce": 861306633,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "pUHWWy-oeSYqo0OJMnnLJ"
        },
        {
          "id": "ZM25nw-oJ51iV9Fs8jytm",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "pUHWWy-oeSYqo0OJMnnLJ",
      "type": "text",
      "x": -1691.580176614316,
      "y": 1404.4278924958546,
      "width": 208.97781372070312,
      "height": 33.934010152284266,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "f1_znDTHFgTM6e_7RJuzV",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bA7",
      "roundness": null,
      "seed": 932728090,
      "version": 1121,
      "versionNonce": 849056263,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./wf_template/",
      "fontSize": 27.14720812182741,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "LkNyKCSEACOimTrwt8mzp",
      "originalText": "./wf_template/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "k1m6oBcyg5DVWEdJLjpFV",
      "type": "arrow",
      "x": -2141.674603,
      "y": -909.461110539679,
      "width": 415.5833334920635,
      "height": 765.1249999999999,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bA8",
      "roundness": null,
      "seed": 263160774,
      "version": 52,
      "versionNonce": 69449193,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          207.79166674603175,
          0
        ],
        [
          207.79166674603175,
          -765.1249999999999
        ],
        [
          415.5833334920635,
          -765.1249999999999
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "WeS9hbEYAHliuay6ipZ6g",
        "focus": -0.002531645569619664,
        "gap": 5,
        "fixedPoint": [
          1.0132625994633535,
          0.4987341772151895
        ]
      },
      "endBinding": {
        "elementId": "ShlnvCC3MUCM2hylriOTD",
        "focus": 1.0507614213197964,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013998
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "0x8ftoO3_ZbXaH1dT91sp",
      "type": "arrow",
      "x": -2141.674603,
      "y": -909.461110539679,
      "width": 415.5833331587305,
      "height": 702.8821423333337,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bA9",
      "roundness": null,
      "seed": 2112577414,
      "version": 48,
      "versionNonce": 160020775,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          207.79166657936526,
          0
        ],
        [
          207.79166657936526,
          702.8821423333337
        ],
        [
          415.5833331587305,
          702.8821423333337
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "WeS9hbEYAHliuay6ipZ6g",
        "focus": -0.002531645569619664,
        "gap": 5,
        "fixedPoint": [
          1.0132625994633535,
          0.4987341772151895
        ]
      },
      "endBinding": {
        "elementId": "tBYM43jj8mYuY-EWvf3Bh",
        "focus": -1.050761421319797,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "1HXtps0d7zgihkJinATeN",
      "type": "arrow",
      "x": -2141.674603,
      "y": -909.461110539679,
      "width": 415.583333492071,
      "height": 1735.5468250000006,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAA",
      "roundness": null,
      "seed": 1519684806,
      "version": 64,
      "versionNonce": 2011631817,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          207.7916667460354,
          0
        ],
        [
          207.7916667460354,
          1735.5468250000006
        ],
        [
          415.583333492071,
          1735.5468250000006
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "WeS9hbEYAHliuay6ipZ6g",
        "focus": -0.002531645569619664,
        "gap": 5,
        "fixedPoint": [
          1.0132625994633535,
          0.4987341772151895
        ]
      },
      "endBinding": {
        "elementId": "-Qo7fAcawoztpotaWfJZG",
        "focus": -1.0361010830324926,
        "gap": 5,
        "fixedPoint": [
          -0.018050541516245484,
          0.4987499999999997
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "ZM25nw-oJ51iV9Fs8jytm",
      "type": "arrow",
      "x": -2141.674603,
      "y": -918.3690476190422,
      "width": 410.58333349207055,
      "height": 2344.9999999999973,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAB",
      "roundness": null,
      "seed": 389245958,
      "version": 85,
      "versionNonce": 711326791,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          205.2916667460354,
          0
        ],
        [
          205.2916667460354,
          2344.9999999999973
        ],
        [
          410.58333349207055,
          2344.9999999999973
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "WeS9hbEYAHliuay6ipZ6g",
        "focus": -0.228049039983879,
        "gap": 5,
        "fixedPoint": [
          1.0132625994633535,
          0.38597548000805976
        ]
      },
      "endBinding": {
        "elementId": "LkNyKCSEACOimTrwt8mzp",
        "focus": -1.0359712230852567,
        "gap": 5.000000000000227,
        "fixedPoint": [
          -0.017985611542627417,
          0.5671289078071566
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "xfoTkwa0D7hfzNtp3S1QR",
      "type": "rectangle",
      "x": -832.6746039523629,
      "y": 687.9357143809577,
      "width": 254.49999996824198,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAC",
      "roundness": {
        "type": 3
      },
      "seed": 2060866202,
      "version": 1390,
      "versionNonce": 339480489,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "v7A8G8YbKeBFdIIGcjF6W"
        },
        {
          "id": "FwSwA6YXE4TubMyFuMt1X",
          "type": "arrow"
        },
        {
          "id": "Ax2jbmApwKAxxMy15cxan",
          "type": "arrow"
        },
        {
          "id": "2eEQAbjo6MgjvGwHsaGV5",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "v7A8G8YbKeBFdIIGcjF6W",
      "type": "text",
      "x": -774.7245765024215,
      "y": 706.1857143809577,
      "width": 138.59994506835938,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAD",
      "roundness": null,
      "seed": 1013247834,
      "version": 1485,
      "versionNonce": 1762450279,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./planin/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "xfoTkwa0D7hfzNtp3S1QR",
      "originalText": "./planin/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "tn6cPNzUZN_L3Idwry0EN",
      "type": "rectangle",
      "x": -837.6746039682419,
      "y": 1071.0130958809577,
      "width": 254.49999999999994,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAE",
      "roundness": {
        "type": 3
      },
      "seed": 794273286,
      "version": 1405,
      "versionNonce": 525218441,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "odvmuHlq1-_Abk1Wm7wgf"
        },
        {
          "id": "7BX3UUdPMMayWd219Ygap",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "odvmuHlq1-_Abk1Wm7wgf",
      "type": "text",
      "x": -818.2245612436325,
      "y": 1093.5130958809577,
      "width": 215.59991455078125,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAF",
      "roundness": null,
      "seed": 851506502,
      "version": 1528,
      "versionNonce": 1774900871,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./run_control/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "tn6cPNzUZN_L3Idwry0EN",
      "originalText": "./run_control/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "f67V1iJ7wwKjr3dVNfnLc",
      "type": "rectangle",
      "x": -837.6746039682419,
      "y": 1386.630952380958,
      "width": 254.49999999999994,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAG",
      "roundness": {
        "type": 3
      },
      "seed": 1205547226,
      "version": 1452,
      "versionNonce": 232323433,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "7x2SlOPgl00DafhTNKx4E"
        },
        {
          "id": "QdyQtEBHAuktKO5InCulw",
          "type": "arrow"
        },
        {
          "id": "IWpmubOG1dlu7HQD0WmWk",
          "type": "arrow"
        }
      ],
      "updated": 1755262053130,
      "link": null,
      "locked": false
    },
    {
      "id": "7x2SlOPgl00DafhTNKx4E",
      "type": "text",
      "x": -795.1245703989059,
      "y": 1409.130952380958,
      "width": 169.39993286132812,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAH",
      "roundness": null,
      "seed": 1236534682,
      "version": 1593,
      "versionNonce": 324824487,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "text": "./pipeline/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "f67V1iJ7wwKjr3dVNfnLc",
      "originalText": "./pipeline/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "FwSwA6YXE4TubMyFuMt1X",
      "type": "arrow",
      "x": -1079.2162705912697,
      "y": 396.5460317936547,
      "width": 241.5416666389068,
      "height": 327.039682587303,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAI",
      "roundness": null,
      "seed": 1660857862,
      "version": 150,
      "versionNonce": 824697929,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053130,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          120.77083331945346,
          0
        ],
        [
          120.77083331945346,
          327.039682587303
        ],
        [
          241.5416666389068,
          327.039682587303
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "GpbJ8YFEWv5hvSyQbsM8l",
        "focus": -0.0027972099662481463,
        "gap": 5,
        "fixedPoint": [
          1.025380710659897,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "xfoTkwa0D7hfzNtp3S1QR",
        "focus": 0.002797193587586167,
        "gap": 5,
        "fixedPoint": [
          -0.019646365424848447,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "7BX3UUdPMMayWd219Ygap",
      "type": "arrow",
      "x": -1079.2162705912697,
      "y": 396.5460317936547,
      "width": 236.54166662302782,
      "height": 714.3670640873031,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAJ",
      "roundness": null,
      "seed": 1102287514,
      "version": 113,
      "versionNonce": 1089347783,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053131,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          118.27083331151402,
          0
        ],
        [
          118.27083331151402,
          714.3670640873031
        ],
        [
          236.54166662302782,
          714.3670640873031
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "GpbJ8YFEWv5hvSyQbsM8l",
        "focus": -0.002797202797204545,
        "gap": 5,
        "fixedPoint": [
          1.025380710659897,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "tn6cPNzUZN_L3Idwry0EN",
        "focus": -1.0392927308447937,
        "gap": 5,
        "fixedPoint": [
          -0.01964636542239686,
          0.4987499999999997
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "QdyQtEBHAuktKO5InCulw",
      "type": "arrow",
      "x": -1079.2162705912697,
      "y": 396.5460317936547,
      "width": 236.5416666230277,
      "height": 1029.9849205873031,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAK",
      "roundness": null,
      "seed": 1676549786,
      "version": 163,
      "versionNonce": 622228265,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053131,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          118.27083331151402,
          0
        ],
        [
          118.27083331151402,
          1029.9849205873031
        ],
        [
          236.5416666230277,
          1029.9849205873031
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "GpbJ8YFEWv5hvSyQbsM8l",
        "focus": -0.002797202797204545,
        "gap": 5,
        "fixedPoint": [
          1.025380710659897,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "f67V1iJ7wwKjr3dVNfnLc",
        "focus": -1.039292730844795,
        "gap": 5,
        "fixedPoint": [
          -0.019646365422397307,
          0.4987499999999997
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "zUgzO1kB7JcEwzbR0zgj2",
      "type": "rectangle",
      "x": -388.42460403065917,
      "y": 1246.6309515989176,
      "width": 197.00000000000003,
      "height": 360,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "te4-8vfNrQkIs8wJGPX-L",
        "iYoaPabTgRLHHe4rY48aj",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAL",
      "roundness": {
        "type": 3
      },
      "seed": 716821757,
      "version": 1630,
      "versionNonce": 874278887,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "jRxtY8odD77xzrjZz8-Tc"
        },
        {
          "id": "IWpmubOG1dlu7HQD0WmWk",
          "type": "arrow"
        }
      ],
      "updated": 1755262053131,
      "link": null,
      "locked": false
    },
    {
      "id": "jRxtY8odD77xzrjZz8-Tc",
      "type": "text",
      "x": -355.92460403065917,
      "y": 1251.6309515989176,
      "width": 132,
      "height": 350,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "te4-8vfNrQkIs8wJGPX-L",
        "iYoaPabTgRLHHe4rY48aj",
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAM",
      "roundness": null,
      "seed": 504376669,
      "version": 1956,
      "versionNonce": 2114987529,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053131,
      "link": null,
      "locked": false,
      "text": "creator\nrelev\nauditoria\nconsolidado\nmigracion\nupdate\ncleanup\nvalidation\ntest\nliteral_work\nreport\nclone\n..\n...",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "zUgzO1kB7JcEwzbR0zgj2",
      "originalText": "creator\nrelev\nauditoria\nconsolidado\nmigracion\nupdate\ncleanup\nvalidation\ntest\nliteral_work\nreport\nclone\n..\n...",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "IWpmubOG1dlu7HQD0WmWk",
      "type": "arrow",
      "x": -578.1746039682419,
      "y": 1426.530952380958,
      "width": 184.7499999375827,
      "height": 7.820403880032245e-7,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAN",
      "roundness": null,
      "seed": 1453568275,
      "version": 24,
      "versionNonce": 1190386439,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053131,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          184.7499999375827,
          -7.820403880032245e-7
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "f67V1iJ7wwKjr3dVNfnLc",
        "focus": -0.0024999859710872034,
        "gap": 5,
        "fixedPoint": [
          1.019646365422397,
          0.49875000000000114
        ]
      },
      "endBinding": {
        "elementId": "zUgzO1kB7JcEwzbR0zgj2",
        "focus": 0.0005555579882225113,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49972222222222246
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "Ax2jbmApwKAxxMy15cxan",
      "type": "arrow",
      "x": -573.174603984121,
      "y": 723.5857143809577,
      "width": 138.36904842856438,
      "height": 195.28968201587543,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAO",
      "roundness": null,
      "seed": 839456787,
      "version": 50,
      "versionNonce": 923827433,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053131,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          69.18452421428219,
          0
        ],
        [
          69.18452421428219,
          -195.28968201587543
        ],
        [
          138.36904842856438,
          -195.28968201587543
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "xfoTkwa0D7hfzNtp3S1QR",
        "focus": -0.00279720279720242,
        "gap": 5,
        "fixedPoint": [
          1.0196463654248482,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "0OKSg18q5MJE1uhDTSl1C",
        "focus": 1.0714285714285707,
        "gap": 5,
        "fixedPoint": [
          -0.035714285714285705,
          0.4982758620689651
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "2eEQAbjo6MgjvGwHsaGV5",
      "type": "arrow",
      "x": -573.174603984121,
      "y": 723.5857143809577,
      "width": 138.36904809523048,
      "height": 142.49999998412443,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAP",
      "roundness": null,
      "seed": 2033919571,
      "version": 36,
      "versionNonce": 1576067623,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053131,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          69.18452404761524,
          0
        ],
        [
          69.18452404761524,
          142.49999998412443
        ],
        [
          138.36904809523048,
          142.49999998412443
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "xfoTkwa0D7hfzNtp3S1QR",
        "focus": -0.00279720279720242,
        "gap": 5,
        "fixedPoint": [
          1.0196463654248482,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "aZhjdKeOwAjr99KOpf2Bf",
        "focus": -1.0458715596330275,
        "gap": 5,
        "fixedPoint": [
          -0.022935779816513756,
          0.49833333333333296
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "MJY4NTY8tFzMAgMdUk--m",
      "type": "arrow",
      "x": -284.80555555555657,
      "y": 528.2960323650823,
      "width": 155.17261899999954,
      "height": 1.1368683772161603e-13,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAQ",
      "roundness": null,
      "seed": 1572502835,
      "version": 30,
      "versionNonce": 1604515785,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053131,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          155.17261899999954,
          1.1368683772161603e-13
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "0OKSg18q5MJE1uhDTSl1C",
        "focus": -0.003448275862074482,
        "gap": 5,
        "fixedPoint": [
          1.0357142857142856,
          0.4982758620689651
        ]
      },
      "endBinding": {
        "elementId": "k21Ko6DaobI6ThyaD96nu",
        "focus": 0.000597014925372403,
        "gap": 5,
        "fixedPoint": [
          -0.021489971346704845,
          0.49970149253731355
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "3eHDBUU_T1JsI0n9h0IuT",
      "type": "arrow",
      "x": -206.80555588889035,
      "y": 866.0857143650821,
      "width": 77.17261933333333,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "nrNZSBZ8YKa0Zf36FH3sL"
      ],
      "frameId": null,
      "index": "bAR",
      "roundness": null,
      "seed": 2013280051,
      "version": 23,
      "versionNonce": 436208967,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755262053131,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          77.17261933333333,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "aZhjdKeOwAjr99KOpf2Bf",
        "focus": -0.003333333333331538,
        "gap": 5,
        "fixedPoint": [
          1.022935779816514,
          0.49833333333333296
        ]
      },
      "endBinding": {
        "elementId": "yRv7fGjL-Ifu89ImRK5P_",
        "focus": 0.000701754385965008,
        "gap": 5,
        "fixedPoint": [
          -0.021489971346704845,
          0.49964912280701745
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "-RqCD-KNXjkvc9UgHtH99",
      "type": "rectangle",
      "x": 6494.4087313015825,
      "y": 931.9446442957866,
      "width": 140.00000000000003,
      "height": 58,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAS",
      "roundness": {
        "type": 3
      },
      "seed": 214538217,
      "version": 1473,
      "versionNonce": 1820606025,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "A0ZxEU34nKrWyI4aNIp0w"
        },
        {
          "id": "IiX4WauFSfiU54x60BphI",
          "type": "arrow"
        },
        {
          "id": "-jxvtixN1lR5IwiKUkPxV",
          "type": "arrow"
        }
      ],
      "updated": 1755279665749,
      "link": null,
      "locked": false
    },
    {
      "id": "A0ZxEU34nKrWyI4aNIp0w",
      "type": "text",
      "x": 6531.4087313015825,
      "y": 948.4446442957866,
      "width": 66,
      "height": 25,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAT",
      "roundness": null,
      "seed": 1971368649,
      "version": 1487,
      "versionNonce": 668437801,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279665749,
      "link": null,
      "locked": false,
      "text": "/mpln/",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "-RqCD-KNXjkvc9UgHtH99",
      "originalText": "/mpln/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "GNBNgEDW3IKMqBJLsSK7q",
      "type": "rectangle",
      "x": 6843.5813503015825,
      "y": 818.4446442957868,
      "width": 201.91071369841757,
      "height": 285,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAU",
      "roundness": {
        "type": 3
      },
      "seed": 844198313,
      "version": 738,
      "versionNonce": 263761191,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "t4ngDgTCx3T4zJt5YYub0"
        },
        {
          "id": "-jxvtixN1lR5IwiKUkPxV",
          "type": "arrow"
        }
      ],
      "updated": 1755279713809,
      "link": null,
      "locked": false
    },
    {
      "id": "t4ngDgTCx3T4zJt5YYub0",
      "type": "text",
      "x": 6856.536707150792,
      "y": 823.4446442957868,
      "width": 176,
      "height": 275,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#b2f2bb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAV",
      "roundness": null,
      "seed": 1483166857,
      "version": 1141,
      "versionNonce": 1989570631,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279713809,
      "link": null,
      "locked": false,
      "text": "Mplan\nBLueprint\nBaseline\n/plans\n/roadmaps\n/task\n/checklist\n/checkpoint\n/feedback\n/validacion\n/update objetive",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "GNBNgEDW3IKMqBJLsSK7q",
      "originalText": "Mplan\nBLueprint\nBaseline\n/plans\n/roadmaps\n/task\n/checklist\n/checkpoint\n/feedback\n/validacion\n/update objetive",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "59Uzb4DwrzBCN5ucC-gqi",
      "type": "rectangle",
      "x": 6499.408730968249,
      "y": 1218.7343262957866,
      "width": 218.00000000000006,
      "height": 60,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAW",
      "roundness": {
        "type": 3
      },
      "seed": 1266539369,
      "version": 1533,
      "versionNonce": 374332009,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "d-rjUniZ04DFzhVuWqG6G"
        },
        {
          "id": "wXyurJBWKrUK4FflUK5C6",
          "type": "arrow"
        },
        {
          "id": "A8PN4wucThrjELf4tebp4",
          "type": "arrow"
        }
      ],
      "updated": 1755279665750,
      "link": null,
      "locked": false
    },
    {
      "id": "d-rjUniZ04DFzhVuWqG6G",
      "type": "text",
      "x": 6514.908730968249,
      "y": 1236.2343262957866,
      "width": 187,
      "height": 25,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAX",
      "roundness": null,
      "seed": 1809876553,
      "version": 1588,
      "versionNonce": 706389321,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279665750,
      "link": null,
      "locked": false,
      "text": "/brainstorm_crtv/",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "59Uzb4DwrzBCN5ucC-gqi",
      "originalText": "/brainstorm_crtv/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "rL_AAXNKJXoA-CLtSduqo",
      "type": "rectangle",
      "x": 6843.5813503015825,
      "y": 1143.7343262957866,
      "width": 201.91071369841754,
      "height": 210,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAY",
      "roundness": {
        "type": 3
      },
      "seed": 74110249,
      "version": 828,
      "versionNonce": 268618889,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "Z5NJv9lMvkXDfhkcTgbnt"
        },
        {
          "id": "A8PN4wucThrjELf4tebp4",
          "type": "arrow"
        }
      ],
      "updated": 1755279718743,
      "link": null,
      "locked": false
    },
    {
      "id": "Z5NJv9lMvkXDfhkcTgbnt",
      "type": "text",
      "x": 6873.036707150791,
      "y": 1148.7343262957866,
      "width": 143,
      "height": 200,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#b2f2bb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAZ",
      "roundness": null,
      "seed": 2022197257,
      "version": 1345,
      "versionNonce": 1894404969,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279718743,
      "link": null,
      "locked": false,
      "text": "Barinstorm\ninsights\nideas\ndraft\nnotas\nnodo (chkpnt)\nnodo_changes\nsnaphots",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "rL_AAXNKJXoA-CLtSduqo",
      "originalText": "Barinstorm\ninsights\nideas\ndraft\nnotas\nnodo (chkpnt)\nnodo_changes\nsnaphots",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "DI1gRCNytTrWzvPu0MWaz",
      "type": "rectangle",
      "x": 6084.34622826587,
      "y": -686.5440572756407,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAc",
      "roundness": {
        "type": 3
      },
      "seed": 318142633,
      "version": 979,
      "versionNonce": 72655657,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "4ar1o2QwuJoGf6dAaB8nU"
        },
        {
          "id": "2e9bT3ghgBz38UUM0vR3p",
          "type": "arrow"
        },
        {
          "id": "oMwnOZmsUbebm9H7u8MRY",
          "type": "arrow"
        }
      ],
      "updated": 1755275177158,
      "link": null,
      "locked": false
    },
    {
      "id": "4ar1o2QwuJoGf6dAaB8nU",
      "type": "text",
      "x": 6098.146261835206,
      "y": -668.2940572756407,
      "width": 169.39993286132812,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAd",
      "roundness": null,
      "seed": 215186313,
      "version": 1026,
      "versionNonce": 649757159,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755275160762,
      "link": null,
      "locked": false,
      "text": "/semantics/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "DI1gRCNytTrWzvPu0MWaz",
      "originalText": "/semantics/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "DKq8K1v-u6vzlj1uLkzVV",
      "type": "rectangle",
      "x": 6091.01289526587,
      "y": -452.7523012756408,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAe",
      "roundness": {
        "type": 3
      },
      "seed": 231547497,
      "version": 1003,
      "versionNonce": 967072681,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "gLB9T4kDeaLEVWYToLphN"
        },
        {
          "id": "jE9BG5mLAqoZkJVgElPec",
          "type": "arrow"
        },
        {
          "id": "1xpbtKEfZolz9k4A9LUEF",
          "type": "arrow"
        }
      ],
      "updated": 1755275180723,
      "link": null,
      "locked": false
    },
    {
      "id": "gLB9T4kDeaLEVWYToLphN",
      "type": "text",
      "x": 6112.512925783448,
      "y": -434.5023012756408,
      "width": 153.99993896484375,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAf",
      "roundness": null,
      "seed": 1387195721,
      "version": 1059,
      "versionNonce": 1792262023,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755275139167,
      "link": null,
      "locked": false,
      "text": "/ai_learn/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "DKq8K1v-u6vzlj1uLkzVV",
      "originalText": "/ai_learn/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "xhS4iD2NXK1UX5AMYbNVT",
      "type": "rectangle",
      "x": 6087.679562265869,
      "y": -206.61112627564077,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAg",
      "roundness": {
        "type": 3
      },
      "seed": 1926519849,
      "version": 1048,
      "versionNonce": 1842029959,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "gqiqwyjjlNRfUxYVjtqqI"
        },
        {
          "id": "ON1jQe4OVgpkhAOgZnkuk",
          "type": "arrow"
        },
        {
          "id": "mUuf5SPelC3-ug9Knf3Pk",
          "type": "arrow"
        }
      ],
      "updated": 1755275183350,
      "link": null,
      "locked": false
    },
    {
      "id": "gqiqwyjjlNRfUxYVjtqqI",
      "type": "text",
      "x": 6116.8795897316895,
      "y": -188.36112627564077,
      "width": 138.59994506835938,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAh",
      "roundness": null,
      "seed": 237563657,
      "version": 1120,
      "versionNonce": 2037035303,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755275155093,
      "link": null,
      "locked": false,
      "text": "/develop/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "xhS4iD2NXK1UX5AMYbNVT",
      "originalText": "/develop/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "jmQR4RR7Q93uNrKBlspl4",
      "type": "rectangle",
      "x": 6506.2212290158695,
      "y": -275.78035627564077,
      "width": 197.00000000000003,
      "height": 210,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAi",
      "roundness": {
        "type": 3
      },
      "seed": 992486889,
      "version": 1311,
      "versionNonce": 521130855,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "eFat9yq6YMtW-IubKVA6p"
        },
        {
          "id": "ON1jQe4OVgpkhAOgZnkuk",
          "type": "arrow"
        }
      ],
      "updated": 1755275155094,
      "link": null,
      "locked": false
    },
    {
      "id": "eFat9yq6YMtW-IubKVA6p",
      "type": "text",
      "x": 6544.2212290158695,
      "y": -270.78035627564077,
      "width": 121,
      "height": 200,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAj",
      "roundness": null,
      "seed": 886931657,
      "version": 1585,
      "versionNonce": 1420742279,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755275155094,
      "link": null,
      "locked": false,
      "text": "rulset\nconfig\nsetup\ncustom\nspec\npreference\nconectors\norquestador",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "jmQR4RR7Q93uNrKBlspl4",
      "originalText": "rulset\nconfig\nsetup\ncustom\nspec\npreference\nconectors\norquestador",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "mX4n5OWptUg4xgfls2OW5",
      "type": "rectangle",
      "x": 5659.13789426587,
      "y": 118.65714372435923,
      "width": 247.00000000000003,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAk",
      "roundness": {
        "type": 3
      },
      "seed": 1222934441,
      "version": 1202,
      "versionNonce": 1925515273,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "PoObO1hfBoL4YENtGebLd"
        },
        {
          "id": "V1MpiR8ElC-sfKhs6SnXz",
          "type": "arrow"
        },
        {
          "id": "yixTMC8SGPdncr21-kCQX",
          "type": "arrow"
        },
        {
          "id": "ks8unQw4hDVkZQAYuSx4o",
          "type": "arrow"
        },
        {
          "id": "qEl4DCeOiBQ4CXVlSoexj",
          "type": "arrow"
        },
        {
          "id": "tr37tYYfDvLena3z-cHty",
          "type": "arrow"
        },
        {
          "id": "RcFvk2idPKqKvG7kNJMLf",
          "type": "arrow"
        }
      ],
      "updated": 1755276213483,
      "link": null,
      "locked": false
    },
    {
      "id": "PoObO1hfBoL4YENtGebLd",
      "type": "text",
      "x": 5674.83793699048,
      "y": 141.15714372435923,
      "width": 215.59991455078125,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAl",
      "roundness": null,
      "seed": 90743433,
      "version": 1293,
      "versionNonce": 688531815,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276148038,
      "link": null,
      "locked": false,
      "text": "/out_template/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "mX4n5OWptUg4xgfls2OW5",
      "originalText": "/out_template/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "gmhvealXUg2jjHhVm5VYz",
      "type": "rectangle",
      "x": 5647.325396265871,
      "y": 1050.6946437243591,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAm",
      "roundness": {
        "type": 3
      },
      "seed": 656763241,
      "version": 1340,
      "versionNonce": 1990875785,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "sv506aF1j9s9AL84ZPGaV"
        },
        {
          "id": "JuB5DP2lvonCm61A7liWm",
          "type": "arrow"
        },
        {
          "id": "ckEO60Md72tvqeaYyO7Jx",
          "type": "arrow"
        },
        {
          "id": "sDTSWBJB9a6zlGWBivJyv",
          "type": "arrow"
        }
      ],
      "updated": 1755279665751,
      "link": null,
      "locked": false
    },
    {
      "id": "sv506aF1j9s9AL84ZPGaV",
      "type": "text",
      "x": 5684.225420679933,
      "y": 1068.9446437243591,
      "width": 123.199951171875,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAn",
      "roundness": null,
      "seed": 1197888585,
      "version": 1437,
      "versionNonce": 2003837289,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279665751,
      "link": null,
      "locked": false,
      "text": "/guides/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "gmhvealXUg2jjHhVm5VYz",
      "originalText": "/guides/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "ON1jQe4OVgpkhAOgZnkuk",
      "type": "arrow",
      "x": 6289.67956226587,
      "y": -170.96112627564077,
      "width": 211.54166674999942,
      "height": 0.10000076923083157,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAt",
      "roundness": null,
      "seed": 1227278729,
      "version": 779,
      "versionNonce": 1295259847,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755275155095,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          211.54166674999942,
          0.10000076923083157
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "xhS4iD2NXK1UX5AMYbNVT",
        "focus": -0.00416036887540748,
        "gap": 5.0000000000009095,
        "fixedPoint": [
          1.0253807106599029,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "jmQR4RR7Q93uNrKBlspl4",
        "focus": 0.0007692307692313104,
        "gap": 1,
        "fixedPoint": [
          -0.025380710659898473,
          0.49961538461538496
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "qlXUM7spnLYkyio4f3G0y",
      "type": "rectangle",
      "x": 6070.867063904778,
      "y": 1050.6946443116622,
      "width": 254.49999996824198,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAy",
      "roundness": {
        "type": 3
      },
      "seed": 329954281,
      "version": 1519,
      "versionNonce": 668181737,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "iMj2V9eHjBcDf3hJ_-2yV"
        },
        {
          "id": "IiX4WauFSfiU54x60BphI",
          "type": "arrow"
        },
        {
          "id": "wXyurJBWKrUK4FflUK5C6",
          "type": "arrow"
        },
        {
          "id": "JuB5DP2lvonCm61A7liWm",
          "type": "arrow"
        }
      ],
      "updated": 1755279665752,
      "link": null,
      "locked": false
    },
    {
      "id": "iMj2V9eHjBcDf3hJ_-2yV",
      "type": "text",
      "x": 6136.517088302961,
      "y": 1068.9446443116622,
      "width": 123.199951171875,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bAz",
      "roundness": null,
      "seed": 970870473,
      "version": 1611,
      "versionNonce": 499195849,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279665752,
      "link": null,
      "locked": false,
      "text": "/planin/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "qlXUM7spnLYkyio4f3G0y",
      "originalText": "/planin/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "xz5B9rnuZfZSr-ANOSyGn",
      "type": "rectangle",
      "x": 6065.867063888898,
      "y": 1256.734325811662,
      "width": 254.49999999999994,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bB0",
      "roundness": {
        "type": 3
      },
      "seed": 1352371625,
      "version": 1529,
      "versionNonce": 1040347977,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "dhe8GDA1Vh4_m9xDj9yXH"
        },
        {
          "id": "ckEO60Md72tvqeaYyO7Jx",
          "type": "arrow"
        }
      ],
      "updated": 1755279665753,
      "link": null,
      "locked": false
    },
    {
      "id": "dhe8GDA1Vh4_m9xDj9yXH",
      "type": "text",
      "x": 6093.0171035617495,
      "y": 1279.234325811662,
      "width": 200.19992065429688,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bB1",
      "roundness": null,
      "seed": 1594749065,
      "version": 1649,
      "versionNonce": 1975984681,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279665753,
      "link": null,
      "locked": false,
      "text": "/run_control/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "xz5B9rnuZfZSr-ANOSyGn",
      "originalText": "/run_control/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "L4E8et0cKUi8eyRpyiOqh",
      "type": "rectangle",
      "x": 6065.867063888898,
      "y": 1507.1240083116622,
      "width": 254.49999999999994,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bB2",
      "roundness": {
        "type": 3
      },
      "seed": 2062612329,
      "version": 1607,
      "versionNonce": 1119147687,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "A5VpR3Lzp5rzHR7xl01_S"
        },
        {
          "id": "sDTSWBJB9a6zlGWBivJyv",
          "type": "arrow"
        },
        {
          "id": "QxDjEJgarAxEBtAENvX_B",
          "type": "arrow"
        }
      ],
      "updated": 1755279703887,
      "link": null,
      "locked": false
    },
    {
      "id": "A5VpR3Lzp5rzHR7xl01_S",
      "type": "text",
      "x": 6116.117094406476,
      "y": 1529.6240083116622,
      "width": 153.99993896484375,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bB3",
      "roundness": null,
      "seed": 1989157449,
      "version": 1741,
      "versionNonce": 255723209,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279665754,
      "link": null,
      "locked": false,
      "text": "/pipeline/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "L4E8et0cKUi8eyRpyiOqh",
      "originalText": "/pipeline/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "JuB5DP2lvonCm61A7liWm",
      "type": "arrow",
      "x": 5849.325396265871,
      "y": 1086.3446437243592,
      "width": 216.5416676389068,
      "height": 5.873030204384122e-7,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bB4",
      "roundness": null,
      "seed": 1321660713,
      "version": 617,
      "versionNonce": 328762473,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279666353,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          216.5416676389068,
          5.873030204384122e-7
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "gmhvealXUg2jjHhVm5VYz",
        "focus": -0.0027972099662481463,
        "gap": 5,
        "fixedPoint": [
          1.025380710659897,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "qlXUM7spnLYkyio4f3G0y",
        "focus": 0.002797193587586167,
        "gap": 5,
        "fixedPoint": [
          -0.019646365424848447,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "ckEO60Md72tvqeaYyO7Jx",
      "type": "arrow",
      "x": 5849.325396265871,
      "y": 1086.3446437243592,
      "width": 211.54166762302702,
      "height": 210.28968208730294,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bB5",
      "roundness": null,
      "seed": 1493230601,
      "version": 570,
      "versionNonce": 213782345,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279666353,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          105.77083381151351,
          0
        ],
        [
          105.77083381151351,
          210.28968208730294
        ],
        [
          211.54166762302702,
          210.28968208730294
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "gmhvealXUg2jjHhVm5VYz",
        "focus": -0.002797202797204545,
        "gap": 5,
        "fixedPoint": [
          1.025380710659897,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "xz5B9rnuZfZSr-ANOSyGn",
        "focus": -1.0392927308447937,
        "gap": 5,
        "fixedPoint": [
          -0.01964636542239686,
          0.4987499999999997
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "sDTSWBJB9a6zlGWBivJyv",
      "type": "arrow",
      "x": 5849.325396265871,
      "y": 1086.3446437243592,
      "width": 211.54166762302702,
      "height": 460.6793645873031,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bB6",
      "roundness": null,
      "seed": 825850601,
      "version": 639,
      "versionNonce": 1297157385,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279703890,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          105.77083381151351,
          0
        ],
        [
          105.77083381151351,
          460.6793645873031
        ],
        [
          211.54166762302702,
          460.6793645873031
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "gmhvealXUg2jjHhVm5VYz",
        "focus": -0.002797202797204545,
        "gap": 5,
        "fixedPoint": [
          1.025380710659897,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "L4E8et0cKUi8eyRpyiOqh",
        "focus": -1.039292730844795,
        "gap": 5,
        "fixedPoint": [
          -0.019646365422397307,
          0.4987499999999997
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "QxDjEJgarAxEBtAENvX_B",
      "type": "arrow",
      "x": 6325.367063888898,
      "y": 1547.0240083116623,
      "width": 508.21428593758446,
      "height": 0.0904439876151173,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bB7",
      "roundness": null,
      "seed": 1744582089,
      "version": 556,
      "versionNonce": 959359815,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279741735,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          508.21428593758446,
          -0.0904439876151173
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "L4E8et0cKUi8eyRpyiOqh",
        "focus": -0.0024999859710872034,
        "gap": 5,
        "fixedPoint": [
          1.019646365422397,
          0.49875000000000114
        ]
      },
      "endBinding": {
        "elementId": "HClTbUtKYPfBBEN1ToHUm",
        "focus": 0.0005555579882225113,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49972222222222246
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "IiX4WauFSfiU54x60BphI",
      "type": "arrow",
      "x": 6330.36706387302,
      "y": 1086.3446443116623,
      "width": 159.0416674285625,
      "height": 125.50000001587557,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bB8",
      "roundness": null,
      "seed": 1885639849,
      "version": 462,
      "versionNonce": 1490180777,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279666352,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          79.52083371428125,
          0
        ],
        [
          79.52083371428125,
          -125.50000001587557
        ],
        [
          159.0416674285625,
          -125.50000001587557
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "qlXUM7spnLYkyio4f3G0y",
        "focus": -0.00279720279720242,
        "gap": 5,
        "fixedPoint": [
          1.0196463654248482,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "-RqCD-KNXjkvc9UgHtH99",
        "focus": 1.0714285714285707,
        "gap": 5,
        "fixedPoint": [
          -0.035714285714285705,
          0.4982758620689651
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "wXyurJBWKrUK4FflUK5C6",
      "type": "arrow",
      "x": 6330.36706387302,
      "y": 1086.3446443116623,
      "width": 164.04166709522906,
      "height": 162.2896819841245,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bB9",
      "roundness": null,
      "seed": 1310594953,
      "version": 499,
      "versionNonce": 820190601,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279666353,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          82.02083354761453,
          0
        ],
        [
          82.02083354761453,
          162.2896819841245
        ],
        [
          164.04166709522906,
          162.2896819841245
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "qlXUM7spnLYkyio4f3G0y",
        "focus": -0.00279720279720242,
        "gap": 5,
        "fixedPoint": [
          1.0196463654248482,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "59Uzb4DwrzBCN5ucC-gqi",
        "focus": -1.0458715596330275,
        "gap": 5,
        "fixedPoint": [
          -0.022935779816513756,
          0.49833333333333296
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "-jxvtixN1lR5IwiKUkPxV",
      "type": "arrow",
      "x": 6639.4087313015825,
      "y": 960.8446442957866,
      "width": 199.17261900000085,
      "height": 0.014925373134587971,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bBA",
      "roundness": null,
      "seed": 56901225,
      "version": 506,
      "versionNonce": 544301479,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279713976,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          199.17261900000085,
          0.014925373134587971
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "-RqCD-KNXjkvc9UgHtH99",
        "focus": -0.003448275862074482,
        "gap": 5,
        "fixedPoint": [
          1.0357142857142856,
          0.4982758620689651
        ]
      },
      "endBinding": {
        "elementId": "GNBNgEDW3IKMqBJLsSK7q",
        "focus": 0.000597014925372403,
        "gap": 5,
        "fixedPoint": [
          -0.021489971346704845,
          0.49970149253731355
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "A8PN4wucThrjELf4tebp4",
      "type": "arrow",
      "x": 6722.408730968249,
      "y": 1248.6343262957867,
      "width": 116.17261933333339,
      "height": 0.02631578947352864,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bBB",
      "roundness": null,
      "seed": 1057130825,
      "version": 585,
      "versionNonce": 178843817,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279719076,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          116.17261933333339,
          0.02631578947352864
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "59Uzb4DwrzBCN5ucC-gqi",
        "focus": -0.003333333333331538,
        "gap": 5,
        "fixedPoint": [
          1.022935779816514,
          0.49833333333333296
        ]
      },
      "endBinding": {
        "elementId": "rL_AAXNKJXoA-CLtSduqo",
        "focus": 0.000701754385965008,
        "gap": 1,
        "fixedPoint": [
          -0.021489971346704845,
          0.49964912280701745
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "II4C7iowI7oQnk19jDMcc",
      "type": "rectangle",
      "x": 6509.554561682537,
      "y": -743.2242461327834,
      "width": 197.00000000000003,
      "height": 185,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bBi",
      "roundness": {
        "type": 3
      },
      "seed": 1852085289,
      "version": 1699,
      "versionNonce": 162690087,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "90aDv63IV4EE2y-dORnL0"
        },
        {
          "id": "2e9bT3ghgBz38UUM0vR3p",
          "type": "arrow"
        }
      ],
      "updated": 1755275160763,
      "link": null,
      "locked": false
    },
    {
      "id": "90aDv63IV4EE2y-dORnL0",
      "type": "text",
      "x": 6542.054561682537,
      "y": -738.2242461327834,
      "width": 132,
      "height": 175,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bBj",
      "roundness": null,
      "seed": 452077321,
      "version": 1596,
      "versionNonce": 1002395463,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755275160763,
      "link": null,
      "locked": false,
      "text": "glossary\ndict_trigger\ndict_code\ndict_app\ndict_prompt\ning_prompt\nvocabulary",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "II4C7iowI7oQnk19jDMcc",
      "originalText": "glossary\ndict_trigger\ndict_code\ndict_app\ndict_prompt\ning_prompt\nvocabulary",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "2e9bT3ghgBz38UUM0vR3p",
      "type": "arrow",
      "x": 6286.34622826587,
      "y": -650.8940572756408,
      "width": 218.2083334166664,
      "height": 0.0999998221026317,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bBk",
      "roundness": null,
      "seed": 1242193385,
      "version": 1890,
      "versionNonce": 135159879,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755275160912,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          218.2083334166664,
          0.0999998221026317
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "DI1gRCNytTrWzvPu0MWaz",
        "focus": -0.0027972027972046854,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "II4C7iowI7oQnk19jDMcc",
        "focus": 0.0007547169811309938,
        "gap": 4.682065820385762,
        "fixedPoint": [
          -0.025380710659898473,
          0.49962264150943386
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "55fv0OiO5JFUUyQmNDmRO",
      "type": "rectangle",
      "x": 6506.2212290158695,
      "y": -522.0023012756408,
      "width": 197.00000000000003,
      "height": 210,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bBl",
      "roundness": {
        "type": 3
      },
      "seed": 448313545,
      "version": 1239,
      "versionNonce": 1039910601,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "hjY6_2nvkeL_BYCx2-16p"
        },
        {
          "id": "jE9BG5mLAqoZkJVgElPec",
          "type": "arrow"
        }
      ],
      "updated": 1755274698378,
      "link": null,
      "locked": false
    },
    {
      "id": "hjY6_2nvkeL_BYCx2-16p",
      "type": "text",
      "x": 6560.7212290158695,
      "y": -517.0023012756408,
      "width": 88,
      "height": 200,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bBm",
      "roundness": null,
      "seed": 1050195881,
      "version": 1518,
      "versionNonce": 1778765225,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755274697777,
      "link": null,
      "locked": false,
      "text": "learn\neval\ninsi\ntune\nshot\nrel\ntrn\nfeedback",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "55fv0OiO5JFUUyQmNDmRO",
      "originalText": "learn\neval\ninsi\ntune\nshot\nrel\ntrn\nfeedback",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "jE9BG5mLAqoZkJVgElPec",
      "type": "arrow",
      "x": 6293.01289526587,
      "y": -417.1023012756408,
      "width": 208.20833374999984,
      "height": 0.03777777777781921,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bBn",
      "roundness": null,
      "seed": 668326537,
      "version": 1323,
      "versionNonce": 1146226281,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755275095396,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          208.20833374999984,
          0.03777777777781921
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "DKq8K1v-u6vzlj1uLkzVV",
        "focus": -0.0033208368486561416,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "55fv0OiO5JFUUyQmNDmRO",
        "focus": 0.0005925925925922078,
        "gap": 1,
        "fixedPoint": [
          -0.025380710659898473,
          0.4997037037037037
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "fij6ByE7PgVouu3MPAAnq",
      "type": "rectangle",
      "x": 6506.221229349202,
      "y": 31.344644391027924,
      "width": 196.99999965079772,
      "height": 185,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bBt",
      "roundness": {
        "type": 3
      },
      "seed": 1481416649,
      "version": 1000,
      "versionNonce": 1441465735,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "IuWGANMxzbCY7rZJdEFX9"
        },
        {
          "id": "oSeNhLWRqQtRfAI5cVr2o",
          "type": "arrow"
        }
      ],
      "updated": 1755276188892,
      "link": null,
      "locked": false
    },
    {
      "id": "IuWGANMxzbCY7rZJdEFX9",
      "type": "text",
      "x": 6549.721229174601,
      "y": 36.34464439102793,
      "width": 110,
      "height": 175,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#b2f2bb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bBu",
      "roundness": null,
      "seed": 253214377,
      "version": 1169,
      "versionNonce": 161397927,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276188892,
      "link": null,
      "locked": false,
      "text": "matrix\ntabla\nficha\nmapping\nrelation\nvalidation\nversus",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "fij6ByE7PgVouu3MPAAnq",
      "originalText": "matrix\ntabla\nficha\nmapping\nrelation\nvalidation\nversus",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "HClTbUtKYPfBBEN1ToHUm",
      "type": "rectangle",
      "x": 6838.581349826481,
      "y": 1384.2262374946195,
      "width": 206.91071417351944,
      "height": 325.5955400700052,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [
        "enMCFaXZjKEnPqDnj3mSI"
      ],
      "frameId": null,
      "index": "bCd",
      "roundness": {
        "type": 3
      },
      "seed": 969586697,
      "version": 1831,
      "versionNonce": 1455885001,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "2ce_fEhBiqFrj-e7a9S2J"
        },
        {
          "id": "QxDjEJgarAxEBtAENvX_B",
          "type": "arrow"
        }
      ],
      "updated": 1755279741518,
      "link": null,
      "locked": false
    },
    {
      "id": "2ce_fEhBiqFrj-e7a9S2J",
      "type": "text",
      "x": 6872.736780155428,
      "y": 1389.4777784634905,
      "width": 138.599853515625,
      "height": 315.09245813226306,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [
        "enMCFaXZjKEnPqDnj3mSI"
      ],
      "frameId": null,
      "index": "bCe",
      "roundness": null,
      "seed": 27840233,
      "version": 2232,
      "versionNonce": 725278281,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279741520,
      "link": null,
      "locked": false,
      "text": "creator\nrelev\nauditoria\nconsolidado\nmigracion\nupdate\ncleanup\nvalidation\ntest\nliteral_work\nreport\nclone",
      "fontSize": 21.006163875484205,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "HClTbUtKYPfBBEN1ToHUm",
      "originalText": "creator\nrelev\nauditoria\nconsolidado\nmigracion\nupdate\ncleanup\nvalidation\ntest\nliteral_work\nreport\nclone",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "ZaibGO8Kfy3_JTbFd-uCX",
      "type": "rectangle",
      "x": 11310.240627904755,
      "y": -3104.9930510730114,
      "width": 287.00000000000006,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bCk",
      "roundness": {
        "type": 3
      },
      "seed": 1012161961,
      "version": 1448,
      "versionNonce": 221459719,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "h8TJMeHsjcZjpNPsXXwtP",
          "type": "text"
        },
        {
          "id": "ZVULUXlbQw6m2OhghDYQV",
          "type": "arrow"
        },
        {
          "id": "C3e8hpLs3dTVCRIMZmQIA",
          "type": "arrow"
        },
        {
          "id": "nqSqLkSUUHy183blKaCle",
          "type": "arrow"
        },
        {
          "id": "BZROqmS8x1_WfN4iMc5ZE",
          "type": "arrow"
        }
      ],
      "updated": 1755266197165,
      "link": null,
      "locked": false
    },
    {
      "id": "h8TJMeHsjcZjpNPsXXwtP",
      "type": "text",
      "x": 11344.840695043427,
      "y": -3077.4930510730114,
      "width": 217.79986572265625,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bCl",
      "roundness": null,
      "seed": 1453546631,
      "version": 1426,
      "versionNonce": 389348391,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197165,
      "link": null,
      "locked": false,
      "text": "/data_base/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "ZaibGO8Kfy3_JTbFd-uCX",
      "originalText": "/data_base/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "37BRcDIBToAHg6adeYvA3",
      "type": "rectangle",
      "x": 11310.240627904755,
      "y": -2592.5561464730104,
      "width": 287.00000009524416,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bCn",
      "roundness": {
        "type": 3
      },
      "seed": 2066530441,
      "version": 1193,
      "versionNonce": 1815053255,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "ztE5k39vlcwf1ZAF_K9Mu"
        },
        {
          "id": "_KEt8O1aCI7sIZvckz5Yn",
          "type": "arrow"
        }
      ],
      "updated": 1755266197167,
      "link": null,
      "locked": false
    },
    {
      "id": "ztE5k39vlcwf1ZAF_K9Mu",
      "type": "text",
      "x": 11354.740688987535,
      "y": -2565.0561464730104,
      "width": 197.9998779296875,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bCo",
      "roundness": null,
      "seed": 356169191,
      "version": 1203,
      "versionNonce": 1463382759,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197167,
      "link": null,
      "locked": false,
      "text": "/packages/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "37BRcDIBToAHg6adeYvA3",
      "originalText": "/packages/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "Mm9uTH4fwvPOwSB6IllHp",
      "type": "rectangle",
      "x": 11310.240627904755,
      "y": -2198.264876873009,
      "width": 287.00000009524416,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bCp",
      "roundness": {
        "type": 3
      },
      "seed": 1253427049,
      "version": 1114,
      "versionNonce": 1776887079,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "1cAF0BuU_GgD2dfBz6jes"
        },
        {
          "id": "HaWTn_OEllFfL_RUZTGT7",
          "type": "arrow"
        }
      ],
      "updated": 1755266197167,
      "link": null,
      "locked": false
    },
    {
      "id": "1cAF0BuU_GgD2dfBz6jes",
      "type": "text",
      "x": 11364.640682884019,
      "y": -2170.764876873009,
      "width": 178.19989013671875,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bCq",
      "roundness": null,
      "seed": 1421191207,
      "version": 1123,
      "versionNonce": 603449415,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197167,
      "link": null,
      "locked": false,
      "text": "/scripts/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "Mm9uTH4fwvPOwSB6IllHp",
      "originalText": "/scripts/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "5bmrPG3vGIkfzZ5haAfQz",
      "type": "rectangle",
      "x": 11310.240627904755,
      "y": -2789.701781273011,
      "width": 287.00000009524416,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bCt",
      "roundness": {
        "type": 3
      },
      "seed": 356184649,
      "version": 1123,
      "versionNonce": 13746823,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "qkZkG8BrCoOC4h21axXu3",
          "type": "text"
        },
        {
          "id": "MDzekzSUfFskkJ8drx18N",
          "type": "arrow"
        },
        {
          "id": "WHNrurVFZWpGy6JLmyCtJ",
          "type": "arrow"
        },
        {
          "id": "uveIv1pbpc4-UpJPV4A4p",
          "type": "arrow"
        }
      ],
      "updated": 1755266197168,
      "link": null,
      "locked": false
    },
    {
      "id": "qkZkG8BrCoOC4h21axXu3",
      "type": "text",
      "x": 11404.240658469957,
      "y": -2762.201781273011,
      "width": 98.99993896484375,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bCu",
      "roundness": null,
      "seed": 496557223,
      "version": 1117,
      "versionNonce": 44423591,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197168,
      "link": null,
      "locked": false,
      "text": "/log/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "5bmrPG3vGIkfzZ5haAfQz",
      "originalText": "/log/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "3ZTBDdzQYL0ehMnaWhroI",
      "type": "rectangle",
      "x": 11801.858015571428,
      "y": -2861.253056206343,
      "width": 327.49713342857115,
      "height": 79.00000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bD0",
      "roundness": {
        "type": 3
      },
      "seed": 366672103,
      "version": 1077,
      "versionNonce": 388255271,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "znBIpS7FCF0fPJAhgQun_",
          "type": "text"
        },
        {
          "id": "WHNrurVFZWpGy6JLmyCtJ",
          "type": "arrow"
        }
      ],
      "updated": 1755266197169,
      "link": null,
      "locked": false
    },
    {
      "id": "znBIpS7FCF0fPJAhgQun_",
      "type": "text",
      "x": 11880.90661585505,
      "y": -2839.253056206343,
      "width": 169.39993286132812,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bD1",
      "roundness": null,
      "seed": 764800647,
      "version": 1083,
      "versionNonce": 837153095,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197169,
      "link": null,
      "locked": false,
      "text": "/changelog/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "3ZTBDdzQYL0ehMnaWhroI",
      "originalText": "/changelog/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "hFIN2jb3SgrUrJFGie4fH",
      "type": "rectangle",
      "x": 11801.858015571426,
      "y": -2729.889480206343,
      "width": 327.4971334285729,
      "height": 79.00000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bD5",
      "roundness": {
        "type": 3
      },
      "seed": 1643725831,
      "version": 1113,
      "versionNonce": 1334938503,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "DJ6dI9QWYiQtoCX9Cf4LS",
          "type": "text"
        },
        {
          "id": "uveIv1pbpc4-UpJPV4A4p",
          "type": "arrow"
        }
      ],
      "updated": 1755266197169,
      "link": null,
      "locked": false
    },
    {
      "id": "DJ6dI9QWYiQtoCX9Cf4LS",
      "type": "text",
      "x": 11927.106597544502,
      "y": -2707.889480206343,
      "width": 76.99996948242188,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bD6",
      "roundness": null,
      "seed": 1741486631,
      "version": 1158,
      "versionNonce": 1485079207,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197169,
      "link": null,
      "locked": false,
      "text": "/qms/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "hFIN2jb3SgrUrJFGie4fH",
      "originalText": "/qms/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "sIBN3Bzoxizr0ITg5kbTH",
      "type": "rectangle",
      "x": 11801.858016238095,
      "y": -3229.608172539677,
      "width": 327.49713276190386,
      "height": 79.00000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bD8",
      "roundness": {
        "type": 3
      },
      "seed": 643902247,
      "version": 1304,
      "versionNonce": 1677935847,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "NunayciaoKKLPTVAP3PzG"
        },
        {
          "id": "C3e8hpLs3dTVCRIMZmQIA",
          "type": "arrow"
        }
      ],
      "updated": 1755266197169,
      "link": null,
      "locked": false
    },
    {
      "id": "NunayciaoKKLPTVAP3PzG",
      "type": "text",
      "x": 11880.906616188382,
      "y": -3207.608172539677,
      "width": 169.39993286132812,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bD9",
      "roundness": null,
      "seed": 342472583,
      "version": 1280,
      "versionNonce": 1563955207,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197169,
      "link": null,
      "locked": false,
      "text": "/core_actv/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "sIBN3Bzoxizr0ITg5kbTH",
      "originalText": "/core_actv/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "qrA5lo3kfCYQGMEiE9XaJ",
      "type": "rectangle",
      "x": 11801.858015238095,
      "y": -3111.4625375396768,
      "width": 327.49713276190374,
      "height": 79.00000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDA",
      "roundness": {
        "type": 3
      },
      "seed": 1602170439,
      "version": 2082,
      "versionNonce": 1518008903,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "6dKXGsZ4v3dtKMzYjZ-na"
        },
        {
          "id": "nqSqLkSUUHy183blKaCle",
          "type": "arrow"
        }
      ],
      "updated": 1755266197170,
      "link": null,
      "locked": false
    },
    {
      "id": "6dKXGsZ4v3dtKMzYjZ-na",
      "type": "text",
      "x": 11888.606612136624,
      "y": -3089.4625375396768,
      "width": 153.99993896484375,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDB",
      "roundness": null,
      "seed": 671662535,
      "version": 2085,
      "versionNonce": 164764007,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197170,
      "link": null,
      "locked": false,
      "text": "/core_dev/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "qrA5lo3kfCYQGMEiE9XaJ",
      "originalText": "/core_dev/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "XRBX0bPuJU4hcEclkV-v0",
      "type": "rectangle",
      "x": 11801.858016238095,
      "y": -2993.316902539676,
      "width": 327.4971323083067,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDC",
      "roundness": {
        "type": 3
      },
      "seed": 1211092327,
      "version": 1538,
      "versionNonce": 1449798567,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "Pi4CqLqJvl5hvNAeHcQIF"
        },
        {
          "id": "BZROqmS8x1_WfN4iMc5ZE",
          "type": "arrow"
        }
      ],
      "updated": 1755266197170,
      "link": null,
      "locked": false
    },
    {
      "id": "Pi4CqLqJvl5hvNAeHcQIF",
      "type": "text",
      "x": 11811.606643427405,
      "y": -2970.816902539676,
      "width": 307.9998779296875,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDD",
      "roundness": null,
      "seed": 1318730759,
      "version": 1556,
      "versionNonce": 395583175,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197170,
      "link": null,
      "locked": false,
      "text": "/core_arch_platform/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "XRBX0bPuJU4hcEclkV-v0",
      "originalText": "/core_arch_platform/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "HNaU6U8k67BQ_FzF07ZG7",
      "type": "rectangle",
      "x": 10636.323962158735,
      "y": -2709.222812873011,
      "width": 304.50000000000017,
      "height": 116.66666666666649,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDH",
      "roundness": {
        "type": 3
      },
      "seed": 790437895,
      "version": 1320,
      "versionNonce": 1320311047,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "oCGfApvsFUxmo6MUduIjM"
        },
        {
          "id": "-NeZkEp-F-dZsIyvTxPCi",
          "type": "arrow"
        },
        {
          "id": "ZVULUXlbQw6m2OhghDYQV",
          "type": "arrow"
        },
        {
          "id": "MDzekzSUfFskkJ8drx18N",
          "type": "arrow"
        },
        {
          "id": "_KEt8O1aCI7sIZvckz5Yn",
          "type": "arrow"
        },
        {
          "id": "t6SycF9es4uKFWMFMP3-S",
          "type": "arrow"
        },
        {
          "id": "HaWTn_OEllFfL_RUZTGT7",
          "type": "arrow"
        }
      ],
      "updated": 1755266197171,
      "link": null,
      "locked": false
    },
    {
      "id": "oCGfApvsFUxmo6MUduIjM",
      "type": "text",
      "x": 10729.173998779828,
      "y": -2673.389479539678,
      "width": 118.7999267578125,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDI",
      "roundness": null,
      "seed": 1489948711,
      "version": 1296,
      "versionNonce": 623878183,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197171,
      "link": null,
      "locked": false,
      "text": "/main/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "HNaU6U8k67BQ_FzF07ZG7",
      "originalText": "/main/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "uH4S-w2X0ns5ZvAu6PUYe",
      "type": "rectangle",
      "x": 11310.240627904755,
      "y": -2395.4105116730098,
      "width": 287.00000009524416,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDd",
      "roundness": {
        "type": 3
      },
      "seed": 1872216361,
      "version": 1022,
      "versionNonce": 1519624711,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "SB069RZMy_HugtF7qur51"
        },
        {
          "id": "t6SycF9es4uKFWMFMP3-S",
          "type": "arrow"
        }
      ],
      "updated": 1755266197173,
      "link": null,
      "locked": false
    },
    {
      "id": "SB069RZMy_HugtF7qur51",
      "type": "text",
      "x": 11364.640682884019,
      "y": -2367.9105116730098,
      "width": 178.19989013671875,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDe",
      "roundness": null,
      "seed": 557205479,
      "version": 1032,
      "versionNonce": 402639143,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197173,
      "link": null,
      "locked": false,
      "text": "/ruleset/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "uH4S-w2X0ns5ZvAu6PUYe",
      "originalText": "/ruleset/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "QcO_dNXolTyDzpt071zrz",
      "type": "rectangle",
      "x": 11310.240627904755,
      "y": -3381.1386858730125,
      "width": 287.00000009524416,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDg",
      "roundness": {
        "type": 3
      },
      "seed": 1194832905,
      "version": 1038,
      "versionNonce": 1027533671,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "P08He2MKTiABp8xMi69_y"
        },
        {
          "id": "-NeZkEp-F-dZsIyvTxPCi",
          "type": "arrow"
        }
      ],
      "updated": 1755266197173,
      "link": null,
      "locked": false
    },
    {
      "id": "P08He2MKTiABp8xMi69_y",
      "type": "text",
      "x": 11364.640682884019,
      "y": -3353.6386858730125,
      "width": 178.19989013671875,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDh",
      "roundness": null,
      "seed": 1861599561,
      "version": 1056,
      "versionNonce": 221963911,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197173,
      "link": null,
      "locked": false,
      "text": "/.github/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "QcO_dNXolTyDzpt071zrz",
      "originalText": "/.github/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "-NeZkEp-F-dZsIyvTxPCi",
      "type": "arrow",
      "x": 10945.823962158733,
      "y": -2650.989479539678,
      "width": 359.4166657460228,
      "height": 680.2492063333343,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDj",
      "roundness": null,
      "seed": 270583207,
      "version": 168,
      "versionNonce": 762991815,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197206,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          179.7083328730114,
          0
        ],
        [
          179.7083328730114,
          -680.2492063333343
        ],
        [
          359.4166657460228,
          -680.2492063333343
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "HNaU6U8k67BQ_FzF07ZG7",
        "focus": -0.0017142857142879314,
        "gap": 4.999999999998181,
        "fixedPoint": [
          1.016420361247941,
          0.4991428571428561
        ]
      },
      "endBinding": {
        "elementId": "QcO_dNXolTyDzpt071zrz",
        "focus": 1.0348432055633692,
        "gap": 5,
        "fixedPoint": [
          -0.017421602781674893,
          0.4990000000000009
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "ZVULUXlbQw6m2OhghDYQV",
      "type": "arrow",
      "x": 10945.823962158733,
      "y": -2650.989479539678,
      "width": 359.41666574602095,
      "height": 404.10357153333325,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDk",
      "roundness": null,
      "seed": 150886151,
      "version": 141,
      "versionNonce": 1176421895,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197204,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          179.7083328730114,
          0
        ],
        [
          179.7083328730114,
          -404.10357153333325
        ],
        [
          359.41666574602095,
          -404.10357153333325
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "HNaU6U8k67BQ_FzF07ZG7",
        "focus": -0.0017142857142879314,
        "gap": 4.999999999998181,
        "fixedPoint": [
          1.016420361247941,
          0.4991428571428561
        ]
      },
      "endBinding": {
        "elementId": "ZaibGO8Kfy3_JTbFd-uCX",
        "focus": 0.0019999999999901273,
        "gap": 5,
        "fixedPoint": [
          -0.01742160278746278,
          0.4990000000000009
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "MDzekzSUfFskkJ8drx18N",
      "type": "arrow",
      "x": 10945.823962158733,
      "y": -2650.989479539678,
      "width": 359.4166657460228,
      "height": 88.81230173333279,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDl",
      "roundness": null,
      "seed": 153804553,
      "version": 122,
      "versionNonce": 780561703,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197204,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          179.7083328730114,
          0
        ],
        [
          179.7083328730114,
          -88.81230173333279
        ],
        [
          359.4166657460228,
          -88.81230173333279
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "HNaU6U8k67BQ_FzF07ZG7",
        "focus": -0.0017142857142879314,
        "gap": 4.999999999998181,
        "fixedPoint": [
          1.016420361247941,
          0.4991428571428561
        ]
      },
      "endBinding": {
        "elementId": "5bmrPG3vGIkfzZ5haAfQz",
        "focus": 0.0019999999999963654,
        "gap": 5,
        "fixedPoint": [
          -0.017421602781674893,
          0.4990000000000009
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "_KEt8O1aCI7sIZvckz5Yn",
      "type": "arrow",
      "x": 10945.823962158733,
      "y": -2650.989479539678,
      "width": 359.4166657460228,
      "height": 108.33333306666782,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDm",
      "roundness": null,
      "seed": 1857981353,
      "version": 210,
      "versionNonce": 1974218823,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197204,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          179.7083328730114,
          0
        ],
        [
          179.7083328730114,
          108.33333306666782
        ],
        [
          359.4166657460228,
          108.33333306666782
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "HNaU6U8k67BQ_FzF07ZG7",
        "focus": -0.0017142857142879314,
        "gap": 4.999999999998181,
        "fixedPoint": [
          1.016420361247941,
          0.4991428571428561
        ]
      },
      "endBinding": {
        "elementId": "37BRcDIBToAHg6adeYvA3",
        "focus": 0.0019999999999963654,
        "gap": 5,
        "fixedPoint": [
          -0.017421602781674893,
          0.4990000000000009
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "t6SycF9es4uKFWMFMP3-S",
      "type": "arrow",
      "x": 10945.823962158733,
      "y": -2650.989479539678,
      "width": 359.4166657460228,
      "height": 305.4789678666684,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDn",
      "roundness": null,
      "seed": 1455542697,
      "version": 101,
      "versionNonce": 174006695,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197205,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          179.7083328730114,
          0
        ],
        [
          179.7083328730114,
          305.4789678666684
        ],
        [
          359.4166657460228,
          305.4789678666684
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "HNaU6U8k67BQ_FzF07ZG7",
        "focus": -0.0017142857142879314,
        "gap": 4.999999999998181,
        "fixedPoint": [
          1.016420361247941,
          0.4991428571428561
        ]
      },
      "endBinding": {
        "elementId": "uH4S-w2X0ns5ZvAu6PUYe",
        "focus": 0.0019999999999973503,
        "gap": 5,
        "fixedPoint": [
          -0.017421602781674893,
          0.4990000000000009
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "HaWTn_OEllFfL_RUZTGT7",
      "type": "arrow",
      "x": 10945.823962158733,
      "y": -2650.989479539678,
      "width": 359.4166657460228,
      "height": 510.329761999998,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDo",
      "roundness": null,
      "seed": 1183269673,
      "version": 114,
      "versionNonce": 403966599,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197205,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          179.7083328730114,
          0
        ],
        [
          179.7083328730114,
          510.329761999998
        ],
        [
          359.4166657460228,
          510.329761999998
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "HNaU6U8k67BQ_FzF07ZG7",
        "focus": -0.0017142857142879314,
        "gap": 4.999999999998181,
        "fixedPoint": [
          1.016420361247941,
          0.4991428571428561
        ]
      },
      "endBinding": {
        "elementId": "Mm9uTH4fwvPOwSB6IllHp",
        "focus": -1.0348432055633672,
        "gap": 5,
        "fixedPoint": [
          -0.017421602781674893,
          0.5760515933332908
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "C3e8hpLs3dTVCRIMZmQIA",
      "type": "arrow",
      "x": 11602.240627904754,
      "y": -3055.0930510730113,
      "width": 194.61738833334311,
      "height": 135.11512146666564,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDp",
      "roundness": null,
      "seed": 307322023,
      "version": 80,
      "versionNonce": 570638727,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197202,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          97.30869416667156,
          0
        ],
        [
          97.30869416667156,
          -135.11512146666564
        ],
        [
          194.61738833334311,
          -135.11512146666564
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ZaibGO8Kfy3_JTbFd-uCX",
        "focus": -0.0019999999999901273,
        "gap": 5,
        "fixedPoint": [
          1.0174216027874499,
          0.4990000000000009
        ]
      },
      "endBinding": {
        "elementId": "sIBN3Bzoxizr0ITg5kbTH",
        "focus": 0.0025316455696096705,
        "gap": 5,
        "fixedPoint": [
          -0.015267309236668244,
          0.4987341772151909
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "nqSqLkSUUHy183blKaCle",
      "type": "arrow",
      "x": 11602.240627904754,
      "y": -3055.0930510730113,
      "width": 194.61738733334096,
      "height": 16.96948646666533,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDq",
      "roundness": null,
      "seed": 1193458695,
      "version": 108,
      "versionNonce": 525301927,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197202,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          97.30869366667139,
          0
        ],
        [
          97.30869366667139,
          -16.96948646666533
        ],
        [
          194.61738733334096,
          -16.96948646666533
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ZaibGO8Kfy3_JTbFd-uCX",
        "focus": -0.0019999999999901273,
        "gap": 4.999999999998181,
        "fixedPoint": [
          1.0174216027874499,
          0.4990000000000009
        ]
      },
      "endBinding": {
        "elementId": "qrA5lo3kfCYQGMEiE9XaJ",
        "focus": 0.002531645569620169,
        "gap": 5,
        "fixedPoint": [
          -0.015267309236673804,
          0.4987341772151909
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "BZROqmS8x1_WfN4iMc5ZE",
      "type": "arrow",
      "x": 11602.240627904754,
      "y": -3055.0930510730113,
      "width": 194.61738833334311,
      "height": 101.67614853333544,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDr",
      "roundness": null,
      "seed": 1362755113,
      "version": 110,
      "versionNonce": 273140679,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197203,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          97.30869416667156,
          0
        ],
        [
          97.30869416667156,
          101.67614853333544
        ],
        [
          194.61738833334311,
          101.67614853333544
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ZaibGO8Kfy3_JTbFd-uCX",
        "focus": -0.0019999999999901273,
        "gap": 4.999999999998181,
        "fixedPoint": [
          1.0174216027874499,
          0.4990000000000009
        ]
      },
      "endBinding": {
        "elementId": "XRBX0bPuJU4hcEclkV-v0",
        "focus": 0.002499999999992807,
        "gap": 5,
        "fixedPoint": [
          -0.015267309257814105,
          0.49875000000000114
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "WHNrurVFZWpGy6JLmyCtJ",
      "type": "arrow",
      "x": 11602.240628,
      "y": -2739.801781273011,
      "width": 194.6173875714303,
      "height": 82.05127493333202,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDs",
      "roundness": null,
      "seed": 459993511,
      "version": 83,
      "versionNonce": 1345136455,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197201,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          97.30869378571333,
          0
        ],
        [
          97.30869378571333,
          -82.05127493333202
        ],
        [
          194.6173875714303,
          -82.05127493333202
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "5bmrPG3vGIkfzZ5haAfQz",
        "focus": -0.0019999999999963654,
        "gap": 5,
        "fixedPoint": [
          1.0174216027816747,
          0.4990000000000009
        ]
      },
      "endBinding": {
        "elementId": "3ZTBDdzQYL0ehMnaWhroI",
        "focus": 0.0025316455696209094,
        "gap": 5,
        "fixedPoint": [
          -0.015267309205589451,
          0.4987341772151909
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "uveIv1pbpc4-UpJPV4A4p",
      "type": "arrow",
      "x": 11602.240628,
      "y": -2739.801781273011,
      "width": 194.61738757142666,
      "height": 49.31230106666817,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDt",
      "roundness": null,
      "seed": 1437303241,
      "version": 92,
      "versionNonce": 1119266407,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266197202,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          97.30869378571333,
          0
        ],
        [
          97.30869378571333,
          49.31230106666817
        ],
        [
          194.61738757142666,
          49.31230106666817
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "5bmrPG3vGIkfzZ5haAfQz",
        "focus": -0.0019999999999963654,
        "gap": 5,
        "fixedPoint": [
          1.0174216027816747,
          0.4990000000000009
        ]
      },
      "endBinding": {
        "elementId": "hFIN2jb3SgrUrJFGie4fH",
        "focus": 0.0025316455696208964,
        "gap": 5,
        "fixedPoint": [
          -0.015267309205594923,
          0.4987341772151909
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "Q9Wsb1N4eCYM7I5lMhaPU",
      "type": "rectangle",
      "x": 12907.727117228293,
      "y": -2940.5966991805767,
      "width": 236.99999977170958,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDu",
      "roundness": {
        "type": 3
      },
      "seed": 1668129159,
      "version": 1144,
      "versionNonce": 500384775,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "neBe72mX0Xgwor-g3FWtp"
        },
        {
          "id": "kdIiJP0nY6YnObps6g8If",
          "type": "arrow"
        }
      ],
      "updated": 1755266193716,
      "link": null,
      "locked": false
    },
    {
      "id": "neBe72mX0Xgwor-g3FWtp",
      "type": "text",
      "x": 12980.027135424694,
      "y": -2922.3466991805767,
      "width": 92.39996337890625,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bDv",
      "roundness": null,
      "seed": 74307751,
      "version": 1148,
      "versionNonce": 1459301159,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266193716,
      "link": null,
      "locked": false,
      "text": "/data/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "Q9Wsb1N4eCYM7I5lMhaPU",
      "originalText": "/data/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "m17KnQEXZyVfc9_zCtbPw",
      "type": "rectangle",
      "x": 12907.727117228293,
      "y": -3153.0899232178017,
      "width": 236.99999977170953,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bE5",
      "roundness": {
        "type": 3
      },
      "seed": 766018535,
      "version": 1282,
      "versionNonce": 441044327,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "LOjuVkpeBSMmGVp7NyPpU"
        },
        {
          "id": "Uxl-EJUWvxB4SxLlttZO5",
          "type": "arrow"
        }
      ],
      "updated": 1755266193717,
      "link": null,
      "locked": false
    },
    {
      "id": "LOjuVkpeBSMmGVp7NyPpU",
      "type": "text",
      "x": 12980.027135424694,
      "y": -3134.8399232178017,
      "width": 92.39996337890625,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bE6",
      "roundness": null,
      "seed": 1574792967,
      "version": 1282,
      "versionNonce": 177834119,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266193717,
      "link": null,
      "locked": false,
      "text": "/docs/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "m17KnQEXZyVfc9_zCtbPw",
      "originalText": "/docs/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "VQ6NOVqZKkLQyEyCRolcC",
      "type": "rectangle",
      "x": 12907.727117228293,
      "y": -2728.1034751433513,
      "width": 236.99999977170958,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEc",
      "roundness": {
        "type": 3
      },
      "seed": 368349959,
      "version": 1383,
      "versionNonce": 2134397639,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "mIzbophJ8cCLa2DvcWenY"
        },
        {
          "id": "juyQhLWMa4PoF9KAzIhcp",
          "type": "arrow"
        }
      ],
      "updated": 1755266193718,
      "link": null,
      "locked": false
    },
    {
      "id": "mIzbophJ8cCLa2DvcWenY",
      "type": "text",
      "x": 12918.427159838757,
      "y": -2705.6034751433513,
      "width": 215.59991455078125,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEd",
      "roundness": null,
      "seed": 2082118183,
      "version": 1637,
      "versionNonce": 1313890791,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266193718,
      "link": null,
      "locked": false,
      "text": "/kns_ctx_vivo/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "VQ6NOVqZKkLQyEyCRolcC",
      "originalText": "/kns_ctx_vivo/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "8KaeF0bYHdjcG7jH0-qH_",
      "type": "rectangle",
      "x": 12907.727117000002,
      "y": -2507.110251106126,
      "width": 237.00000000000045,
      "height": 78,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEe",
      "roundness": {
        "type": 3
      },
      "seed": 976403783,
      "version": 1315,
      "versionNonce": 1833980967,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "qZww1jcQMpastIo-UssuM"
        },
        {
          "id": "QgogT7BEUW88pdOVGcy7l",
          "type": "arrow"
        }
      ],
      "updated": 1755266193719,
      "link": null,
      "locked": false
    },
    {
      "id": "qZww1jcQMpastIo-UssuM",
      "type": "text",
      "x": 12926.127156672854,
      "y": -2485.610251106126,
      "width": 200.19992065429688,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEf",
      "roundness": null,
      "seed": 1134132327,
      "version": 1423,
      "versionNonce": 815871815,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266193719,
      "link": null,
      "locked": false,
      "text": "/wf_template/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "8KaeF0bYHdjcG7jH0-qH_",
      "originalText": "/wf_template/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "XBExlwWZxLfxbDSWtkjkU",
      "type": "rectangle",
      "x": 12393.72855068068,
      "y": -2830.600086828632,
      "width": 327.49713276190386,
      "height": 79.00000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEg",
      "roundness": {
        "type": 3
      },
      "seed": 369538311,
      "version": 1402,
      "versionNonce": 1622364551,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "hVKf0UC4stEwWSZz8ZwVQ"
        },
        {
          "id": "Uxl-EJUWvxB4SxLlttZO5",
          "type": "arrow"
        },
        {
          "id": "kdIiJP0nY6YnObps6g8If",
          "type": "arrow"
        },
        {
          "id": "juyQhLWMa4PoF9KAzIhcp",
          "type": "arrow"
        },
        {
          "id": "QgogT7BEUW88pdOVGcy7l",
          "type": "arrow"
        }
      ],
      "updated": 1755266193720,
      "link": null,
      "locked": false
    },
    {
      "id": "hVKf0UC4stEwWSZz8ZwVQ",
      "type": "text",
      "x": 12472.777150630967,
      "y": -2808.600086828632,
      "width": 169.39993286132812,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEh",
      "roundness": null,
      "seed": 966294567,
      "version": 1375,
      "versionNonce": 763201703,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266193720,
      "link": null,
      "locked": false,
      "text": "/core_actv/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "XBExlwWZxLfxbDSWtkjkU",
      "originalText": "/core_actv/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "Uxl-EJUWvxB4SxLlttZO5",
      "type": "arrow",
      "x": 12726.225683442586,
      "y": -2791.200086828632,
      "width": 176.50143378570647,
      "height": 326.2398363891697,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEi",
      "roundness": null,
      "seed": 2056284583,
      "version": 374,
      "versionNonce": 353386567,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266193724,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          88.25071689285323,
          0
        ],
        [
          88.25071689285323,
          -326.2398363891697
        ],
        [
          176.50143378570647,
          -326.2398363891697
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "XBExlwWZxLfxbDSWtkjkU",
        "focus": -0.0025316455696098293,
        "gap": 5,
        "fixedPoint": [
          1.0152673092366802,
          0.4987341772151895
        ]
      },
      "endBinding": {
        "elementId": "m17KnQEXZyVfc9_zCtbPw",
        "focus": 1.0421940928676474,
        "gap": 5,
        "fixedPoint": [
          -0.02109704643382386,
          0.4986013986013998
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "kdIiJP0nY6YnObps6g8If",
      "type": "arrow",
      "x": 12726.225683442586,
      "y": -2791.200086828632,
      "width": 176.50143378570647,
      "height": 113.74661235194458,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEj",
      "roundness": null,
      "seed": 153214281,
      "version": 367,
      "versionNonce": 231645031,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266193724,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          88.25071689285323,
          0
        ],
        [
          88.25071689285323,
          -113.74661235194458
        ],
        [
          176.50143378570647,
          -113.74661235194458
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "XBExlwWZxLfxbDSWtkjkU",
        "focus": -0.0025316455696098293,
        "gap": 5.000000000001819,
        "fixedPoint": [
          1.0152673092366802,
          0.4987341772151895
        ]
      },
      "endBinding": {
        "elementId": "Q9Wsb1N4eCYM7I5lMhaPU",
        "focus": 0.0027972027971857895,
        "gap": 5,
        "fixedPoint": [
          -0.021097046433823853,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "juyQhLWMa4PoF9KAzIhcp",
      "type": "arrow",
      "x": 12726.225683442586,
      "y": -2791.200086828632,
      "width": 176.50143378570647,
      "height": 102.99661168528064,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEk",
      "roundness": null,
      "seed": 1357890567,
      "version": 367,
      "versionNonce": 431233671,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266193724,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          88.25071689285323,
          0
        ],
        [
          88.25071689285323,
          102.99661168528064
        ],
        [
          176.50143378570647,
          102.99661168528064
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "XBExlwWZxLfxbDSWtkjkU",
        "focus": -0.0025316455696098293,
        "gap": 5.000000000001819,
        "fixedPoint": [
          1.0152673092366802,
          0.4987341772151895
        ]
      },
      "endBinding": {
        "elementId": "VQ6NOVqZKkLQyEyCRolcC",
        "focus": 0.0024999999999939944,
        "gap": 5,
        "fixedPoint": [
          -0.021097046433823853,
          0.4987499999999997
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "QgogT7BEUW88pdOVGcy7l",
      "type": "arrow",
      "x": 12726.225683442586,
      "y": -2791.200086828632,
      "width": 176.50143355741602,
      "height": 330.1000000000002,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEl",
      "roundness": null,
      "seed": 2091528681,
      "version": 384,
      "versionNonce": 2105356711,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266193724,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          88.25071677870801,
          0
        ],
        [
          88.25071677870801,
          330.1000000000002
        ],
        [
          176.50143355741602,
          330.1000000000002
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "XBExlwWZxLfxbDSWtkjkU",
        "focus": -0.0025316455696098293,
        "gap": 5.000000000001819,
        "fixedPoint": [
          1.0152673092366802,
          0.4987341772151895
        ]
      },
      "endBinding": {
        "elementId": "8KaeF0bYHdjcG7jH0-qH_",
        "focus": -1.042194092826987,
        "gap": 5,
        "fixedPoint": [
          -0.02109704641350207,
          0.5898739009935176
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "Prjk2JrFiDPJnWhTVq-NC",
      "type": "rectangle",
      "x": 14120.099085,
      "y": -3484.003185380636,
      "width": 202.00000000000009,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEm",
      "roundness": {
        "type": 3
      },
      "seed": 1890282343,
      "version": 1217,
      "versionNonce": 761474407,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "KIdpVGm63gprzR5hfEDnu"
        },
        {
          "id": "6wfq_LEpLJa1IUsD5Czhp",
          "type": "arrow"
        },
        {
          "id": "3CL-keD7NDF7H1yUySeWT",
          "type": "arrow"
        },
        {
          "id": "VZYgJfczBlJpnh0K-UBdg",
          "type": "arrow"
        },
        {
          "id": "nP2syS4KZ6nWBgYT7tGSn",
          "type": "arrow"
        },
        {
          "id": "vjVFydwPLEbBdUJRHLShl",
          "type": "arrow"
        }
      ],
      "updated": 1755272450970,
      "link": null,
      "locked": false
    },
    {
      "id": "KIdpVGm63gprzR5hfEDnu",
      "type": "text",
      "x": 14174.899103310547,
      "y": -3465.753185380636,
      "width": 92.39996337890625,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEn",
      "roundness": null,
      "seed": 521627271,
      "version": 1224,
      "versionNonce": 864479367,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272450970,
      "link": null,
      "locked": false,
      "text": "/docs/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "Prjk2JrFiDPJnWhTVq-NC",
      "originalText": "/docs/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "ofe1cVeHZPT62wPr6Hqxt",
      "type": "rectangle",
      "x": 14604.974085197644,
      "y": -3785.565685380636,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEo",
      "roundness": {
        "type": 3
      },
      "seed": 278330791,
      "version": 1264,
      "versionNonce": 1858264903,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "l7kWg7do9hw0nlaVXdL3V"
        },
        {
          "id": "6wfq_LEpLJa1IUsD5Czhp",
          "type": "arrow"
        },
        {
          "id": "YvV5VzAbVOjKP1uUopGWu",
          "type": "arrow"
        }
      ],
      "updated": 1755272469889,
      "link": null,
      "locked": false
    },
    {
      "id": "l7kWg7do9hw0nlaVXdL3V",
      "type": "text",
      "x": 14649.574106559949,
      "y": -3767.315685380636,
      "width": 107.79995727539062,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEp",
      "roundness": null,
      "seed": 1482076359,
      "version": 1283,
      "versionNonce": 1977751143,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272450972,
      "link": null,
      "locked": false,
      "text": "/audio/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "ofe1cVeHZPT62wPr6Hqxt",
      "originalText": "/audio/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "QveUNEfJ1OTd95eC1gm4k",
      "type": "rectangle",
      "x": 14604.974085197644,
      "y": -3634.784435380636,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEs",
      "roundness": {
        "type": 3
      },
      "seed": 1633907239,
      "version": 1261,
      "versionNonce": 1555482375,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "qWNxHz4FCM_-RPVU56uTL"
        },
        {
          "id": "3CL-keD7NDF7H1yUySeWT",
          "type": "arrow"
        },
        {
          "id": "Hqs3torA7X3uLbdor_5UR",
          "type": "arrow"
        }
      ],
      "updated": 1755272472049,
      "link": null,
      "locked": false
    },
    {
      "id": "qWNxHz4FCM_-RPVU56uTL",
      "type": "text",
      "x": 14649.574106559949,
      "y": -3616.534435380636,
      "width": 107.79995727539062,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEt",
      "roundness": null,
      "seed": 815830343,
      "version": 1294,
      "versionNonce": 1877556167,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272450972,
      "link": null,
      "locked": false,
      "text": "/image/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "QveUNEfJ1OTd95eC1gm4k",
      "originalText": "/image/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "DAaU7vM4sCKDBMSvhUk7g",
      "type": "rectangle",
      "x": 14604.974085197644,
      "y": -3484.003185380636,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEw",
      "roundness": {
        "type": 3
      },
      "seed": 1209116327,
      "version": 1289,
      "versionNonce": 470096329,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "KEe9UiWN0XwUHn501h5Ep"
        },
        {
          "id": "VZYgJfczBlJpnh0K-UBdg",
          "type": "arrow"
        },
        {
          "id": "5t5jhPgLIOivY4kJ-_-3q",
          "type": "arrow"
        }
      ],
      "updated": 1755272474437,
      "link": null,
      "locked": false
    },
    {
      "id": "KEe9UiWN0XwUHn501h5Ep",
      "type": "text",
      "x": 14649.574106559949,
      "y": -3465.753185380636,
      "width": 107.79995727539062,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bEx",
      "roundness": null,
      "seed": 2090088903,
      "version": 1333,
      "versionNonce": 1180556583,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272450972,
      "link": null,
      "locked": false,
      "text": "/video/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "DAaU7vM4sCKDBMSvhUk7g",
      "originalText": "/video/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "rndbErvq1x9Zm4GV8GR93",
      "type": "rectangle",
      "x": 14604.974085197644,
      "y": -3341.5345773806357,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bF0",
      "roundness": {
        "type": 3
      },
      "seed": 1707186983,
      "version": 1392,
      "versionNonce": 817686759,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "dQQo2zMOtDXpf_T2OaT-M"
        },
        {
          "id": "nP2syS4KZ6nWBgYT7tGSn",
          "type": "arrow"
        },
        {
          "id": "eLKmiAim1bewL4zmCSs7z",
          "type": "arrow"
        }
      ],
      "updated": 1755272476949,
      "link": null,
      "locked": false
    },
    {
      "id": "dQQo2zMOtDXpf_T2OaT-M",
      "type": "text",
      "x": 14634.174112663464,
      "y": -3323.2845773806357,
      "width": 138.59994506835938,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bF1",
      "roundness": null,
      "seed": 961650247,
      "version": 1446,
      "versionNonce": 199326343,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272450973,
      "link": null,
      "locked": false,
      "text": "/library/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "rndbErvq1x9Zm4GV8GR93",
      "originalText": "/library/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "gTrl2Z5RKfjle-p7UvpKe",
      "type": "rectangle",
      "x": 14604.974085197644,
      "y": -3199.0659693806356,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bF4",
      "roundness": {
        "type": 3
      },
      "seed": 1267945383,
      "version": 1598,
      "versionNonce": 464591785,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "u6IxuJ_jRALFd0MkfvzjC"
        },
        {
          "id": "vjVFydwPLEbBdUJRHLShl",
          "type": "arrow"
        },
        {
          "id": "_QmHTMut7rLoalO1zpKj4",
          "type": "arrow"
        }
      ],
      "updated": 1755272480511,
      "link": null,
      "locked": false
    },
    {
      "id": "u6IxuJ_jRALFd0MkfvzjC",
      "type": "text",
      "x": 14634.174112663464,
      "y": -3180.8159693806356,
      "width": 138.59994506835938,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bF5",
      "roundness": null,
      "seed": 1408811719,
      "version": 1666,
      "versionNonce": 881169383,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272450973,
      "link": null,
      "locked": false,
      "text": "/onboard/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "gTrl2Z5RKfjle-p7UvpKe",
      "originalText": "/onboard/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "6wfq_LEpLJa1IUsD5Czhp",
      "type": "arrow",
      "x": 14327.099085,
      "y": -3448.3531853806358,
      "width": 272.8750001976441,
      "height": 301.5625,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bF8",
      "roundness": null,
      "seed": 2057749543,
      "version": 2001,
      "versionNonce": 1097938919,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272451199,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          136.43750009882206,
          0
        ],
        [
          136.43750009882206,
          -301.5625
        ],
        [
          272.8750001976441,
          -301.5625
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "Prjk2JrFiDPJnWhTVq-NC",
        "focus": -0.002797202797204035,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "ofe1cVeHZPT62wPr6Hqxt",
        "focus": 1.0507614213197964,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "3CL-keD7NDF7H1yUySeWT",
      "type": "arrow",
      "x": 14327.099085,
      "y": -3448.3531853806358,
      "width": 272.8750001976441,
      "height": 150.78125,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bF9",
      "roundness": null,
      "seed": 698984263,
      "version": 1980,
      "versionNonce": 1584374535,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272451200,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          136.43750009882206,
          0
        ],
        [
          136.43750009882206,
          -150.78125
        ],
        [
          272.8750001976441,
          -150.78125
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "Prjk2JrFiDPJnWhTVq-NC",
        "focus": -0.002797202797202923,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "QveUNEfJ1OTd95eC1gm4k",
        "focus": 1.0507614213197964,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "VZYgJfczBlJpnh0K-UBdg",
      "type": "arrow",
      "x": 14327.099085,
      "y": -3448.3531853806358,
      "width": 272.8750001976441,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFA",
      "roundness": null,
      "seed": 950216295,
      "version": 1928,
      "versionNonce": 582199847,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272451201,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          272.8750001976441,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "Prjk2JrFiDPJnWhTVq-NC",
        "focus": -0.002797202797202923,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "DAaU7vM4sCKDBMSvhUk7g",
        "focus": 0.0027972027972034325,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49860139860139857
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "nP2syS4KZ6nWBgYT7tGSn",
      "type": "arrow",
      "x": 14327.099085,
      "y": -3448.3531853806358,
      "width": 272.8750001976441,
      "height": 142.46860800000013,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFB",
      "roundness": null,
      "seed": 643809671,
      "version": 1965,
      "versionNonce": 1261030727,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272451202,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          136.43750009882206,
          0
        ],
        [
          136.43750009882206,
          142.46860800000013
        ],
        [
          272.8750001976441,
          142.46860800000013
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "Prjk2JrFiDPJnWhTVq-NC",
        "focus": -0.002797202797202923,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "rndbErvq1x9Zm4GV8GR93",
        "focus": -1.0507614213197969,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013984
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "vjVFydwPLEbBdUJRHLShl",
      "type": "arrow",
      "x": 14327.099085,
      "y": -3448.3531853806358,
      "width": 272.8750001976441,
      "height": 284.93721600000026,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFC",
      "roundness": null,
      "seed": 1679554727,
      "version": 2080,
      "versionNonce": 1127124071,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272451202,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          136.43750009882206,
          0
        ],
        [
          136.43750009882206,
          284.93721600000026
        ],
        [
          272.8750001976441,
          284.93721600000026
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "Prjk2JrFiDPJnWhTVq-NC",
        "focus": -0.002797202797204035,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "gTrl2Z5RKfjle-p7UvpKe",
        "focus": -1.050761421319797,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "bTvq3cr_8GIcV3pMW2gph",
      "type": "rectangle",
      "x": 13438.224085322654,
      "y": -2426.0409753806293,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFX",
      "roundness": {
        "type": 3
      },
      "seed": 2108023751,
      "version": 991,
      "versionNonce": 1860084775,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "4Aa5pGnE8BTH8cQ0B9sR5"
        },
        {
          "id": "cbU56arV4o9iPpoNblBii",
          "type": "arrow"
        },
        {
          "id": "KN4T-9qVLcAyDr0vhVXW_",
          "type": "arrow"
        },
        {
          "id": "jzmt3ZRUq04sfyAa8VDBv",
          "type": "arrow"
        },
        {
          "id": "CUg39dsYAuA2G49djioVm",
          "type": "arrow"
        },
        {
          "id": "DNKod6_tXerWWjHBlIeZs",
          "type": "arrow"
        }
      ],
      "updated": 1755265408343,
      "link": null,
      "locked": false
    },
    {
      "id": "4Aa5pGnE8BTH8cQ0B9sR5",
      "type": "text",
      "x": 13490.5241036332,
      "y": -2407.7909753806293,
      "width": 92.39996337890625,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFY",
      "roundness": null,
      "seed": 719573735,
      "version": 1002,
      "versionNonce": 199591751,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755265408343,
      "link": null,
      "locked": false,
      "text": "/data/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "bTvq3cr_8GIcV3pMW2gph",
      "originalText": "/data/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "uiYngN6OAhPraJW1xfqsW",
      "type": "rectangle",
      "x": 13873.099084572656,
      "y": -2727.6034753806293,
      "width": 247.00000042734442,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFZ",
      "roundness": {
        "type": 3
      },
      "seed": 1423367687,
      "version": 1071,
      "versionNonce": 873408007,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "fwTpC8LcU3_r-h_2M76lq"
        },
        {
          "id": "cbU56arV4o9iPpoNblBii",
          "type": "arrow"
        }
      ],
      "updated": 1755265408346,
      "link": null,
      "locked": false
    },
    {
      "id": "fwTpC8LcU3_r-h_2M76lq",
      "type": "text",
      "x": 13911.899118355665,
      "y": -2709.3534753806293,
      "width": 169.39993286132812,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFa",
      "roundness": null,
      "seed": 1585153319,
      "version": 1108,
      "versionNonce": 1063963943,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755265408346,
      "link": null,
      "locked": false,
      "text": "/semantics/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "uiYngN6OAhPraJW1xfqsW",
      "originalText": "/semantics/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "aLlVq1XKmOFB3QZpwYAH4",
      "type": "rectangle",
      "x": 13873.099084572656,
      "y": -2576.8222253806293,
      "width": 247.00000042734433,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFb",
      "roundness": {
        "type": 3
      },
      "seed": 389957703,
      "version": 1051,
      "versionNonce": 12119911,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "ZPU28eaDkcMmVbOeP2KSS"
        },
        {
          "id": "KN4T-9qVLcAyDr0vhVXW_",
          "type": "arrow"
        }
      ],
      "updated": 1755265408347,
      "link": null,
      "locked": false
    },
    {
      "id": "ZPU28eaDkcMmVbOeP2KSS",
      "type": "text",
      "x": 13919.599115303907,
      "y": -2558.5722253806293,
      "width": 153.99993896484375,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFc",
      "roundness": null,
      "seed": 754689895,
      "version": 1097,
      "versionNonce": 1523870343,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755265408347,
      "link": null,
      "locked": false,
      "text": "/ai_learn/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "aLlVq1XKmOFB3QZpwYAH4",
      "originalText": "/ai_learn/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "GN1gdtxVsO92z0klndw5Y",
      "type": "rectangle",
      "x": 13873.099084572656,
      "y": -2426.0409753806293,
      "width": 247.00000042734433,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFd",
      "roundness": {
        "type": 3
      },
      "seed": 1577067143,
      "version": 1073,
      "versionNonce": 1134736583,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "Q2jDlQcvUAb3HbTVQdn1B"
        },
        {
          "id": "jzmt3ZRUq04sfyAa8VDBv",
          "type": "arrow"
        }
      ],
      "updated": 1755265408347,
      "link": null,
      "locked": false
    },
    {
      "id": "Q2jDlQcvUAb3HbTVQdn1B",
      "type": "text",
      "x": 13927.299112252149,
      "y": -2407.7909753806293,
      "width": 138.59994506835938,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFe",
      "roundness": null,
      "seed": 1795701159,
      "version": 1132,
      "versionNonce": 454984679,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755265408347,
      "link": null,
      "locked": false,
      "text": "/develop/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "GN1gdtxVsO92z0klndw5Y",
      "originalText": "/develop/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "lEQV2avW_Tc2zZEZB4BEW",
      "type": "rectangle",
      "x": 13873.099084572656,
      "y": -2275.2597253806293,
      "width": 247.00000000000003,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFf",
      "roundness": {
        "type": 3
      },
      "seed": 1228958919,
      "version": 1196,
      "versionNonce": 310244903,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "r0M0hiGHkaJoJsq3CZQNc"
        },
        {
          "id": "DNKod6_tXerWWjHBlIeZs",
          "type": "arrow"
        }
      ],
      "updated": 1755265408348,
      "link": null,
      "locked": false
    },
    {
      "id": "r0M0hiGHkaJoJsq3CZQNc",
      "type": "text",
      "x": 13888.799127297265,
      "y": -2252.7597253806293,
      "width": 215.59991455078125,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFg",
      "roundness": null,
      "seed": 340081639,
      "version": 1283,
      "versionNonce": 1674221895,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755265408348,
      "link": null,
      "locked": false,
      "text": "/out_template/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "lEQV2avW_Tc2zZEZB4BEW",
      "originalText": "/out_template/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "6RA3AvqId2jLhSfomDTIU",
      "type": "rectangle",
      "x": 13873.099084572656,
      "y": -2115.9784753806293,
      "width": 247.00000042734433,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFh",
      "roundness": {
        "type": 3
      },
      "seed": 1076045575,
      "version": 1322,
      "versionNonce": 2121020295,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "v355mOKf-BR3nHPU085cj"
        },
        {
          "id": "CUg39dsYAuA2G49djioVm",
          "type": "arrow"
        }
      ],
      "updated": 1755265408348,
      "link": null,
      "locked": false
    },
    {
      "id": "v355mOKf-BR3nHPU085cj",
      "type": "text",
      "x": 13934.999109200391,
      "y": -2097.7284753806293,
      "width": 123.199951171875,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFi",
      "roundness": null,
      "seed": 190230055,
      "version": 1416,
      "versionNonce": 634006183,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755265408348,
      "link": null,
      "locked": false,
      "text": "/guides/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "6RA3AvqId2jLhSfomDTIU",
      "originalText": "/guides/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "cbU56arV4o9iPpoNblBii",
      "type": "arrow",
      "x": 13640.224085322654,
      "y": -2390.3909753806292,
      "width": 227.87499925000157,
      "height": 301.5625,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFj",
      "roundness": null,
      "seed": 818696519,
      "version": 1588,
      "versionNonce": 1592446631,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755265408590,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          113.93749962500078,
          0
        ],
        [
          113.93749962500078,
          -301.5625
        ],
        [
          227.87499925000157,
          -301.5625
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "bTvq3cr_8GIcV3pMW2gph",
        "focus": -0.002797202797204035,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "uiYngN6OAhPraJW1xfqsW",
        "focus": 1.0507614213197964,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "KN4T-9qVLcAyDr0vhVXW_",
      "type": "arrow",
      "x": 13640.224085322654,
      "y": -2390.3909753806292,
      "width": 227.87499925000157,
      "height": 150.78125,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFk",
      "roundness": null,
      "seed": 1507889255,
      "version": 1541,
      "versionNonce": 772301255,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755265408591,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          113.93749962500078,
          0
        ],
        [
          113.93749962500078,
          -150.78125
        ],
        [
          227.87499925000157,
          -150.78125
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "bTvq3cr_8GIcV3pMW2gph",
        "focus": -0.002797202797202923,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "aLlVq1XKmOFB3QZpwYAH4",
        "focus": 1.0507614213197964,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "jzmt3ZRUq04sfyAa8VDBv",
      "type": "arrow",
      "x": 13640.224085322654,
      "y": -2390.3909753806292,
      "width": 227.87499925000157,
      "height": 0,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFl",
      "roundness": null,
      "seed": 1348463495,
      "version": 1487,
      "versionNonce": 1715900647,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755265408592,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          227.87499925000157,
          0
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "bTvq3cr_8GIcV3pMW2gph",
        "focus": -0.002797202797202923,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "GN1gdtxVsO92z0klndw5Y",
        "focus": 0.0027972027972034325,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49860139860139857
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "DNKod6_tXerWWjHBlIeZs",
      "type": "arrow",
      "x": 13640.224085322654,
      "y": -2390.3909753806292,
      "width": 227.87499925000338,
      "height": 155.0193618881117,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFm",
      "roundness": null,
      "seed": 1887888039,
      "version": 1536,
      "versionNonce": 1362222087,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755265408593,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          113.93749962500078,
          0
        ],
        [
          113.93749962500078,
          155.0193618881117
        ],
        [
          227.87499925000338,
          155.0193618881117
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "bTvq3cr_8GIcV3pMW2gph",
        "focus": -0.002797202797202923,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "lEQV2avW_Tc2zZEZB4BEW",
        "focus": -1.0507614213197969,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013984
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "CUg39dsYAuA2G49djioVm",
      "type": "arrow",
      "x": 13640.224085322654,
      "y": -2390.3909753806292,
      "width": 227.87499925000157,
      "height": 310.0625,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFn",
      "roundness": null,
      "seed": 1526855111,
      "version": 1560,
      "versionNonce": 1388757799,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755265408594,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          113.93749962500078,
          0
        ],
        [
          113.93749962500078,
          310.0625
        ],
        [
          227.87499925000157,
          310.0625
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "bTvq3cr_8GIcV3pMW2gph",
        "focus": -0.002797202797204035,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598984,
          0.49860139860139857
        ]
      },
      "endBinding": {
        "elementId": "6RA3AvqId2jLhSfomDTIU",
        "focus": -1.050761421319797,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "MFi4wPOjD8sveu0mWL-Zh",
      "type": "rectangle",
      "x": 15231.88480029884,
      "y": -2360.3442453785033,
      "width": 217.99999970116014,
      "height": 58,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFo",
      "roundness": {
        "type": 3
      },
      "seed": 1885628361,
      "version": 1505,
      "versionNonce": 1141960329,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "-gszvfkregrBP8070E_uq"
        },
        {
          "id": "-LBRoyzq27kWucxQxixBh",
          "type": "arrow"
        }
      ],
      "updated": 1755266188648,
      "link": null,
      "locked": false
    },
    {
      "id": "-gszvfkregrBP8070E_uq",
      "type": "text",
      "x": 15307.88480014942,
      "y": -2343.8442453785033,
      "width": 66,
      "height": 25,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFp",
      "roundness": null,
      "seed": 1626769065,
      "version": 1518,
      "versionNonce": 48510313,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266188648,
      "link": null,
      "locked": false,
      "text": "/mpln/",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "MFi4wPOjD8sveu0mWL-Zh",
      "originalText": "/mpln/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "1nJEX84Fo1GDxHVeRDrsC",
      "type": "rectangle",
      "x": 15231.884799965506,
      "y": -2230.844245378503,
      "width": 218.00000000000006,
      "height": 60,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFs",
      "roundness": {
        "type": 3
      },
      "seed": 549567305,
      "version": 1541,
      "versionNonce": 92450601,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "LB6cOrP4T9j5u1E-a9nka"
        },
        {
          "id": "vfJN5lRtEnKgmrkpUtA_V",
          "type": "arrow"
        }
      ],
      "updated": 1755266188649,
      "link": null,
      "locked": false
    },
    {
      "id": "LB6cOrP4T9j5u1E-a9nka",
      "type": "text",
      "x": 15247.384799965506,
      "y": -2213.344245378503,
      "width": 187,
      "height": 25,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFt",
      "roundness": null,
      "seed": 1365076521,
      "version": 1595,
      "versionNonce": 2106909193,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266188649,
      "link": null,
      "locked": false,
      "text": "/brainstorm_crtv/",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "1nJEX84Fo1GDxHVeRDrsC",
      "originalText": "/brainstorm_crtv/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "VUD-d-ZYfO71I_4FV8TJf",
      "type": "rectangle",
      "x": 14357.974085263128,
      "y": -2114.5414679499304,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#d0bfff",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFw",
      "roundness": {
        "type": 3
      },
      "seed": 337202889,
      "version": 1289,
      "versionNonce": 438875081,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "uynMPN-l4sUkHxi_d1W-G"
        },
        {
          "id": "G0pAnB-OvdKneG4gBnYUx",
          "type": "arrow"
        },
        {
          "id": "McyqkPhtiDtftgPJ4vygH",
          "type": "arrow"
        },
        {
          "id": "2kW5CUAJZRjOV_BxECsIG",
          "type": "arrow"
        }
      ],
      "updated": 1755266188649,
      "link": null,
      "locked": false
    },
    {
      "id": "uynMPN-l4sUkHxi_d1W-G",
      "type": "text",
      "x": 14394.87410967719,
      "y": -2096.2914679499304,
      "width": 123.199951171875,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFx",
      "roundness": null,
      "seed": 729189801,
      "version": 1383,
      "versionNonce": 1683051177,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266188649,
      "link": null,
      "locked": false,
      "text": "/guides/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "VUD-d-ZYfO71I_4FV8TJf",
      "originalText": "/guides/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "fhu0MvY6IsSoRrzKLKrG2",
      "type": "rectangle",
      "x": 14829.015751902034,
      "y": -2302.3442453626276,
      "width": 214.50000009796514,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFy",
      "roundness": {
        "type": 3
      },
      "seed": 646508681,
      "version": 1498,
      "versionNonce": 1525823017,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "2QH6IcHUdSDQd16yIo-jk"
        },
        {
          "id": "G0pAnB-OvdKneG4gBnYUx",
          "type": "arrow"
        },
        {
          "id": "-LBRoyzq27kWucxQxixBh",
          "type": "arrow"
        },
        {
          "id": "vfJN5lRtEnKgmrkpUtA_V",
          "type": "arrow"
        }
      ],
      "updated": 1755266188651,
      "link": null,
      "locked": false
    },
    {
      "id": "2QH6IcHUdSDQd16yIo-jk",
      "type": "text",
      "x": 14874.665776365078,
      "y": -2284.0942453626276,
      "width": 123.199951171875,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bFz",
      "roundness": null,
      "seed": 453769065,
      "version": 1594,
      "versionNonce": 695961865,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266188651,
      "link": null,
      "locked": false,
      "text": "/planin/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "fhu0MvY6IsSoRrzKLKrG2",
      "originalText": "/planin/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "mpgvHNbpJoJg8rrhnJ0Gq",
      "type": "rectangle",
      "x": 14829.015751886152,
      "y": -2118.7914678626275,
      "width": 219.49999999999991,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bG0",
      "roundness": {
        "type": 3
      },
      "seed": 1531650633,
      "version": 1540,
      "versionNonce": 496909449,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "55pnUgq2rEibHl79SdloH"
        },
        {
          "id": "McyqkPhtiDtftgPJ4vygH",
          "type": "arrow"
        }
      ],
      "updated": 1755266188652,
      "link": null,
      "locked": false
    },
    {
      "id": "55pnUgq2rEibHl79SdloH",
      "type": "text",
      "x": 14838.665791559004,
      "y": -2096.2914678626275,
      "width": 200.19992065429688,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bG1",
      "roundness": null,
      "seed": 1679946025,
      "version": 1664,
      "versionNonce": 429376361,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266188652,
      "link": null,
      "locked": false,
      "text": "/run_control/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "mpgvHNbpJoJg8rrhnJ0Gq",
      "originalText": "/run_control/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "0_SS4JYqZr1pEV3EFoK3h",
      "type": "rectangle",
      "x": 14829.015751886152,
      "y": -1926.7386913626272,
      "width": 219.50000011384685,
      "height": 80,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bG2",
      "roundness": {
        "type": 3
      },
      "seed": 184280073,
      "version": 1580,
      "versionNonce": 858438953,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "TXoc9s3QppY5vbxQXk5bZ"
        },
        {
          "id": "2kW5CUAJZRjOV_BxECsIG",
          "type": "arrow"
        }
      ],
      "updated": 1755266188652,
      "link": null,
      "locked": false
    },
    {
      "id": "TXoc9s3QppY5vbxQXk5bZ",
      "type": "text",
      "x": 14861.765782460654,
      "y": -1904.2386913626272,
      "width": 153.99993896484375,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bG3",
      "roundness": null,
      "seed": 1809087209,
      "version": 1721,
      "versionNonce": 386609161,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266188652,
      "link": null,
      "locked": false,
      "text": "/pipeline/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "0_SS4JYqZr1pEV3EFoK3h",
      "originalText": "/pipeline/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "G0pAnB-OvdKneG4gBnYUx",
      "type": "arrow",
      "x": 14559.974085263128,
      "y": -2078.8914679499303,
      "width": 264.04166663890646,
      "height": 187.8027774126972,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bG4",
      "roundness": null,
      "seed": 389494217,
      "version": 516,
      "versionNonce": 149127625,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266188653,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          132.02083331945323,
          0
        ],
        [
          132.02083331945323,
          -187.8027774126972
        ],
        [
          264.04166663890646,
          -187.8027774126972
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "VUD-d-ZYfO71I_4FV8TJf",
        "focus": -0.0027972099662481463,
        "gap": 5,
        "fixedPoint": [
          1.025380710659897,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "fhu0MvY6IsSoRrzKLKrG2",
        "focus": 0.002797193587586167,
        "gap": 5,
        "fixedPoint": [
          -0.019646365424848447,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "McyqkPhtiDtftgPJ4vygH",
      "type": "arrow",
      "x": 14559.974085263128,
      "y": -2078.8914679499303,
      "width": 264.04166662302487,
      "height": 8.730285117053427e-8,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bG5",
      "roundness": null,
      "seed": 4166825,
      "version": 529,
      "versionNonce": 243425449,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266188653,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          264.04166662302487,
          8.730285117053427e-8
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "VUD-d-ZYfO71I_4FV8TJf",
        "focus": -0.002797202797204545,
        "gap": 5,
        "fixedPoint": [
          1.025380710659897,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "mpgvHNbpJoJg8rrhnJ0Gq",
        "focus": -1.0392927308447937,
        "gap": 5,
        "fixedPoint": [
          -0.01964636542239686,
          0.4987499999999997
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "2kW5CUAJZRjOV_BxECsIG",
      "type": "arrow",
      "x": 14559.974085263128,
      "y": -2078.8914679499303,
      "width": 264.04166662302487,
      "height": 192.05277658730347,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bG6",
      "roundness": null,
      "seed": 714676105,
      "version": 568,
      "versionNonce": 2124571529,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266188653,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          132.02083331151152,
          0
        ],
        [
          132.02083331151152,
          192.05277658730347
        ],
        [
          264.04166662302487,
          192.05277658730347
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "VUD-d-ZYfO71I_4FV8TJf",
        "focus": -0.002797202797204545,
        "gap": 5,
        "fixedPoint": [
          1.025380710659897,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "0_SS4JYqZr1pEV3EFoK3h",
        "focus": -1.039292730844795,
        "gap": 5,
        "fixedPoint": [
          -0.019646365422397307,
          0.4987499999999997
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "-LBRoyzq27kWucxQxixBh",
      "type": "arrow",
      "x": 15048.515751999998,
      "y": -2266.694245362628,
      "width": 178.36904829884406,
      "height": 64.75000001587568,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bG8",
      "roundness": null,
      "seed": 2025687369,
      "version": 451,
      "versionNonce": 897518185,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266188653,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          89.18452414942294,
          0
        ],
        [
          89.18452414942294,
          -64.75000001587568
        ],
        [
          178.36904829884406,
          -64.75000001587568
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "fhu0MvY6IsSoRrzKLKrG2",
        "focus": -0.00279720279720242,
        "gap": 5,
        "fixedPoint": [
          1.0196463654248482,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "MFi4wPOjD8sveu0mWL-Zh",
        "focus": 1.0714285714285707,
        "gap": 5,
        "fixedPoint": [
          -0.035714285714285705,
          0.4982758620689651
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "vfJN5lRtEnKgmrkpUtA_V",
      "type": "arrow",
      "x": 15048.515751999998,
      "y": -2266.694245362628,
      "width": 178.3690479655088,
      "height": 65.74999998412477,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bG9",
      "roundness": null,
      "seed": 347043881,
      "version": 427,
      "versionNonce": 2078528841,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755266188653,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          89.18452398275622,
          0
        ],
        [
          89.18452398275622,
          65.74999998412477
        ],
        [
          178.3690479655088,
          65.74999998412477
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "fhu0MvY6IsSoRrzKLKrG2",
        "focus": -0.00279720279720242,
        "gap": 5,
        "fixedPoint": [
          1.0196463654248482,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "1nJEX84Fo1GDxHVeRDrsC",
        "focus": -1.0458715596330275,
        "gap": 5,
        "fixedPoint": [
          -0.022935779816513756,
          0.49833333333333296
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "x4KuJN9PbG60JdxO96c5s",
      "type": "rectangle",
      "x": 14950.649029988137,
      "y": -4018.940826938844,
      "width": 197.00000000000003,
      "height": 185,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGa",
      "roundness": {
        "type": 3
      },
      "seed": 1072612391,
      "version": 1137,
      "versionNonce": 1888156039,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "sODuVX5HAxMiSjD1fprYL",
          "type": "text"
        },
        {
          "id": "YvV5VzAbVOjKP1uUopGWu",
          "type": "arrow"
        }
      ],
      "updated": 1755272469892,
      "link": null,
      "locked": false
    },
    {
      "id": "sODuVX5HAxMiSjD1fprYL",
      "type": "text",
      "x": 14956.74906660923,
      "y": -4013.940826938844,
      "width": 184.7999267578125,
      "height": 175,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGb",
      "roundness": null,
      "seed": 99723079,
      "version": 1275,
      "versionNonce": 2009546377,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272434661,
      "link": null,
      "locked": false,
      "text": "notas de voz\nreuniones\nentrevistas\npodcast\naudio/videos",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "x4KuJN9PbG60JdxO96c5s",
      "originalText": "notas de voz\nreuniones\nentrevistas\npodcast\naudio/videos",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "_P6PZeFPWhNlTpDUUoA6p",
      "type": "rectangle",
      "x": 14950.649029988137,
      "y": -3810.253326938844,
      "width": 197.00000000000003,
      "height": 255,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGc",
      "roundness": {
        "type": 3
      },
      "seed": 1273701991,
      "version": 1250,
      "versionNonce": 888664391,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "2C_jGsbz4k5KvswjxC5Jl",
          "type": "text"
        },
        {
          "id": "Hqs3torA7X3uLbdor_5UR",
          "type": "arrow"
        }
      ],
      "updated": 1755272472052,
      "link": null,
      "locked": false
    },
    {
      "id": "2C_jGsbz4k5KvswjxC5Jl",
      "type": "text",
      "x": 14964.449063557473,
      "y": -3805.253326938844,
      "width": 169.39993286132812,
      "height": 245,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGd",
      "roundness": null,
      "seed": 279429511,
      "version": 1449,
      "versionNonce": 189826409,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272434661,
      "link": null,
      "locked": false,
      "text": "fotos\nimagenes\ngraficos\nesquemas\ndiagramas\nplanos\nexplosiones",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "_P6PZeFPWhNlTpDUUoA6p",
      "originalText": "fotos\nimagenes\ngraficos\nesquemas\ndiagramas\nplanos\nexplosiones",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "O77tWduP7RHoQFW5iviPY",
      "type": "rectangle",
      "x": 14950.649029988137,
      "y": -3531.565826938844,
      "width": 197.00000000000003,
      "height": 150,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGe",
      "roundness": {
        "type": 3
      },
      "seed": 1164179623,
      "version": 1345,
      "versionNonce": 943586185,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "ySprEi6JVQL1IxzqCP72Q",
          "type": "text"
        },
        {
          "id": "5t5jhPgLIOivY4kJ-_-3q",
          "type": "arrow"
        }
      ],
      "updated": 1755272474441,
      "link": null,
      "locked": false
    },
    {
      "id": "ySprEi6JVQL1IxzqCP72Q",
      "type": "text",
      "x": 14964.449063557473,
      "y": -3526.565826938844,
      "width": 169.39993286132812,
      "height": 140,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGf",
      "roundness": null,
      "seed": 2144095175,
      "version": 1639,
      "versionNonce": 802025545,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272434661,
      "link": null,
      "locked": false,
      "text": "videos\nyoutube\nanimaciones\npresentac",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "O77tWduP7RHoQFW5iviPY",
      "originalText": "videos\nyoutube\nanimaciones\npresentac",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "Mz58K5IVqy3pxuR5516vx",
      "type": "rectangle",
      "x": 14950.649029988137,
      "y": -3357.878326938844,
      "width": 197.00000000000003,
      "height": 185,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGg",
      "roundness": {
        "type": 3
      },
      "seed": 1811757799,
      "version": 1587,
      "versionNonce": 92740391,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "2thfxolpbnVpcaGobnJkM",
          "type": "text"
        },
        {
          "id": "eLKmiAim1bewL4zmCSs7z",
          "type": "arrow"
        }
      ],
      "updated": 1755272476952,
      "link": null,
      "locked": false
    },
    {
      "id": "2thfxolpbnVpcaGobnJkM",
      "type": "text",
      "x": 14979.849057453957,
      "y": -3352.878326938844,
      "width": 138.59994506835938,
      "height": 175,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGh",
      "roundness": null,
      "seed": 2122532359,
      "version": 1815,
      "versionNonce": 2065366825,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272434661,
      "link": null,
      "locked": false,
      "text": "libros\nmanuales\nguias\narticulos\npappers",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "Mz58K5IVqy3pxuR5516vx",
      "originalText": "libros\nmanuales\nguias\narticulos\npappers",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "aLqj9QodOLYnUAPZkXu9P",
      "type": "rectangle",
      "x": 14950.649029988137,
      "y": -3149.190826938844,
      "width": 197.00000000000003,
      "height": 115,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGi",
      "roundness": {
        "type": 3
      },
      "seed": 1717234983,
      "version": 1499,
      "versionNonce": 746259817,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "E1ozBu62vBXynsoMpog6o",
          "type": "text"
        },
        {
          "id": "_QmHTMut7rLoalO1zpKj4",
          "type": "arrow"
        }
      ],
      "updated": 1755272480513,
      "link": null,
      "locked": false
    },
    {
      "id": "E1ozBu62vBXynsoMpog6o",
      "type": "text",
      "x": 14987.5490544022,
      "y": -3144.190826938844,
      "width": 123.199951171875,
      "height": 105,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGj",
      "roundness": null,
      "seed": 1055961159,
      "version": 1892,
      "versionNonce": 1000550921,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272434661,
      "link": null,
      "locked": false,
      "text": "notas\nmensajes\nobserv.",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "aLqj9QodOLYnUAPZkXu9P",
      "originalText": "notas\nmensajes\nobserv.",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "YvV5VzAbVOjKP1uUopGWu",
      "type": "arrow",
      "x": 14806.974085197644,
      "y": -3749.9156853806358,
      "width": 138.6749447904931,
      "height": 176.62514155820827,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGk",
      "roundness": null,
      "seed": 595975847,
      "version": 24,
      "versionNonce": 1976917607,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272469892,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          69.33747239524564,
          0
        ],
        [
          69.33747239524564,
          -176.62514155820827
        ],
        [
          138.6749447904931,
          -176.62514155820827
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "ofe1cVeHZPT62wPr6Hqxt",
        "focus": -0.0027972027971858177,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4986013986013998
        ]
      },
      "endBinding": {
        "elementId": "x4KuJN9PbG60JdxO96c5s",
        "focus": 1.0507614213197747,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49945945945945996
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "Hqs3torA7X3uLbdor_5UR",
      "type": "arrow",
      "x": 14806.974085197644,
      "y": -3599.1344353806358,
      "width": 138.6749447904931,
      "height": 83.71889155820827,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGl",
      "roundness": null,
      "seed": 1102434633,
      "version": 19,
      "versionNonce": 343297575,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272472052,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          69.33747239524564,
          0
        ],
        [
          69.33747239524564,
          -83.71889155820827
        ],
        [
          138.6749447904931,
          -83.71889155820827
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "QveUNEfJ1OTd95eC1gm4k",
        "focus": -0.0027972027971858177,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4986013986013998
        ]
      },
      "endBinding": {
        "elementId": "_P6PZeFPWhNlTpDUUoA6p",
        "focus": 0.0007843137254968928,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49960784313725526
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "5t5jhPgLIOivY4kJ-_-3q",
      "type": "arrow",
      "x": 14806.974085197644,
      "y": -3448.3531853806358,
      "width": 138.67494479049492,
      "height": 8.31264155820827,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGm",
      "roundness": null,
      "seed": 1905175945,
      "version": 26,
      "versionNonce": 2041641129,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272474441,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          69.33747239524564,
          0
        ],
        [
          69.33747239524564,
          -8.31264155820827
        ],
        [
          138.67494479049492,
          -8.31264155820827
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "DAaU7vM4sCKDBMSvhUk7g",
        "focus": -0.0027972027971858177,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4986013986013998
        ]
      },
      "endBinding": {
        "elementId": "O77tWduP7RHoQFW5iviPY",
        "focus": 0.0013333333333178006,
        "gap": 5,
        "fixedPoint": [
          -0.02538071065988924,
          0.49933333333333396
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "eLKmiAim1bewL4zmCSs7z",
      "type": "arrow",
      "x": 14806.974085197644,
      "y": -3305.8845773806356,
      "width": 138.6749447904931,
      "height": 40.4062504417916,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGn",
      "roundness": null,
      "seed": 631821479,
      "version": 41,
      "versionNonce": 1105221639,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272530314,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          69.33747239524564,
          0
        ],
        [
          69.33747239524564,
          40.4062504417916
        ],
        [
          138.6749447904931,
          40.4062504417916
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "rndbErvq1x9Zm4GV8GR93",
        "focus": -0.0027972027971872983,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4986013986013998
        ]
      },
      "endBinding": {
        "elementId": "Mz58K5IVqy3pxuR5516vx",
        "focus": 0.0010810810810686765,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.49945945945945996
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "_QmHTMut7rLoalO1zpKj4",
      "type": "arrow",
      "x": 14806.974085197644,
      "y": -3163.4159693806355,
      "width": 138.67494479049492,
      "height": 71.62514244179147,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGo",
      "roundness": null,
      "seed": 1876299177,
      "version": 31,
      "versionNonce": 965498055,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755272482705,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          69.33747239524564,
          0
        ],
        [
          69.33747239524564,
          71.62514244179147
        ],
        [
          138.67494479049492,
          71.62514244179147
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "gTrl2Z5RKfjle-p7UvpKe",
        "focus": -0.0027972027971858177,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4986013986013998
        ]
      },
      "endBinding": {
        "elementId": "aLqj9QodOLYnUAPZkXu9P",
        "focus": 0.001739130434788576,
        "gap": 4.999999999998181,
        "fixedPoint": [
          -0.02538071065988924,
          0.4991304347826095
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "KO_ap88tIuzROAjJ7j_wa",
      "type": "rectangle",
      "x": 11907.111161773846,
      "y": -1522.6963403388468,
      "width": 287.00000009524416,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#be4bdb",
      "fillStyle": "solid",
      "strokeWidth": 4,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGp",
      "roundness": {
        "type": 3
      },
      "seed": 859634441,
      "version": 1167,
      "versionNonce": 654691241,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "ZwgGS7aP9BMUhrL2KnOZZ",
          "type": "text"
        },
        {
          "id": "KoyOwA04KDd12-h6Aa4Ow",
          "type": "arrow"
        },
        {
          "id": "8iGX4lRdjcWJUiwMseOs3",
          "type": "arrow"
        }
      ],
      "updated": 1755273901775,
      "link": null,
      "locked": false
    },
    {
      "id": "ZwgGS7aP9BMUhrL2KnOZZ",
      "type": "text",
      "x": 12001.111192339047,
      "y": -1495.1963403388468,
      "width": 98.99993896484375,
      "height": 45,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGq",
      "roundness": null,
      "seed": 970633705,
      "version": 1162,
      "versionNonce": 696282761,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755273901775,
      "link": null,
      "locked": false,
      "text": "/log/",
      "fontSize": 36,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "KO_ap88tIuzROAjJ7j_wa",
      "originalText": "/log/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "TTOfNchA6RasRgEW_IjcR",
      "type": "rectangle",
      "x": 12398.728549440519,
      "y": -1594.2476152721788,
      "width": 327.49713342857115,
      "height": 79.00000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGr",
      "roundness": {
        "type": 3
      },
      "seed": 1432259785,
      "version": 1122,
      "versionNonce": 1617145545,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "n5GXVp7FihwOhCQ7b5We4",
          "type": "text"
        },
        {
          "id": "KoyOwA04KDd12-h6Aa4Ow",
          "type": "arrow"
        },
        {
          "id": "dMM7SFcnf431Md47Vwp6o",
          "type": "arrow"
        }
      ],
      "updated": 1755274082871,
      "link": null,
      "locked": false
    },
    {
      "id": "n5GXVp7FihwOhCQ7b5We4",
      "type": "text",
      "x": 12477.777149724141,
      "y": -1572.2476152721788,
      "width": 169.39993286132812,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGs",
      "roundness": null,
      "seed": 1298402217,
      "version": 1128,
      "versionNonce": 1866752521,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755273901776,
      "link": null,
      "locked": false,
      "text": "/changelog/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "TTOfNchA6RasRgEW_IjcR",
      "originalText": "/changelog/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "hVdRFZp6qE7jjr7XdiTvi",
      "type": "rectangle",
      "x": 12398.728549440519,
      "y": -1462.884039272179,
      "width": 327.4971334285729,
      "height": 79.00000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#da77f2",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGt",
      "roundness": {
        "type": 3
      },
      "seed": 1779871369,
      "version": 1160,
      "versionNonce": 782711049,
      "isDeleted": false,
      "boundElements": [
        {
          "id": "LaWhgjA8LjQaUWRyFMj6n",
          "type": "text"
        },
        {
          "id": "8iGX4lRdjcWJUiwMseOs3",
          "type": "arrow"
        },
        {
          "id": "kWRdUlqHDBFHkEJi_CQ4Z",
          "type": "arrow"
        }
      ],
      "updated": 1755274090890,
      "link": null,
      "locked": false
    },
    {
      "id": "LaWhgjA8LjQaUWRyFMj6n",
      "type": "text",
      "x": 12523.977131413594,
      "y": -1440.884039272179,
      "width": 76.99996948242188,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGu",
      "roundness": null,
      "seed": 1647441257,
      "version": 1204,
      "versionNonce": 796432551,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755274087175,
      "link": null,
      "locked": false,
      "text": "/qms/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "hVdRFZp6qE7jjr7XdiTvi",
      "originalText": "/qms/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "KoyOwA04KDd12-h6Aa4Ow",
      "type": "arrow",
      "x": 12199.11116186909,
      "y": -1472.7963403388467,
      "width": 194.6173875714303,
      "height": 82.05127493333202,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGv",
      "roundness": null,
      "seed": 151085129,
      "version": 219,
      "versionNonce": 163118185,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755273901776,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          97.30869378571515,
          0
        ],
        [
          97.30869378571515,
          -82.05127493333202
        ],
        [
          194.6173875714303,
          -82.05127493333202
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "KO_ap88tIuzROAjJ7j_wa",
        "focus": -0.0019999999999963654,
        "gap": 5,
        "fixedPoint": [
          1.0174216027816747,
          0.4990000000000009
        ]
      },
      "endBinding": {
        "elementId": "TTOfNchA6RasRgEW_IjcR",
        "focus": 0.0025316455696209094,
        "gap": 5,
        "fixedPoint": [
          -0.015267309205589451,
          0.4987341772151909
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "8iGX4lRdjcWJUiwMseOs3",
      "type": "arrow",
      "x": 12199.11116186909,
      "y": -1472.7963403388467,
      "width": 194.61738757142848,
      "height": 49.312301066667715,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGw",
      "roundness": null,
      "seed": 1012952873,
      "version": 229,
      "versionNonce": 2118970311,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755274087179,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          97.30869378571333,
          0
        ],
        [
          97.30869378571333,
          49.312301066667715
        ],
        [
          194.61738757142848,
          49.312301066667715
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "KO_ap88tIuzROAjJ7j_wa",
        "focus": -0.0019999999999963654,
        "gap": 5,
        "fixedPoint": [
          1.0174216027816747,
          0.4990000000000009
        ]
      },
      "endBinding": {
        "elementId": "hVdRFZp6qE7jjr7XdiTvi",
        "focus": 0.0025316455696208964,
        "gap": 5,
        "fixedPoint": [
          -0.015267309205594923,
          0.4987341772151909
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "o3aiqqw4VekQd5VyeefmS",
      "type": "rectangle",
      "x": 12862.23532988,
      "y": -1625.2476146055117,
      "width": 189.49999954960194,
      "height": 110,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGx",
      "roundness": {
        "type": 3
      },
      "seed": 1184298311,
      "version": 1174,
      "versionNonce": 1807437961,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "ZTPjvx4y48UO6FWjbYBOA"
        },
        {
          "id": "dMM7SFcnf431Md47Vwp6o",
          "type": "arrow"
        }
      ],
      "updated": 1755274082874,
      "link": null,
      "locked": false
    },
    {
      "id": "ZTPjvx4y48UO6FWjbYBOA",
      "type": "text",
      "x": 12885.485329654803,
      "y": -1620.2476146055117,
      "width": 143,
      "height": 100,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#b2f2bb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGy",
      "roundness": null,
      "seed": 649507943,
      "version": 1565,
      "versionNonce": 1570342377,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755274076995,
      "link": null,
      "locked": false,
      "text": "changelog\nlogbook\nauditlog\nvalidationlog",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "o3aiqqw4VekQd5VyeefmS",
      "originalText": "changelog\nlogbook\nauditlog\nvalidationlog",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "n1Rm3S0ALKrkAV76GFvNH",
      "type": "rectangle",
      "x": 12862.235330880001,
      "y": -1462.884038605512,
      "width": 189.49999911999842,
      "height": 109.9999996055119,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#ffec99",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bGz",
      "roundness": {
        "type": 3
      },
      "seed": 1725009799,
      "version": 1300,
      "versionNonce": 1305561801,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "-xRMfdxK6OVgYbPlxIDG_"
        },
        {
          "id": "kWRdUlqHDBFHkEJi_CQ4Z",
          "type": "arrow"
        }
      ],
      "updated": 1755274090893,
      "link": null,
      "locked": false
    },
    {
      "id": "-xRMfdxK6OVgYbPlxIDG_",
      "type": "text",
      "x": 12912.98533044,
      "y": -1445.3840388027559,
      "width": 88,
      "height": 75,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#b2f2bb",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bH0",
      "roundness": null,
      "seed": 287573671,
      "version": 1700,
      "versionNonce": 1974501193,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755274072679,
      "link": null,
      "locked": false,
      "text": "trace\ncrossref\nversion",
      "fontSize": 20,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "n1Rm3S0ALKrkAV76GFvNH",
      "originalText": "trace\ncrossref\nversion",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "dMM7SFcnf431Md47Vwp6o",
      "type": "arrow",
      "x": 12731.22568286909,
      "y": -1554.8476152721787,
      "width": 126.00964701091107,
      "height": 15.49999933333288,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bH1",
      "roundness": null,
      "seed": 1182654377,
      "version": 28,
      "versionNonce": 1064627625,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755274082874,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          63.004823505454624,
          0
        ],
        [
          63.004823505454624,
          -15.49999933333288
        ],
        [
          126.00964701091107,
          -15.49999933333288
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "TTOfNchA6RasRgEW_IjcR",
        "focus": -0.002531645569610412,
        "gap": 5,
        "fixedPoint": [
          1.0152673092055946,
          0.4987341772151909
        ]
      },
      "endBinding": {
        "elementId": "o3aiqqw4VekQd5VyeefmS",
        "focus": 0.0018181818181609451,
        "gap": 5,
        "fixedPoint": [
          -0.026385224337117964,
          0.4990909090909099
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "kWRdUlqHDBFHkEJi_CQ4Z",
      "type": "arrow",
      "x": 12731.22568286909,
      "y": -1429.7324936055122,
      "width": 126.00964801091322,
      "height": 21.748454802756214,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bH3",
      "roundness": null,
      "seed": 224126471,
      "version": 29,
      "versionNonce": 156053481,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755274090893,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          63.00482400545661,
          0
        ],
        [
          63.00482400545661,
          21.748454802756214
        ],
        [
          126.00964801091322,
          21.748454802756214
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "hVdRFZp6qE7jjr7XdiTvi",
        "focus": -0.16072036286918773,
        "gap": 4.999999999998181,
        "fixedPoint": [
          1.0152673092055893,
          0.4196398185654029
        ]
      },
      "endBinding": {
        "elementId": "n1Rm3S0ALKrkAV76GFvNH",
        "focus": 0.001818181824683307,
        "gap": 5,
        "fixedPoint": [
          -0.026385224396924645,
          0.49909090908764864
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "cwJlxwEO9TPH1BG_fWeP0",
      "type": "rectangle",
      "x": 5659.137894321461,
      "y": -686.4742459388432,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bH4",
      "roundness": {
        "type": 3
      },
      "seed": 1489100775,
      "version": 1059,
      "versionNonce": 803081031,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "aN9GzpA9d7ygOvc_7OFbl"
        },
        {
          "id": "oMwnOZmsUbebm9H7u8MRY",
          "type": "arrow"
        },
        {
          "id": "1xpbtKEfZolz9k4A9LUEF",
          "type": "arrow"
        },
        {
          "id": "mUuf5SPelC3-ug9Knf3Pk",
          "type": "arrow"
        }
      ],
      "updated": 1755275183347,
      "link": null,
      "locked": false
    },
    {
      "id": "aN9GzpA9d7ygOvc_7OFbl",
      "type": "text",
      "x": 5711.437912632008,
      "y": -668.2242459388432,
      "width": 92.39996337890625,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bH5",
      "roundness": null,
      "seed": 359353095,
      "version": 1067,
      "versionNonce": 1111547721,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755275171598,
      "link": null,
      "locked": false,
      "text": "/data/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "cwJlxwEO9TPH1BG_fWeP0",
      "originalText": "/data/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "oMwnOZmsUbebm9H7u8MRY",
      "type": "arrow",
      "x": 5861.13789432146,
      "y": -650.8242459388432,
      "width": 218.2083339444098,
      "height": 0.06981133679755658,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bH6",
      "roundness": null,
      "seed": 211158247,
      "version": 41,
      "versionNonce": 678171721,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755275177158,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          218.2083339444098,
          -0.06981133679755658
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "cwJlxwEO9TPH1BG_fWeP0",
        "focus": -0.0018693248428746563,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598938,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "DI1gRCNytTrWzvPu0MWaz",
        "focus": 0.0037201537114124822,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "1xpbtKEfZolz9k4A9LUEF",
      "type": "arrow",
      "x": 5861.13789432146,
      "y": -650.8242459388432,
      "width": 224.8750009444093,
      "height": 233.7219446632024,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bH7",
      "roundness": null,
      "seed": 1305914119,
      "version": 47,
      "versionNonce": 1466490057,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755275180722,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          112.4375004722051,
          0
        ],
        [
          112.4375004722051,
          233.7219446632024
        ],
        [
          224.8750009444093,
          233.7219446632024
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "cwJlxwEO9TPH1BG_fWeP0",
        "focus": -0.002797202797194346,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598938,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "DKq8K1v-u6vzlj1uLkzVV",
        "focus": -1.0507614213197887,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659898473,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "mUuf5SPelC3-ug9Knf3Pk",
      "type": "arrow",
      "x": 5861.13789432146,
      "y": -650.8242459388432,
      "width": 221.5416679444097,
      "height": 479.86311966320244,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bH8",
      "roundness": null,
      "seed": 74369671,
      "version": 42,
      "versionNonce": 1118505575,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755275183350,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          110.77083397220485,
          0
        ],
        [
          110.77083397220485,
          479.86311966320244
        ],
        [
          221.5416679444097,
          479.86311966320244
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "cwJlxwEO9TPH1BG_fWeP0",
        "focus": -0.002797202797194346,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598938,
          0.4986013986013982
        ]
      },
      "endBinding": {
        "elementId": "xhS4iD2NXK1UX5AMYbNVT",
        "focus": -1.0507614213197878,
        "gap": 5,
        "fixedPoint": [
          -0.025380710659893856,
          0.49860139860139857
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "rF-IY2lynW51IlFAGTZRh",
      "type": "rectangle",
      "x": 6085.596229004008,
      "y": 88.09464406115679,
      "width": 254.49999996824198,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bH9",
      "roundness": {
        "type": 3
      },
      "seed": 2919913,
      "version": 1457,
      "versionNonce": 274508871,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "prqvhhhfFGqqHGMdY6Ew2"
        },
        {
          "id": "V1MpiR8ElC-sfKhs6SnXz",
          "type": "arrow"
        },
        {
          "id": "oSeNhLWRqQtRfAI5cVr2o",
          "type": "arrow"
        }
      ],
      "updated": 1755276181128,
      "link": null,
      "locked": false
    },
    {
      "id": "prqvhhhfFGqqHGMdY6Ew2",
      "type": "text",
      "x": 6174.346244246918,
      "y": 106.3446440611568,
      "width": 76.99996948242188,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHA",
      "roundness": null,
      "seed": 756345033,
      "version": 1560,
      "versionNonce": 1827763465,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276137988,
      "link": null,
      "locked": false,
      "text": "/mtx/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "rF-IY2lynW51IlFAGTZRh",
      "originalText": "/mtx/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "wx4BYBkEFNYsR7HPgZeYg",
      "type": "rectangle",
      "x": 6085.596229004006,
      "y": 203.8446440611568,
      "width": 254.49999996824198,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHB",
      "roundness": {
        "type": 3
      },
      "seed": 1190263143,
      "version": 1464,
      "versionNonce": 92994313,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "llUCn7q-c23AGHuqVcJZP"
        },
        {
          "id": "yixTMC8SGPdncr21-kCQX",
          "type": "arrow"
        }
      ],
      "updated": 1755276163335,
      "link": null,
      "locked": false
    },
    {
      "id": "llUCn7q-c23AGHuqVcJZP",
      "type": "text",
      "x": 6166.646247298674,
      "y": 222.0946440611568,
      "width": 92.39996337890625,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHC",
      "roundness": null,
      "seed": 1230779527,
      "version": 1584,
      "versionNonce": 1941735113,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276137988,
      "link": null,
      "locked": false,
      "text": "/docs/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "wx4BYBkEFNYsR7HPgZeYg",
      "originalText": "/docs/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "TxQyyX6IwztGIEI5x3bs9",
      "type": "rectangle",
      "x": 6087.679561670673,
      "y": 319.5946440611568,
      "width": 254.49999996824198,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHD",
      "roundness": {
        "type": 3
      },
      "seed": 1876042791,
      "version": 1486,
      "versionNonce": 15036775,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "jIFhqpAP-xrqr6k85SW_R"
        },
        {
          "id": "ks8unQw4hDVkZQAYuSx4o",
          "type": "arrow"
        }
      ],
      "updated": 1755276165394,
      "link": null,
      "locked": false
    },
    {
      "id": "jIFhqpAP-xrqr6k85SW_R",
      "type": "text",
      "x": 6122.529598275888,
      "y": 337.8446440611568,
      "width": 184.7999267578125,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHE",
      "roundness": null,
      "seed": 577308487,
      "version": 1617,
      "versionNonce": 1891510409,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276137988,
      "link": null,
      "locked": false,
      "text": "/workspaces/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "TxQyyX6IwztGIEI5x3bs9",
      "originalText": "/workspaces/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "iUv-R2Q_sYta_u00DUUG1",
      "type": "rectangle",
      "x": 6085.596228670674,
      "y": 435.3446440611568,
      "width": 254.49999996824198,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHF",
      "roundness": {
        "type": 3
      },
      "seed": 2101793929,
      "version": 1501,
      "versionNonce": 695769225,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "FA_Ikr9jKA93RmzegIVZI"
        },
        {
          "id": "qEl4DCeOiBQ4CXVlSoexj",
          "type": "arrow"
        }
      ],
      "updated": 1755276168312,
      "link": null,
      "locked": false
    },
    {
      "id": "FA_Ikr9jKA93RmzegIVZI",
      "type": "text",
      "x": 6097.346274431162,
      "y": 453.5946440611568,
      "width": 230.99990844726562,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHG",
      "roundness": null,
      "seed": 678255465,
      "version": 1646,
      "versionNonce": 328358473,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276137988,
      "link": null,
      "locked": false,
      "text": "/platform_arch/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "iUv-R2Q_sYta_u00DUUG1",
      "originalText": "/platform_arch/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "9hDXto_C_bdgoMrOwbSay",
      "type": "rectangle",
      "x": 6082.679562337339,
      "y": 551.0946443944899,
      "width": 254.49999996824198,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#9775fa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHH",
      "roundness": {
        "type": 3
      },
      "seed": 1970653129,
      "version": 1517,
      "versionNonce": 1231204359,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "0DWfTyUuQie1T6gCzIg5z"
        },
        {
          "id": "tr37tYYfDvLena3z-cHty",
          "type": "arrow"
        }
      ],
      "updated": 1755276171712,
      "link": null,
      "locked": false
    },
    {
      "id": "0DWfTyUuQie1T6gCzIg5z",
      "type": "text",
      "x": 6132.929592839038,
      "y": 569.3446443944899,
      "width": 153.99993896484375,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHI",
      "roundness": null,
      "seed": 2094786217,
      "version": 1671,
      "versionNonce": 1423252489,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276137988,
      "link": null,
      "locked": false,
      "text": "/ai_tools/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "9hDXto_C_bdgoMrOwbSay",
      "originalText": "/ai_tools/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "V1MpiR8ElC-sfKhs6SnXz",
      "type": "arrow",
      "x": 5911.13789426587,
      "y": 158.55714372435924,
      "width": 169.45833473813673,
      "height": 34.81249966320243,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHK",
      "roundness": null,
      "seed": 2130529129,
      "version": 35,
      "versionNonce": 233437959,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276161388,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          84.72916736906882,
          0
        ],
        [
          84.72916736906882,
          -34.81249966320243
        ],
        [
          169.45833473813673,
          -34.81249966320243
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "mX4n5OWptUg4xgfls2OW5",
        "focus": -0.0024999999999944554,
        "gap": 5,
        "fixedPoint": [
          1.020242914979757,
          0.4987500000000001
        ]
      },
      "endBinding": {
        "elementId": "rF-IY2lynW51IlFAGTZRh",
        "focus": 0.0027972027972001105,
        "gap": 5,
        "fixedPoint": [
          -0.01964636542485202,
          0.4986013986013988
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "yixTMC8SGPdncr21-kCQX",
      "type": "arrow",
      "x": 5911.13789426587,
      "y": 158.55714372435924,
      "width": 169.4583347381349,
      "height": 80.93750033679757,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHL",
      "roundness": null,
      "seed": 124188329,
      "version": 36,
      "versionNonce": 1351084073,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276163335,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          84.72916736906791,
          0
        ],
        [
          84.72916736906791,
          80.93750033679757
        ],
        [
          169.4583347381349,
          80.93750033679757
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "mX4n5OWptUg4xgfls2OW5",
        "focus": -0.0024999999999944554,
        "gap": 5,
        "fixedPoint": [
          1.020242914979757,
          0.4987500000000001
        ]
      },
      "endBinding": {
        "elementId": "wx4BYBkEFNYsR7HPgZeYg",
        "focus": 0.0027972027972001105,
        "gap": 5,
        "fixedPoint": [
          -0.01964636542485202,
          0.49860139860139857
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "ks8unQw4hDVkZQAYuSx4o",
      "type": "arrow",
      "x": 5911.13789426587,
      "y": 158.55714372435924,
      "width": 171.54166740480287,
      "height": 196.68750033679757,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHM",
      "roundness": null,
      "seed": 723680551,
      "version": 30,
      "versionNonce": 1192841799,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276165394,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          85.77083370240143,
          0
        ],
        [
          85.77083370240143,
          196.68750033679757
        ],
        [
          171.54166740480287,
          196.68750033679757
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "mX4n5OWptUg4xgfls2OW5",
        "focus": -0.0024999999999944554,
        "gap": 5,
        "fixedPoint": [
          1.020242914979757,
          0.4987500000000001
        ]
      },
      "endBinding": {
        "elementId": "TxQyyX6IwztGIEI5x3bs9",
        "focus": -1.0392927308496975,
        "gap": 5,
        "fixedPoint": [
          -0.019646365424848447,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "qEl4DCeOiBQ4CXVlSoexj",
      "type": "arrow",
      "x": 5911.13789426587,
      "y": 158.55714372435924,
      "width": 169.45833440480328,
      "height": 312.4375003367976,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHN",
      "roundness": null,
      "seed": 183731049,
      "version": 56,
      "versionNonce": 2101032361,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276168311,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          84.7291672024021,
          0
        ],
        [
          84.7291672024021,
          312.4375003367976
        ],
        [
          169.45833440480328,
          312.4375003367976
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "mX4n5OWptUg4xgfls2OW5",
        "focus": -0.0024999999999944554,
        "gap": 5,
        "fixedPoint": [
          1.020242914979757,
          0.4987500000000001
        ]
      },
      "endBinding": {
        "elementId": "iUv-R2Q_sYta_u00DUUG1",
        "focus": -1.0392927308496904,
        "gap": 5,
        "fixedPoint": [
          -0.019646365424848447,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "tr37tYYfDvLena3z-cHty",
      "type": "arrow",
      "x": 5911.13789426587,
      "y": 158.55714372435924,
      "width": 166.54166807146885,
      "height": 428.1875006701307,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHO",
      "roundness": null,
      "seed": 1795434407,
      "version": 48,
      "versionNonce": 687989991,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276171712,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          83.27083403573488,
          0
        ],
        [
          83.27083403573488,
          428.1875006701307
        ],
        [
          166.54166807146885,
          428.1875006701307
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "mX4n5OWptUg4xgfls2OW5",
        "focus": -0.0024999999999944554,
        "gap": 5,
        "fixedPoint": [
          1.020242914979757,
          0.4987500000000001
        ]
      },
      "endBinding": {
        "elementId": "9hDXto_C_bdgoMrOwbSay",
        "focus": -1.0392927308496909,
        "gap": 5,
        "fixedPoint": [
          -0.019646365424848447,
          0.4986013986013982
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "oSeNhLWRqQtRfAI5cVr2o",
      "type": "arrow",
      "x": 6345.096228972249,
      "y": 123.7446440611568,
      "width": 156.12500037695372,
      "height": 3.298711277466282e-7,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHP",
      "roundness": null,
      "seed": 1954388551,
      "version": 66,
      "versionNonce": 2014220231,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276188893,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          156.12500037695372,
          3.298711277466282e-7
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "rF-IY2lynW51IlFAGTZRh",
        "focus": -0.0027972027972001105,
        "gap": 4.9999999999990905,
        "fixedPoint": [
          1.019646365424846,
          0.4986013986013988
        ]
      },
      "endBinding": {
        "elementId": "fij6ByE7PgVouu3MPAAnq",
        "focus": 0.0010810810810792753,
        "gap": 4.9999999999990905,
        "fixedPoint": [
          -0.025380710704883718,
          0.49945945945945946
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "LNA1H7pcyyvqhpYKF8y1J",
      "type": "rectangle",
      "x": 5282.679559228206,
      "y": 123.74464447536312,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHQ",
      "roundness": {
        "type": 3
      },
      "seed": 704271655,
      "version": 1134,
      "versionNonce": 1624264105,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "Qcbbs6mpqyYRinbMJ70fB"
        },
        {
          "id": "RcFvk2idPKqKvG7kNJMLf",
          "type": "arrow"
        }
      ],
      "updated": 1755276217052,
      "link": null,
      "locked": false
    },
    {
      "id": "Qcbbs6mpqyYRinbMJ70fB",
      "type": "text",
      "x": 5334.979577538753,
      "y": 141.9946444753631,
      "width": 92.39996337890625,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHR",
      "roundness": null,
      "seed": 711137351,
      "version": 1141,
      "versionNonce": 178958473,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276217052,
      "link": null,
      "locked": false,
      "text": "/data/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "LNA1H7pcyyvqhpYKF8y1J",
      "originalText": "/data/",
      "autoResize": true,
      "lineHeight": 1.25
    },
    {
      "id": "RcFvk2idPKqKvG7kNJMLf",
      "type": "arrow",
      "x": 5484.679559228206,
      "y": 159.39464447536312,
      "width": 169.45833503766426,
      "height": 0.837500751003887,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#fab005",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 0,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHS",
      "roundness": null,
      "seed": 538223817,
      "version": 47,
      "versionNonce": 351647593,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755276217052,
      "link": null,
      "locked": false,
      "points": [
        [
          0,
          0
        ],
        [
          169.45833503766426,
          -0.837500751003887
        ]
      ],
      "lastCommittedPoint": null,
      "startBinding": {
        "elementId": "LNA1H7pcyyvqhpYKF8y1J",
        "focus": -0.0027972027972025053,
        "gap": 5,
        "fixedPoint": [
          1.0253807106598982,
          0.4986013986013988
        ]
      },
      "endBinding": {
        "elementId": "mX4n5OWptUg4xgfls2OW5",
        "focus": 0.0024999999999944554,
        "gap": 5,
        "fixedPoint": [
          -0.020242914979757082,
          0.4987500000000001
        ]
      },
      "startArrowhead": null,
      "endArrowhead": "arrow",
      "elbowed": true,
      "fixedSegments": null,
      "startIsSpecial": null,
      "endIsSpecial": null
    },
    {
      "id": "-P5Zj5N8gLABPyrrfVQzT",
      "type": "rectangle",
      "x": 5275.867060990351,
      "y": 1050.6946442367084,
      "width": 197.00000000000003,
      "height": 71.50000000000001,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "#eebefa",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHT",
      "roundness": {
        "type": 3
      },
      "seed": 1134599047,
      "version": 1202,
      "versionNonce": 1145258761,
      "isDeleted": false,
      "boundElements": [
        {
          "type": "text",
          "id": "b95padYfDlpDZzbukBgXQ"
        }
      ],
      "updated": 1755279665755,
      "link": null,
      "locked": false
    },
    {
      "id": "b95padYfDlpDZzbukBgXQ",
      "type": "text",
      "x": 5328.167079300898,
      "y": 1068.9446442367084,
      "width": 92.39996337890625,
      "height": 35,
      "angle": 0,
      "strokeColor": "#1e1e1e",
      "backgroundColor": "transparent",
      "fillStyle": "solid",
      "strokeWidth": 2,
      "strokeStyle": "solid",
      "roughness": 1,
      "opacity": 100,
      "groupIds": [],
      "frameId": null,
      "index": "bHU",
      "roundness": null,
      "seed": 405901991,
      "version": 1209,
      "versionNonce": 1658321385,
      "isDeleted": false,
      "boundElements": [],
      "updated": 1755279665755,
      "link": null,
      "locked": false,
      "text": "/data/",
      "fontSize": 28,
      "fontFamily": 8,
      "textAlign": "center",
      "verticalAlign": "middle",
      "containerId": "-P5Zj5N8gLABPyrrfVQzT",
      "originalText": "/data/",
      "autoResize": true,
      "lineHeight": 1.25
    }
  ],
  "appState": {
    "gridSize": 20,
    "gridStep": 5,
    "gridModeEnabled": false,
    "viewBackgroundColor": "#fdf8f6",
    "lockedMultiSelections": {}
  },
  "files": {}
}
```

