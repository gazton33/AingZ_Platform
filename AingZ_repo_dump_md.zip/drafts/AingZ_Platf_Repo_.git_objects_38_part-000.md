---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/38
part_index: 0
files_included: 7
size_bytes_sum: 6414
created_at: 2025-08-31T21:08:15.571955+00:00
integrity:
  sha256_concat: 70a0b04da8e6f73b162abc2fac6ee39e631ae53f599f149d5a0847bbd77e8950
---

## AingZ_Platf_Repo/.git/objects/38/056dce9dd3918329e4da44c1da0c155e8c1037
meta: {size:425, lines:0, sha256:"ead2f5759b6752d525d0fe8fb64faf54a0547c2a299d9d0407db17a173c7103d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/38/2dbcf8a8253dfd9f6248a90d7e538cc7e86da1
meta: {size:2423, lines:0, sha256:"11ebb859917a986bee6371ed573eb8253417b33f258621f3ada186c195b1a9a3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/38/43d2fb9cf3c3a0d134c6304dd4bf51c073ac22
meta: {size:266, lines:0, sha256:"485ccb27fa7b981423e92ebf9262448cc32471bf6285da18dd349133c35dd631", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/38/654209fe22c7026d88e997ad02bdb873ef2c27
meta: {size:153, lines:2, sha256:"b5662b270e8fc6147f528871439ff101b8bcdf5bf899725f02d02d73bd949a46", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎ[
Â0@Q¿³lÀ×LRq+ÉØ#!"tõvþ^8p¹Õºí,^FÑ#y±3Ä`	¢âÙKD°A½©Ëkhò(`¨MÆ0S~Ê	K:H3E«è3ÖÖõBÇh/ïõmÙ×öþX*mûÄ­ÞµbL8'}5ÞuÖsqÈ_X9õrC
```

## AingZ_Platf_Repo/.git/objects/38/9fe3a209358d027b62a0d84b75d8606e49dd6e
meta: {size:2071, lines:0, sha256:"856a04e58443bf88b509cb19223a9ba1f582a1dbd64dc051b9bcccdb65cdb41e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/38/b19ecf0d69a44ac88fc45f42be6b7e7ffd3358
meta: {size:857, lines:0, sha256:"6312e7a973941cb6f94192c53a069cffe8bb66edc786d766db3397dcae274cbc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/38/c8120a15aed83867e8b48f666dc80a59167031
meta: {size:219, lines:0, sha256:"01bd5fdb7fefce5209135d981647582ddef5c87d8ae3d45bea6d3fdee04be7d8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

