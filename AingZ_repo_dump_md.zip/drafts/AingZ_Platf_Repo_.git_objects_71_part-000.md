---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/71
part_index: 0
files_included: 4
size_bytes_sum: 3044
created_at: 2025-08-31T21:08:15.623808+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/71/3b184ea6f77cff92ff56df5139e0f6f400f500
meta: {size:173, lines:0, sha256:"08e5931845fad73452eb4e39a64ad0be9f9d124665b19fdf791d6c385cbfaa7c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/71/6d7e3167473f4449ef03f37b2c1b02cb4fc9f6
meta: {size:1717, lines:0, sha256:"c679c35ca2cf4f25ab5885c3b5fb1e2b0b6eeb27cb0ab37eb35d9ae2bb0c60d2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/71/7bd9445f3de038759c4ba0eff6f65fc88c4f3e
meta: {size:941, lines:0, sha256:"fe85f1f359cd20a23d6197797d1d1f45f0edc963e802e2f53c8eed2b1feb2c9a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/71/9e2122a4f9d79fd9be5f363e85c5cbd0d901db
meta: {size:213, lines:0, sha256:"a8cfadd028684e158502e9183200b13f52a71d6b850f127e9c5c607c8152fd4f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

