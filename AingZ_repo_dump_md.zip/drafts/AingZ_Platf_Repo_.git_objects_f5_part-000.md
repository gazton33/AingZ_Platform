---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/f5
part_index: 0
files_included: 3
size_bytes_sum: 984
created_at: 2025-08-31T21:08:15.652259+00:00
integrity:
  sha256_concat: 18c1de803155a49cd5f4ef574d517da45ffb0990e3cb538ed764ae78b863da0e
---

## AingZ_Platf_Repo/.git/objects/f5/15f34913ff6fe4898c8b5c642c21139c1ef98c
meta: {size:86, lines:1, sha256:"a6de11d80755347f8dd84164d4781abe443a4e268a75bf3819a30060890991d3", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU07`040031Q(JMLÉMOÎ/JÏÎ+OÌÏIM,Ê/JÍ/*O/77ÒËMaXçß`¶Óïw²nÙÇÆ$é÷xã%ï
```

## AingZ_Platf_Repo/.git/objects/f5/9fefd31fe20c509b27ffede885853ef78682c4
meta: {size:596, lines:0, sha256:"9787ac5c365658c335b7cda9e922b0d20c8f208cb5d54d315dcae14676172bc8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f5/f953ec0f2394b45361d130343022ab60ccd322
meta: {size:302, lines:0, sha256:"7adbdca13a3c3dfbd7e2b0beb997ceba3b530ef33d0a7f862712057d29497544", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

