---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/e2
part_index: 0
files_included: 11
size_bytes_sum: 9415
created_at: 2025-08-31T21:08:15.650395+00:00
integrity:
  sha256_concat: 76c2ce12cb6f8077412d6ae8f4c615892e865a1f86b5c1b19f46a88a63d204f7
---

## AingZ_Platf_Repo/.git/objects/e2/10dce2e8ce4e235eebe33a82a5bf7c363ee5e4
meta: {size:988, lines:0, sha256:"e0ca79b7aac1d68e862e8b20ed333fcdfbdd0404ba214617013e6c01bbb0e9b3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e2/1ddf5272ee922d4a7f4608e45067d8300f7517
meta: {size:99, lines:0, sha256:"63ecf629c023e085f357f17bfb9bc3790c2138f1b0e029533052605de3905287", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e2/3e40120dd374418d0c278f3b4f4337b02ce860
meta: {size:214, lines:0, sha256:"07f82cbd0cd207168270d05ef81d70aa59cd7ed78ef13b28ab818e71f7fca13f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e2/5e60fa5eb858ec16a91a5de9ba5dbe0d4e3556
meta: {size:123, lines:0, sha256:"14800ebffce168c88d064d9d087a66f50530fb6964efc01da01a174ff12404c5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e2/6174a9bab194da6522d3c44d4b700ac452f025
meta: {size:534, lines:0, sha256:"4dd8e2b5fa1be7acaddb0bf10620e4208060d9b56f270e773628428349832cb3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e2/64caa725d177d28f5a0948f39f15a3a61921b4
meta: {size:158, lines:3, sha256:"468b9331bd2742ba219dff4a8a219a5a89c6f9fbeeb34003397c4c99dcdd89f2", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎQ
0á=÷½À$Mma]¥¶
jTÆ<ý<Ã^øàÏu]çfùÖv"* sAÈ¹|C {$5ï´ËvA)sC%(E=èUÕñ@&mª»ÓÙêFdcwÊ"yªÙ_ãæ¥Ëu}Zç¸½«^MþÂf1å¯­G3?®eG2
```

## AingZ_Platf_Repo/.git/objects/e2/b2d45daa7a4cef23f6ad1e831e3d4d65c18115
meta: {size:1057, lines:0, sha256:"b04afc18d9b48dda1b37521e8d25ce27222dd7a649dca9640cf322d59080a8de", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e2/b3b72d64aa8297fefac70edf93ca428175b4ed
meta: {size:3336, lines:0, sha256:"842924299bd2ec4a7fba6b016764a74ff82a3e9f0c79f9eea7da384d462bde88", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e2/c5e74548a17d4763f512c46504e0640c863f8c
meta: {size:2292, lines:0, sha256:"1069d733ad1da3b787747d0abb5de438a349d117068fe00e3bb2faab6587f4ad", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e2/ec21e9c6004265e4822b611036c8dcc340dcf7
meta: {size:416, lines:0, sha256:"5b9291559f8cd40ff33e00f8734b57fad990789e77c44bc1e32998d110362100", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e2/f2e368ce79c0ea3c4d12d55c6eae1a7454995a
meta: {size:198, lines:0, sha256:"c401cff5b25323584fbbb654f2c5d4a57c0c2011b6fc82061be56e6608250e0c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

