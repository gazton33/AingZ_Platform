---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/d9
part_index: 0
files_included: 11
size_bytes_sum: 9779
created_at: 2025-08-31T21:08:15.649616+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/d9/3e159046c1b14471674a85eb583efb660de085
meta: {size:155, lines:0, sha256:"a389befea603a1eaef51ef8f874c43c9bc3c5b3dd611220eb4492804391bec82", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d9/420ccb18a171e71384af09bfdf5ebbdac8b626
meta: {size:146, lines:0, sha256:"5299a3d3372e980d514197d1a27008f19b9dc049b7bc9ce883f9791e9f04743b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d9/493ed9a2affc94951f06c482c7ec4711d1f73d
meta: {size:1010, lines:0, sha256:"282eb5c0e1afa0e22c73d02b0db1c750ca25ce892f116212532ff86f58a25748", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d9/4fb4fb2667f0e93e28f0ed94d108942ecfe751
meta: {size:684, lines:0, sha256:"d4af400bc2a601226f57650c620d6e4022181746a20ae2d3771f90e806243262", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d9/72b91d9bdd5d1b4ef7741508868f4957fbcbf5
meta: {size:31, lines:0, sha256:"d4cf106afb946108e367c0323df52044976640e7b88e0feb7f58a80c09c1f86f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d9/8af3a7f5782f06280bbadf81c5b972b4303998
meta: {size:1796, lines:0, sha256:"1e3d4958309fd08a620294fe2cc7279ef4210b07dc3520e73cbfcd73c22bb6cc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d9/b49a65bfedf7b93258b0d7d68b3b328516dbc2
meta: {size:2167, lines:0, sha256:"e018ec1262f38841805dbfe2390e887f42f703001eb900974db185360c9f4a95", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d9/b52b04bacc37f764acf564fcb531a2c7ca6a2a
meta: {size:781, lines:0, sha256:"36aea3d68b4f77223ea55638ec7d8269a9d0f481f6f8dcc66ba3afadebde182d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d9/cef636081845a86d885026ddcb26fdad4a3355
meta: {size:2092, lines:0, sha256:"933077f0b51582ef0b2057a713b401fe8f6ec544d36cb3bb6479eabdf173caa8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d9/df57eaf22cb7513fb9b1a0ed5435dd8941b8ff
meta: {size:824, lines:0, sha256:"86f253be542cff00ffa976a2db447bdc4e30dd30936a50157b3e49580f990c4d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d9/e15984cec426fc7fd836e669dc12aa0861e167
meta: {size:93, lines:0, sha256:"6e63e8d559928728f5bd73b6419e0980bd4f360514ee5328e85d8ad0e64bb316", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

