---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/a0
part_index: 0
files_included: 11
size_bytes_sum: 130540
created_at: 2025-08-31T21:08:15.628537+00:00
integrity:
  sha256_concat: 123000904ef89e72c91bff8e3de624a2f674fd0f4207aa25ab6d97cbd716814c
---

## AingZ_Platf_Repo/.git/objects/a0/329284327a601bdccbd10fe29e4b88b450b2a0
meta: {size:728, lines:0, sha256:"fa8bdfcc44e9df3fe6e817eeb26e66626e66b2bdd84964fbf3744aee90ca4c9a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a0/5c6962c6d6a10898b6f404ef098bb09ee7ca21
meta: {size:113, lines:0, sha256:"a3296a802c74a4e6d3b8c3681b1dc5ee66e4eaaa9b14e5e5fe0470cb9802bd53", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a0/5f53f851c2a61ee93aa827aefa457b829b8769
meta: {size:911, lines:0, sha256:"4dce9f43b8ca7f6f0e83c014aae6598cdda610e89bbac8f766aae9645bd739ab", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a0/66d02ce86e1f9e9eb8575d3bbcc04165abf110
meta: {size:1796, lines:0, sha256:"621f11e72d475753227637492cd445ab620417e76f365456a9b5dcbdc831d1e2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a0/6888c835d4f53a319102f4ee50b1370c8725b8
meta: {size:67385, lines:0, sha256:"783be82ed61d5854fb87b5c440ee49ac88e341b6803cdb0c45de8ce9395f392b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a0/6f5e073ef04fa68854a1b7539e4e378b658d44
meta: {size:1295, lines:0, sha256:"d1259eb0bbac3c1010a52318fc03aabcd5408b8b217ade1a5e4873bc0cac5646", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a0/7005467fb493616801d845c1d0e807e7d1c9d3
meta: {size:1157, lines:0, sha256:"f12b19339c6b6e0f410c12d0470749e93503198ad1abb4114efc1c6647f1fe60", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a0/afd634ff9b806f42511c3b53edbf0352f49785
meta: {size:54957, lines:0, sha256:"65fe746028cfb35e033db973ef0eb10eef1868559384f9c0c15edfb4178d0ef4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a0/bf7085acb55fe02365fa112991d0b57e168958
meta: {size:232, lines:4, sha256:"3d913060cff3aed817f350ffdee27cc9b14c5ff57a634c66dbdd3d551cba97d1", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xAK1=ï¯Xz.fmWéUjB­"ÔÈ°IF&!jý÷Í¦vA
Â¼!ß{3´^õ¬:{.ÊrdÍ+ªoeQ0:á$H»E
¦eøpÇØj£=LªÉ%T3¨®ÎOÙ]mÚPð×¸ÙD´¦Å¢ÞQ}ôs(ÂÖFdñ¸Y-`~³\ß¦r÷°Z^¯çxª{ÚSéAÀF».n
¿>ÉPtÀúî´1rìÄ_KgHL¾n§l>ôp¨!>¬ñ£!lý[Þ!ÕT¼{Úé¦
```

## AingZ_Platf_Repo/.git/objects/a0/dc407ed5a94e1d88216094ed14ea976a6bc5cc
meta: {size:1118, lines:0, sha256:"36d319c7c7c07bdb574270649f57da62d7cdd58ec23f7878c1a7a6e3a0fe9948", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a0/de3cb8680a1226a0f1d4bc5cfbda4a51fb0a90
meta: {size:848, lines:0, sha256:"63bb95d12f3927f2ce5081cedc6694f7143229f2daad21370fb13b4cc819591f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

