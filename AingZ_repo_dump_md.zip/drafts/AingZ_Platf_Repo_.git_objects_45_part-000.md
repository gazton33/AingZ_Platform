---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/45
part_index: 0
files_included: 6
size_bytes_sum: 3024
created_at: 2025-08-31T21:08:15.573431+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/45/2d4abf32d533f3bb8513d0d02984c6a872ff29
meta: {size:65, lines:0, sha256:"53cefd05d90447867279df87992622a521de568a74594c1054e22be27005cab3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/45/ab95ca9aa48cd807304fc284cbcfb991f36b52
meta: {size:700, lines:0, sha256:"8fff6fd960009fcbdd96cd72951bf3b0e003d12cf1c1dd1ee73893246e2dc3a7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/45/bd654e9726392d831dcee04777d790ca334344
meta: {size:51, lines:0, sha256:"27a0ea5daeda833df83798285845127a77b92faf23e6ccffe3e9a910bf71c64c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/45/da9b156e9d657df486a399d94605ad7fb60ee1
meta: {size:1717, lines:0, sha256:"bda256a0ac85ad8b9cc28952ab32607c05c97a86ecd834dd3b75a13e53f8560d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/45/faaa51f8a5b0487d1e3a58631ce6cb66f67e8b
meta: {size:437, lines:0, sha256:"9654334909a5591d9825ec42c32b0bd6402c5e16db3794779baa5453122b89a3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/45/fbbba1e628040fdec7a5780d696c83d96b3fa4
meta: {size:54, lines:0, sha256:"9a325be3dad80859748f621755226e86b0e8a6285f2bdbecfb7f090aae6d890a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

