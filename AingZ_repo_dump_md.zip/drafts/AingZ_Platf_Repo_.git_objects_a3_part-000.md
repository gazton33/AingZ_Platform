---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/a3
part_index: 0
files_included: 14
size_bytes_sum: 17978
created_at: 2025-08-31T21:08:15.628747+00:00
integrity:
  sha256_concat: aaa48b54f3dbd97df2d9138827c855062d50e3b6391560cd69323691b362a760
---

## AingZ_Platf_Repo/.git/objects/a3/22db3766a6a53c55025b15835e77fcfc649084
meta: {size:368, lines:0, sha256:"ecd5cec425c76ee357bca7a0056f02ffc83d7594059308fce47574d8526e4e15", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a3/2372e546cf17a82c0a13b47623bd595d0b248f
meta: {size:763, lines:0, sha256:"e379523233666e647d322cf4028c56a0c111ccf2ae9f3583525d4a72ad065533", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a3/2785fa20a86d3f65ad19c23655313b8f768871
meta: {size:9090, lines:0, sha256:"5f31d8e36d4d61321aa1ca294312ea6d26da6757dbf1d7473ec0a6fe8bdc0273", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a3/4dd7baf1a32210fcee7f58f2c40e4a773e3404
meta: {size:3106, lines:0, sha256:"0c40b0a3ef1e6d8df629132fc32953bb6029847e67c13190dd046742541a8430", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a3/4e25b762e31510d061de5758de2265a97913ce
meta: {size:171, lines:0, sha256:"915368cb1dc1475a8e40a5399b8afe2dfe098e6b8253806a7f1514b15c8dd679", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a3/5cb3b6cc9e692da1c998671dbb06b9bcc1cc5a
meta: {size:212, lines:0, sha256:"30ce2057fc1bad6e039255482732bb827b59eaf3d53db0f44891c8e70b9a1dec", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a3/82b6fa165e8a0ec0ef5f7296c29d7a64de379d
meta: {size:64, lines:1, sha256:"4a3e166db7162165f822d2ee603a87270c1d5132f60affd75c2632d86f93a504", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xKÊÉOR03`¨æRPP*ÎÈ/÷ÉÌKõ+ÍMJ-R²R()*MÕÉæä¤¦¸eæ¤Cå¹jí³
```

## AingZ_Platf_Repo/.git/objects/a3/82ee686bcd3116a238aa19561b8e4ceb6f91b8
meta: {size:1412, lines:0, sha256:"5534c2b7691b50a738101c7a14d06a13e3aeb8a138d84bd7a6731f437143041d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a3/b3294d3ed70e2114257b861b486ee658844c3c
meta: {size:1349, lines:0, sha256:"c20c9c1257f08badd2720125fc614da9a9fd52425e94c96c09225965c88925f7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a3/b4dee9561fcab57695cdebbde57113d9c9c73b
meta: {size:125, lines:0, sha256:"8e2150f96602e047e3fb5d83cd39d55af271613ea0bec3d99d4f7f76c67461ea", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a3/bbb14a99b6db0816252db88b19a0bc49fc9a98
meta: {size:330, lines:0, sha256:"b88aa78cd05fe493061782fa31eb031c6c7b2312a7008598cbf46556af7ae313", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a3/c48d83426aa0c8edce472c8370afef21c061f1
meta: {size:79, lines:0, sha256:"67418788d1bc7503e9b2e507b7fcf2e239dd6dd32dda4976f25700f2fd8bc3ba", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a3/c66e50ad51800049abfdab85d284a262589a71
meta: {size:192, lines:4, sha256:"c3ec6d1bcda4f63d5acea1934bee5c86350d74a9c44dadc2b881fe8f1204b030", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xQjÃ0Dû­SìÒ°dË*¥¢ÿ+keØY#o0äôÕ
Ãx0lÛMÁþM+3K$ôcpil=>Ó1åäµhã²³hvªüPÈ}G=bÂÔcÄûGOÉ+¥6:ì=u
3½TÎÁç|}ñÊÓ"'×ïy£Ûzdû.ô>¡ÞÑ!¶¶ÊÿÍZi_ÿ§Ô{Yå<.P+¬XDî·}%eó1
T»
```

## AingZ_Platf_Repo/.git/objects/a3/d1e68cea6d130c5239eb30813c6d8189c8c659
meta: {size:717, lines:0, sha256:"453d9f8cf607d5b31ab996042ce76403ce6c16e7eb252515ab2162f3cacdaf48", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

