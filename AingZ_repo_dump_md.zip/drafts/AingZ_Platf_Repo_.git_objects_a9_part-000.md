---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/a9
part_index: 0
files_included: 12
size_bytes_sum: 46573
created_at: 2025-08-31T21:08:15.629134+00:00
integrity:
  sha256_concat: 724781c07951643cc9b9838fff4490cb125cde82b01516c5ba24700ae68f2fbf
---

## AingZ_Platf_Repo/.git/objects/a9/056a5ef271587563cb20539d06ded62cd6948d
meta: {size:2302, lines:0, sha256:"ad01a25ac24a972eef9978c7dc79ebc3b38dce37c5ceb2afc52ec8f76a32a36c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a9/12a95726a386d1306d6ebc6680eb92aaa65e11
meta: {size:83, lines:0, sha256:"2517151a58604bad11edbfb1a45b46406fdaadff0637cbd384e1ce79a885cf45", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a9/2be71ccc9aa3a1e10853778846213227d7a102
meta: {size:1001, lines:0, sha256:"e93cb09c8c10e48b27a1bf0bef19ae3e88b8085b89056b5dd1da5baff58b1179", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a9/3e25a36d37709f9842f8d580c44b6c066df146
meta: {size:88, lines:0, sha256:"023c17fbc8a545a32268cbaa31a0a142c26132b458e94858b2a5f342c3063a0d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a9/4ac3517207e0f26eb7e375efed03067cf8dc98
meta: {size:1821, lines:0, sha256:"5e67cd8eb4a2c1d68a3122841029f2760c418f0e69c2aa2966995d2ce837a1ac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a9/8266ec66a53356349d51c91bebc0bd6b43dbcc
meta: {size:586, lines:0, sha256:"8bb6303f7c11be9d0fc2a19a7896c8b03dfb4bf335399e1d33de97d69dfb0307", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a9/879f0872f506ddca46a64c4a9a18b25df9c68b
meta: {size:322, lines:0, sha256:"4cbf203dd19a4a8ef44c8c82646952d2aa0d92e77ca2eb0236d2fbe0702d0f4e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a9/8be5a6b9278f7c80b1b3c174b678b53b910f77
meta: {size:155, lines:0, sha256:"9e2f68b0116cc3004304f7e58cb90fa073cf6b2c7aa975c9442210f97de79bc3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a9/ac2ad3e7f0a971574321c6f350d066df8a233e
meta: {size:711, lines:7, sha256:"0cd3e67d8c1409bee4f7d031019e3af82f3b047addcd61093f502a2e8c5998b7", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xmSÍjÛ@îYO1Kc"Çr:ZíE¤±ÖÒØÞz½«î®rh/}Ò×È)BõäI:UÛ`µ;ß|ßÌX¨1x×~åº®ãL¸@R¥ñ8SéñÒó1Êtv|~Õ¿ü0oOqwzÁ0î1.éLã¥×\dQtØ#.H¶(/ÿq¾õ`Úp%} ÀV³³äÜnµOÜÖ©ëz¨}8çrJeÙÒøýÂ0ÙÂøi6±ðZCÐ8AM`9#ËýE×Ý¥s;\GÑ¥roí#ÂºtÜDw«A7¢ã]vG`5N	%ÂË]¿A?
ïF²Å+ã;»Ø@Z½Ê0¦ifùRÁ*-¬`Às\¢iB:ÃtNÙ\è+"PZKcu¦ÄP9V!·@
Ò£Y?ÆE:Gk é\¾¬RÈyxùòcZ |²P¶!d8tF#T¢ÑðÉCfD<¬Iª&tPó%£ZIÝBB=$Û&&Üp	93jU&¡8>[âÚ_?Ë±§
ÏX?YÒååÛw¸¿¯àï»Ác]d4"ÿký©@»J@aøÓbsÙ#Ç-*pýUU©4Ð¹ú§ÐõuôØ«PB½$¹¤]?ÍN$+¶Tq­%-L<£óiD
tHÀ¹«Øª¸¡¶iUXÔq:£¡9Úl{V¶wDîY	xT©
_6/ltÁ]qJBï1~fdAßíào«Ø­öñl)Å,fv¢VË¯>·õ~ÈO£)-³¸%A¤ECMÒ­
GPýn5ýa,æ¬°3¥ë,å[¶	^®r\q³éïárI
```

## AingZ_Platf_Repo/.git/objects/a9/d03ea100da708f6945900e3c889dd3ddf90380
meta: {size:499, lines:0, sha256:"95997499e9c41a0cd8aa7f3e261de9575c8623677d39cf0bd848b4f29667eed7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a9/d7b4225b9ba35e892fa1704f55360c12152040
meta: {size:37635, lines:0, sha256:"051628185d484d5d7c69840051a58d7ad66253d650067e2774483adecb662fbd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a9/f3badf2cfdba1215d36d27669a94b4d921a118
meta: {size:1370, lines:0, sha256:"2d91f2fc55c5bf52c9c4ebf46446bc30e2ca7397900fe22d89bfe794972950c4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

