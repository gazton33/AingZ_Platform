---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/31
part_index: 0
files_included: 6
size_bytes_sum: 7576
created_at: 2025-08-31T21:08:15.570869+00:00
integrity:
  sha256_concat: 969f9e11309e126d1b86df9c7cd3056ff363dd28388826c3db735ada91289768
---

## AingZ_Platf_Repo/.git/objects/31/114c48609d3e73335a8afb03de1299bef5b2a1
meta: {size:2715, lines:0, sha256:"e934f176355fb4335c1fe5ad6e5fae94f3b824f8189008c65e3a2aa9d38e8040", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/31/27739d0b10d12f4c4b3d5c0f46d59930bd9dbb
meta: {size:761, lines:0, sha256:"954bf277108607bcad96aeeb5d2955b8ec6b6556d0bfad0aab3bc502edbf31e9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/31/44bf3800cc1831c12170d5f84d708ab10bc968
meta: {size:3211, lines:0, sha256:"76957932c4362cc642c8c05b6471945cfb934c85885e6b6e2a26a20009448fab", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/31/5f92c84b1bc1cb991be98990c75de6c8e9ff84
meta: {size:198, lines:1, sha256:"8ce3dc9628bf36be056eaff9b9da2f9e063bfbb697162fb468eb2499b0d2a993", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x=ÁÂ@D÷<_Qà9{XdY¼	÷ âM'6i{tº'aÿ~G<×ëª×mL-¾¾>V+ëæÎ}öÆI°/1â@ÏBjÎíH»Ì-ÁÂj2EoÐ^zRx	 ÑgðbLK¿q®Á	gì0¶HPóÙÛË¸Þ\àXçjOµ5eGx,á.uåNb³á¯¢z°P[C$¯$L#ÓD^{©ûe¹UÓ¿Íö¬Z¿|Í×~ºæ$^_
```

## AingZ_Platf_Repo/.git/objects/31/7e3796b04261e4d247dd94157c139cc47bd80b
meta: {size:58, lines:0, sha256:"6fa9cebacd9770b5f20b037f936684d45262733a2c6a4752ef9c1b11edc2bb96", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/31/9958f0ca0d7a7155ae46fdf26ddbc5f9ead957
meta: {size:633, lines:0, sha256:"2a76a023d8940b237d11717873bbb7d0fa40a3daf506847c0a23660c545c0693", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

