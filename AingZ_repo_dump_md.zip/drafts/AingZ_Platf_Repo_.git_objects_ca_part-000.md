---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ca
part_index: 0
files_included: 9
size_bytes_sum: 6662
created_at: 2025-08-31T21:08:15.648313+00:00
integrity:
  sha256_concat: 7bd3a37c95142f9e01d60943b5f9ff68fc8f4df18d3ef715c8fcca0839a0a965
---

## AingZ_Platf_Repo/.git/objects/ca/0c9793f76bdd5e8f44a230807d16582d1ff267
meta: {size:358, lines:0, sha256:"64bd2c229826a0a21db2c4748651603c530ce0077b030f538b302c8110b3ff13", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ca/3b4823aed84ccae3c37a4ff116a5fc83bcb7ce
meta: {size:137, lines:2, sha256:"e5a1e4d6f49868a80da3027d64fba048f4ee58817e5d71674e43816a1c99526c", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x=Á
Â0D=ç+ô`Q¨ üø)nK ÙÝàßVp.sÞ1çËuç½"ÇM>XJdSLE°¤`­3Þ$£ïN]s/ ÷ïPCKÛdUó¨mÁª"jiÓ©éæYùþñ?ëW3G½û4Ú4½
```

## AingZ_Platf_Repo/.git/objects/ca/5b5932ebbb0a5b0d13b6b8412221e0700ffcad
meta: {size:397, lines:0, sha256:"b96fc2f75610a0c870195ccbd5d28903f6113d1b75fbd50c4a141ca0aa28fcb8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ca/6bcadcb1dfeef691b03679135937c4e5d8d45d
meta: {size:99, lines:0, sha256:"82affa32705dfae0a1982097b04116eb5976cd302ed9fdc56892cdd0decbf85d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ca/95161bb977a7b666e2e29f9f684aceb6c3cd27
meta: {size:345, lines:3, sha256:"211a0e285be34a7be45e9cf2d10e8bd45386330f67b4e51febed9e4552fb2e2f", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuQMOÃ0å¼_QõÌPÓ®k»Û$'ÒàBSÖzmD'e|hÿ'ÝWÈ¡©ß{¶Ô«`?£ K-%o×BZÀp¬¹4pé8Ë 0ìãFoym±Øí5Í­åe³euÊoDO
ÁhùÕ2vmÃÕ ÚÑýh×¨»vXÓ·ülÄð½ür~[nÙ\¨úyù ¹]kÜ,7\(Ò¸I¼ØW"ñ!8N!;(ÆzåI1äûÄ¿Ý÷Õoåè¹¦Üõ?­ÀÍ9GÔÛjáÓÞð
î:iE+ß{ä«)]ÁB|)ï)BýG=Ð¤%üÙ½àÂ"¨Úº×®Rg,'yE	}cäõ~¨éÛ9êµ¼ÆrUÓ^kJ.]L¢<²<OÓ¬ÓbÒ/Jjãh¿Ñî=»¾
```

## AingZ_Platf_Repo/.git/objects/ca/ade56e26834fc23c626b9996d1708ad7d585d3
meta: {size:1264, lines:0, sha256:"99b70357743fe66e1042fe82e8f4805aaa7293840e768cdda74c81b887de2056", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ca/cfebe5faf5f8e137688a0e4809f93dfd6fc7a9
meta: {size:845, lines:6, sha256:"80bdc2fbc62666ea6409ea1f1bba1dce3d0722afd656da5d1e3a42bab0a94f62", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuIÏ£FsæW´K"4c³IhXÜ`Ån@7ÙlüëãÌ9©KIO©Jµ¼]WO¦ê·iÄi*e¹Sâ~ÏáñU÷áæ)
qÄ=q?æ$Ìïô	°ì~ÏH$æü^LY"Ç3b± é<UÃäº/ð£üþÆ-Î«aÁãÏ²Këö{>tZàø=M}
oKQÄ~ðôz2æüèßÛígYOÕýOZy/u	¾ýkÊA?«» 8ê'ùrõ¿8°<a®È²¢Ê²§xæð´AõU:õyæ®U+Ërc;lËK
9ûµ"Iy0vï;Rh	 5oâ1<ßubA>µ>ó0R2dX¡³nÕûÔNw¾¸·3-#^âDdk]Ïû¬i_óVÚ}é÷ë(ChR;H]hÁ"·¡°¢ó4=1}O*Gz#1+Ç{­elãépE*_ök>£·µfP¯¯EÛB#OtdV{õ1öZ°4ölõÅjO¨lvIh?§¬.*oivñ#«67DYÌ¸HwðÁKÌÄ´n5n'ë3ÅµÛØ/Ìv\ÏÚOÝs*¼m8Ûü'qèFzê®½/´uètë;Êî$
ÏYÕ@©=FE_ÞHÈ&m0¿nº&ÕÎ¦¦.áDã+¿½U:`Ó8ÉKÒöÐ"ßyöû7lÄl«ôÞU}PâwíFÕ½I©MÿKôHreôb®¨SÑ5Ç¥Ç];ÄnyE{
k²Úóáö²»ÒÜ&¯ÐUàñÒ»3î,xºTmxo*xr*î<mwõ¼K²¥&å.àGQy¾µçÓ+tP¶ÉË`bÞ	èGuìº\)xÏf­bd¬<ÕD?¯*ÐÙA¢TÆf¹òáÝüN{ºXêª½jö~äÜðî5¸cãAÕ®p._wÎ#)>|NoGÃMT'klà¯wÁ~Ü/íNÚ!#Ôá4ý°´äC?áu÷4oÀ¿KÌñ!Q
```

## AingZ_Platf_Repo/.git/objects/ca/ec692722915056c945505d2649a03a9575174c
meta: {size:3092, lines:0, sha256:"0bb67e8e4775bd6bc139b584470e1a0fe4f70e140d3ffb2d9595b8e64fa8e4d9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ca/fa3e3e503d769c3ca6a2afab51c67f858da9b5
meta: {size:125, lines:0, sha256:"64e791024c63aecf17456f2814b1d17e96ed86671fb6537d25389c89e3917d7c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

