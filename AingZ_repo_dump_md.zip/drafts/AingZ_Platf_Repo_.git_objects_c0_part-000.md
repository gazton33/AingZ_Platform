---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/c0
part_index: 0
files_included: 6
size_bytes_sum: 2562
created_at: 2025-08-31T21:08:15.630711+00:00
integrity:
  sha256_concat: b897fbf187d69a46085d39a2c77ab32ee5fbeac994b36c8fbd9756db4703cd98
---

## AingZ_Platf_Repo/.git/objects/c0/12f888cb4141b2c05957a9e96c720101f1f697
meta: {size:74, lines:0, sha256:"e0b4e4ebf4fab753e17bc5ca2d0f6f239a6b7ee44f309ddef3536cfaa0671ee5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c0/20b12600a64273cee9d2614781a0d3cd489425
meta: {size:265, lines:3, sha256:"0e56d177e55c337e12a82c1f031cf0eac3eafdcda6189ff6bb80b9e50e4374f4", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xí±jAE_"IùÈÀì²â66FD²²Á,ùê5iRÍØúgzotù­æÌÝ»a=Û·÷m3yÊ:ÏwÜÊ\7Nùü£ÄîNÎ/ûã³cÝdìÐ«~>Ût	SÀÐô}@`Ú^MÉÉðûÖã«SzÅª¦ä*BÈ	 #ü!1YÖèà5:0©ÏU/\ú~Õÿc°ÿxâ§
)LÒDñÈk<8øËÑ_ÉÞk²´^[Ëïf'èL'!]AfN4]±²Ae°ch
¨øàà/G%æUÔç	×Áå
```

## AingZ_Platf_Repo/.git/objects/c0/60717b517b64513a09505d4c20489ed3a44669
meta: {size:57, lines:0, sha256:"ecf5d6416dc6f8b70165d889bef0cbc0adbba5f1d64f0a90bb2029a98f9068ff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c0/62519f9a09c8420caedb3905d3f8cab54c88bb
meta: {size:1044, lines:0, sha256:"2883d5070ba1137714795055ff5cd17b3aec718ca9c28f3a372090ed67657f40", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c0/741f84b8138ac8c21e6fec5a01c0db73645f9b
meta: {size:679, lines:0, sha256:"d6f6b53a21adec176a06c83829ccdb2b7622298a2acdfd59976b51abf499e510", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c0/abf467e06b5896077822bdbd2e84c332f4c577
meta: {size:443, lines:4, sha256:"0417bb31b8dae6d7201f7865d82e425373e2e12db38a3eee9150b3d3c7a5f990", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xMRËnÔ@äì¯hi/É
!!q'Úr@HnÏô:íOæh9ñü'n\÷OøzÆÁäÖ§ª««jt2ÂÇ÷Þìàà³D/0ÏOºþ|ÿO) !0äsDÇßÐJ×R&°É(ø$-9Øï/¿=4VK ØgÙï!`DÈ	LäII)½i	N!ÄB£þUC`H)ÇbrQè>ÂD=Ü®³bÊ¢{Ððå9²atD$R¦4õ^Gø2äº	3¥áëU³}^÷]·ÛÁç2þ¿,uï`Qf½Tß7S¯¥Ê¹zÐÄF:RÔe}Em¼/°[	¬W	 ÅP§NL5`=6
ó«×[(5¶gGv¢¶;XM
Ä k­F3+ÇFCÒÉm	l±6.ñ£`´ì§ÒÉòUû§rù¹ºßLS[d¾Ð.LËeu$²#Ó¦IiG^rf/«Sz»Þª9z-v¥$Q×oµ>ÅåÖó~"'\ÛÜ/v¸^uÔ\F^M×fÔ[Ñúî/±HG
```

