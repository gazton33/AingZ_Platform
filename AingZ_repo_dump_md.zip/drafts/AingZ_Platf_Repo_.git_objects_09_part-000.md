---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/09
part_index: 0
files_included: 10
size_bytes_sum: 4312
created_at: 2025-08-31T21:08:15.566885+00:00
integrity:
  sha256_concat: 69f03eac64187c11597853ec9a15018ce79ef364f206f6387cd85e0dba3d11df
---

## AingZ_Platf_Repo/.git/objects/09/04ddde39de66fe6d9170b572e804109a3a5703
meta: {size:82, lines:0, sha256:"ff0a223d5efe4b47d14864f2905ad8cf6b1b5083922eb4401244f2238178e175", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/09/17f990fd03ef055c0d64a0857ca5b5e856044f
meta: {size:1304, lines:0, sha256:"be7c7a8bd3c65ba183de8464f7c62447c1911efba1f159b0bbc9dfe617590ab3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/09/18f7ce9cb28e86eeb20395ca7111f69976862c
meta: {size:160, lines:0, sha256:"8efcaa8a658ad3556bc951527939556c110c5385d4570ea98a135741a56ba9f6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/09/41335deeb42f1a2c9d76923ec956b0b9afb918
meta: {size:1189, lines:0, sha256:"ab316dcb1f3bc45974f4fccd5b2a8c1e7c59a6f88ddc4ced03ce36040021e8aa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/09/5b651b5e4960a3231c71e64fa275cf670dd1f6
meta: {size:372, lines:3, sha256:"7159106e7ca2d492e6c3f576880925776529774ac15b957a9344ff1994e70285", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xRÁj1íy¿â9É.$PØ\JBiB -i¡Äîz¬Gªfä:¤ù÷JZÛ4oÞ{3zýè{¼{{ò»5µü¶¦ïFÇdMã¹mdUN ç´¸]wïjqm¤Dÿjî}/¥BSG~µúÄÌØif«Ä	|¼´ß>_ødo¾Ûs{qÕâèé	BC$Ùë*+(*^ü$)î»Ag×1}Ò÷Ó
.NwÓ þ²µÿÑ*Ó:¿"|yÔçõKq!MÁ
ù	a6%nq|2Ûï8÷zW,Ú#Ä#9Èæõ¶øu¸n[%Ê·¹Hkâ¼@Ý*îÎ +bàv&þ;ÃÒ½2p%CØgS¦%Ö¿o1d.CtAeÍÙ	»o´S[{gáñ`zð¬åÑÇËnj~lÚ 
```

## AingZ_Platf_Repo/.git/objects/09/948f111603643c159bffc85f49a1d5c132fad2
meta: {size:120, lines:0, sha256:"0b3b0207d5801d8e2ece4b97f8aa88fbe119f621e826f48193530f5c3b953e5f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/09/a1f0c668d31943410af998a63cba1227b8a01e
meta: {size:83, lines:0, sha256:"563cafc8c5b7d34cd7d04780f319fe1a0a34794f1823b474c125c2334f5c6d30", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/09/cfdb594920f8cfd626b68618c2f9b09864c011
meta: {size:285, lines:0, sha256:"66e1d806cc6c690a899dec6443301689c84066e3c66870a142dea52cc3622697", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/09/d53cc90aa12fa00c41ba838ce3c4d85d5a4442
meta: {size:167, lines:2, sha256:"c810903384f7d754b634bf35bc3bc02dd355787876e0761c71a74399e7f55ba9", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xM½
Â0EóLí`AÁE¨ îâ4ùÚóG}{£]z÷{Îlp>]óæ`5%dL,C\´)ðÒ?!{,)/vELÆ	G9Ë ½}LÉ«HÆ¦Nß´8Þð®uÿgÃï{zÜáÔLêa\´äª4V*¼­\3BZEB ïÁøYà~S²/nçGÔ
```

## AingZ_Platf_Repo/.git/objects/09/da77d09f2338fbbfedb6c062c40270863ac33c
meta: {size:550, lines:0, sha256:"01ccf01febfc7eea01f4c687f0f85caeb00bd619dbc8a18f57c9483c40200acc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

