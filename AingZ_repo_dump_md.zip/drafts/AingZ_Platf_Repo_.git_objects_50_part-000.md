---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/50
part_index: 0
files_included: 10
size_bytes_sum: 3706
created_at: 2025-08-31T21:08:15.619554+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/50/57bfb6b8e684a914168c8364bb7a46ffae89f6
meta: {size:74, lines:0, sha256:"eaa39794ffe3ba56ab16792de75d9b8632e280f2de75e91ae649a5e80f865b6e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/50/62176e0aa57af9b58b42775448a7a0b38b4c6c
meta: {size:148, lines:0, sha256:"8a18f2fb49d8caffc3e2023bee505ee6bed7c01b908ebadd7d689c7a8a4865fc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/50/ab9cedfc628c5e252cd498fd8508a4e503b05a
meta: {size:96, lines:0, sha256:"dc936e4c8bd64fd082a996b29ea33c1b2713250bdb57c4aa14ba541eba78a590", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/50/b092d731f8f31aacc95fe3d71f0c3875bef7ce
meta: {size:405, lines:0, sha256:"046db80f01017b379f3e10020afb80dc4ed3a864d526485d3b7a49e15740fd6f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/50/d03e71b0ec2793e547b59e9ccac99b60bc32c8
meta: {size:581, lines:0, sha256:"53ab22d4302e7385409b575115f27fe51491764a91c2186cd98abbce033bf5aa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/50/d076da61d8d24e153660457bef99d18ceda5b0
meta: {size:877, lines:0, sha256:"4cd42b14e75142c1daf77cbb7c2deb08d6a7d2c4f65679df8639f00489e48d7f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/50/d2d368bae2639487821a30ead45828409ea936
meta: {size:849, lines:0, sha256:"58a29faa517467bbb2cdc0adab44fbf561f6b31a4f26671b6e2ff72c23dddda1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/50/f312b72a1130a9622631c6d1f524daa09a7ea1
meta: {size:81, lines:0, sha256:"6d716a1c2a105813cf6bb530d0b856007109f23da5c497d65dc45fd759abc11d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/50/faa5f47557920b609a296f5427e0dc56b35209
meta: {size:233, lines:0, sha256:"779e957911fe6ea189d66f7e53311e09fed546fefc865856e1319f193e867064", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/50/fc90503952a3453754934a6a743762b23f87cb
meta: {size:362, lines:0, sha256:"08555b40ca4f0e21d9692a0b893acb435323c87fa38f412fa706d8d282d31fc3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

