---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/98
part_index: 0
files_included: 9
size_bytes_sum: 5188
created_at: 2025-08-31T21:08:15.628110+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/98/370731f378886d818c33de67995c6453a43488
meta: {size:883, lines:0, sha256:"55a0fd19e9e920483e6b5a51987867131af0b99a92657221077d387a2a93769c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/98/40a3d3dfe4d20145239f548a543c87dc0b73be
meta: {size:894, lines:0, sha256:"d8b220d31e92ec1c7935ebc5296f11f8b48715f80e49969ebe2a09f4bc9cd1cb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/98/416b8edf10cea24dad955de5393018eb8d7f72
meta: {size:153, lines:0, sha256:"0046bbd61f700464df2c463db3df4d08c6abebbdff81c40f8a9be3e28e199ee4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/98/46bacc4461d352aa2edd5974e23f602435c886
meta: {size:669, lines:0, sha256:"ee1814f4b7daef5c329f3195c8c3d4a8ad837d3c4089cb4095394eac2ffc6b6f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/98/5f6a0c4963e324e97a3aee9b14186e2abbb680
meta: {size:152, lines:0, sha256:"474c03aa3604ebbdcf5876c61e9f1c0a0f05822fcbb62eba0a9c30731ce2e921", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/98/8d5ac3a7c2aee1a6bdb2270e296a3db730f16c
meta: {size:631, lines:0, sha256:"e4fd8228ace299c7892264fe18504c05e73e95a43975059f2c1139a5a78fb0cd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/98/c09f9bac8eabcdc884bc5f3a961de75b3ac1da
meta: {size:753, lines:0, sha256:"8d10aa5667fd3f7ec38b8f69a5b702e37e91b1f90246c70e7619d58c5810c465", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/98/f29fd90d32cecc48b38c6b17a00afc4e0a67a3
meta: {size:110, lines:0, sha256:"380de14007550dc7fa13b28c921cb2ce614856568ffc73be706aa3f0a256e326", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/98/f77dca1ce2a8c3df56d57077de233e977dd56b
meta: {size:943, lines:0, sha256:"76f8c25f44119bd335c536cecf04840f1a77026c158bdec60aaecb1e0c4526d4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

