---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/aa
part_index: 0
files_included: 6
size_bytes_sum: 2156
created_at: 2025-08-31T21:08:15.629199+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/aa/4bc477ab6f61314dc926ed2675c7794b04fab8
meta: {size:108, lines:0, sha256:"957eb72aaf71cd3368f6a6d5e87d128e03ea4918768127cf19e6a766305a4eda", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/aa/6c217a239bd1c583b8392d0648fc4f3ac46403
meta: {size:519, lines:0, sha256:"6967ad07ea72c8e1a39e6c55c4d10ff3d3651649308dce1dd2d394417b21c1a7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/aa/74cd8d22002cde6d1b4ceb8dbbb9ac36cd4c92
meta: {size:133, lines:0, sha256:"a2998477b564b2d85a6b34b90ae7da749326b986d17fb11ea7c2cb5f68c9479e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/aa/da2b5538c883b26dd86f585a83eebe2bca5221
meta: {size:124, lines:0, sha256:"ccacf83f972e4f8344e746cd17a5a4c51a207aea3d17bb9ec11c71edfc3e7c25", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/aa/dedd65667b581cd94a70bda08b740b8afdc479
meta: {size:844, lines:0, sha256:"3bf3590174c1f80d412f941966e8c3277ef41cd6f2fe16733ead0ec7ccb56149", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/aa/ef37c1bbe5fa4fef79740b1a7cc528c890e3ae
meta: {size:428, lines:0, sha256:"d65f303eee1e22c696044395747002448b4ea790e28e6cac024532856de1188d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

