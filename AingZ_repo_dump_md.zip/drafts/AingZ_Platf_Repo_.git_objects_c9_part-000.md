---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/c9
part_index: 0
files_included: 14
size_bytes_sum: 9644
created_at: 2025-08-31T21:08:15.648006+00:00
integrity:
  sha256_concat: b559d938b368c49f12897b1323609a7c684d0cdbc1da5b6719846f2fd31e9bd1
---

## AingZ_Platf_Repo/.git/objects/c9/0deed99158d63f53a8ab56013e74e47eebb4e3
meta: {size:164, lines:2, sha256:"ca34ee6a4ed2f813a62fbcdf5d76f7ff3dc61acbbe93322953bbe55929a22343", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xmÎ¿0pç>Å¥00àÂn|/~Jcÿ¥­	¼½Uo¿ûÝlÃaNRÊU¯ÁjNæ³Êlg,+/Oä%Xz1½Rb_ì/
sVò¼{QïpÊø¦EwÁ5x>Ô|üëÄ#|8øã¢eWeÖØ¹È¶î;¼rLq$úhDò`Z¼f¹J5
```

## AingZ_Platf_Repo/.git/objects/c9/0e0f4d68a86ae40e16089972e137098b6792bb
meta: {size:849, lines:0, sha256:"81eb5636a18a6438a6e27291975c0b93b1ddd524bf6427041ce404c2a083a22d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c9/0f77ff6d57020166bd6f939fdef349b1263553
meta: {size:144, lines:0, sha256:"1bdf59228e869822cd843752e74eb7d8f1e40747df149fa87ab079eeca5a7ab1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c9/31ed64e055a26b61a8506acfaf30f0cd44de55
meta: {size:180, lines:0, sha256:"f3a7dcbbf4fbf8064f1bca5f4f07d4f5c732077e24d4058136593108e0abc40a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c9/33b930aaf5e9d72a47c05f13e855e2e1f7322f
meta: {size:81, lines:0, sha256:"4069199ec0a20f6bddf90d78d4334b240575149f67330ded6b2fdc678bafe4e3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c9/5ec0dc0caf8e2652801b1ff4aacaa698ad1e65
meta: {size:211, lines:0, sha256:"9902ae7e2e46fdf13bdc1a4bdfb728a80d8bb4962b2fc948a87166f4037a256c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c9/63e2a01df95cf12ee5a26297c7e836e2e181cc
meta: {size:283, lines:0, sha256:"ff40166f8bd952cb35efd680d2020d4cbe2e0f80f4ca4d90362731a9ad11b1b3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c9/7e5a8e241b85dbd7e62c0933688c0de4289dfe
meta: {size:342, lines:0, sha256:"fe3abcf1eecc9c1f96a074614d20b06a084969d9c77310a4f788ef87b858d66e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c9/842dc427f2e3d4604077f1527574b75e13e419
meta: {size:1196, lines:0, sha256:"e0a93a32e262d27f9656b3ad80e78756cee1c1b89feb591007612e9d85f1839e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c9/c460fe241ed7a3737d89a4a8b8dc21699211a0
meta: {size:1701, lines:0, sha256:"1e7bd49e0352842625651b59d614e269f31a3013d347d756d0df1c1e04ee5d48", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c9/c96f44e5f445c4312d7b4bf91aaf294ba727e0
meta: {size:268, lines:0, sha256:"7b859c1c55437203b0879a2bf2144a4c82ec14c58f2ae27bb8ddf0ca93c753d2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c9/cf912d50131d45e6d49c43916af2f85bd2e01b
meta: {size:130, lines:0, sha256:"b612c79c46cc7fd48a51e82c8a240c870e8056c2c8edad1366ccd15f6c5ce744", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c9/d93bde06bc74634da7fb91736905ce66fbc326
meta: {size:3117, lines:0, sha256:"4f5d8373a0c84f36bc1e63a479a8e75c99cd840fde7f4b5d020b205130130192", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c9/f6fae4c782bff96670a3d11a5bcd8dfda52a79
meta: {size:978, lines:0, sha256:"8d2092daa79bc22ef6d7139cd788aa9b011673cb91318ca3fbff489c03aaf601", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

