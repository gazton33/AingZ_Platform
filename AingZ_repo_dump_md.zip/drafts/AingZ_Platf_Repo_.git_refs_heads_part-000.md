---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/refs/heads
part_index: 0
files_included: 2
size_bytes_sum: 82
created_at: 2025-08-31T21:08:15.653165+00:00
integrity:
  sha256_concat: 5b590288db48ec86d8d0381419fd694fc7e65341f469c994b9524f7a9a4b7c77
---

## AingZ_Platf_Repo/.git/refs/heads/main
meta: {size:41, lines:1, sha256:"30014953767dccd56ddfbd69085271e93fa7d525ec6e7adfd4bc90e68f8ac9da", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
6c958c44161094ff15e8501bcfd1f5f94d8e6d08
```

## AingZ_Platf_Repo/.git/refs/heads/v4-migration
meta: {size:41, lines:1, sha256:"5965a146ebd68620f9cf41db021bad0fcfd18a859588ef25d8484e0300f2573b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
c34e3a7feb7a7422835198aa38045f2490b15d19
```

