---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/5f
part_index: 0
files_included: 5
size_bytes_sum: 3918
created_at: 2025-08-31T21:08:15.621510+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/5f/0b0abf75300551f2887ab645cca824db3f3381
meta: {size:1188, lines:0, sha256:"11621358f92a3255ae48dd50a69db077ff5347225e9679831dd36bee3980e584", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5f/6048d9e4f4ec19545e57289849283926ca9309
meta: {size:1289, lines:0, sha256:"4f6acfac586bbb6e69fbefe8b6ea400564271c9ef114c686d61936342092fb13", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5f/9d5ae403173c6401229f2a9d26144df56b2610
meta: {size:160, lines:0, sha256:"c5862b0ff61ff96dc37b15c52a9f662b869fcb649e81eeacf3a76027c53adf19", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5f/a0b153f0d5219b3976c84bb07c74baf5611ee7
meta: {size:433, lines:0, sha256:"ced7df4a08d500ce9159eb96803b418f32a697c383f55a92b6104a69f0aa0c63", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5f/e423df17912df2da2883241c8d57709f5371e7
meta: {size:848, lines:0, sha256:"66ac228626c24f16a45b980bb8e66632c5de90c8b821f6178827fb8b20cae9ac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

