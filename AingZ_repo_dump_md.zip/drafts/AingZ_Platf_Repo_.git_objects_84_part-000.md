---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/84
part_index: 0
files_included: 7
size_bytes_sum: 7995
created_at: 2025-08-31T21:08:15.625788+00:00
integrity:
  sha256_concat: f579822022bbd3cd0f988d87ea50697eb72f76de3ca4b8f056e46e104064dc34
---

## AingZ_Platf_Repo/.git/objects/84/00978233ab2903e0f4c7c662cfc7465aaa50e5
meta: {size:4224, lines:0, sha256:"95aca557b66c4d92b5b15e1027348132d26cca3f4f6b68da0bbe3f685d7a5425", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/84/598121f2386a842a59ada829029dfdb9821914
meta: {size:131, lines:0, sha256:"66292601b9a2250f7b12071950a5d726f8dd4e4b5247161ef316c5ab2e7eb50d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/84/5b7a30e2097e16498ecb66febb8f70e7380900
meta: {size:632, lines:0, sha256:"2b5a3fe35e91fe90529dadcefafcf223dd865b500c0da3a282b2e27cb3d1b478", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/84/8ffee820a15f3eb444a6028392c8d2605bb992
meta: {size:850, lines:0, sha256:"e6a798832e5af4db8d8dbc482d45e2c925b844a5082419d5b676df2a7252573b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/84/a26c83f9249bdf543c86f399701acdbe2e3f7f
meta: {size:177, lines:0, sha256:"4034bacc18c42d07e418aeb71e3398703853317ee7ce873933119f067f3565e7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/84/d4d0b7372f954718cfce583e59bcf61a886356
meta: {size:226, lines:2, sha256:"685eed7887f4e8bcdbec97a5a3d05742c83e6a55cfc8638c343193581fa00c64", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x5AK1=çWxQzóXk,ÞJÉÎn¦1dÊ$éÒßåOðR÷öà}óÞ¼1ðOW×°íçç|R<,á%Qê#`*>Ì`	FÜôÕËûNÀE8Ã%bi¢!53ì¦J©P§ÔS®¡ b£)ÿz
.A_5bb½zkÃ¥d!ÜRÎq´ÜB{:ú@¶.pFñínºN'YGYÍæ´Ìf4j&¶dæ¾	¡.ÚÛË3µ¡Ð.`úý±ÞKÒuêuj
```

## AingZ_Platf_Repo/.git/objects/84/f9897fd2f30015fc6087ef939ccae0f8b29ee5
meta: {size:1755, lines:0, sha256:"ad2d345923bbffc152f2bdd6ac1e925ac606188cb84723b2446e1046907b6868", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

