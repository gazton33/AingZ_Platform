---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/06
part_index: 0
files_included: 6
size_bytes_sum: 3202
created_at: 2025-08-31T21:08:15.566204+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/06/30fd582bf64aa5c05aa1e0a24c288058f2ce01
meta: {size:557, lines:0, sha256:"34b27c16531227cd7d948d7f1776b5575c062d29a6220173f659659cac17d175", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/06/760192c6d3ddd58a95022593392c306be46302
meta: {size:848, lines:0, sha256:"1d6f43bf4dd888e63aa1a9625cd4524e25c622753bfc3cfc12113850ec171727", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/06/782f10282deb1a2cf26cda17695a153e19218d
meta: {size:245, lines:0, sha256:"ffcb03ce50207841907435fe6f6870984f8532e8c7dc931a5ad420e3704bf95b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/06/a478380484aad19a0938c42f720e165fe79599
meta: {size:1173, lines:0, sha256:"1b2e862eef4f6969bffe56ec7993f5f2a8b3a8bc8c2a4a7849dcec16cfb23d19", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/06/b08b31b856178516b44229041b4c2b922c7d16
meta: {size:178, lines:0, sha256:"4163cd5dc95930ac04f52d9031e0f5c4ef7be34f6ea36dc1836d9dc0d0942a0a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/06/dae02159e26bb1df5481a3796e217838630b3b
meta: {size:201, lines:0, sha256:"012a2dc7ddc4ec99b8cdbdb3d1f3230a2a1eb0ba38e09838aadf68c5553d6afa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

