---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/27
part_index: 0
files_included: 6
size_bytes_sum: 5347
created_at: 2025-08-31T21:08:15.570138+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/27/04985f6d51a73945dd08d518d0611a7e92aa7c
meta: {size:1968, lines:0, sha256:"cf5deab4aed378e0fddbb8a5920272441762b4faf615f4c2757f87254c010cd0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/27/404a2d077c713b93bcfaa565afc20fc7d20587
meta: {size:1770, lines:0, sha256:"a3d37577b61bcf15a0215f4c7cf5da21ddc926869279395a392173802a45d72a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/27/4fb20b108d55af0c8b461e7da8cf166d546c24
meta: {size:145, lines:0, sha256:"baeb74d5dcdc872d4f89809ad60496a39b7c77a84ed3d8ad40be61e72bb176d2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/27/71d72fba09e04546c88895307f4845fb50dc08
meta: {size:609, lines:0, sha256:"96c449fe6f80823f15b6c04fca90ec8758044e7861322477c989d0b2570e6cae", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/27/ae6ba058ff8349991fe4b9bee4dc2c8c2e6be7
meta: {size:54, lines:0, sha256:"24ac1c9c28e53573fe122e7744ae1647562db4a053df96a3c950a72a8cdf0f05", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/27/cbee57343ed030ff11a2dff2f4425175893ad5
meta: {size:801, lines:0, sha256:"a87c762bc6d921b89ec494470edd6c5657d1e593532c4ac5526dd389462f05f9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

