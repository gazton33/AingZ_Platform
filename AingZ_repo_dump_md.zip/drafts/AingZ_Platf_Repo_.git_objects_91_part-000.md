---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/91
part_index: 0
files_included: 13
size_bytes_sum: 8233
created_at: 2025-08-31T21:08:15.627605+00:00
integrity:
  sha256_concat: 49db891f81be7529caf579b4782b3e63bce6624ef61e7e7ff29690734b00e0ed
---

## AingZ_Platf_Repo/.git/objects/91/0b4ea77e063e80610ea218eee744e5a339b7f9
meta: {size:212, lines:0, sha256:"fe7fa9d79ff6dc5f47062fbcf3611969a4b6bc0ba13a08a6fe99320faab1bf58", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/91/45c8a1149428ac001e3d32d5da1dad6ce9b969
meta: {size:115, lines:0, sha256:"52891fceb2e096a975d772eca50f2a842b348d9b3318cc6f35f4ffb7a6179ac8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/91/468bc32411f17e02bc04e705ebdcfa0e835f20
meta: {size:847, lines:0, sha256:"71ebfb83736140791ab9c86dcd6a8b603855d0c7acda81572c85a86240023c6e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/91/6662c4dd40cf264262f8afe60b5657e31e2b7e
meta: {size:54, lines:0, sha256:"3f126b9d905dca1369e8ae9ede08386ed82ef2572080952de886040e849afdb6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/91/6ef3bf856363d52efc1371c6adc6f69012f780
meta: {size:532, lines:0, sha256:"497c649990a66f84785b413f88a35d5d400643afe828775c2716543f99704a1a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/91/85df5b0355a3153e82417fff6af9a86e7c1c6d
meta: {size:1673, lines:0, sha256:"8c84bca93f03f6f72fe5aa32bb59a9bdd96acba55e447d7e42510324905116d9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/91/96f9338208226933459974aa2b8e94f0b3d59c
meta: {size:635, lines:0, sha256:"c7b599ec1ab1b742d0183c249d0f524607f422ee7be40285c9abfe650e343c12", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/91/9a56823d28516fd1c25d8ba66e9d3b0be7b0dc
meta: {size:867, lines:0, sha256:"d559032729a3179c5d3572a88b812beb71c30eed0cbec359a4296205e0181e69", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/91/a4ecdf189c83927f3ccef0fd8278672f214534
meta: {size:289, lines:0, sha256:"adadd17cb3cb490eef9f987818e5cfd2952a6383d2bdcbdb77e00ec91b7942ff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/91/bd23c63d5db23c40f2fdf9df0a665816b5dcac
meta: {size:332, lines:2, sha256:"0c4d456581f5ab78f72e84b4fcba49e70555ea62e47baecce84cd635ff3b0343", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuQk0÷ì¯¸oFGíÃ`Ð0co¥¨qUsIRÖ2úßwcQ»ùdsNîùRuºíö©5º[Îu'¬å¶¨µqÐª¡áãv«:isø2ú¼ºòAô2	vîØ©jò¼Ó2IF¶à¤u|Á\Ü{²×è»¯áRÁß>?x£ë¢oÒ¬ø6ÊIîäÅ±ôfAoÏì`
ñ&ÚI§£¢?5Ê°QÊ¼UHÕî(Ícî5æüï¼9¤4\TûúÔ?Xø_hµ58ÝÂ8DSÄ(%í²å­»Í¹-Hóæª½óüp³ÂARß×7c`É	ÉJtg6.°aIâè"zy?ßËÅö5Ôð¤}Ø79Ýq*²Ò±Q_äÕ²,Ç6`A¶CÔïçC°É/Èäì
```

## AingZ_Platf_Repo/.git/objects/91/ceefd395169cb6a4c0bc507ec3fd904c39b21a
meta: {size:535, lines:0, sha256:"226cbec4366a6a3b5fe855feca33283a1c7f0de561a2b941b337f17206389820", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/91/dcd5a7698f736971ee800ddc9688571358b95a
meta: {size:98, lines:0, sha256:"8533add5df00d3810186b2aff84dd0d44a678404f985687fbb615112e8cfd5b4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/91/e414c1d1c4c98f07d3836ec70dde9b3ba5b068
meta: {size:2044, lines:0, sha256:"b122175c67325eb81b3c0030b189462026ff203b0a4639a24ca6103eec86a435", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

