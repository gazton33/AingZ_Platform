---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/32
part_index: 0
files_included: 9
size_bytes_sum: 8855
created_at: 2025-08-31T21:08:15.571146+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/32/0a589626144ea2e66c1ae75965ca0dd372aa2a
meta: {size:195, lines:0, sha256:"2ff194a32e9cda5351970856e9b38442eb77943245c28d543c3782b548208d38", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/32/29d44aafbd45b9602076f274bea756e57d804b
meta: {size:99, lines:0, sha256:"4765ad4e49be6d04040535403a13a9d8e2d0219a6f4a4c2332e27e1c07889269", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/32/4b171faeab1016441319f448f4457ce7a6f72c
meta: {size:277, lines:0, sha256:"16bb33af60ed771f17da09a987c45a6996379a5ecf4969bbad09920644629819", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/32/6b4d4c298aa1208b786674ccab27bb2f3ef1b9
meta: {size:760, lines:0, sha256:"0a87376ea3ffab241fde1f63d559f6b7d60b58dc8c7dbec99f043d67e6ae4c23", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/32/754335e4e346924b86bdb63f0974ad7c041b05
meta: {size:3336, lines:0, sha256:"4be54d4f75d21ac73addb6602e3190739a1d081f9d2972e48b40bd847fb7fd1a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/32/942a8fa9c185f14c9ce1892c13a3581fcb1796
meta: {size:80, lines:0, sha256:"d1d1803fa1d438d6b2cde48a867bcda394b77b8e1eb8e0f5099f7aaf8e0062ee", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/32/aba79554051296e1af8bb9e8f1fbf5ed389df7
meta: {size:1362, lines:0, sha256:"8a6af6075b42d256e89bde4ce2edab07a613c018763c8286828fffef129fe612", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/32/e858813226f942c7b6f20feb59364818e1beac
meta: {size:1388, lines:0, sha256:"82b4b02d47d4b9ad9dd28ac9411cded88e877e47f58981cefea276d07a8d6b3d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/32/eb0a1aeafc4e9db5bdf1042c47d4aee2a9d766
meta: {size:1358, lines:0, sha256:"8eeb3d8d1234f8073a3c9f643185ab485d8d79bc8184668b67777e3ae545e787", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

