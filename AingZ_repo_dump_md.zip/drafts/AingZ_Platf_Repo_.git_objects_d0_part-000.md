---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/d0
part_index: 0
files_included: 10
size_bytes_sum: 18533
created_at: 2025-08-31T21:08:15.648964+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/d0/079298ac2d792c364ee544c60ba727fe305447
meta: {size:551, lines:0, sha256:"a9bd105a72cac485c34cd0fe3a524c49facb350b50e04e6aee6a5440d7f7ec23", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d0/2cfa8e317ee8745d0944658c959f2e058e3e99
meta: {size:117, lines:0, sha256:"4a1c27fb3e43d2ddc14f8e56cf68f1c0ab93c59656121868fda97b7d04430949", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d0/46224a9fbb17428bcabc3a38490ef34e382cee
meta: {size:518, lines:0, sha256:"e6750d751d4bb81aa11aeb9ac8a4061bf48f119fab81c56950788f411dfd9052", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d0/980c689e9af7f1d827a03e32458c0dc3f1c296
meta: {size:918, lines:0, sha256:"71bd8ba3dc2558d6314fa32bf291c20b71f0d56b366170214c36e1c2265d767d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d0/a9ed7d19e3eba8455cd62597c4400f0d2b9de9
meta: {size:533, lines:0, sha256:"9ae920dd86c55a907293f71292d2d6fb456a93e2569def82a991a0db08b50d20", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d0/c59ad8f1e8bd8d208352917c1767844f428bc1
meta: {size:330, lines:0, sha256:"e9ab2dc30909ac7c9a6100140444d390b40d7e3aa454bf4cd733eada253d2c08", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d0/ececd4b8b8dfbc19ca57f5460c02e1bf397009
meta: {size:1741, lines:0, sha256:"4444434f4ccbb6eb5583821bdf70ebd39ec45dd7c30a64c230cf16d2df95805d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d0/edc9f95d168cc9351c01443c1a2c6bded18da5
meta: {size:847, lines:0, sha256:"04cb3f4dfd6590dd2d8c81a6d424aebc9c39c54cabb491ecb6ce9a8de17f0a87", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d0/f491de2dc2d82cd0ec016b271d835a4d5fad54
meta: {size:11832, lines:0, sha256:"35c376f68825fa09bfd607cf190494469f63f5fd1865facf0077aed19c29f9f7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d0/ff51cc63e915439bccc323f9325152851f2aca
meta: {size:1146, lines:0, sha256:"df1cd521bd82a00d53c6a5ca15582724df382a299a027a3cc7bd9914115ba9d4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

