---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/74
part_index: 0
files_included: 6
size_bytes_sum: 6731
created_at: 2025-08-31T21:08:15.624071+00:00
integrity:
  sha256_concat: ba3fd3644d89b9c18aaaa5014969806a287f3e4af80e2d96fae6ddb537b26184
---

## AingZ_Platf_Repo/.git/objects/74/1bfc865d21259f3b8a2b304115e3b0477e6abb
meta: {size:614, lines:7, sha256:"e3e4a0a4a127dfc833e88ef666dea10bed5214fdaa6bcc52ea931d9ec36ce390", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x}ßkÛ0Ç÷ì¿âÞ,ÄÐÁ`<ÈÒP
][Ò¾Rb-	IacÿûNc/%Áî{¿>wÞvz7¾|þ {£­awFXYkuFø}'·0\>Ók6<[Ì²õÝrõßÞo pÉòÜúY5ØB+UÃëN8Ç[Ù¡c´X{m(Aº¬upÞèG=ZEn-µîÙd:Ç÷wOõjù².¢Æ¢?äÍ@«-
Æh¥ÝQ¥,ÿ [0¥L	±jNáJÂÖ{fJá¸ÑNþbEñ>²³ú`øöÈèÎ¸!Ùxã(×ßb"cøh

E%;
â©5âÐy
Íàí½(1¨fÎI!!ÇÂ_õ¨ý"fR8ñ+vwèQùç@Ó²]m¥ñR«*©."B¶Ç¢e)&ÄÎX>1Èg°ÇÎTù*àBðzáë=`¹+áûëf·O«kþæùÉçó½Ý©hØ4bÅ)Þ7áp"b:ªçjys0¬GGþEÚàh{{À±½þ	ZuG±C8¹!Æ0h-/¨&¿R±N Elþ±L¦Ë¸>Á°OQT]Y%ª(è&4I8e|'7úK´	)âØËaCJ_ÄOF6ÎvØ±aª¥ÇÞÑ:ÏÕ°ðn¦¸:úÞ`ÃÎõCÇâüY©<¢m8ûßjMö9Àp­0í¥ÅãærU9ççyª8ÑÊþB£0
```

## AingZ_Platf_Repo/.git/objects/74/45c94e92acd27711822a3ccfb091868d078348
meta: {size:126, lines:0, sha256:"7d50a32de0132dec02878d71437f0e0430c9ad2c77603097d59610d5193a9c45", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/74/64cc195ba51ee824e9fa48d0062aef4a888b32
meta: {size:178, lines:0, sha256:"89e759113c762371e76d81ab3220fc7c7316cbcc942ed12d737309c1aa3e283b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/74/9dceba235c5f0627be554886a9ae07ffb5cdf3
meta: {size:1370, lines:0, sha256:"68a95734c2608be881fca18353ebc6650cf5c6bff9998a1156f79a7cfa534004", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/74/e0f0747d1dde2d33b0d3559ff96cc71139d7a0
meta: {size:3226, lines:0, sha256:"46f69eb6b332f8dd1bb39ff7610d3e695d7fe519e191937c5da1cb9d04bae492", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/74/f26ba9aae28f7ab10d78d2665f514e581a6a99
meta: {size:1217, lines:0, sha256:"2dbf4d9e61a10fa6f8e0716dcefebc10548d44732f6107543b22f2b50e46c9bb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

