---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/8e
part_index: 0
files_included: 4
size_bytes_sum: 2397
created_at: 2025-08-31T21:08:15.627233+00:00
integrity:
  sha256_concat: 676825f87d950ca31907fc50e3d041488c878e195a67d5349ce3eb90f045c965
---

## AingZ_Platf_Repo/.git/objects/8e/33b8e4bd5de182bcd32c985fc80a6c9916a8c0
meta: {size:1157, lines:0, sha256:"c5a099fc57c7bf9b5bb0cb8c58b5cc9bb48cd70d28401039f12a1b76035cfa2e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8e/4cd1ec5de99449e3ecce1adcd561a13d220a96
meta: {size:1032, lines:0, sha256:"497c04593ce225da0360d55546767e419361047df00ab2de6ea4b7337c580644", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8e/596d2777ed65e990f82d0433861f649ea1fba8
meta: {size:53, lines:1, sha256:"aec519fe174b67bad258843948caf10bc83bd978955efbf7ad9df02637abfac7", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU06g040031QrutñuÕËMaØmÔ²¼êO§Ñæ=,D¥,EZ1üÉ
```

## AingZ_Platf_Repo/.git/objects/8e/bcfe0e1385d68d47c64098833910c2b6cf35af
meta: {size:155, lines:0, sha256:"9ead08f8d1dff5b081575549cb09d4447c2b65a8236a834839137420b06eaf14", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

