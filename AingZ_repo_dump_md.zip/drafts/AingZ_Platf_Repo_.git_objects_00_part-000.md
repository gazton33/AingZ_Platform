---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/00
part_index: 0
files_included: 7
size_bytes_sum: 5216
created_at: 2025-08-31T21:08:15.565596+00:00
integrity:
  sha256_concat: e9703c6b85d834d99d04c702c90f61a91b18f818680e94369509a21c671d60b4
---

## AingZ_Platf_Repo/.git/objects/00/041c36451b1d408610bf64d82e82253169312c
meta: {size:841, lines:0, sha256:"864a9f38d2c80ec6ba905865cf1a940cf27035a379fb171d814859e2211e9af7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/00/3aa6cf26b36b3c39613669373aaf54be395211
meta: {size:441, lines:0, sha256:"7bc1727bba1a7a7191a2bb37f2a06514bc274e3f1dbc4bb15595785587f8bafe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/00/6a45a280dc3dd6dde1463978f27924122a7231
meta: {size:1148, lines:0, sha256:"91b1316961b931771db2f6454f5add45881c13708e78527c7c70f2f89133f6d9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/00/6e12cdafb2d402c120a8534dfd6e8b96ec046c
meta: {size:404, lines:4, sha256:"3b4f549307c9a619e128f1809d27d82312bae2068f1e827f54e39873b2d4d364", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÍT]Kë@õ9¿bÀ>Å¤µ~Ð¡¶A
±ÚÞûpeèÂf7ÌnÕ?Þ©xlCA,l2KØ3çìÉpÆ- }vÚ98½wÖsdQEQö,«Ú  ´ÒQ%C/¡vºqÚæ/PËðÚàQ¥øË%i,A¡/H×A;®óÖ<â8æÌk%*(ÈyO|\[fýáuÆ=z@Ob!f5iÄ£è
|hVN0ýHÏEzºæ/ÀèUa0	XÕIspC!ôIÔFÚ]¤4#ÆÕ>áGJU!óöx´YVÃ+÷óÂ78ö>{ïÎ}ì÷ÑÁæ2Zòswÿ6\÷ÑÉíò~ÕÁ/Ù6çL£ñë|Ô2ñ§ûf#Lhi<dÓYþuÆé9/ÝO
ÞÏ¦W¢?fbC)99TÿeDÖAçÆü²xuf#P°V=h}¶¶q&ãÛI>ögÙnLÿ7ØÊßþ½Ùá>kX+z=áY
```

## AingZ_Platf_Repo/.git/objects/00/73b3dacad71b20435fb94e46820c4ba93fd1bc
meta: {size:1602, lines:0, sha256:"b46a4379bd6a81937c32072f4e02f5376ad070cc43c6799b363b98aba11f0e44", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/00/c5b07e7683a9d4c4ea43be66440ac6e03a835d
meta: {size:321, lines:0, sha256:"dd7c7a87dcc40cd016ac6f1e959b439a29c169ee67b0473c18e87ffe0628f6cd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/00/fddb0d2721798ec99f50ac5e3aa0ad30b26902
meta: {size:459, lines:0, sha256:"11b0bc42787d23b848db5607c9dc124a1d3ddc38f50e054b92569a6ff211b869", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

