---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/88
part_index: 0
files_included: 8
size_bytes_sum: 53788
created_at: 2025-08-31T21:08:15.626401+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/88/12701d7896a22ad41ab7ca9076af46f023aabf
meta: {size:7444, lines:0, sha256:"12273640381aac8dfc5c64925bcd4ab437e0116c1c4fe9a5304465ab290e1a53", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/88/4eb4c03b1cb5d6661ca38f499c10385835d09e
meta: {size:211, lines:0, sha256:"de35441f581184445b55a08f370659095d96c976d0f7d0b324798cea9b61c699", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/88/6bb787c1fdc06b280e43abd9064db18e01df61
meta: {size:517, lines:0, sha256:"509c29009b6803e7bc3e20f6cf6c93817549c7f7c748ed421c9cc194140cce32", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/88/79a86cf1391f05e9960fa9054a2a1ac01e26cc
meta: {size:495, lines:0, sha256:"33aa47a63358ee7775d39738fee5cc3e5d07bfe25a1aa3a2c856844189435188", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/88/c77f03564123e45e859c9b0d06812a4cea201e
meta: {size:41818, lines:0, sha256:"adae2dabf93515921f51330609a0d78122497c9338f8d92e84d5167692c72ab6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/88/cdc7910e6e3dd9f2e315f61ae5e3c25569767b
meta: {size:837, lines:0, sha256:"8be11b0c5180d625ee6ea01c140bb1065ee24cdb403ce0ca89f76cf366f664f8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/88/da80604d976d7a9e318327a59199dc839c6c01
meta: {size:1806, lines:0, sha256:"f1ee7946d7705be73bd8ace03ec338a6bba38e049cea859ac5072f0429df22ed", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/88/dce579872a90253c3935ade0e35ba0c920a20c
meta: {size:660, lines:0, sha256:"c43764ba94091ad00de2a24c94debf38ff99147a05bb627c22bede8ff0d7e6d5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

