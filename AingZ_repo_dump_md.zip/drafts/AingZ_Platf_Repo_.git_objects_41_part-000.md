---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/41
part_index: 0
files_included: 12
size_bytes_sum: 12329
created_at: 2025-08-31T21:08:15.573020+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/41/050a53abe7b8db00a3c083aa5e7241e849a2ae
meta: {size:580, lines:0, sha256:"bc58b33bf618b7bb8c9d6aecb226d216b38905956160ddf37e0a60b033cff783", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/41/20fecffd1d417eb20a0dc405eccd27d06b17ee
meta: {size:76, lines:0, sha256:"bdecb754950584f6f6aec4d4ef5f1e927557d1b5f0f024e762571601e1e3557d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/41/4ee408015b67c16e10806b65f23984edbc4512
meta: {size:116, lines:0, sha256:"c149276b2ed08b9f6eedb835dcb91fbf9f8a68d99ed8f90574a541d1451b036f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/41/549d4d904de3d21cc5da9447304ae805579ec4
meta: {size:5362, lines:0, sha256:"b6e880af97ba21c0c9fcf81a7d6438d829897d9eb3a2d94a2bbc3daffea5e347", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/41/655fe6daaaa2fd345f2d1122cd686b20943861
meta: {size:88, lines:0, sha256:"29a2f3ebe75b7423458fa09db2b0b958043041209511910bf909f00dbb608bae", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/41/759f9b517580d38cf976670fd21646b8f518e2
meta: {size:766, lines:0, sha256:"83cb67759db7cf9488891d077cd655e3f858454b64304ebc0b2f30c19491fa03", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/41/7b5dc938615e66913e659f721f397a966b98b5
meta: {size:407, lines:0, sha256:"31e9bbd858b21f66918975fb6e7f7309edcea7bfdcbeb894e6a65b25c9631c73", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/41/87998a8cede0705841804669799d5515694a7b
meta: {size:68, lines:0, sha256:"c0f3ad632cfb8f3fda26ea4a07636292a2e8d3f42a9e54ebb7196e764e4f8cde", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/41/9603f5098a4f0bfe7ce779eebae5f2bc173b5a
meta: {size:968, lines:0, sha256:"d8cf4378fbd364ab7e18c24c43295980c40db4dff33f98d6fd12eefd13839e60", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/41/ab64a8d2f7cce34dd3421add2a07ffbca9644d
meta: {size:1491, lines:0, sha256:"0e412ba03fc6e347f972b979291b50a5d4d25e5a9b1f7f71f6220bfaf438d8e8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/41/ad08a0e23261d89929cf066890405e9a5f319a
meta: {size:2250, lines:0, sha256:"a373cee288eb7ffaa034d9b551cec980615ca5532223a5f67097fd051da38412", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/41/fa5b77e2365fe70a8e9a4466d8fcf0e8434d7d
meta: {size:157, lines:0, sha256:"3a92d25d464f8efc20ed144294d840aaca4ce6d1047d0fa34bf6412b6aed810c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

