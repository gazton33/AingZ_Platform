---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ed
part_index: 0
files_included: 7
size_bytes_sum: 7409
created_at: 2025-08-31T21:08:15.651427+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/ed/240ba5fb0a28c6b17e88bf980d169be6c4ee86
meta: {size:1071, lines:0, sha256:"c7a80de2fd7a39880a29a959d2acf91763df414af9ce381b6d06c23d533e8287", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ed/3a667e62a884db141431a5dcc6f11ecafd0d16
meta: {size:548, lines:0, sha256:"350d4f8a49637d429e0ddfc195842142cc2b8ac51d518430b27f075d2d5220b9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ed/3ba42d4a8aea4145e801e290850ae0b4ea68be
meta: {size:4486, lines:0, sha256:"918834c582e2ef36da309c5dde9f8f664417d95b3153552188c2de58284a5f0c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ed/53ae2385e503dd27affeca1695e64ff28c099e
meta: {size:111, lines:0, sha256:"49d630fca2db94e2b078232e8cec1b7aa98eb958a01c43e28a0d04101e91fedb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ed/a162954dfc606e0992ef47a4ae3173ab845870
meta: {size:634, lines:0, sha256:"7790637cad4d85db0dd068c67c7f6f965842419fdec1f26a7aed15a7bb087d49", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ed/a30d8f113a603f6c419695291ce496651b040c
meta: {size:505, lines:0, sha256:"64fe6262ed4bdaea5685012e8a2fe4f35f551a8df33298496fa052f8cc0f047e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ed/bb679ff07d8a39b30192deb4d89f94f5dd66fd
meta: {size:54, lines:0, sha256:"385280cb127540a4c55a4da7c3fab0877f246d5001825da9ac82d63bdd30164a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

