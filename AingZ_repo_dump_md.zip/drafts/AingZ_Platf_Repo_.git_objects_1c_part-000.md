---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/1c
part_index: 0
files_included: 10
size_bytes_sum: 10333
created_at: 2025-08-31T21:08:15.568659+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/1c/0ebf7db0a4ae61f12239103f95fb5e495b07f9
meta: {size:2961, lines:0, sha256:"f9cca98be8bc02188294803453f3c23b5a02044d24d4d852843d1911666db068", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1c/14a38e18ac957043162849e5898c67d7f28c0c
meta: {size:1581, lines:0, sha256:"44d713fdc49a9c82ba853ebf0785b70f95bff57b6c75aafd53fb7b9ce05ef2f1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1c/7f9b54bbc88ffaa9dfdac7441c34f64222b33e
meta: {size:256, lines:0, sha256:"d2456914884e9785367a48c45dc38029be04e74bf8f278eacd8138b27f86e5d8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1c/8fbe2f39bbd3224237bd182097590fbb2e9ae5
meta: {size:1034, lines:0, sha256:"d296157daede13e0dca20f73b29cc560ddc57424efc3baf070fc6aeff9cc45f1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1c/99fe52873af1182c001b54af485aadc7177573
meta: {size:116, lines:0, sha256:"c2170ea935fe60be17503c78ab2695d5c8d9c9a818eb580b260962df24246d51", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1c/9fa60c1e74e477ed7b4dc396a9da8e56862614
meta: {size:289, lines:0, sha256:"5516a332eb3c7181cb7f20e6e6520af41a759a85d2bef552b5c7936c09720a57", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1c/a41ed2fe227b9f54aadef0dca7b0b96095776a
meta: {size:1193, lines:0, sha256:"c4c495e7b66a91ac0a68de2b8b4e895538acbca0187b694837cd16d37ad602b4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1c/aa0bfbd21e8fd7e3f188a610843de99c2fb48c
meta: {size:1163, lines:0, sha256:"b1a4affb775568059472408230d898e867beb46c9b7228aad4a517e1ed937f02", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1c/ce32ad0c0809a5136fb20c9b6c915e01930d3d
meta: {size:852, lines:0, sha256:"b41a6010108ec1fb448d5114d06afb6fd61c92beea87d1f61db648f05481025c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1c/dd4af2d60cc736a34b05030822ff2a6eca4fdc
meta: {size:888, lines:0, sha256:"cf82a34e4d72ec99763cfaeccc14696f8a7eb921423ec5a3a1a33a1a02b389bd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

