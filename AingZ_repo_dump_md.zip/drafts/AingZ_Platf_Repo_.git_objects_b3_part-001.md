---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/b3
part_index: 1
files_included: 9
size_bytes_sum: 29516
created_at: 2025-08-31T21:08:15.629736+00:00
integrity:
  sha256_concat: 4275f8234320cb2d63d468b8938d252067c2de7794f5627bf8ea7c2b43614e27
---

## AingZ_Platf_Repo/.git/objects/b3/5389ad78888a228e502b7fc561c1890945a224
meta: {size:1004, lines:0, sha256:"661b0253d6c22e461174eb6f7fe6ee6f703f0afe4e775bd93108845c122b6941", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b3/8a9cf5b5d97f41294ec2a16c5cba7f48d47698
meta: {size:24331, lines:0, sha256:"76d33304ffb36019a7d9b279acc72a24be1260f678b9c7a2c9ea082e17cd396a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b3/9cf0778243a5a08e3de6486bf5ced3da75b077
meta: {size:267, lines:0, sha256:"b8e14d4cd4676109d2d02a02aac3c8d97df326e43f4364828019e5555a43d20a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b3/a67bd6d319e325fd3b3ca0cce913b65bb45dae
meta: {size:2093, lines:0, sha256:"6eb4cc662b57fac843679ead69f81924b8f8c22dadfbbf1ac6fa1dd66abb6f23", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b3/bfe4f9692b5dc8db01be565daf4542f7145722
meta: {size:132, lines:1, sha256:"ecfd85ea4f6879e43549819f6045383841bba2aabf45855c7052245ee86bb3f0", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU043c040031QH,(ÐË*ÎÏc§vÿÝ¶gm×y&J&îÝºI¡&5±(1/9 Òäü¢TÝÒôÌ¼bâåBîq¸;ßòÎõ2a÷|Û%¡æçe$ÂçæÚ_jÀø©£jë*·í¶|CÛ
```

## AingZ_Platf_Repo/.git/objects/b3/cb45ae9be84c1ad40fa82c40216a717d000fea
meta: {size:85, lines:0, sha256:"75ed350063bbd0270a4f12d03b2445cfc338c4eb62409eff61c27f67a7ccf851", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b3/df0f2cc25ef0f49d98a9b172f1726004d8c878
meta: {size:54, lines:0, sha256:"98713426e2dbd623bac85cbf6202bd5d09865ac2794809c5c57a2c2d6f4c261d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b3/eae99837209b51b2c718c3ac17c068e5c2a71f
meta: {size:177, lines:0, sha256:"aae1a5a76b826c5f45d6e74a68a928bcb6cc00e87e30ab2047a84d2ab7f3498b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b3/fe18d0c5fe00bd9b08c4083badd6e9ea2b7a1c
meta: {size:1373, lines:0, sha256:"ccde8dd8cb5feef8fa74faba65eabada491d6de3ed569f3cf636aa7bbf441723", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

