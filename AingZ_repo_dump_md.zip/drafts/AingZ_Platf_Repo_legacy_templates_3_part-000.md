---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/legacy/templates/3
part_index: 0
files_included: 2
size_bytes_sum: 13860
created_at: 2025-08-31T21:08:15.667075+00:00
integrity:
  sha256_concat: 895016c15456f366031742af3bb0941b0fc0a5129b04601d7e148a5e4185a277
---

## AingZ_Platf_Repo/legacy/templates/3/aingz_v_5_glosario_diff_interactive_2025_08_18.md
meta: {size:6949, lines:168, sha256:"2fbab38b898ea2e315f3359a954fa8e15f962ac073bcd3c7ca5954ef5cc5f3c2", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: glossary.diff.interactive code: GBLD name: GlosarioDiffInteractive version: 1.0.0 date: 2025-08-18 owner: Arch status: Draft refs: [GLOS::, RULESET::, WF::, DIR::, QMS::, CHG::, TPL::] triggers: [qa\_glosario, router\_chain] changes: [] checks: [no\_file\_refs, wikilinks\_only, router\_chain\_enforced]

# Canvas interactivo — Revisión y validación de *diffs* de glosarios

> Política: sin rutas ni enlaces a archivos. Solo namespaces aprobados (DIR::, GLOS::, RULESET::, WF::, QMS::, CHG::, TPL::).

## 0) Instrucciones de revisión

1. Validar mapeo *Legacy→V5* en §2.
2. Confirmar altas/renombres/deprecaciones en §3.
3. Aprobar *patch plan* de integración a [[GLOS::GlosarioReal]] en §4.
4. Ejecutar checklist §5 y firmar §6.

---

## 1) Resumen del origen (versión adjunta)

```yaml
source_summary:
  name: CodeSemanticsV5 (MAIN)
  version: v5.0.0-rc2
  date: 2025-08-12
  status: working
  scope: genérico, sin rutas
  notes: "Sub-secciones listas para feedback iterativo"
```

---

## 2) Mapeo Legacy→V5 (propuesta inicial)

> Edite la columna *Acción* y el *Target V5* cuando aplique. Sin rutas.

| Legacy.CODE | Legacy.Name       | Acción                 | Target V5 (canon)          | Notas                           |
| ----------- | ----------------- | ---------------------- | -------------------------- | ------------------------------- |
| RULE        | Ruleset           | mantener               | [[RULESET::INDEX]]         | Autoridad normativa             |
| LITW        | LiteralWork       | **agregar**            | [[QMS::Checklists]] · LSWP | Unificar con LSWP en control    |
| CFG         | Configuration     | **agregar**            | GLOS::Config               | Declarar límites por entorno    |
| SPEC        | SpecificExtension | **renombrar**          | RULESET::SPEC              | Extensión neutral               |
| BLN         | Baseline          | **agregar**            | GLOS::Baseline             | Snapshot QA                     |
| PKG         | Package           | **agregar**            | GLOS::Package              | Release firmado                 |
| CTX         | Context           | **agregar**            | GLOS::Context              | Ámbito lógico                   |
| MOD         | Module            | **agregar**            | GLOS::Module               | Interfaz estable                |
| TRG         | Trigger           | **alinear**            | [[WF::]]                   | Triggers sólo bajo WF::\*       |
| PIPE        | PipelineScript    | **verificar colisión** | GLOS::Script.Pipeline      | Evitar choque con [[DIR::PIPE]] |
| SCR         | Script            | **agregar**            | GLOS::Script               | Ejecutable puntual              |
| TST         | Test              | **agregar**            | QMS::Test                  | Exit codes claros               |
| AUDT        | Audit             | **agregar**            | QMS::Audit                 | Evidencia formal                |
| LOG         | Log               | **agregar**            | [[DIR::LOG]]               | Append‑only                     |
| RDM         | Readme            | **alinear**            | GLOS::Readme               | Onboarding + contrato           |
| MTR         | Matrix            | **agregar**            | GLOS::Matrix               | CSV/JSON                        |
| VRS         | VersusMatrix      | **agregar**            | GLOS::Versus               | Comparativas                    |
| KNS         | Knowledge         | **agregar**            | GLOS::Knowledge            | Núcleo de saberes               |
| INSI        | Insight           | **agregar**            | GLOS::Insight              | Accionable                      |

> Si detecta más códigos, añádalos aquí. Este cuadro es el *backlog* vivo de normalización.

---

## 3) Deltas propuestos (auto‑clasificados)

> Revise y marque *OK*.

### 3.1 Altas (no existen en [[GLOS::GlosarioReal]])

-

### 3.2 Renombres / Reubicaciones

-

### 3.3 Deprecaciones

-

---

## 4) Patch plan — Integración a [[GLOS::GlosarioReal]]

```yaml
patch_plan:
  add:
    - LITW: {name: LiteralWork, contract: "Barrido literal 100% sin inferencia", refs: [QMS::Checklists]}
    - CFG:  {name: Configuration, contract: "Parámetros operativos declarativos", refs: []}
    - BLN:  {name: Baseline, contract: "Snapshot QA de referencia", refs: []}
    - PKG:  {name: Package, contract: "Unidad empaquetada firmada", refs: []}
    - CTX:  {name: Context, contract: "Ámbito lógico de trabajo", refs: []}
    - MOD:  {name: Module, contract: "Interfaz estable y versionada", refs: []}
    - SCR:  {name: Script, contract: "Ejecutable puntual con side‑effects controlados", refs: []}
    - MTR:  {name: Matrix, contract: "Tabla/DF. Export CSV/JSON", refs: []}
    - VRS:  {name: VersusMatrix, contract: "Comparativas con criterios trazables", refs: []}
    - KNS:  {name: Knowledge, contract: "Núcleo de saberes", refs: []}
    - INSI: {name: Insight, contract: "Hallazgo estratégico accionable", refs: []}
  rename:
    - TRG→WF: {rule: "Triggers sólo bajo WF::*", action: "mover alias TRG_* a WF::*"}
    - PIPE.script: {rule: "Evitar colisión con DIR::PIPE", target: "Script.Pipeline"}
  deprecate:
    - RWB: {replaced_by: SPEC, note: "Neutralización de marca"}
    - RWS: {replaced_by: SPEC, note: "Neutralización de marca"}
validation:
  assertions: [no_file_refs, wikilinks_only, router_chain_enforced]
```

---

## 5) Checklist de aceptación (glosario)

```yaml
checklist_glossary:
  schema:
    - [ ] Cada entrada tiene {CODE, Name, Contract}
    - [ ] Sin duplicados de CODE
    - [ ] Sin rutas ni URLs
  semantics:
    - [ ] Crossrefs sólo en namespaces aprobados
    - [ ] TRG bajo WF::*
    - [ ] Publicación de E/S de PIPE sólo como [[DIR::*]]
  coverage:
    - [ ] Legacy→V5 coverage_pct == 100
    - [ ] broken_links == 0
```

---

## 6) Firma y registro

```yaml
signoff:
  reviewer: <tu_nombre>
  date: 2025-08-18
  decision: approve|changes_requested
chg_log:
  - id: CHG-2025-08-18-008
    title: Diff validado CodeSemanticsV5 → GlosarioReal
    outcome: pending
```

---

## 7) Previsualización de entradas (si se aprueba §4)

> Estas entradas se agregarían a [[GLOS::GlosarioReal]].

```yaml
preview_entries:
  - code: LITW
    name: LiteralWork
    definition: Barrido literal 100% sin inferencia
    scope: QA y auditoría
    refs: [QMS::Checklists]
  - code: CFG
    name: Configuration
    definition: Parámetros operativos declarativos por entorno
    scope: Global
    refs: []
  - code: BLN
    name: Baseline
    definition: Snapshot de referencia de QA
    scope: Control de calidad
    refs: []
```

---

OutputTemplate: example: diff\_review: status: READY actions\_required: [validate\_mapping, approve\_patch] coverage\_target\_pct: 100 router\_chain: [README, RULESET, PIPE] log: - step1: authoring - step2: validation

```

## AingZ_Platf_Repo/legacy/templates/3/aingz_v_5_glosario_diff_ui_2025_08_18.md
meta: {size:6911, lines:165, sha256:"a4c6b237705007fa4af7c96a30c33607c2c5eccec4849452b4e7233c8c070e6d", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

## file: glossary.diff.ui code: GBLDUI name: GlosarioDiffUI version: 1.0.1 date: 2025-08-18 owner: Arch status: Draft refs: [GLOS::, RULESET::, WF::, DIR::, QMS::, CHG::, TPL::] triggers: [qa\_glosario, router\_chain] changes: [CHG-2025-08-18-009] checks: [no\_file\_refs, wikilinks\_only, router\_chain\_enforced]

# UI de validación dinámica para *diffs* de glosarios

> Interacción vía casillas, listas editables y bloques YAML. Sin rutas ni URLs. Solo namespaces aprobados.

## 0) Controles rápidos

-

---

## 1) Resumen del origen a integrar

```yaml
source_summary:
  name: CodeSemanticsV5 (MAIN)
  version: v5.0.0-rc2
  date: 2025-08-12
  status: working
  scope: generico, sin rutas
  notes: "Listo para normalización a V5 canon"
```

---

## 2) Editor de mapeo Legacy→V5

> Marque la **Acción** y ajuste **Target V5**. Añada filas si faltan códigos.

| Legacy.CODE | Legacy.Name       | Mantener | Agregar | Renombrar | Deprec. | Target V5 (canon)          | Notas                           |
| ----------- | ----------------- | -------- | ------- | --------- | ------- | -------------------------- | ------------------------------- |
| RULE        | Ruleset           | [ ]      | [ ]     | [ ]       | [ ]     | [[RULESET::INDEX]]         | Autoridad normativa             |
| LITW        | LiteralWork       | [ ]      | [ ]     | [ ]       | [ ]     | [[QMS::Checklists]] · LSWP | Unificar con LSWP               |
| CFG         | Configuration     | [ ]      | [ ]     | [ ]       | [ ]     | GLOS::Config               | Por entorno                     |
| SPEC        | SpecificExtension | [ ]      | [ ]     | [ ]       | [ ]     | RULESET::SPEC              | Neutral                         |
| BLN         | Baseline          | [ ]      | [ ]     | [ ]       | [ ]     | GLOS::Baseline             | Snapshot QA                     |
| PKG         | Package           | [ ]      | [ ]     | [ ]       | [ ]     | GLOS::Package              | Release                         |
| CTX         | Context           | [ ]      | [ ]     | [ ]       | [ ]     | GLOS::Context              | Ámbito                          |
| MOD         | Module            | [ ]      | [ ]     | [ ]       | [ ]     | GLOS::Module               | Interfaz                        |
| TRG         | Trigger           | [ ]      | [ ]     | [ ]       | [ ]     | [[WF::]]                   | Solo WF::\*                     |
| PIPE        | PipelineScript    | [ ]      | [ ]     | [ ]       | [ ]     | GLOS::Script.Pipeline      | Evitar choque con [[DIR::PIPE]] |
| SCR         | Script            | [ ]      | [ ]     | [ ]       | [ ]     | GLOS::Script               | Ejecutable                      |
| TST         | Test              | [ ]      | [ ]     | [ ]       | [ ]     | QMS::Test                  | Exit codes                      |
| AUDT        | Audit             | [ ]      | [ ]     | [ ]       | [ ]     | QMS::Audit                 | Evidencia                       |
| LOG         | Log               | [ ]      | [ ]     | [ ]       | [ ]     | [[DIR::LOG]]               | Append-only                     |
| RDM         | Readme            | [ ]      | [ ]     | [ ]       | [ ]     | GLOS::Readme               | Onboarding                      |
| MTR         | Matrix            | [ ]      | [ ]     | [ ]       | [ ]     | GLOS::Matrix               | CSV/JSON                        |
| VRS         | VersusMatrix      | [ ]      | [ ]     | [ ]       | [ ]     | GLOS::Versus               | Comparativas                    |
| KNS         | Knowledge         | [ ]      | [ ]     | [ ]       | [ ]     | GLOS::Knowledge            | Núcleo                          |
| INSI        | Insight           | [ ]      | [ ]     | [ ]       | [ ]     | GLOS::Insight              | Accionable                      |

---

## 3) Deltas propuestos

> Marque **OK** en cada bloque.

### 3.1 Altas

-

### 3.2 Renombres / Reubicaciones

-

### 3.3 Deprecaciones

-

---

## 4) Patch plan — a [[GLOS::GlosarioReal]]

> Este bloque se usará para aplicar cambios.

```yaml
patch_plan:
  add:
    - LITW: {name: LiteralWork, contract: "Barrido literal 100% sin inferencia", refs: [QMS::Checklists]}
    - CFG:  {name: Configuration, contract: "Parámetros operativos declarativos", refs: []}
    - BLN:  {name: Baseline, contract: "Snapshot QA de referencia", refs: []}
    - PKG:  {name: Package, contract: "Unidad empaquetada firmada", refs: []}
    - CTX:  {name: Context, contract: "Ámbito lógico de trabajo", refs: []}
    - MOD:  {name: Module, contract: "Interfaz estable y versionada", refs: []}
    - SCR:  {name: Script, contract: "Ejecutable puntual con side‑effects controlados", refs: []}
    - MTR:  {name: Matrix, contract: "Tabla/DF. Export CSV/JSON", refs: []}
    - VRS:  {name: VersusMatrix, contract: "Comparativas con criterios trazables", refs: []}
    - KNS:  {name: Knowledge, contract: "Núcleo de saberes", refs: []}
    - INSI: {name: Insight, contract: "Hallazgo estratégico accionable", refs: []}
  rename:
    - TRG→WF: {rule: "Triggers sólo bajo WF::*", action: "mover alias TRG_* a WF::*"}
    - PIPE.script: {rule: "Evitar colisión con DIR::PIPE", target: "Script.Pipeline"}
  deprecate:
    - RWB: {replaced_by: SPEC, note: "Neutralización de marca"}
    - RWS: {replaced_by: SPEC, note: "Neutralización de marca"}
validation:
  assertions: [no_file_refs, wikilinks_only, router_chain_enforced]
```

---

## 5) Checklist de aceptación

```yaml
checklist_glossary:
  schema:
    - [ ] Cada entrada tiene {CODE, Name, Contract}
    - [ ] Sin duplicados de CODE
    - [ ] Sin rutas ni URLs
  semantics:
    - [ ] Crossrefs sólo en namespaces aprobados
    - [ ] TRG bajo WF::*
    - [ ] Publicación de E/S de PIPE sólo como [[DIR::*]]
  coverage:
    - [ ] Legacy→V5 coverage_pct == 100
    - [ ] broken_links == 0
```

---

## 6) Firma y registro

```yaml
signoff:
  reviewer: <tu_nombre>
  date: 2025-08-18
  decision: approve|changes_requested
chg_log:
  - id: CHG-2025-08-18-009
    title: UI de diff aprobada para integración
    outcome: pending
```

---

## 7) Previsualización de entradas

> Se agregarán en [[GLOS::GlosarioReal]] cuando §4 esté aprobado.

```yaml
preview_entries:
  - code: LITW
    name: LiteralWork
    definition: Barrido literal 100% sin inferencia
    scope: QA y auditoría
    refs: [QMS::Checklists]
  - code: CFG
    name: Configuration
    definition: Parámetros operativos declarativos por entorno
    scope: Global
    refs: []
  - code: BLN
    name: Baseline
    definition: Snapshot de referencia de QA
    scope: Control de calidad
    refs: []
```

---

OutputTemplate: example: diff\_review: status: READY actions\_required: [validate\_mapping, approve\_patch] coverage\_target\_pct: 100 router\_chain: [README, RULESET, PIPE] log: - step1: authoring - step2: validation

```

