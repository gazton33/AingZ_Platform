---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/bc
part_index: 0
files_included: 14
size_bytes_sum: 19684
created_at: 2025-08-31T21:08:15.630359+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/bc/0e33e60ae9b036b3265e973eca825d6eaadeb1
meta: {size:1738, lines:0, sha256:"dae871aa332024f1110e35525bd7d49f9a0530326cc5cd6e554b23265f73c4bc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/1c826c3078a2f1df8f81742dabeb3ca300f094
meta: {size:753, lines:0, sha256:"f6dc03db78052aaebd4c01ae09858ebaa7afdea2990bc7e4ffeffb8e5778c233", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/40575236fd52c9ddc36f306d0096fc65194642
meta: {size:100, lines:0, sha256:"6fef5cd00d3235e5c5835ec38a183aea0ed9aa32f6355f25577a73fd15526fbe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/4265b0601990a81c527ab6b8fe2c582cef4628
meta: {size:206, lines:0, sha256:"d3f79f3396d059bcbff653bdee4b68341263bc6ccbab0f61132a4b21aa8f0cf8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/59005f218d6a03d902394adb9d40fd9a645d49
meta: {size:8993, lines:0, sha256:"729ffb8bb912bd7f2c581105305308adb125397115c58d426f169dea5a602e48", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/8145a2eaa6b6611b60850a9efa381a6c583456
meta: {size:534, lines:0, sha256:"962a7277f69f0af18a3d58d0e153531e8608545e13f11de0289a3847604c6e3f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/ac8a2879f828d926ecfde1948e8c37c486a99c
meta: {size:413, lines:0, sha256:"3cca15336b07d6a174c71ae325915ec52c77c52d373e60e11075829093937962", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/aeb3082cc6f50535e03033486f845f341d80e2
meta: {size:689, lines:0, sha256:"1b20750c39aef6721fe13aa61e33b421823b5ebb51a0a2625c9e785ee86af422", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/bb38beb5a9918dc3de1b5e33fc76b3df72c60d
meta: {size:1603, lines:0, sha256:"53721e55d2302a22bbe055cae9b871f0a466b17c5af32ce4d4bd47d01bbb7285", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/ca3197064a6c6125153d25e6df182c22baadc6
meta: {size:224, lines:0, sha256:"6f4d28e2078bf4894b29b367a74599d468ecba4a47a277d46f2510f178a46b35", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/cc9fa85aa5cbe1a78d2c33bb86ecaf9ad6ce38
meta: {size:841, lines:0, sha256:"7f456941289f29b629f1549c46a10c0f25575a46861ca3689ba0f2bdf7ab0986", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/d91769f44c181026d4c1a4ebe1723b2d288ed5
meta: {size:779, lines:0, sha256:"2cd7d634a97333acfec8ae4dd86ffff81e0660efa747d80fb9f0fea59cdd1593", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/e323bda2778aaf2dc2b533149c088c264f4941
meta: {size:1747, lines:0, sha256:"b5fd1558e70adf19a3e5a2666866aa5ec5e71925bfb0edfe0fc21e3c44b71429", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bc/e3bf941adcaf11361053413b9ebec6ac791705
meta: {size:1064, lines:0, sha256:"abc4863f04096f4e1622f55bb6692adb3d30da3ac701c12013f7b54a69b0437d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

