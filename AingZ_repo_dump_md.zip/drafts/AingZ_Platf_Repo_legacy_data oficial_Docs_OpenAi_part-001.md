---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/legacy/data oficial/Docs_OpenAi
part_index: 1
files_included: 2
size_bytes_sum: 112259
created_at: 2025-08-31T21:08:15.520360+00:00
integrity:
  sha256_concat: c69a28125551b9055c7fb8a2cbcf0e870c434c41d204349bed2ef884db8b5f25
---

## AingZ_Platf_Repo/legacy/data oficial/Docs_OpenAi/12.0.Resources.md
meta: {size:72364, lines:1457, sha256:"0bab8a8a10190d36c79e1024178c20a21a3b44eb7296db306a034f34edc232e7", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md


## Imported snippet – 2025-07-03 14:45:53

Data controls in the OpenAI platform
====================================
Understand how OpenAI uses your data, and how you can control it.
Understand how OpenAI uses your data, and how you can control it.
Your data is your data. As of March 1, 2023, data sent to the OpenAI API is not used to train or improve OpenAI models (unless you explicitly opt in to share data with us).
Types of data stored with the OpenAI API
----------------------------------------
When using the OpenAI API, data may be stored as:
\* \*\*Abuse monitoring logs:\*\* Logs generated from your use of the platform, necessary for OpenAI to enforce our [API data usage policies](https://openai.com/policies/api-data-usage-policies) and mitigate harmful uses of AI.
\* \*\*Application state:\*\* Data persisted from some API features in order to fulfill the task or request.
Data retention controls for abuse monitoring
--------------------------------------------
Abuse monitoring logs may contain certain customer content, such as prompts and responses, as well as metadata derived from that customer content, such as classifier outputs. By default, abuse monitoring logs are generated for all API feature usage and retained for up to 30 days, unless we are legally required to retain the logs for longer.
Eligible customers may have their customer content excluded from these abuse monitoring logs by getting approved for the [Zero Data Retention](#zero-data-retention) or [Modified Abuse Monitoring](#modified-abuse-monitoring) controls. Currently, these controls are subject to prior approval by OpenAI and acceptance of additional requirements. Approved customers may select between Modified Abuse Monitoring or Zero Data Retention for their API Organization or project.
Customers who enable Modified Abuse Monitoring or Zero Data Retention are responsible for ensuring their users abide by OpenAI's policies for safe and responsible use of AI and complying with any moderation and reporting requirements under applicable law.
Get in touch with our [sales team](https://openai.com/contact-sales) to learn more about these offerings and inquire about eligibility.

### Modified Abuse Monitoring
Modified Abuse Monitoring excludes customer content (other than image and file inputs in rare cases, as described [below](#image-and-file-inputs)) from abuse monitoring logs across all API endpoints, while still allowing the customer to take advantage of the full capabilities of the OpenAI platform.

### Zero Data Retention
Zero Data Retention excludes customer content from abuse monitoring logs, in the same way as Modified Abuse Monitoring.
Additionally, Zero Data Retention changes some endpoint behavior to prevent the storage of application state. Specifically, the `store` parameter for `/v1/responses` and `v1/chat/completions` will always be treated as `false`, even if the request attempts to set the value to `true`.

### Storage requirements and retention controls per endpoint
The table below indicates when application state is stored for each endpoint. Zero Data Retention eligible endpoints will not store any data. Zero Data Retention ineligible endpoints or capabilities may store application state.
|Endpoint|Data used for training|Abuse monitoring retention|Application state retention|Zero Data Retention eligible|
|---|---|---|---|---|
|/v1/chat/completions|No|30 days|None, see below for exceptions|Yes, see below for limitations|
|/v1/responses|No|30 days|None, see below for exceptions|Yes, see below for limitations|
|/v1/assistants|No|30 days|Until deleted|No|
|/v1/threads|No|30 days|Until deleted|No|
|/v1/threads/messages|No|30 days|Until deleted|No|
|/v1/threads/runs|No|30 days|Until deleted|No|
|/v1/threads/runs/steps|No|30 days|Until deleted|No|
|/v1/vector\_stores|No|30 days|Until deleted|No|
|/v1/images/generations|No|30 days|None|Yes, see below for limitations|
|/v1/images/edits|No|30 days|None|Yes, see below for limitations|
|/v1/images/variations|No|30 days|None|Yes, see below for limitations|
|/v1/embeddings|No|30 days|None|Yes|
|/v1/audio/transcriptions|No|None|None|Yes|
|/v1/audio/translations|No|None|None|Yes|
|/v1/audio/speech|No|30 days|None|Yes|
|/v1/files|No|30 days|Until deleted|No|
|/v1/fine\_tuning/jobs|No|30 days|Until deleted|No|
|/v1/evals|No|30 days|Until deleted|No|
|/v1/batches|No|30 days|Until deleted|No|
|/v1/moderations|No|None|None|Yes|
|/v1/completions|No|30 days|None|Yes|
|/v1/realtime (beta)|No|30 days|None|Yes|

#### `/v1/chat/completions`
\* Audio outputs application state is stored for 1 hour to enable [multi-turn conversations](./audio).
\* When Structured Outputs is enabled, schemas provided (either as the `response\_format` or in the function definition) will be stored. Other request content will not be stored.
\* When Zero Data Retention is enabled for an organization, the `store` parameter will always be treated as `false`, even if the request attempts to set the value to `true`.
\* See [image and file inputs](#image-and-file-inputs).

#### `/v1/responses`
\* The Responses API has a 30 day Application State retention period by default, or when the `store` parameter is set to `true`. Response data will be stored for at least 30 days.
\* When Zero Data Retention is enabled for an organization, the `store` parameter will always be treated as `false`, even if the request attempts to set the value to `true`.
\* Audio outputs application state is stored for 1 hour to enable [multi-turn conversations](./audio).
\* When Structured Outputs is enabled, schemas provided (either as the `response\_format` or in the function definition) will be stored as Application State, even if Zero Data Retention is enabled.
\* See [image and file inputs](#image-and-file-inputs).
\* MCP servers (used with the [remote MCP server tool](/docs/guides/tools-remote-mcp)) are third-party services, and data sent to an MCP server is subject to their data retention policies.

#### `/v1/assistants`, `/v1/threads`, and `/v1/vector\_stores`
\* Objects related to the Assistants API are deleted from our servers 30 days after you delete them via the API or the dashboard. Objects that are not deleted via the API or dashboard are retained indefinitely.

#### `/v1/images`
\* Image generation is Zero Data Retention compatible when using `gpt-image-1`, not when using `dall-e-3` or `dall-e-2`.

#### Image and file inputs
Images and files may be uploaded as inputs to `/v1/responses` (including when using the Computer Use tool), `/v1/chat/completions`, and `/v1/images`. Image and file inputs are scanned for CSAM content upon submission. If the classifier detects potential CSAM content, the image will be retained for manual review, even if Zero Data Retention or Modified Abuse Monitoring is enabled.

#### Web Search
Web Search is not HIPAA eligible and is not covered by a BAA.
Data residency controls
-----------------------
Data residency controls are a project configuration option that allow you to configure the location of infrastructure OpenAI uses to provide services.
Contact our [sales team](https://openai.com/contact-sales) to see if you're eligible for using data residency controls.

### How does data residency work?
When data residency is enabled on your account, you can set a region for new projects you create in your account from the available regions listed below. If you use the supported endpoints, models, and snapshots listed below, your customer content (as defined in your services agreement) for that project will be stored at rest in the selected region to the extent the endpoint requires data persistence to function (such as /v1/batches).
If you select a region that supports regional processing, as specifically identified below, the services will perform inference for your Customer Content in the selected region as well.
Data residency does not apply to system data, which may be processed and stored outside the selected region. System data means account data, metadata, and usage data that do not contain Customer Content, which are collected by the services and used to manage and operate the services, such as account information or profiles of end users that directly access the services (e.g., your personnel), analytics, usage statistics, billing information, support requests, and structured output schema.

### Limitations
Data residency does not apply to: (a) any transmission or storage of Customer Content outside of the selected region caused by the location of an End User or Customer's infrastructure when accessing the services; (b) products, services, or content offered by parties other than OpenAI through the Services; or (c) any data other than Customer Content, such as system data.
If your selected Region does not support regional processing, as identified below, OpenAI may also process and temporarily store Customer Content outside of the Region to deliver the services.

### Additional requirements for non-US regions
To use data residency with any region other than the United States, you must be approved for abuse monitoring controls, and execute a Zero Data Retention amendment.

### How to use data residency
Data residency is configured per-project within your API Organization.
To configure data residency for regional storage, select the appropriate region from the dropdown when creating a new project.
In Europe, you must also send requests to the [https://eu.api.openai.com/](https://eu.api.openai.com/) base URL for the request to be processed in the region.

### Which models and features are eligible for data residency?
The following models and API services are eligible for data residency today for the regions specified below.
\*\*Table 1: Regional data residency capabilities\*\*
|Region|Regional storage|Regional processing|Requires modified abuse monitoring or ZDR|Default modes of entry|
|---|---|---|---|---|
|US|✅|✅|❌|Text, Audio, Voice, Image|
|Europe (EEA + Switzerland)|✅|✅|✅|Text, Audio, Voice, Image\*|
|Australia|✅|❌|✅|Text, Audio, Voice, Image\*|
|Canada|✅|❌|✅|Text, Audio, Voice, Image\*|
|Japan|✅|❌|✅|Text, Audio, Voice, Image\*|
|India|✅|❌|✅|Text, Audio, Voice, Image\*|
|Singapore|✅|❌|✅|Text, Audio, Voice, Image\*|
|South Korea|✅|❌|✅|Text, Audio, Voice, Image\*|
\\* Image support in these regions requires approval for enhanced Zero Data Retention or enhanced Modified Abuse Monitoring.
\*\*Table 2: API endpoint and tool support\*\*
|Supported services|Supported model snapshots|Supported region|
|---|---|---|
|/v1/chat/completions|gpt-4.1-2025-04-14gpt-4.1-mini-2025-04-14gpt-4.1-nano-2025-04-14o3-mini-2025-01-31o3-2025-04-16o4-mini-2025-04-16o1-2024-12-17o1-mini-2024-09-12o1-previewgpt-4o-2024-11-20gpt-4o-2024-08-06gpt-4o-mini-2024-07-18gpt-4-turbo-2024-04-09gpt-4-0613gpt-3.5-turbo-0125|All|
|/v1/responses|gpt-4.1-2025-04-14gpt-4.1-mini-2025-04-14gpt-4.1-nano-2025-04-14o3-2025-04-16o4-mini-2025-04-16o1-proo1-pro-2025-03-19computer-use-preview\*o3-mini-2025-01-31o1-2024-12-17o1-mini-2024-09-12o1-previewgpt-4o-2024-11-20gpt-4o-2024-08-06gpt-4o-mini-2024-07-18gpt-4-turbo-2024-04-09gpt-4-0613gpt-3.5-turbo-0125|All|
|/v1/images/generations|dall-e-3|All|
|/v1/audio/transcriptions /v1/audio/translations /v1/audio/speech|tts-1whisper-1gpt-4o-ttsgpt-4o-transcribegpt-4o-mini-transcribe|All|
|/v1/moderations|text-moderation-007omni-moderation-latest|All|
|/v1/batches|gpt-4.1-2025-04-14gpt-4.1-mini-2025-04-14gpt-4.1-nano-2025-04-14o3-2025-04-16o4-mini-2025-04-16o1-proo1-pro-2025-03-19o3-mini-2025-01-31o1-2024-12-17o1-mini-2024-09-12o1-previewgpt-4o-2024-11-20gpt-4o-2024-08-06gpt-4o-mini-2024-07-18gpt-4-turbo-2024-04-09gpt-4-0613gpt-3.5-turbo-0125|All|
|/v1/embeddings|text-embedding-3-smalltext-embedding-3-largetext-embedding-ada-002|All|
|/v1/fine\_tuning/jobs|gpt-4o-2024-08-06gpt-4o-mini-2024-07-18gpt-4.1-2025-04-14gpt-4.1-mini-2025-04-14|All|
|/v1/realtime (beta)|gpt-4o-realtime-previewgpt-4o-mini-realtime-preview|US|
|/v1/files||All|
|Scale Tier||All|
|Structured Outputs (excluding schema)||All|
|/v1/vector\_stores||All|
|/v1/responses File Search||All|
|/v1/responses Web Search||All|
|File Search||All|
|File Uploads||All, when used with base64 file uploads|
|Supported Input Modalities||Text Image Audio/Voice|
|Remote MCP server tool||All, but MCP servers are third-party services, and data sent to an MCP server is subject to their data residency policies.|
|Code Interpreter tool||All|

#### /v1/chat/completions
Cannot set store=true in non-US regions

#### /v1/responses
computer-use-preview snapshots are only supported for US/EU. Cannot set background=True in EU region.
Was this page useful?


## Imported snippet – 2025-07-03 14:45:57

Rate limits
===========
Understand API rate limits and restrictions.
Rate limits are restrictions that our API imposes on the number of times a user or client can access our services within a specified period of time.
Why do we have rate limits?
---------------------------
Rate limits are a common practice for APIs, and they're put in place for a few different reasons:
\* \*\*They help protect against abuse or misuse of the API.\*\* For example, a malicious actor could flood the API with requests in an attempt to overload it or cause disruptions in service. By setting rate limits, OpenAI can prevent this kind of activity.
\* \*\*Rate limits help ensure that everyone has fair access to the API.\*\* If one person or organization makes an excessive number of requests, it could bog down the API for everyone else. By throttling the number of requests that a single user can make, OpenAI ensures that the most number of people have an opportunity to use the API without experiencing slowdowns.
\* \*\*Rate limits can help OpenAI manage the aggregate load on its infrastructure.\*\* If requests to the API increase dramatically, it could tax the servers and cause performance issues. By setting rate limits, OpenAI can help maintain a smooth and consistent experience for all users.
Please work through this document in its entirety to better understand how OpenAI’s rate limit system works. We include code examples and possible solutions to handle common issues. We also include details around how your rate limits are automatically increased in the usage tiers section below.
How do these rate limits work?
------------------------------
Rate limits are measured in five ways: \*\*RPM\*\* (requests per minute), \*\*RPD\*\* (requests per day), \*\*TPM\*\* (tokens per minute), \*\*TPD\*\* (tokens per day), and \*\*IPM\*\* (images per minute). Rate limits can be hit across any of the options depending on what occurs first. For example, you might send 20 requests with only 100 tokens to the ChatCompletions endpoint and that would fill your limit (if your RPM was 20), even if you did not send 150k tokens (if your TPM limit was 150k) within those 20 requests.
[Batch API](/docs/api-reference/batch/create) queue limits are calculated based on the total number of input tokens queued for a given model. Tokens from pending batch jobs are counted against your queue limit. Once a batch job is completed, its tokens are no longer counted against that model's limit.
Other important things worth noting:
\* Rate limits are defined at the [organization level](/docs/guides/production-best-practices) and at the project level, not user level.
\* Rate limits vary by the [model](/docs/models) being used.
\* For long context models like GPT-4.1, there is a separate rate limit for long context requests. You can view these rate limits in [developer console](/settings/organization/limits).
\* Limits are also placed on the total amount an organization can spend on the API each month. These are also known as "usage limits".
\* Some model families have shared rate limits. Any models listed under a "shared limit" in your [organizations limit page](https://platform.openai.com/settings/organization/limits) share a rate limit between them. For example, if the listed shared TPM is 3.5M, all calls to any model in the given "shared limit" list will count towards that 3.5M.
Usage tiers
-----------
You can view the rate and usage limits for your organization under the [limits](/settings/organization/limits) section of your account settings. As your spend on our API goes up, we automatically graduate you to the next usage tier. This usually results in an increase in rate limits across most models.
|Tier|Qualification|Usage limits|
|---|---|---|
|Free|User must be in an allowed geography|$100 / month|
|Tier 1|$5 paid|$100 / month|
|Tier 2|$50 paid and 7+ days since first successful payment|$500 / month|
|Tier 3|$100 paid and 7+ days since first successful payment|$1,000 / month|
|Tier 4|$250 paid and 14+ days since first successful payment|$5,000 / month|
|Tier 5|$1,000 paid and 30+ days since first successful payment|$200,000 / month|
To view a high-level summary of rate limits per model, visit the [models page](/docs/models).

### Rate limits in headers
In addition to seeing your rate limit on your [account page](/settings/organization/limits), you can also view important information about your rate limits such as the remaining requests, tokens, and other metadata in the headers of the HTTP response.
You can expect to see the following header fields:
|Field|Sample Value|Description|
|---|---|---|
|x-ratelimit-limit-requests|60|The maximum number of requests that are permitted before exhausting the rate limit.|
|x-ratelimit-limit-tokens|150000|The maximum number of tokens that are permitted before exhausting the rate limit.|
|x-ratelimit-remaining-requests|59|The remaining number of requests that are permitted before exhausting the rate limit.|
|x-ratelimit-remaining-tokens|149984|The remaining number of tokens that are permitted before exhausting the rate limit.|
|x-ratelimit-reset-requests|1s|The time until the rate limit (based on requests) resets to its initial state.|
|x-ratelimit-reset-tokens|6m0s|The time until the rate limit (based on tokens) resets to its initial state.|

### Fine-tuning rate limits
The fine-tuning rate limits for your organization can be [found in the dashboard as well](/settings/organization/limits), and can also be retrieved via API:
```bash
curl https://api.openai.com/v1/fine\_tuning/model\_limits \
-H "Authorization: Bearer $OPENAI\_API\_KEY"
```
Error mitigation
----------------

### What are some steps I can take to mitigate this?
The OpenAI Cookbook has a [Python notebook](https://cookbook.openai.com/examples/how\_to\_handle\_rate\_limits) that explains how to avoid rate limit errors, as well an example [Python script](https://github.com/openai/openai-cookbook/blob/main/examples/api\_request\_parallel\_processor.py) for staying under rate limits while batch processing API requests.
You should also exercise caution when providing programmatic access, bulk processing features, and automated social media posting - consider only enabling these for trusted customers.
To protect against automated and high-volume misuse, set a usage limit for individual users within a specified time frame (daily, weekly, or monthly). Consider implementing a hard cap or a manual review process for users who exceed the limit.

#### Retrying with exponential backoff
One easy way to avoid rate limit errors is to automatically retry requests with a random exponential backoff. Retrying with exponential backoff means performing a short sleep when a rate limit error is hit, then retrying the unsuccessful request. If the request is still unsuccessful, the sleep length is increased and the process is repeated. This continues until the request is successful or until a maximum number of retries is reached. This approach has many benefits:
\* Automatic retries means you can recover from rate limit errors without crashes or missing data
\* Exponential backoff means that your first retries can be tried quickly, while still benefiting from longer delays if your first few retries fail
\* Adding random jitter to the delay helps retries from all hitting at the same time.
Note that unsuccessful requests contribute to your per-minute limit, so continuously resending a request won’t work.
Below are a few example solutions \*\*for Python\*\* that use exponential backoff.
Example 1: Using the Tenacity library
Tenacity is an Apache 2.0 licensed general-purpose retrying library, written in Python, to simplify the task of adding retry behavior to just about anything. To add exponential backoff to your requests, you can use the `tenacity.retry` decorator. The below example uses the `tenacity.wait\_random\_exponential` function to add random exponential backoff to a request.
Using the Tenacity library
```python
from openai import OpenAI
client = OpenAI()
from tenacity import (
retry,
stop\_after\_attempt,
wait\_random\_exponential,
) # for exponential backoff
@retry(wait=wait\_random\_exponential(min=1, max=60), stop=stop\_after\_attempt(6))
def completion\_with\_backoff(\*\*kwargs):
return client.completions.create(\*\*kwargs)
completion\_with\_backoff(model="gpt-4o-mini", prompt="Once upon a time,")
```
Note that the Tenacity library is a third-party tool, and OpenAI makes no guarantees about its reliability or security.
Example 2: Using the backoff library
Another python library that provides function decorators for backoff and retry is [backoff](https://pypi.org/project/backoff/):
Using the Tenacity library
```python
import backoff
import openai
from openai import OpenAI
client = OpenAI()
@backoff.on\_exception(backoff.expo, openai.RateLimitError)
def completions\_with\_backoff(\*\*kwargs):
return client.completions.create(\*\*kwargs)
completions\_with\_backoff(model="gpt-4o-mini", prompt="Once upon a time,")
```
Like Tenacity, the backoff library is a third-party tool, and OpenAI makes no guarantees about its reliability or security.
Example 3: Manual backoff implementation
If you don't want to use third-party libraries, you can implement your own backoff logic following this example:
Using manual backoff implementation
```python

# imports
import random
import time
import openai
from openai import OpenAI
client = OpenAI()

# define a retry decorator
def retry\_with\_exponential\_backoff(
func,
initial\_delay: float = 1,
exponential\_base: float = 2,
jitter: bool = True,
max\_retries: int = 10,
errors: tuple = (openai.RateLimitError,),
):
"""Retry a function with exponential backoff."""
def wrapper(\*args, \*\*kwargs):

# Initialize variables
num\_retries = 0
delay = initial\_delay

# Loop until a successful response or max\_retries is hit or an exception is raised
while True:
try:
return func(\*args, \*\*kwargs)

# Retry on specific errors
except errors as e:

# Increment retries
num\_retries += 1

# Check if max retries has been reached
if num\_retries > max\_retries:
raise Exception(
f"Maximum number of retries ({max\_retries}) exceeded."
)

# Increment the delay
delay \*= exponential\_base \* (1 + jitter \* random.random())

# Sleep for the delay
time.sleep(delay)

# Raise exceptions for any errors not specified
except Exception as e:
raise e
return wrapper
@retry\_with\_exponential\_backoff
def completions\_with\_backoff(\*\*kwargs):
return client.completions.create(\*\*kwargs)
```
Again, OpenAI makes no guarantees on the security or efficiency of this solution but it can be a good starting place for your own solution.

#### Reduce the `max\_tokens` to match the size of your completions
Your rate limit is calculated as the maximum of `max\_tokens` and the estimated number of tokens based on the character count of your request. Try to set the `max\_tokens` value as close to your expected response size as possible.

#### Batching requests
If your use case does not require immediate responses, you can use the [Batch API](/docs/guides/batch) to more easily submit and execute large collections of requests without impacting your synchronous request rate limits.
For use cases that \_do\_ requires synchronous respones, the OpenAI API has separate limits for \*\*requests per minute\*\* and \*\*tokens per minute\*\*.
If you're hitting the limit on requests per minute but have available capacity on tokens per minute, you can increase your throughput by batching multiple tasks into each request. This will allow you to process more tokens per minute, especially with our smaller models.
Sending in a batch of prompts works exactly the same as a normal API call, except you pass in a list of strings to the prompt parameter instead of a single string. [Learn more in the Batch API guide](/docs/guides/batch).
Was this page useful?


## Imported snippet – 2025-07-03 14:46:00

Deprecations
============
Find deprecated features and recommended replacements.
Overview
--------
As we launch safer and more capable models, we regularly retire older models. Software relying on OpenAI models may need occasional updates to keep working. Impacted customers will always be notified by email and in our documentation along with [blog posts](https://openai.com/blog) for larger changes.
This page lists all API deprecations, along with recommended replacements.
Deprecation vs Legacy
---------------------
We use the term "deprecation" to refer to the process of retiring a model or endpoint. When we announce that a model or endpoint is being deprecated, it immediately becomes deprecated. All deprecated models and endpoints will also have a shut down date. At the time of the shut down, the model or endpoint will no longer be accessible.
We use the term "legacy" to refer to models and endpoints that will no longer receive updates. We tag endpoints and models as legacy to signal to developers where we are moving as a platform and that they should likely migrate to newer models or endpoints. You can expect that a legacy model or endpoint will be deprecated at some point in the future.
Deprecation history
-------------------
All deprecations are listed below, with the most recent announcements at the top.

### 2025-06-10: gpt-4o-realtime-preview-2024-10-01
On June 10th, 2025, we notified developers using `gpt-4o-realtime-preview-2024-10-01` of its deprecation and removal from the API in three months.
|Shutdown date|Model / system|Recommended replacement|
|---|---|---|
|2025-09-10|gpt-4o-realtime-preview-2024-10-01|gpt-4o-realtime-preview|

### 2025-06-10: gpt-4o-audio-preview-2024-10-01
On June 10th, 2025, we notified developers using `gpt-4o-audio-preview-2024-10-01` of it's deprecation and removal from the API in three months.
|Shutdown date|Model / system|Recommended replacement|
|---|---|---|
|2025-09-10|gpt-4o-audio-preview-2024-10-01|gpt-4o-audio-preview|

### 2025-04-28: text-moderation
On April 28th, 2025, we notified developers using `text-moderation` of its deprecation and removal from the API in six months.
|Shutdown date|Model / system|Recommended replacement|
|---|---|---|
|2025-10-27|text-moderation-007|omni-moderation|
|2025-10-27|text-moderation-stable|omni-moderation|
|2025-10-27|text-moderation-latest|omni-moderation|

### 2025-04-28: o1-preview and o1-mini
On April 28th, 2025, we notified developers using `o1-preview` and `o1-mini` of their deprecations and removal from the API in three months and six months respectively.
|Shutdown date|Model / system|Recommended replacement|
|---|---|---|
|2025-07-28|o1-preview|o3|
|2025-10-27|o1-mini|o4-mini|

### 2025-04-14: GPT-4.5-preview
On April 14th, 2025, we notified developers that the `gpt-4.5-preview` model is deprecated and will be removed from the API in the coming months.
|Shutdown date|Model / system|Recommended replacement|
|---|---|---|
|2025-07-14|gpt-4.5-preview|gpt-4.1|

### 2024-10-02: Assistants API beta v1
In [April 2024](/docs/assistants/whats-new) when we released the v2 beta version of the Assistants API, we announced that access to the v1 beta would be shut off by the end of 2024. Access to the v1 beta will be discontinued on December 18, 2024.
See the Assistants API v2 beta [migration guide](/docs/assistants/migration) to learn more about how to migrate your tool usage to the latest version of the Assistants API.
|Shutdown date|Model / system|Recommended replacement|
|---|---|---|
|2024-12-18|OpenAI-Beta: assistants=v1|OpenAI-Beta: assistants=v2|

### 2024-08-29: Fine-tuning training on babbage-002 and davinci-002 models
On August 29th, 2024, we notified developers fine-tuning `babbage-002` and `davinci-002` that new fine-tuning training runs on these models will no longer be supported starting October 28, 2024.
Fine-tuned models created from these base models are not affected by this deprecation, but you will no longer be able to create new fine-tuned versions with these models.
|Shutdown date|Model / system|Recommended replacement|
|---|---|---|
|2024-10-28|New fine-tuning training on babbage-002|gpt-4o-mini|
|2024-10-28|New fine-tuning training on davinci-002|gpt-4o-mini|

### 2024-06-06: GPT-4-32K and Vision Preview models
On June 6th, 2024, we notified developers using `gpt-4-32k` and `gpt-4-vision-preview` of their upcoming deprecations in one year and six months respectively. As of June 17, 2024, only existing users of these models will be able to continue using them.
|Shutdown date|Deprecated model|Deprecated model price|Recommended replacement|
|---|---|---|---|
|2025-06-06|gpt-4-32k|$60.00 / 1M input tokens + $120 / 1M output tokens|gpt-4o|
|2025-06-06|gpt-4-32k-0613|$60.00 / 1M input tokens + $120 / 1M output tokens|gpt-4o|
|2025-06-06|gpt-4-32k-0314|$60.00 / 1M input tokens + $120 / 1M output tokens|gpt-4o|
|2024-12-06|gpt-4-vision-preview|$10.00 / 1M input tokens + $30 / 1M output tokens|gpt-4o|
|2024-12-06|gpt-4-1106-vision-preview|$10.00 / 1M input tokens + $30 / 1M output tokens|gpt-4o|

### 2023-11-06: Chat model updates
On November 6th, 2023, we [announced](https://openai.com/blog/new-models-and-developer-products-announced-at-devday) the release of an updated GPT-3.5-Turbo model (which now comes by default with 16k context) along with deprecation of `gpt-3.5-turbo-0613` and `gpt-3.5-turbo-16k-0613`. As of June 17, 2024, only existing users of these models will be able to continue using them.
|Shutdown date|Deprecated model|Deprecated model price|Recommended replacement|
|---|---|---|---|
|2024-09-13|gpt-3.5-turbo-0613|$1.50 / 1M input tokens + $2.00 / 1M output tokens|gpt-3.5-turbo|
|2024-09-13|gpt-3.5-turbo-16k-0613|$3.00 / 1M input tokens + $4.00 / 1M output tokens|gpt-3.5-turbo|
Fine-tuned models created from these base models are not affected by this deprecation, but you will no longer be able to create new fine-tuned versions with these models.

### 2023-08-22: Fine-tunes endpoint
On August 22nd, 2023, we [announced](https://openai.com/blog/gpt-3-5-turbo-fine-tuning-and-api-updates) the new fine-tuning API (`/v1/fine\_tuning/jobs`) and that the original `/v1/fine-tunes` API along with legacy models (including those fine-tuned with the `/v1/fine-tunes` API) will be shut down on January 04, 2024. This means that models fine-tuned using the `/v1/fine-tunes` API will no longer be accessible and you would have to fine-tune new models with the updated endpoint and associated base models.

#### Fine-tunes endpoint
|Shutdown date|System|Recommended replacement|
|---|---|---|
|2024-01-04|/v1/fine-tunes|/v1/fine\_tuning/jobs|

### 2023-07-06: GPT and embeddings
On July 06, 2023, we [announced](https://openai.com/blog/gpt-4-api-general-availability) the upcoming retirements of older GPT-3 and GPT-3.5 models served via the completions endpoint. We also announced the upcoming retirement of our first-generation text embedding models. They will be shut down on January 04, 2024.

#### InstructGPT models
|Shutdown date|Deprecated model|Deprecated model price|Recommended replacement|
|---|---|---|---|
|2024-01-04|text-ada-001|$0.40 / 1M tokens|gpt-3.5-turbo-instruct|
|2024-01-04|text-babbage-001|$0.50 / 1M tokens|gpt-3.5-turbo-instruct|
|2024-01-04|text-curie-001|$2.00 / 1M tokens|gpt-3.5-turbo-instruct|
|2024-01-04|text-davinci-001|$20.00 / 1M tokens|gpt-3.5-turbo-instruct|
|2024-01-04|text-davinci-002|$20.00 / 1M tokens|gpt-3.5-turbo-instruct|
|2024-01-04|text-davinci-003|$20.00 / 1M tokens|gpt-3.5-turbo-instruct|
Pricing for the replacement `gpt-3.5-turbo-instruct` model can be found on the [pricing page](https://openai.com/api/pricing).

#### Base GPT models
|Shutdown date|Deprecated model|Deprecated model price|Recommended replacement|
|---|---|---|---|
|2024-01-04|ada|$0.40 / 1M tokens|babbage-002|
|2024-01-04|babbage|$0.50 / 1M tokens|babbage-002|
|2024-01-04|curie|$2.00 / 1M tokens|davinci-002|
|2024-01-04|davinci|$20.00 / 1M tokens|davinci-002|
|2024-01-04|code-davinci-002|---|gpt-3.5-turbo-instruct|
Pricing for the replacement `babbage-002` and `davinci-002` models can be found on the [pricing page](https://openai.com/api/pricing).

#### Edit models & endpoint
|Shutdown date|Model / system|Recommended replacement|
|---|---|---|
|2024-01-04|text-davinci-edit-001|gpt-4o|
|2024-01-04|code-davinci-edit-001|gpt-4o|
|2024-01-04|/v1/edits|/v1/chat/completions|

#### Fine-tuning GPT models
|Shutdown date|Deprecated model|Training price|Usage price|Recommended replacement|
|---|---|---|---|---|
|2024-01-04|ada|$0.40 / 1M tokens|$1.60 / 1M tokens|babbage-002|
|2024-01-04|babbage|$0.60 / 1M tokens|$2.40 / 1M tokens|babbage-002|
|2024-01-04|curie|$3.00 / 1M tokens|$12.00 / 1M tokens|davinci-002|
|2024-01-04|davinci|$30.00 / 1M tokens|$120.00 / 1K tokens|davinci-002, gpt-3.5-turbo, gpt-4o|

#### First-generation text embedding models
|Shutdown date|Deprecated model|Deprecated model price|Recommended replacement|
|---|---|---|---|
|2024-01-04|text-similarity-ada-001|$4.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|text-search-ada-doc-001|$4.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|text-search-ada-query-001|$4.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|code-search-ada-code-001|$4.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|code-search-ada-text-001|$4.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|text-similarity-babbage-001|$5.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|text-search-babbage-doc-001|$5.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|text-search-babbage-query-001|$5.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|code-search-babbage-code-001|$5.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|code-search-babbage-text-001|$5.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|text-similarity-curie-001|$20.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|text-search-curie-doc-001|$20.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|text-search-curie-query-001|$20.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|text-similarity-davinci-001|$200.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|text-search-davinci-doc-001|$200.00 / 1M tokens|text-embedding-3-small|
|2024-01-04|text-search-davinci-query-001|$200.00 / 1M tokens|text-embedding-3-small|

### 2023-06-13: Updated chat models
On June 13, 2023, we announced new chat model versions in the [Function calling and other API updates](https://openai.com/blog/function-calling-and-other-api-updates) blog post. The three original versions will be retired in June 2024 at the earliest. As of January 10, 2024, only existing users of these models will be able to continue using them.
|Shutdown date|Legacy model|Legacy model price|Recommended replacement|
|---|---|---|---|
|at earliest 2024-06-13|gpt-4-0314|$30.00 / 1M input tokens + $60.00 / 1M output tokens|gpt-4o|
|Shutdown date|Deprecated model|Deprecated model price|Recommended replacement|
|---|---|---|---|
|2024-09-13|gpt-3.5-turbo-0301|$15.00 / 1M input tokens + $20.00 / 1M output tokens|gpt-3.5-turbo|
|2025-06-06|gpt-4-32k-0314|$60.00 / 1M input tokens + $120.00 / 1M output tokens|gpt-4o|

### 2023-03-20: Codex models
|Shutdown date|Deprecated model|Recommended replacement|
|---|---|---|
|2023-03-23|code-davinci-002|gpt-4o|
|2023-03-23|code-davinci-001|gpt-4o|
|2023-03-23|code-cushman-002|gpt-4o|
|2023-03-23|code-cushman-001|gpt-4o|

### 2022-06-03: Legacy endpoints
|Shutdown date|System|Recommended replacement|
|---|---|---|
|2022-12-03|/v1/engines|/v1/models|
|2022-12-03|/v1/search|View transition guide|
|2022-12-03|/v1/classifications|View transition guide|
|2022-12-03|/v1/answers|View transition guide|
Was this page useful?


## Imported snippet – 2025-07-03 14:46:07

Retrieval
=========
Search your data using semantic similarity.
The \*\*Retrieval API\*\* allows you to perform [\*\*semantic search\*\*](#semantic-search) over your data, which is a technique that surfaces semantically similar results — even when they match few or no keywords. Retrieval is useful on its own, but is especially powerful when combined with our models to synthesize responses.
![Retrieval depiction](https://cdn.openai.com/API/docs/images/retrieval-depiction.png)
The Retrieval API is powered by [\*\*vector stores\*\*](#vector-stores), which serve as indices for your data. This guide will cover how to perform semantic search, and go into the details of vector stores.
Quickstart
----------
\* \*\*Create vector store\*\* and upload files.
Create vector store with files
```python
from openai import OpenAI
client = OpenAI()
vector\_store = client.vector\_stores.create( # Create vector store
name="Support FAQ",
)
client.vector\_stores.files.upload\_and\_poll( # Upload file
vector\_store\_id=vector\_store.id,
file=open("customer\_policies.txt", "rb")
)
```
```javascript
import OpenAI from "openai";
const client = new OpenAI();
const vector\_store = await client.vectorStores.create({ // Create vector store
name: "Support FAQ",
});
await client.vector\_stores.files.upload\_and\_poll({ // Upload file
vector\_store\_id: vector\_store.id,
file: fs.createReadStream("customer\_policies.txt"),
});
```
\* \*\*Send search query\*\* to get relevant results.
Search query
```python
user\_query = "What is the return policy?"
results = client.vector\_stores.search(
vector\_store\_id=vector\_store.id,
query=user\_query,
)
```
```javascript
const userQuery = "What is the return policy?";
const results = await client.vectorStores.search({
vector\_store\_id: vector\_store.id,
query: userQuery,
});
```
To learn how to use the results with our models, check out the [synthesizing responses](#synthesizing-responses) section.
Semantic search
---------------
\*\*Semantic search\*\* is a technique that leverages [vector embeddings](/docs/guides/embeddings) to surface semantically relevant results. Importantly, this includes results with few or no shared keywords, which classical search techniques might miss.
For example, let's look at potential results for `"When did we go to the moon?"`:
|Text|Keyword Similarity|Semantic Similarity|
|---|---|---|
|The first lunar landing occured in July of 1969.|0%|65%|
|The first man on the moon was Neil Armstrong.|27%|43%|
|When I ate the moon cake, it was delicious.|40%|28%|
\_([Jaccard](https://en.wikipedia.org/wiki/Jaccard\_index) used for keyword, [cosine](https://en.wikipedia.org/wiki/Cosine\_similarity) with `text-embedding-3-small` used for semantic.)\_
Notice how the most relevant result contains none of the words in the search query. This flexibility makes semantic search a very powerful technique for querying knowledge bases of any size.
Semantic search is powered by [vector stores](#vector-stores), which we cover in detail later in the guide. This section will focus on the mechanics of semantic search.

### Perfoming semantic search
You can query a vector store using the `search` function and specifying a `query` in natural language. This will return a list of results, each with the relevant chunks, similarity scores, and file of origin.
Search query
```python
results = client.vector\_stores.search(
vector\_store\_id=vector\_store.id,
query="How many woodchucks are allowed per passenger?",
)
```
```javascript
const results = await client.vectorStores.search({
vector\_store\_id: vector\_store.id,
query: "How many woodchucks are allowed per passenger?",
});
```
Results
```json
{
"object": "vector\_store.search\_results.page",
"search\_query": "How many woodchucks are allowed per passenger?",
"data": [
{
"file\_id": "file-12345",
"filename": "woodchuck\_policy.txt",
"score": 0.85,
"attributes": {
"region": "North America",
"author": "Wildlife Department"
},
"content": [
{
"type": "text",
"text": "According to the latest regulations, each passenger is allowed to carry up to two woodchucks."
},
{
"type": "text",
"text": "Ensure that the woodchucks are properly contained during transport."
}
]
},
{
"file\_id": "file-67890",
"filename": "transport\_guidelines.txt",
"score": 0.75,
"attributes": {
"region": "North America",
"author": "Transport Authority"
},
"content": [
{
"type": "text",
"text": "Passengers must adhere to the guidelines set forth by the Transport Authority regarding the transport of woodchucks."
}
]
}
],
"has\_more": false,
"next\_page": null
}
```
A response will contain 10 results maximum by default, but you can set up to 50 using the `max\_num\_results` param.

### Query rewriting
Certain query styles yield better results, so we've provided a setting to automatically rewrite your queries for optimal performance. Enable this feature by setting `rewrite\_query=true` when performing a `search`.
The rewritten query will be available in the result's `search\_query` field.
|Original|Rewritten|
|---|---|
|I'd like to know the height of the main office building.|primary office building height|
|What are the safety regulations for transporting hazardous materials?|safety regulations for hazardous materials|
|How do I file a complaint about a service issue?|service complaint filing process|

### Attribute filtering
Attribute filtering helps narrow down results by applying criteria, such as restricting searches to a specific date range. You can define and combine criteria in `attribute\_filter` to target files based on their attributes before performing semantic search.
Use \*\*comparison filters\*\* to compare a specific `key` in a file's `attributes` with a given `value`, and \*\*compound filters\*\* to combine multiple filters using `and` and `or`.
Comparison filter
```json
{
"type": "eq" | "ne" | "gt" | "gte" | "lt" | "lte", // comparison operators
"property": "attributes\_property", // attributes property
"value": "target\_value" // value to compare against
}
```
Compound filter
```json
{
"type": "and" | "or", // logical operators
"filters": [...]
}
```
Below are some example filters.
Region
Filter for a region
```json
{
"type": "eq",
"property": "region",
"value": "us"
}
```
Date range
Filter for a date range
```json
{
"type": "and",
"filters": [
{
"type": "gte",
"property": "date",
"value": 1704067200 // unix timestamp for 2024-01-01
},
{
"type": "lte",
"property": "date",
"value": 1710892800 // unix timestamp for 2024-03-20
}
]
}
```
Filenames
Filter to match any of a set of filenames
```json
{
"type": "or",
"filters": [
{
"type": "eq",
"property": "filename",
"value": "example.txt"
},
{
"type": "eq",
"property": "filename",
"value": "example2.txt"
}
]
}
```
Complex
Filter for top secret projects with certain names in english
```json
{
"type": "or",
"filters": [
{
"type": "and",
"filters": [
{
"type": "or",
"filters": [
{
"type": "eq",
"property": "project\_code",
"value": "X123"
},
{
"type": "eq",
"property": "project\_code",
"value": "X999"
}
]
},
{
"type": "eq",
"property": "confidentiality",
"value": "top\_secret"
}
]
},
{
"type": "eq",
"property": "language",
"value": "en"
}
]
}
```

### Ranking
If you find that your file search results are not sufficiently relevant, you can adjust the `ranking\_options` to improve the quality of responses. This includes specifying a `ranker`, such as `auto` or `default-2024-08-21`, and setting a `score\_threshold` between 0.0 and 1.0. A higher `score\_threshold` will limit the results to more relevant chunks, though it may exclude some potentially useful ones.
Vector stores
-------------
Vector stores are the containers that power semantic search for the Retrieval API and the Assistants API file search tool. When you add a file to a vector store it will be automatically chunked, embedded, and indexed.
Vector stores contain `vector\_store\_file` objects, which are backed by a `file` object.
|Object type|Description|
|---|---|
|file|Represents content uploaded through the Files API. Often used with vector stores, but also for fine-tuning and other use cases.|
|vector\_store|Container for searchable files.|
|vector\_store.file|Wrapper type specifically representing a file that has been chunked and embedded, and has been associated with a vector\_store.Contains attributes map used for filtering.|

### Pricing
You will be charged based on the total storage used across all your vector stores, determined by the size of parsed chunks and their corresponding embeddings.
|Storage|Cost|
|---|---|
|Up to 1 GB (across all stores)|Free|
|Beyond 1 GB|$0.10/GB/day|
See [expiration policies](#expiration-policies) for options to minimize costs.

### Vector store operations
Create
Create vector store
```python
client.vector\_stores.create(
name="Support FAQ",
file\_ids=["file\_123"]
)
```
```javascript
await client.vector\_stores.create({
name: "Support FAQ",
file\_ids: ["file\_123"]
});
```
Retrieve
Retrieve vector store
```python
client.vector\_stores.retrieve(
vector\_store\_id="vs\_123"
)
```
```javascript
await client.vector\_stores.retrieve({
vector\_store\_id: "vs\_123"
});
```
Update
Update vector store
```python
client.vector\_stores.update(
vector\_store\_id="vs\_123",
name="Support FAQ Updated"
)
```
```javascript
await client.vector\_stores.update({
vector\_store\_id: "vs\_123",
name: "Support FAQ Updated"
});
```
Delete
Delete vector store
```python
client.vector\_stores.delete(
vector\_store\_id="vs\_123"
)
```
```javascript
await client.vector\_stores.delete({
vector\_store\_id: "vs\_123"
});
```
List
List vector stores
```python
client.vector\_stores.list()
```
```javascript
await client.vector\_stores.list();
```

### Vector store file operations
Some operations, like `create` for `vector\_store.file`, are asynchronous and may take time to complete — use our helper functions, like `create\_and\_poll` to block until it is. Otherwise, you may check the status.
Create
Create vector store file
```python
client.vector\_stores.files.create\_and\_poll(
vector\_store\_id="vs\_123",
file\_id="file\_123"
)
```
```javascript
await client.vector\_stores.files.create\_and\_poll({
vector\_store\_id: "vs\_123",
file\_id: "file\_123"
});
```
Upload
Upload vector store file
```python
client.vector\_stores.files.upload\_and\_poll(
vector\_store\_id="vs\_123",
file=open("customer\_policies.txt", "rb")
)
```
```javascript
await client.vector\_stores.files.upload\_and\_poll({
vector\_store\_id: "vs\_123",
file: fs.createReadStream("customer\_policies.txt"),
});
```
Retrieve
Retrieve vector store file
```python
client.vector\_stores.files.retrieve(
vector\_store\_id="vs\_123",
file\_id="file\_123"
)
```
```javascript
await client.vector\_stores.files.retrieve({
vector\_store\_id: "vs\_123",
file\_id: "file\_123"
});
```
Update
Update vector store file
```python
client.vector\_stores.files.update(
vector\_store\_id="vs\_123",
file\_id="file\_123",
attributes={"key": "value"}
)
```
```javascript
await client.vector\_stores.files.update({
vector\_store\_id: "vs\_123",
file\_id: "file\_123",
attributes: { key: "value" }
});
```
Delete
Delete vector store file
```python
client.vector\_stores.files.delete(
vector\_store\_id="vs\_123",
file\_id="file\_123"
)
```
```javascript
await client.vector\_stores.files.delete({
vector\_store\_id: "vs\_123",
file\_id: "file\_123"
});
```
List
List vector store files
```python
client.vector\_stores.files.list(
vector\_store\_id="vs\_123"
)
```
```javascript
await client.vector\_stores.files.list({
vector\_store\_id: "vs\_123"
});
```

### Batch operations
Create
Batch create operation
```python
client.vector\_stores.file\_batches.create\_and\_poll(
vector\_store\_id="vs\_123",
file\_ids=["file\_123", "file\_456"]
)
```
```javascript
await client.vector\_stores.file\_batches.create\_and\_poll({
vector\_store\_id: "vs\_123",
file\_ids: ["file\_123", "file\_456"]
});
```
Retrieve
Batch retrieve operation
```python
client.vector\_stores.file\_batches.retrieve(
vector\_store\_id="vs\_123",
batch\_id="vsfb\_123"
)
```
```javascript
await client.vector\_stores.file\_batches.retrieve({
vector\_store\_id: "vs\_123",
batch\_id: "vsfb\_123"
});
```
Cancel
Batch cancel operation
```python
client.vector\_stores.file\_batches.cancel(
vector\_store\_id="vs\_123",
batch\_id="vsfb\_123"
)
```
```javascript
await client.vector\_stores.file\_batches.cancel({
vector\_store\_id: "vs\_123",
batch\_id: "vsfb\_123"
});
```
List
Batch list operation
```python
client.vector\_stores.file\_batches.list(
vector\_store\_id="vs\_123"
)
```
```javascript
await client.vector\_stores.file\_batches.list({
vector\_store\_id: "vs\_123"
});
```

### Attributes
Each `vector\_store.file` can have associated `attributes`, a dictionary of values that can be referenced when performing [semantic search](#semantic-search) with [attribute filtering](#attribute-filtering). The dictionary can have at most 16 keys, with a limit of 256 characters each.
Create vector store file with attributes
```python
client.vector\_stores.files.create(
vector\_store\_id="",
file\_id="file\_123",
attributes={
"region": "US",
"category": "Marketing",
"date": 1672531200 # Jan 1, 2023
}
)
```
```javascript
await client.vector\_stores.files.create(, {
file\_id: "file\_123",
attributes: {
region: "US",
category: "Marketing",
date: 1672531200, // Jan 1, 2023
},
});
```

### Expiration policies
You can set an expiration policy on `vector\_store` objects with `expires\_after`. Once a vector store expires, all associated `vector\_store.file` objects will be deleted and you'll no longer be charged for them.
Set expiration policy for vector store
```python
client.vector\_stores.update(
vector\_store\_id="vs\_123",
expires\_after={
"anchor": "last\_active\_at",
"days": 7
}
)
```
```javascript
await client.vector\_stores.update({
vector\_store\_id: "vs\_123",
expires\_after: {
anchor: "last\_active\_at",
days: 7,
},
});
```

### Limits
The maximum file size is 512 MB. Each file should contain no more than 5,000,000 tokens per file (computed automatically when you attach a file).

### Chunking
By default, `max\_chunk\_size\_tokens` is set to `800` and `chunk\_overlap\_tokens` is set to `400`, meaning every file is indexed by being split up into 800-token chunks, with 400-token overlap between consecutive chunks.
You can adjust this by setting [`chunking\_strategy`](/docs/api-reference/vector-stores-files/createFile#vector-stores-files-createfile-chunking\_strategy) when adding files to the vector store. There are certain limitations to `chunking\_strategy`:
\* `max\_chunk\_size\_tokens` must be between 100 and 4096 inclusive.
\* `chunk\_overlap\_tokens` must be non-negative and should not exceed `max\_chunk\_size\_tokens / 2`.
Supported file types
\_For `text/` MIME types, the encoding must be one of `utf-8`, `utf-16`, or `ascii`.\_
|File format|MIME type|
|---|---|
|.c|text/x-c|
|.cpp|text/x-c++|
|.cs|text/x-csharp|
|.css|text/css|
|.doc|application/msword|
|.docx|application/vnd.openxmlformats-officedocument.wordprocessingml.document|
|.go|text/x-golang|
|.html|text/html|
|.java|text/x-java|
|.js|text/javascript|
|.json|application/json|
|.md|text/markdown|
|.pdf|application/pdf|
|.php|text/x-php|
|.pptx|application/vnd.openxmlformats-officedocument.presentationml.presentation|
|.py|text/x-python|
|.py|text/x-script.python|
|.rb|text/x-ruby|
|.sh|application/x-sh|
|.tex|text/x-tex|
|.ts|application/typescript|
|.txt|text/plain|
Synthesizing responses
----------------------
After performing a query you may want to synthesize a response based on the results. You can leverage our models to do so, by supplying the results and original query, to get back a grounded response.
Perform search query to get results
```python
from openai import OpenAI
client = OpenAI()
user\_query = "What is the return policy?"
results = client.vector\_stores.search(
vector\_store\_id=vector\_store.id,
query=user\_query,
)
```
```javascript
const { OpenAI } = require('openai');
const client = new OpenAI();
const userQuery = "What is the return policy?";
const results = await client.vectorStores.search({
vector\_store\_id: vector\_store.id,
query: userQuery,
});
```
Synthesize a response based on results
```python
formatted\_results = format\_results(results.data)
'\n'.join('\n'.join(c.text) for c in result.content for result in results.data)
completion = client.chat.completions.create(
model="gpt-4.1",
messages=[
{
"role": "developer",
"content": "Produce a concise answer to the query based on the provided sources."
},
{
"role": "user",
"content": f"Sources: {formatted\_results}\n\nQuery: '{user\_query}'"
}
],
)
print(completion.choices[0].message.content)
```
```javascript
const formattedResults = formatResults(results.data);
// Join the text content of all results
const textSources = results.data.map(result => result.content.map(c => c.text).join('\n')).join('\n');
const completion = await client.chat.completions.create({
model: "gpt-4.1",
messages: [
{
role: "developer",
content: "Produce a concise answer to the query based on the provided sources."
},
{
role: "user",
content: `Sources: ${formattedResults}\n\nQuery: '${userQuery}'`
}
],
});
console.log(completion.choices[0].message.content);
```
```json
"Our return policy allows returns within 30 days of purchase."
```
This uses a sample `format\_results` function, which could be implemented like so:
Sample result formatting function
```python
def format\_results(results):
formatted\_results = ''
for result in results.data:
formatted\_result = f""
for part in result.content:
formatted\_result += f"{part.text}"
formatted\_results += formatted\_result + ""
return f"{formatted\_results}"
```
```javascript
function formatResults(results) {
let formattedResults = '';
for (const result of results.data) {
let formattedResult = ``;
for (const part of result.content) {
formattedResult += `${part.text}`;
}
formattedResults += formattedResult + "";
}
return `${formattedResults}`;
}
```
Was this page useful?


## Imported snippet – 2025-07-03 14:46:12

Building MCP servers for deep research
======================================
Build an MCP server to use with deep research via API or ChatGPT.
[Model Context Protocol](https://modelcontextprotocol.io/introduction) (MCP) is an open protocol that's becoming the industry standard for extending AI models with additional tools and knowledge. Remote MCP servers can be used to connect models over the Internet to new data sources and capabilities.
In this guide, we'll cover how to build a remote MCP server that reads data from a private data source (a [vector store](/docs/guides/retrieval)) and makes it available to deep research models in ChatGPT via connectors, and [via API](/docs/guides/deep-research).
Configure a data source
-----------------------
You can use data from any source to power a remote MCP server, but for simplicity, we will use [vector stores](/docs/guides/retrieval) in the OpenAI API. Begin by uploading a PDF document to a new vector store - [you can use this public domain 19th century book about cats](https://cdn.openai.com/API/docs/cats.pdf) for an example.
You can upload files and create a vector store [in the dashboard here](/storage/vector\_stores), or you can create vector stores and upload files via API. [Follow the vector store guide](/docs/guides/retrieval) to set up a vector store and upload a file to it.
Make a note of the vector store's unique ID to use in the example to follow.
![vector store configuration](https://cdn.openai.com/API/docs/images/vector\_store.png)
Create an MCP server
--------------------
Next, let's create a deep research-compatible remote MCP server that will do search queries against our vector store, and be able to return document content for files with a given ID.
In this example, we are going to build our MCP server using Python and [FastMCP](https://github.com/jlowin/fastmcp). A full implementation of the server will be provided at the end of this section, along with instructions for running it on [Replit](https://replit.com/).
Note that there are a number of other MCP server frameworks you can use in a variety of programming languages. Whichever framework you use though, the tool definitions in your server will need to conform to the shape described here.
Your MCP server must implement two tools to work with deep research - `search` and `fetch`.

### `search` tool
The search tool is used by deep research models (and others) to return a list of possibly relevant search results from the data set exposed by your MCP server.
\_Arguments:\_
A single query string.
\_Returns:\_
An array of objects with the following properties:
\* `id` - a unique ID for the document or search result item
\* `title` - a string title for the search result item
\* `text` - a relevant snippet of text for the search terms
\* `url` - a URL to the document or search result item. Useful for citing specific resources in research.

### `fetch` tool
The fetch tool is used to retrieve the full contents of a search result document or item.
\_Arguments:\_
A string which is a unique identifier for the search document.
\_Returns:\_
A single object with the following properties:
\* `id` - a unique ID for the document or search result item
\* `title` - a string title for the search result item
\* `text` - The full text of the document or item
\* `url` - a URL to the document or search result item. Useful for citing specific resources in research.
\* `metadata` - an optional key/value pairing of data about the result

### Server example
An easy way to try out this example MCP server is using [Replit](https://replit.com/). You can configure this sample application with your own API credentials and vector store information to try it yourself.
[
Example MCP server on Replit
Remix the server example on Replit to test live.
](https://replit.com/@kwhinnery-oai/DeepResearchServer?v=1#README.md)
A full implementation of both the `search` and `fetch` tools in FastMCP is below also for convenience.
Full implementation - FastMCP server
```python
"""
Sample MCP Server for ChatGPT Deep Research Integration
This server implements the Model Context Protocol (MCP) with search and fetch
capabilities designed to work with ChatGPT's deep research feature.
"""
import logging
import os
from typing import Dict, List, Any
from fastmcp import FastMCP
from openai import OpenAI

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(\_\_name\_\_)

# OpenAI configuration
OPENAI\_API\_KEY = os.environ.get("OPENAI\_API\_KEY")
VECTOR\_STORE\_ID = os.environ.get("VECTOR\_STORE\_ID", "")

# Initialize OpenAI client
openai\_client = OpenAI()
server\_instructions = """
This MCP server provides search and document retrieval capabilities
for deep research. Use the search tool to find relevant documents
based on keywords, then use the fetch tool to retrieve complete
document content with citations.
"""
def create\_server():
"""Create and configure the MCP server with search and fetch tools."""

# Initialize the FastMCP server
mcp = FastMCP(name="Sample Deep Research MCP Server",
instructions=server\_instructions)
@mcp.tool()
async def search(query: str) -> Dict[str, List[Dict[str, Any]]]:
"""
Search for documents using OpenAI Vector Store search.
This tool searches through the vector store to find semantically relevant matches.
Returns a list of search results with basic information. Use the fetch tool to get
complete document content.
Args:
query: Search query string. Natural language queries work best for semantic search.
Returns:
Dictionary with 'results' key containing list of matching documents.
Each result includes id, title, text snippet, and optional URL.
"""
if not query or not query.strip():
return {"results": []}
if not openai\_client:
logger.error("OpenAI client not initialized - API key missing")
raise ValueError(
"OpenAI API key is required for vector store search")

# Search the vector store using OpenAI API
logger.info(f"Searching {VECTOR\_STORE\_ID} for query: '{query}'")
response = openai\_client.vector\_stores.search(
vector\_store\_id=VECTOR\_STORE\_ID, query=query)
results = []

# Process the vector store search results
if hasattr(response, 'data') and response.data:
for i, item in enumerate(response.data):

# Extract file\_id, filename, and content
item\_id = getattr(item, 'file\_id', f"vs\_{i}")
item\_filename = getattr(item, 'filename', f"Document {i+1}")

# Extract text content from the content array
content\_list = getattr(item, 'content', [])
text\_content = ""
if content\_list and len(content\_list) > 0:

# Get text from the first content item
first\_content = content\_list[0]
if hasattr(first\_content, 'text'):
text\_content = first\_content.text
elif isinstance(first\_content, dict):
text\_content = first\_content.get('text', '')
if not text\_content:
text\_content = "No content available"

# Create a snippet from content
text\_snippet = text\_content[:200] + "..." if len(
text\_content) > 200 else text\_content
result = {
"id": item\_id,
"title": item\_filename,
"text": text\_snippet,
"url":
f"https://platform.openai.com/storage/files/{item\_id}"
}
results.append(result)
logger.info(f"Vector store search returned {len(results)} results")
return {"results": results}
@mcp.tool()
async def fetch(id: str) -> Dict[str, Any]:
"""
Retrieve complete document content by ID for detailed
analysis and citation. This tool fetches the full document
content from OpenAI Vector Store. Use this after finding
relevant documents with the search tool to get complete
information for analysis and proper citation.
Args:
id: File ID from vector store (file-xxx) or local document ID
Returns:
Complete document with id, title, full text content,
optional URL, and metadata
Raises:
ValueError: If the specified ID is not found
"""
if not id:
raise ValueError("Document ID is required")
if not openai\_client:
logger.error("OpenAI client not initialized - API key missing")
raise ValueError(
"OpenAI API key is required for vector store file retrieval")
logger.info(f"Fetching content from vector store for file ID: {id}")

# Fetch file content from vector store
content\_response = openai\_client.vector\_stores.files.content(
vector\_store\_id=VECTOR\_STORE\_ID, file\_id=id)

# Get file metadata
file\_info = openai\_client.vector\_stores.files.retrieve(
vector\_store\_id=VECTOR\_STORE\_ID, file\_id=id)

# Extract content from paginated response
file\_content = ""
if hasattr(content\_response, 'data') and content\_response.data:

# Combine all content chunks from FileContentResponse objects
content\_parts = []
for content\_item in content\_response.data:
if hasattr(content\_item, 'text'):
content\_parts.append(content\_item.text)
file\_content = "\n".join(content\_parts)
else:
file\_content = "No content available"

# Use filename as title and create proper URL for citations
filename = getattr(file\_info, 'filename', f"Document {id}")
result = {
"id": id,
"title": filename,
"text": file\_content,
"url": f"https://platform.openai.com/storage/files/{id}",
"metadata": None
}

# Add metadata if available from file info
if hasattr(file\_info, 'attributes') and file\_info.attributes:
result["metadata"] = file\_info.attributes
logger.info(f"Fetched vector store file: {id}")
return result
return mcp
def main():
"""Main function to start the MCP server."""

# Verify OpenAI client is initialized
if not openai\_client:
logger.error(
"OpenAI API key not found. Please set OPENAI\_API\_KEY environment variable."
)
raise ValueError("OpenAI API key is required")
logger.info(f"Using vector store: {VECTOR\_STORE\_ID}")

# Create the MCP server
server = create\_server()

# Configure and start the server
logger.info("Starting MCP server on 0.0.0.0:8000")
logger.info("Server will be accessible via SSE transport")
try:

# Use FastMCP's built-in run method with SSE transport
server.run(transport="sse", host="0.0.0.0", port=8000)
except KeyboardInterrupt:
logger.info("Server stopped by user")
except Exception as e:
logger.error(f"Server error: {e}")
raise
if \_\_name\_\_ == "\_\_main\_\_":
main()
```
Replit setup
On Replit, you will need to configure two environment variables in the "Secrets" UI:
\* `OPENAI\_API\_KEY` - Your standard OpenAI API key
\* `VECTOR\_STORE\_ID` - The unique identifier of a vector store that can be used for search - the one you created earlier.
On free Replit accounts, server URLs are active for as long as the editor is active, so while you are testing, you'll need to keep the browser tab open. You can get a URL for your MCP server by clicking on the chainlink icon:
![replit configuration](https://cdn.openai.com/API/docs/images/replit.png)
In the long dev URL, ensure it ends with `/sse/`, which is the server-sent events (streaming) interface to the MCP server. This is the URL you will use to configure deep research both via API and ChatGPT. An example Replit URL looks like:
```text
https://777xxx.janeway.replit.dev/sse/
```
Test and connect your MCP server
--------------------------------
You can test your MCP server with a deep research model [in the prompts dashboard](/prompts). Create a new prompt, or edit an existing one, and add a new MCP tool to the prompt configuration. Remember that MCP servers used via API for deep research have to be configured with no approval required.
![prompts configuration](https://cdn.openai.com/API/docs/images/prompts\_mcp.png)
Once you have configured your MCP server, you can chat with a model using it via the Prompts UI.
![prompts chat](https://cdn.openai.com/API/docs/images/chat\_prompts\_mcp.png)
You can test the MCP server using the Responses API directly with a request like this one:
```bash
curl https://api.openai.com/v1/responses \
-H "Content-Type: application/json" \
-H "Authorization: Bearer $OPENAI\_API\_KEY" \
-d '{
"model": "o4-mini-deep-research",
"input": [
{
"role": "developer",
"content": [
{
"type": "input\_text",
"text": "You are a research assistant that searches MCP servers to find answers to your questions."
}
]
},
{
"role": "user",
"content": [
{
"type": "input\_text",
"text": "Are cats attached to their homes? Give a succinct one page overview."
}
]
}
],
"reasoning": {
"summary": "auto"
},
"tools": [
{
"type": "mcp",
"server\_label": "cats",
"server\_url": "https://777ff573-9947-4b9c-8982-658fa40c7d09-00-3le96u7wsymx.janeway.replit.dev/sse/",
"allowed\_tools": [
"search",
"fetch"
],
"require\_approval": "never"
}
]
}'
```

### Handle authentication
As someone building a custom remote MCP server, authorization and authentication help you protect your data. We recommend using OAuth and [dynamic client registration](https://modelcontextprotocol.io/specification/2025-03-26/basic/authorization#2-4-dynamic-client-registration). To learn more about the protocol's authentication, read the [MCP user guide](https://modelcontextprotocol.io/docs/concepts/transports#authentication-and-authorization) or see the [authorization specification](https://modelcontextprotocol.io/specification/2025-03-26/basic/authorization).
After connecting your custom remote MCP server in ChatGPT, users in your workspace will get an OAuth flow to your application.

### Connect in ChatGPT
1. Import your remote MCP servers directly in [ChatGPT settings](https://chatgpt.com/#settings).
2. Connect your server in the \*\*Connectors\*\* tab. It should now be visible in the composer > deep research tool. You may have to add the server as a source.
3. Test your server by running some prompts.
Risks and safety
----------------
Custom MCP servers enable you to connect your ChatGPT workspace to external applications, which allows ChatGPT to access, send and receive data, and take action in these applications. Please note that custom MCP servers are not developed or verified by OpenAI, and are third-party services that are subject to their own terms and conditions.
If you come across a malicious MCP server, please report it to [security@openai.com](mailto:security@openai.com).

### Connecting to trusted servers
Be careful with which custom MCP servers you add to your ChatGPT workspace. Currently, we only support deep research with custom MCP servers in ChatGPT, meaning the only tools intended to be available within the remote MCP servers are \*\*search\*\* and \*\*document retrieval\*\*. However, risks still apply even with this narrow scope.
We recommend that you do not connect to a custom MCP server unless you know and trust the underlying application. For example, pick official servers hosted by the service providers themselves (e.g., we recommend connecting to the Stripe server hosted by Stripe themselves on mcp.stripe.com, instead of a custom Stripe MCP server hosted by a third party). Because there aren't many official remote MCP servers today, you may be tempted to use a MCP server hosted by an organization that doesn't operate that server and simply proxies requests to that service via an API. If you do this, be extra careful in doing your due diligence on these unofficial MCP servers, and only connect once you’ve carefully reviewed how they use your data and have verified that you can trust the server. When building and connecting to your own MCP server, double check that it's the correct server.
Malicious MCP servers may include hidden instructions (prompt injections) designed to make ChatGPT behave unexpectedly. While OpenAI has implemented built-in safeguards to help detect and block these threats, it's essential to carefully review and ensure connections are established only with trusted servers.
When connecting to MCP servers that define their own tool definitions, your organization may get requests for data that you do not want or intend to share with the host of that MCP server. Before connecting to any MCP server, review the type of data being shared carefully and robustly.
MCP servers may update tool behavior unexpectedly, potentially leading to unintended or malicious behavior.

### Building servers
Be careful with the data you allow access to. Your remote MCP server permits others to connect OpenAI to your services and allows OpenAI to access, send and receive data, and take action in these services. Avoid putting any sensitive information in the JSON for your tools, and avoid storing any sensitive information from ChatGPT users accessing your remote MCP server.
As someone building an MCP server, don't put anything malicious in your tool definitions. At this time, we only support search and document retrieval.
Was this page useful?
```

## AingZ_Platf_Repo/legacy/data oficial/Docs_OpenAi/12.1.ChatGPT_Actions.md
meta: {size:39895, lines:525, sha256:"07cabc8c89cf92674ed12c56096b0186d298dcfe27276d1eaf73accf7cfc44b6", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md


## Imported snippet – 2025-07-03 14:46:59

GPT Actions
===========
Customize ChatGPT with GPT Actions and API integrations.
GPT Actions are stored in [Custom GPTs](https://openai.com/blog/introducing-gpts), which enable users to customize ChatGPT for specific use cases by providing instructions, attaching documents as knowledge, and connecting to 3rd party services.
GPT Actions empower ChatGPT users to interact with external applications via RESTful APIs calls outside of ChatGPT simply by using natural language. They convert natural language text into the json schema required for an API call. GPT Actions are usually either used to do [data retrieval](https://platform.openai.com/docs/actions/data-retrieval) to ChatGPT (e.g. query a Data Warehouse) or take action in another application (e.g. file a JIRA ticket).
How GPT Actions work
--------------------
At their core, GPT Actions leverage [Function Calling](https://platform.openai.com/docs/guides/function-calling) to execute API calls.
Similar to ChatGPT's Data Analysis capability (which generates Python code and then executes it), they leverage Function Calling to (1) decide which API call is relevant to the user's question and (2) generate the json input necessary for the API call. Then finally, the GPT Action executes the API call using that json input.
Developers can even specify the authentication mechanism of an action, and the Custom GPT will execute the API call using the third party app’s authentication. GPT Actions obfuscates the complexity of the API call to the end user: they simply ask a question in natural language, and ChatGPT provides the output in natural language as well.
The Power of GPT Actions
------------------------
APIs allow for \*\*interoperability\*\* to enable your organization to access other applications. However, enabling users to access the right information from 3rd-party APIs can require significant overhead from developers.
GPT Actions provide a viable alternative: developers can now simply describe the schema of an API call, configure authentication, and add in some instructions to the GPT, and ChatGPT provides the bridge between the user's natural language questions and the API layer.
Simplified example
------------------
The [getting started guide](https://platform.openai.com/docs/actions/getting-started) walks through an example using two API calls from [weather.gov](weather.gov) to generate a forecast:
\* /points/{latitude},{longitude} inputs lat-long coordinates and outputs forecast office (wfo) and x-y coordinates
\* /gridpoints/{office}/{gridX},{gridY}/forecast inputs wfo,x,y coordinates and outputs a forecast
Once a developer has encoded the json schema required to populate both of those API calls in a GPT Action, a user can simply ask "What I should pack on a trip to Washington DC this weekend?" The GPT Action will then figure out the lat-long of that location, execute both API calls in order, and respond with a packing list based on the weekend forecast it receives back.
In this example, GPT Actions will supply api.weather.gov with two API inputs:
/points API call:
```json
{
"latitude": 38.9072,
"longitude": -77.0369
}
```
/forecast API call:
```json
{
"wfo": "LWX",
"x": 97,
"y": 71
}
```
Get started on building
-----------------------
Check out the [getting started guide](https://platform.openai.com/docs/actions/getting-started) for a deeper dive on this weather example and our [actions library](https://platform.openai.com/docs/actions/actions-library) for pre-built example GPT Actions of the most common 3rd party apps.
Additional information
----------------------
\* Familiarize yourself with our [GPT policies](https://openai.com/policies/usage-policies#:~:text=or%20educational%20purposes.-,Building%20with%20ChatGPT,-Shared%20GPTs%20allow)
\* Explore the [differences between GPTs and Assistants](https://help.openai.com/en/articles/8673914-gpts-vs-assistants)
\* Check out the [GPT data privacy FAQ's](https://help.openai.com/en/articles/8554402-gpts-data-privacy-faqs)
\* Find answers to [common GPT questions](https://help.openai.com/en/articles/8554407-gpts-faq)
Was this page useful?


## Imported snippet – 2025-07-03 14:47:02

Getting started with GPT Actions
================================
Set up and test GPT Actions from scratch.
Weather.gov example
-------------------
The NSW (National Weather Service) maintains a [public API](https://www.weather.gov/documentation/services-web-api) that users can query to receive a weather forecast for any lat-long point. To retrieve a forecast, there’s 2 steps:
1. A user provides a lat-long to the api.weather.gov/points API and receives back a WFO (weather forecast office), grid-X, and grid-Y coordinates
2. Those 3 elements feed into the api.weather.gov/forecast API to retrieve a forecast for that coordinate
For the purpose of this exercise, let’s build a Custom GPT where a user writes a city, landmark, or lat-long coordinates, and the Custom GPT answers questions about a weather forecast in that location.
Step 1: Write and test Open API schema (using Actions GPT)
----------------------------------------------------------
A GPT Action requires an [Open API schema](https://swagger.io/specification/) to describe the parameters of the API call, which is a standard for describing APIs.
OpenAI released a public [Actions GPT](https://chatgpt.com/g/g-TYEliDU6A-actionsgpt) to help developers write this schema. For example, go to the Actions GPT and ask: \_“Go to [https://www.weather.gov/documentation/services-web-api](https://www.weather.gov/documentation/services-web-api) and read the documentation on that page. Build an Open API Schema for the /points/{latitude},{longitude} and /gridpoints/{office}/{gridX},{gridY}/forecast” API calls”\_
![The above Actions GPT request](https://cdn.openai.com/API/images/guides/actions\_action\_gpt.png)
Deep dive
See Full Open API Schema
ChatGPT uses the \*\*info\*\* at the top (including the description in particular) to determine if this action is relevant for the user query.
```yaml
info:
title: NWS Weather API
description: Access to weather data including forecasts, alerts, and observations.
version: 1.0.0
```
Then the \*\*parameters\*\* below further define each part of the schema. For example, we're informing ChatGPT that the \_office\_ parameter refers to the Weather Forecast Office (WFO).
```yaml
/gridpoints/{office}/{gridX},{gridY}/forecast:
get:
operationId: getGridpointForecast
summary: Get forecast for a given grid point
parameters:
- name: office
in: path
required: true
schema:
type: string
description: Weather Forecast Office ID
```
\*\*Key:\*\* Pay special attention to the \*\*schema names\*\* and \*\*descriptions\*\* that you use in this Open API schema. ChatGPT uses those names and descriptions to understand (a) which API action should be called and (b) which parameter should be used. If a field is restricted to only certain values, you can also provide an "enum" with descriptive category names.
While you can just try the Open API schema directly in a GPT Action, debugging directly in ChatGPT can be a challenge. We recommend using a 3rd party service, like [Postman](https://www.postman.com/), to test that your API call is working properly. Postman is free to sign up, verbose in its error-handling, and comprehensive in its authentication options. It even gives you the option of importing Open API schemas directly (see below).
![Choosing to import your API with Postman](https://cdn.openai.com/API/images/guides/actions\_import.png)
Step 2: Identify authentication requirements
--------------------------------------------
This Weather 3rd party service does not require authentication, so you can skip that step for this Custom GPT. For other GPT Actions that do require authentication, there are 2 options: API Key or OAuth. Asking ChatGPT can help you get started for most common applications. For example, if I needed to use OAuth to authenticate to Google Cloud, I can provide a screenshot and ask for details: \_“I’m building a connection to Google Cloud via OAuth. Please provide instructions for how to fill out each of these boxes.”\_
![The above ChatGPT request](https://cdn.openai.com/API/images/guides/actions\_oauth\_panel.png)
Often, ChatGPT provides the correct directions on all 5 elements. Once you have those basics ready, try testing and debugging the authentication in Postman or another similar service. If you encounter an error, provide the error to ChatGPT, and it can usually help you debug from there.
Step 3: Create the GPT Action and test
--------------------------------------
Now is the time to create your Custom GPT. If you've never created a Custom GPT before, start at our [Creating a GPT guide](https://help.openai.com/en/articles/8554397-creating-a-gpt).
1. Provide a name, description, and image to describe your Custom GPT
2. Go to the Action section and paste in your Open API schema. Take a note of the Action names and json parameters when writing your instructions.
3. Add in your authentication settings
4. Go back to the main page and add in instructions
Deep dive
Guidance on Writing Instructions

### Test the GPT Action
Next to each action, you'll see a \*\*Test\*\* button. Click on that for each action. In the test, you can see the detailed input and output of each API call.
![Available actions](https://cdn.openai.com/API/images/guides/actions\_available\_action.png)
If your API call is working in a 3rd party tool like Postman and not in ChatGPT, there are a few possible culprits:
\* The parameters in ChatGPT are wrong or missing
\* An authentication issue in ChatGPT
\* Your instructions are incomplete or unclear
\* The descriptions in the Open API schema are unclear
![A preview response from testing the weather API call](https://cdn.openai.com/API/images/guides/actions\_test\_action.png)
Step 4: Set up callback URL in the 3rd party app
------------------------------------------------
If your GPT Action uses OAuth Authentication, you’ll need to set up the callback URL in your 3rd party application. Once you set up a GPT Action with OAuth, ChatGPT provides you with a callback URL (this will update any time you update one of the OAuth parameters). Copy that callback URL and add it to the appropriate place in your application.
![Setting up a callback URL](https://cdn.openai.com/API/images/guides/actions\_bq\_callback.png)
Step 5: Evaluate the Custom GPT
-------------------------------
Even though you tested the GPT Action in the step above, you still need to evaluate if the Instructions and GPT Action function in the way users expect. Try to come up with at least 5-10 representative questions (the more, the better) of an \*\*“evaluation set”\*\* of questions to ask your Custom GPT.
\*\*Key:\*\* Test that the Custom GPT handles each one of your questions as you expect.
An example question: \_“What should I pack for a trip to the White House this weekend?”\_ tests the Custom GPT’s ability to: (1) convert a landmark to a lat-long, (2) run both GPT Actions, and (3) answer the user’s question.
![The response to the above ChatGPT request, including weather data](https://cdn.openai.com/API/images/guides/actions\_prompt\_2\_actions.png) ![A continuation of the response above](https://cdn.openai.com/API/images/guides/actions\_output.png)
Common Debugging Steps
----------------------
\_Challenge:\_ The GPT Action is calling the wrong API call (or not calling it at all)
\* \_Solution:\_ Make sure the descriptions of the Actions are clear - and refer to the Action names in your Custom GPT Instructions
\_Challenge:\_ The GPT Action is calling the right API call but not using the parameters correctly
\* \_Solution:\_ Add or modify the descriptions of the parameters in the GPT Action
\_Challenge:\_ The Custom GPT is not working but I am not getting a clear error
\* \_Solution:\_ Make sure to test the Action - there are more robust logs in the test window. If that is still unclear, use Postman or another 3rd party service to better diagnose.
\_Challenge:\_ The Custom GPT is giving an authentication error
\* \_Solution:\_ Make sure your callback URL is set up correctly. Try testing the exact same authentication settings in Postman or another 3rd party service
\_Challenge:\_ The Custom GPT cannot handle more difficult / ambiguous questions
\* \_Solution:\_ Try to prompt engineer your instructions in the Custom GPT. See examples in our [prompt engineering guide](https://platform.openai.com/docs/guides/prompt-engineering)
This concludes the guide to building a Custom GPT. Good luck building and leveraging the [OpenAI developer forum](https://community.openai.com/) if you have additional questions.
Was this page useful?


## Imported snippet – 2025-07-03 14:47:07

GPT Actions library
===================
Build and integrate GPT Actions for common applications.
Purpose
-------
While GPT Actions should be significantly less work for an API developer to set up than an entire application using those APIs from scratch, there’s still some set up required to get GPT Actions up and running. A Library of GPT Actions is meant to provide guidance for building GPT Actions on common applications.
Getting started
---------------
If you’ve never built an action before, start by reading the [getting started guide](https://platform.openai.com/docs/actions/getting-started) first to understand better how actions work.
Generally, this guide is meant for people with familiarity and comfort with calling API calls. For debugging help, try to explain your issues to ChatGPT - and include screenshots.
How to access
-------------
[The OpenAI Cookbook](https://cookbook.openai.com/) has a [directory](https://cookbook.openai.com/topic/chatgpt) of 3rd party applications and middleware application.

### 3rd party Actions cookbook
GPT Actions can integrate with HTTP services directly. GPT Actions leveraging SaaS API directly will authenticate and request resources directly from SaaS providers, such as [Google Drive](https://cookbook.openai.com/examples/chatgpt/gpt\_actions\_library/gpt\_action\_google\_drive) or [Snowflake](https://cookbook.openai.com/examples/chatgpt/gpt\_actions\_library/gpt\_action\_snowflake\_direct).

### Middleware Actions cookbook
GPT Actions can benefit from having a middleware. It allows pre-processing, data formatting, data filtering or even connection to endpoints not exposed through HTTP (e.g: databases). Multiple middleware cookbooks are available describing an example implementation path, such as [Azure](https://cookbook.openai.com/examples/chatgpt/gpt\_actions\_library/gpt\_middleware\_azure\_function), [GCP](https://cookbook.openai.com/examples/chatgpt/gpt\_actions\_library/gpt\_middleware\_google\_cloud\_function) and [AWS](https://cookbook.openai.com/examples/chatgpt/gpt\_actions\_library/gpt\_middleware\_aws\_function).
Give us feedback
----------------
Are there integrations that you’d like us to prioritize? Are there errors in our integrations? File a PR or issue on the cookbook page's github, and we’ll take a look.
Contribute to our library
-------------------------
If you’re interested in contributing to our library, please follow the below guidelines, then submit a PR in github for us to review. In general, follow the template similar to [this example GPT Action](https://cookbook.openai.com/examples/chatgpt/gpt\_actions\_library/gpt\_action\_bigquery).
Guidelines - include the following sections:
\* Application Information - describe the 3rd party application, and include a link to app website and API docs
\* Custom GPT Instructions - include the exact instructions to be included in a Custom GPT
\* OpenAPI Schema - include the exact OpenAPI schema to be included in the GPT Action
\* Authentication Instructions - for OAuth, include the exact set of items (authorization URL, token URL, scope, etc.); also include instructions on how to write the callback URL in the application (as well as any other steps)
\* FAQ and Troubleshooting - what are common pitfalls that users may encounter? Write them here and workarounds
Disclaimers
-----------
This action library is meant to be a guide for interacting with 3rd parties that OpenAI have no control over. These 3rd parties may change their API settings or configurations, and OpenAI cannot guarantee these Actions will work in perpetuity. Please see them as a starting point.
This guide is meant for developers and people with comfort writing API calls. Non-technical users will likely find these steps challenging.
Was this page useful?


## Imported snippet – 2025-07-03 14:47:10

GPT Action authentication
=========================
Learn authentication options for GPT Actions.
Actions offer different authentication schemas to accommodate various use cases. To specify the authentication schema for your action, use the GPT editor and select "None", "API Key", or "OAuth".
By default, the authentication method for all actions is set to "None", but you can change this and allow different actions to have different authentication methods.
No authentication
-----------------
We support flows without authentication for applications where users can send requests directly to your API without needing an API key or signing in with OAuth.
Consider using no authentication for initial user interactions as you might experience a user drop off if they are forced to sign into an application. You can create a "signed out" experience and then move users to a "signed in" experience by enabling a separate action.
API key authentication
----------------------
Just like how a user might already be using your API, we allow API key authentication through the GPT editor UI. We encrypt the secret key when we store it in our database to keep your API key secure.
This approach is useful if you have an API that takes slightly more consequential actions than the no authentication flow but does not require an individual user to sign in. Adding API key authentication can protect your API and give you more fine-grained access controls along with visibility into where requests are coming from.
OAuth
-----
Actions allow OAuth sign in for each user. This is the best way to provide personalized experiences and make the most powerful actions available to users. A simple example of the OAuth flow with actions will look like the following:
\* To start, select "Authentication" in the GPT editor UI, and select "OAuth".
\* You will be prompted to enter the OAuth client ID, client secret, authorization URL, token URL, and scope.
\* The client ID and secret can be simple text strings but should [follow OAuth best practices](https://www.oauth.com/oauth2-servers/client-registration/client-id-secret/).
\* We store an encrypted version of the client secret, while the client ID is available to end users.
\* OAuth requests will include the following information: `request={'grant\_type': 'authorization\_code', 'client\_id': 'YOUR\_CLIENT\_ID', 'client\_secret': 'YOUR\_CLIENT\_SECRET', 'code': 'abc123', 'redirect\_uri': 'https://chat.openai.com/aip/{g-YOUR-GPT-ID-HERE}/oauth/callback'}` Note: `https://chatgpt.com/aip/{g-YOUR-GPT-ID-HERE}/oauth/callback` is also valid.
\* In order for someone to use an action with OAuth, they will need to send a message that invokes the action and then the user will be presented with a "Sign in to \[domain\]" button in the ChatGPT UI.
\* The `authorization\_url` endpoint should return a response that looks like: `{ "access\_token": "example\_token", "token\_type": "bearer", "refresh\_token": "example\_token", "expires\_in": 59 }`
\* During the user sign in process, ChatGPT makes a request to your `authorization\_url` using the specified `authorization\_content\_type`, we expect to get back an access token and optionally a [refresh token](https://auth0.com/learn/refresh-tokens) which we use to periodically fetch a new access token.
\* Each time a user makes a request to the action, the user’s token will be passed in the Authorization header: ("Authorization": "\[Bearer/Basic\] \[user’s token\]").
\* We require that OAuth applications make use of the [state parameter](https://auth0.com/docs/secure/attack-protection/state-parameters#set-and-compare-state-parameter-values) for security reasons.
Failure to login issues on Custom GPTs (Redirect URLs)?
\* Be sure to enable this redirect URL in your OAuth application:
\* #1 Redirect URL: `https://chat.openai.com/aip/{g-YOUR-GPT-ID-HERE}/oauth/callback` (Different domain possible for some clients)
\* #2 Redirect URL: `https://chatgpt.com/aip/{g-YOUR-GPT-ID-HERE}/oauth/callback` (Get your GPT ID in the URL bar of the ChatGPT UI once you save) if you have several GPTs you'd need to enable for each or a wildcard depending on risk tolerance.
\* Debug Note: Your Auth Provider will typically log failures (e.g. 'redirect\\_uri is not registered for client'), which helps debug login issues as well.
Was this page useful?


## Imported snippet – 2025-07-03 14:47:15

Production notes on GPT Actions
===============================
Deploy GPT Actions in production with best practices.
Rate limits
-----------
Consider implementing rate limiting on the API endpoints you expose. ChatGPT will respect 429 response codes and dynamically back off from sending requests to your action after receiving a certain number of 429's or 500's in a short period of time.
Timeouts
--------
When making API calls during the actions experience, timeouts take place if the following thresholds are exceeded:
\* 45 seconds round trip for API calls
Use TLS and HTTPS
-----------------
All traffic to your action must use TLS 1.2 or later on port 443 with a valid public certificate.
IP egress ranges
----------------
ChatGPT will call your action from an IP address from one of the [CIDR blocks](https://en.wikipedia.org/wiki/Classless\_Inter-Domain\_Routing) listed in [chatgpt-actions.json](https://openai.com/chatgpt-actions.json)
You may wish to explicitly allowlist these IP addresses. This list is updated automatically periodically.
Multiple authentication schemas
-------------------------------
When defining an action, you can mix a single authentication type (OAuth or API key) along with endpoints that do not require authentication.
You can learn more about action authentication on our [actions authentication page](/docs/actions/authentication).
Open API specification limits
-----------------------------
Keep in mind the following limits in your OpenAPI specification, which are subject to change:
\* 300 characters max for each API endpoint description/summary field in API specification
\* 700 characters max for each API parameter description field in API specification
Additional limitations
----------------------
There are a few limitations to be aware of when building with actions:
\* Custom headers are not supported
\* With the exception of Google, Microsoft and Adobe OAuth domains, all domains used in an OAuth flow must be the same as the domain used for the primary endpoints
\* Request and response payloads must be less than 100,000 characters each
\* Requests timeout after 45 seconds
\* Requests and responses can only contain text (no images or video)
Consequential flag
------------------
In the OpenAPI specification, you can now set certain endpoints as "consequential" as shown below:
```yaml
paths:
/todo:
get:
operationId: getTODOs
description: Fetches items in a TODO list from the API.
security: []
post:
operationId: updateTODOs
description: Mutates the TODO list.
x-openai-isConsequential: true
```
A good example of a consequential action is booking a hotel room and paying for it on behalf of a user.
\* If the `x-openai-isConsequential` field is `true`, ChatGPT treats the operation as "must always prompt the user for confirmation before running" and don't show an "always allow" button (both are features of GPTs designed to give builders and users more control over actions).
\* If the `x-openai-isConsequential` field is `false`, ChatGPT shows the "always allow button".
\* If the field isn't present, ChatGPT defaults all GET operations to `false` and all other operations to `true`
Best practices on feeding examples
----------------------------------
Here are some best practices to follow when writing your GPT instructions and descriptions in your schema, as well as when designing your API responses:
1. Your descriptions should not encourage the GPT to use the action when the user hasn't asked for your action's particular category of service.
\_Bad example\_:
> Whenever the user mentions any type of task, ask if they would like to use the TODO action to add something to their todo list.
\_Good example\_:
> The TODO list can add, remove and view the user's TODOs.
2. Your descriptions should not prescribe specific triggers for the GPT to use the action. ChatGPT is designed to use your action automatically when appropriate.
\_Bad example\_:
> When the user mentions a task, respond with "Would you like me to add this to your TODO list? Say 'yes' to continue."
\_Good example\_:
> \[no instructions needed for this\]
3. Action responses from an API should return raw data instead of natural language responses unless it's necessary. The GPT will provide its own natural language response using the returned data.
\_Bad example\_:
> I was able to find your todo list! You have 2 todos: get groceries and walk the dog. I can add more todos if you'd like!
\_Good example\_:
> { "todos": \[ "get groceries", "walk the dog" \] }
How GPT Action data is used
---------------------------
GPT Actions connect ChatGPT to external apps. If a user interacts with a GPT’s custom action, ChatGPT may send parts of their conversation to the action’s endpoint.
If you have questions or run into additional limitations, you can join the discussion on the [OpenAI developer forum](https://community.openai.com).
Was this page useful?


## Imported snippet – 2025-07-03 14:47:20

Data retrieval with GPT Actions
===============================
Retrieve data using APIs and databases with GPT Actions.
One of the most common tasks an action in a GPT can perform is data retrieval. An action might:
1. Access an API to retrieve data based on a keyword search
2. Access a relational database to retrieve records based on a structured query
3. Access a vector database to retrieve text chunks based on semantic search
We’ll explore considerations specific to the various types of retrieval integrations in this guide.
Data retrieval using APIs
-------------------------
Many organizations rely on 3rd party software to store important data. Think Salesforce for customer data, Zendesk for support data, Confluence for internal process data, and Google Drive for business documents. These providers often provide REST APIs which enable external systems to search for and retrieve information.
When building an action to integrate with a provider's REST API, start by reviewing the existing documentation. You’ll need to confirm a few things:
1. Retrieval methods
\* \*\*Search\*\* - Each provider will support different search semantics, but generally you want a method which takes a keyword or query string and returns a list of matching documents. See [Google Drive’s `file.list` method](https://developers.google.com/drive/api/guides/search-files) for an example.
\* \*\*Get\*\* - Once you’ve found matching documents, you need a way to retrieve them. See [Google Drive’s `file.get` method](https://developers.google.com/drive/api/reference/rest/v3/files/get) for an example.
2. Authentication scheme
\* For example, [Google Drive uses OAuth](https://developers.google.com/workspace/guides/configure-oauth-consent) to authenticate users and ensure that only their available files are available for retrieval.
3. OpenAPI spec
\* Some providers will provide an OpenAPI spec document which you can import directly into your action. See [Zendesk](https://developer.zendesk.com/api-reference/ticketing/introduction/#download-openapi-file), for an example.
\* You may want to remove references to methods your GPT \_won’t\_ access, which constrains the actions your GPT can perform.
\* For providers who \_don’t\_ provide an OpenAPI spec document, you can create your own using the [ActionsGPT](https://chatgpt.com/g/g-TYEliDU6A-actionsgpt) (a GPT developed by OpenAI).
Your goal is to get the GPT to use the action to search for and retrieve documents containing context which are relevant to the user’s prompt. Your GPT follows your instructions to use the provided search and get methods to achieve this goal.
Data retrieval using Relational Databases
-----------------------------------------
Organizations use relational databases to store a variety of records pertaining to their business. These records can contain useful context that will help improve your GPT’s responses. For example, let’s say you are building a GPT to help users understand the status of an insurance claim. If the GPT can look up claims in a relational database based on a claims number, the GPT will be much more useful to the user.
When building an action to integrate with a relational database, there are a few things to keep in mind:
1. Availability of REST APIs
\* Many relational databases do not natively expose a REST API for processing queries. In that case, you may need to build or buy middleware which can sit between your GPT and the database.
\* This middleware should do the following:
\* Accept a formal query string
\* Pass the query string to the database
\* Respond back to the requester with the returned records
2. Accessibility from the public internet
\* Unlike APIs which are designed to be accessed from the public internet, relational databases are traditionally designed to be used within an organization’s application infrastructure. Because GPTs are hosted on OpenAI’s infrastructure, you’ll need to make sure that any APIs you expose are accessible outside of your firewall.
3. Complex query strings
\* Relational databases uses formal query syntax like SQL to retrieve relevant records. This means that you need to provide additional instructions to the GPT indicating which query syntax is supported. The good news is that GPTs are usually very good at generating formal queries based on user input.
4. Database permissions
\* Although databases support user-level permissions, it is likely that your end users won’t have permission to access the database directly. If you opt to use a service account to provide access, consider giving the service account read-only permissions. This can avoid inadvertently overwriting or deleting existing data.
Your goal is to get the GPT to write a formal query related to the user’s prompt, submit the query via the action, and then use the returned records to augment the response.
Data retrieval using Vector Databases
-------------------------------------
If you want to equip your GPT with the most relevant search results, you might consider integrating your GPT with a vector database which supports semantic search as described above. There are many managed and self hosted solutions available on the market, [see here for a partial list](https://github.com/openai/chatgpt-retrieval-plugin#choosing-a-vector-database).
When building an action to integrate with a vector database, there are a few things to keep in mind:
1. Availability of REST APIs
\* Many relational databases do not natively expose a REST API for processing queries. In that case, you may need to build or buy middleware which can sit between your GPT and the database (more on middleware below).
2. Accessibility from the public internet
\* Unlike APIs which are designed to be accessed from the public internet, relational databases are traditionally designed to be used within an organization’s application infrastructure. Because GPTs are hosted on OpenAI’s infrastructure, you’ll need to make sure that any APIs you expose are accessible outside of your firewall.
3. Query embedding
\* As discussed above, vector databases typically accept a vector embedding (as opposed to plain text) as query input. This means that you need to use an embedding API to convert the query input into a vector embedding before you can submit it to the vector database. This conversion is best handled in the REST API gateway, so that the GPT can submit a plaintext query string.
4. Database permissions
\* Because vector databases store text chunks as opposed to full documents, it can be difficult to maintain user permissions which might have existed on the original source documents. Remember that any user who can access your GPT will have access to all of the text chunks in the database and plan accordingly.

### Middleware for vector databases
As described above, middleware for vector databases typically needs to do two things:
1. Expose access to the vector database via a REST API
2. Convert plaintext query strings into vector embeddings
![Middleware for vector databases](https://cdn.openai.com/API/docs/images/actions-db-diagram.webp)
The goal is to get your GPT to submit a relevant query to a vector database to trigger a semantic search, and then use the returned text chunks to augment the response.
Was this page useful?


## Imported snippet – 2025-07-03 14:47:24

Sending and returning files with GPT Actions
============================================
Sending files
-------------
POST requests can include up to ten files (including DALL-E generated images) from the conversation. They will be sent as URLs which are valid for five minutes.
For files to be part of your POST request, the parameter must be named `openaiFileIdRefs` and the description should explain to the model the type and quantity of the files which your API is expecting.
The `openaiFileIdRefs` parameter will be populated with an array of JSON objects. Each object contains:
\* `name` The name of the file. This will be an auto generated name when created by DALL-E.
\* `id` A stable identifier for the file.
\* `mime\_type` The mime type of the file. For user uploaded files this is based on file extension.
\* `download\_link` The URL to fetch the file which is valid for five minutes.
Here’s an example of an `openaiFileIdRefs` array with two elements:
```json
[
{
"name": "dalle-Lh2tg7WuosbyR9hk",
"id": "file-XFlOqJYTPBPwMZE3IopCBv1Z",
"mime\_type": "image/webp",
"download\_link": "https://files.oaiusercontent.com/file-XFlOqJYTPBPwMZE3IopCBv1Z?se=2024-03-11T20%3A29%3A52Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Da580bae6-ea30-478e-a3e2-1f6c06c3e02f.webp&sig=ZPWol5eXACxU1O9azLwRNgKVidCe%2BwgMOc/TdrPGYII%3D"
},
{
"name": "2023 Benefits Booklet.pdf",
"id": "file-s5nX7o4junn2ig0J84r8Q0Ew",
"mime\_type": "application/pdf",
"download\_link": "https://files.oaiusercontent.com/file-s5nX7o4junn2ig0J84r8Q0Ew?se=2024-03-11T20%3A29%3A52Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D299%2C%20immutable&rscd=attachment%3B%20filename%3D2023%2520Benefits%2520Booklet.pdf&sig=Ivhviy%2BrgoyUjxZ%2BingpwtUwsA4%2BWaRfXy8ru9AfcII%3D"
}
]
```
Actions can include files uploaded by the user, images generated by DALL-E, and files created by Code Interpreter.

### OpenAPI Example
```yaml
/createWidget:
post:
operationId: createWidget
summary: Creates a widget based on an image.
description: Uploads a file reference using its file id. This file should be an image created by DALL·E or uploaded by the user. JPG, WEBP, and PNG are supported for widget creation.
requestBody:
required: true
content:
application/json:
schema:
type: object
properties:
openaiFileIdRefs:
type: array
items:
type: string
```
While this schema shows `openaiFileIdRefs` as being an array of type `string`, at runtime this will be populated with an array of JSON objects as previously shown.
Returning files
---------------
Requests may return up to 10 files. Each file may be up to 10 MB and cannot be an image or video.
These files will become part of the conversation similarly to if a user uploaded them, meaning they may be made available to code interpreter, file search, and sent as part of subsequent action invocations. In the web app users will see that the files have been returned and can download them.
To return files, the body of the response must contain an `openaiFileResponse` parameter. This parameter must always be an array and must be populated in one of two ways.

### Inline option
Each element of the array is a JSON object which contains:
\* `name` The name of the file. This will be visible to the user.
\* `mime\_type` The MIME type of the file. This is used to determine eligibility and which features have access to the file.
\* `content` The base64 encoded contents of the file.
Here’s an example of an openaiFileResponse array with two elements:
```json
[
{
"name": "example\_document.pdf",
"mime\_type": "application/pdf",
"content": "JVBERi0xLjQKJcfsj6IKNSAwIG9iago8PC9MZW5ndGggNiAwIFIvRmlsdGVyIC9GbGF0ZURlY29kZT4+CnN0cmVhbQpHhD93PQplbmRzdHJlYW0KZW5kb2JqCg=="
},
{
"name": "sample\_spreadsheet.csv",
"mime\_type": "text/csv",
"content": "iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg=="
}
]
```
OpenAPI example
```yaml
/papers:
get:
operationId: findPapers
summary: Retrieve PDFs of relevant academic papers.
description: Provided an academic topic, up to five relevant papers will be returned as PDFs.
parameters:
- in: query
name: topic
required: true
schema:
type: string
description: The topic the papers should be about.
responses:
'200':
description: Zero to five academic paper PDFs
content:
application/json:
schema:
type: object
properties:
openaiFileResponse:
type: array
items:
type: object
properties:
name:
type: string
description: The name of the file.
mime\_type:
type: string
description: The MIME type of the file.
content:
type: string
format: byte
description: The content of the file in base64 encoding.
```

### URL option
Each element of the array is a URL referencing a file to be downloaded. The headers `Content-Disposition` and `Content-Type` must be set such that a file name and MIME type can be determined. The name of the file will be visible to the user. The MIME type of the file determines eligibility and which features have access to the file.
There is a 10 second timeout for fetching each file.
Here’s an example of an `openaiFileResponse` array with two elements:
```json
[
"https://example.com/f/dca89f18-16d4-4a65-8ea2-ededced01646",
"https://example.com/f/01fad6b0-635b-4803-a583-0f678b2e6153"
]
```
Here’s an example of the required headers for each URL:
```text
Content-Type: application/pdf
Content-Disposition: attachment; filename="example\_document.pdf"
```
OpenAPI example
```yaml
/papers:
get:
operationId: findPapers
summary: Retrieve PDFs of relevant academic papers.
description: Provided an academic topic, up to five relevant papers will be returned as PDFs.
parameters:
- in: query
name: topic
required: true
schema:
type: string
description: The topic the papers should be about.
responses:
'200':
description: Zero to five academic paper PDFs
content:
application/json:
schema:
type: object
properties:
openaiFileResponse:
type: array
items:
type: string
format: uri
description: URLs to fetch the files.
```
Was this page useful?
```

