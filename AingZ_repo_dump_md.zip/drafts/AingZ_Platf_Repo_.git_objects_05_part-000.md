---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/05
part_index: 0
files_included: 10
size_bytes_sum: 8524
created_at: 2025-08-31T21:08:15.566077+00:00
integrity:
  sha256_concat: ac96c2b89fc0b68e7d3b4d67760c46dafb79d4ec61bd6557c9c2f536bf3874da
---

## AingZ_Platf_Repo/.git/objects/05/0d6a8d58bde3abc56bd100d64f305573230e17
meta: {size:634, lines:0, sha256:"c94302948e0b0f14ac7f1dd7e0edfd841ac6334e9f3729cc8679ce9ff3bca517", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/05/207febb972e03b9b7cca5613d8a799c317934b
meta: {size:772, lines:0, sha256:"f29efb44b370e42356bd391230394dc050675280924cc8a9805d48d6d9a33e0f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/05/2263a30c74d0ca6e40474ceaae53960ca6e93d
meta: {size:650, lines:2, sha256:"e46c9826e3f5f85c531a7875a54fb80fc2934b5517200359f792fa385faa317d", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x]RK0îÙ¿bÓVBÛíJí¡7Å*`dMÓ'¸"8Â¦ÑþûI²U+!!g¾×¸l¾>È¹Ì´ztØß&sì=<´áùéùP3Rêéd3vã ×nÞà8Õ£×]Ik°hûz:ê¼z|³ØÆ×fD¨¡E¾GgþRO;¨³­©:ÛÎ'=úÚ¾´ßkXU·ÕÇ¤Óõ@ÌhîWp1¾·³I;?6`D`Æv» á~=¹1ñÅ¶#¨|vè èàd;s½Ø:ÏÍ`\Agt3{ìt¡¸äìNAº¯Õ-=!Ìùo¹P¹ôöô¯ãÈaF¤ÄP°£³ÙÂøK·>Tò{	ÖZ;v&øußQxU7ö·^¼\·:ZR¸,"®[½]¹¾hô-0äÅx±ônÝÍó¸xSp¶ÓÂ÷¿ÍGäOTb£vT2àR¼ò%°¢Wì¸JÅVvHZ¨=ÐbßyDÀ~UIx^faq¶Mxñk+>]A@xâç63§L×<ãjWEÀÜ	J*·Pne)*ô	Â¼ØHda9+Ô#²bØ+ Ji*B·¨^}r/ùKª YÂ°¸f¨®3v¥BSqFyABsúÔI"Ih»ª]ÊB)ðQübÅElÄ¢Pºê}tÇ+¼
l¤È#âÄ	DG+Ø%D½ô¾l	mÑô]$fë)÷æGòàzTF
```

## AingZ_Platf_Repo/.git/objects/05/246e5a70b21fe8c43671d9627b54f36bd6f310
meta: {size:634, lines:0, sha256:"ec05019c5d81061e338961b46b4741d58e8d8071999f3076a898fa3c36e487cf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/05/38949cc8bb7b6cf7aeb3886d62bfc49ba9b870
meta: {size:82, lines:0, sha256:"1738fb789f3afe2206eda37bae8c1bfea107458c40ddb9f1cf7b01fe092c8ca4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/05/4c34b6642ed00f2576471b6b5ffbca60bc25a6
meta: {size:1145, lines:0, sha256:"2b5e83042d9829ab8afb4fe5ce8d06b8c194dbac69b529fae1269b890b35b078", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/05/66b7319179447a42ff44b2c7802a6d2e5bb6de
meta: {size:1846, lines:0, sha256:"b17b325c856d6a0245c04d4ea926d5a7704b87f66dc94f1e7e23650f783b6345", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/05/b90c1e79cbe5c0534b2a5fb9fda6589f421963
meta: {size:1493, lines:0, sha256:"8dddaa39b0e65dda36dc304cc55b4b76863057f32cce6b71cc44aa32d060d620", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/05/cc9291ea3c1d6a3f4ff5b6baa913ac0a88a11b
meta: {size:713, lines:0, sha256:"cf1bf3c38180560be1dca2b7a5845d4350587365d617cf023610875ae4116055", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/05/f948733b75098c0249290ed012fc737d402aaa
meta: {size:555, lines:0, sha256:"d4ee4749c5f64445f52960430865fd62752f581310aa1edd17a01a68cedbe4ce", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

