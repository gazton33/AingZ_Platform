---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/96
part_index: 0
files_included: 8
size_bytes_sum: 3992
created_at: 2025-08-31T21:08:15.627952+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/96/22a725715c992ad4e120b60a49e1f49520cc78
meta: {size:212, lines:0, sha256:"e8f7ad81dd7318a7ef24e04e3d2848e56832e7d09aa57a67ad6801dcd9d5129f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/96/4ac7747e7fe5570dcdd496d5fc066726e087a5
meta: {size:197, lines:0, sha256:"67979c414b161aebd6546ede699915b330e9c8d02bf6cdf9e5127e9a05c04479", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/96/942f81ed5cb5b11d36829b54fb2257c4581eff
meta: {size:200, lines:0, sha256:"733263242e4b93d472d68ec2026dbc62d835420c5e5f61b8beb57a8250ace8d5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/96/9f200913ce343d84cd82c3dd1410fbc5ac5881
meta: {size:507, lines:0, sha256:"89806b7a68e8cdfe46e381d7a5e25a73da239b3ff97a02adf794d86cb9d5eca1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/96/a50a8733f47d6fba984239434272f36baf6a37
meta: {size:1352, lines:0, sha256:"997db03efda7709bad1830a920d010d415b1d83eebd65fbad22378839f7de7c0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/96/ad3d521ab7318697773ddcc9b3fc28c329a90d
meta: {size:124, lines:0, sha256:"c0d27f81653c3b689fb1a3497dd7cbd62c932f46630e9eff30c06f3455b7015e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/96/cb38858e6c7602138a7f491ec08609aae8c38a
meta: {size:1112, lines:0, sha256:"77e64a1755e19a7d73b3e818b1f2cf1a8edf0eaa3f8e4b5c507f6cecef0ada7b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/96/e8b7747cd7b1cc9e1955fff0c7b14c2782e42a
meta: {size:288, lines:0, sha256:"79480eb6adcff2ab2230c818f8431ecc5c93a84a091e24e2b752c95b779f3067", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

