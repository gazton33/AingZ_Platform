---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/37
part_index: 0
files_included: 11
size_bytes_sum: 5957
created_at: 2025-08-31T21:08:15.571866+00:00
integrity:
  sha256_concat: 3da2083cb46ec568519e5e0d7408bf30b23f4fa697de924fc681b1f808dca8d4
---

## AingZ_Platf_Repo/.git/objects/37/05613fa7f211510cb9b4cb77c270cfb60a87c6
meta: {size:2137, lines:0, sha256:"b34a8707de5b557b9c4b6f4dfaea0d1e144ef6b512acadb2b73b39f3481b9282", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/37/2b0ac3181dc4a9060c67d583435c7bcb62788c
meta: {size:1041, lines:0, sha256:"c2cbb71c52e844bbc9b32cc6f982c851716d0f35314ade4c9452ef7914a4f544", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/37/32483eaef7dff49c94a3adda909bd5ef61b7c2
meta: {size:71, lines:0, sha256:"af88fc8f9708e5a5988e5add3799e8de55a600c24ef5dacf165d0ecde2ff422d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/37/36ef78c5a95a6781293ec403202f25ecda362f
meta: {size:809, lines:0, sha256:"469c275e22e98be8b54d8605c7e5a12d6e34ca840cf6d2cd915ac5fad52761e4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/37/3c56bc0ce0c02dae34da205f7c13a3b820082e
meta: {size:172, lines:1, sha256:"96ac798346c5726c101f4f814cbb9910ecab19c70488986a88335e27ba380941", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x[J1EýîUÔò®8Ûð¯ºú&èÄ¢«··à×çpõØ¶6Èùü4:@QØÌ:d3Ô²u~A.!8ÄEäéS:öA¬¼x('ç¨<#æÄ^Èì	0îeÇ¸ÞÛ^?èµ^~±BïÇ7ú­nÒÖÛY)Øä\ gãNzþø¿9õ+µºK+ªèI­¯?ÍLÔ
```

## AingZ_Platf_Repo/.git/objects/37/597570eff0ba8037de7ce0018b4703ed09d94c
meta: {size:414, lines:0, sha256:"0cdbf4ccce0c73e7eb779e8107587560454d9460afb47999a9bdd834e0994484", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/37/65531f42061a2ca8c392a24960afe514fe5188
meta: {size:720, lines:0, sha256:"8270f70e3037a2aeb63ba76aad040a390293317380a501afa6bba8c5d9997753", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/37/90c28a477242c0e32511931c1991b6aff94fe7
meta: {size:82, lines:0, sha256:"c702d110d305b3cfb5cc13c826e220955e9663a99dc432a21ecdb24f2d47b4ce", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/37/9d29c6a5c6fd03e62cf65a2da1a14df5ad8f9c
meta: {size:179, lines:1, sha256:"b41fded16f971b2d32213e99bdef0811786526e9c263abe8b2fec05ba396069d", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎMNÄ0@aÖ=/À¨ÎÏ8!4\ã¸JMS¥^í>éI-eé`{éM"ÒèÌ$IÙ,M²ÊB¢É!;7Ý:øL!DB&8Þ;Öd:«õÈ&øÙµÁÇ²Íð6_~uUyÔom÷¹ð²^¤w@òîJÑÃëhÇq8ëù×õÿrÈU4-õK¡kÙkãöÒêq4`_yûñ*N
```

## AingZ_Platf_Repo/.git/objects/37/a40965857b0b912222a8451fde13c033e46171
meta: {size:232, lines:2, sha256:"32f8d46440efe8501bbaec830d5a9c29dddcef81985bfd9fb5536e986558f6d8", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x±NÄ0D©óî®âbïÚ@¢¦AëÍÚÄ'ãÒ}=¦¸ ÍèÍç}_«Bðµ¨À$µæ!:íÐFhý½u­½è.Tä¨ÊF×Áh<F?9¬	h6£`¸ûÙúY,1ÚiçàÝ¦9MÈíèZ\T¢[Í¢zNçlÂKþòvZ·3çýEÑYã¨ÇVUwMmªü+Ü½KIíB/êÔ0ÇIå¨Z/ßO}Öº\Ã¹¿WëßÖ#}~}lTc.{÷j
g
```

## AingZ_Platf_Repo/.git/objects/37/d1423fe71a9ef422b27e0df61d590385b008a8
meta: {size:100, lines:0, sha256:"8e46c54355551c59d3b3c0d681cb431a83aa5657ffde3b99995a57938c6cea0f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

