---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/5b
part_index: 0
files_included: 9
size_bytes_sum: 4777
created_at: 2025-08-31T21:08:15.620712+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/5b/22e198c0fde5fe4d235144950d5eebeadb4bf8
meta: {size:399, lines:0, sha256:"c8a537aa57e32b50403d480cb9e91bfe14aa23546f93d14df8f3429ae1a75c51", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5b/852d83e0731277e485b3d83a339039a8ebebb7
meta: {size:606, lines:0, sha256:"1f7b0a151e1ebd89be4a7f4219b57f8482c065b6199df72aca8f24cf3ae2e322", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5b/861164718df5865c0d3aaf5cd77d71e92cff03
meta: {size:138, lines:0, sha256:"e8b839c02ff903684ac1065f826dade7bccc358422b0607e8c147b0cec168b7d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5b/ae6b493965aa1e566572baa01ce4c4c1bcddc1
meta: {size:132, lines:0, sha256:"ac8afff563828ac8a784ee2fd01552b875d721f9eb07d8ee622b8839b8e0efea", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5b/b4665174ce6218f2b51daef69a2c63b28224d1
meta: {size:736, lines:0, sha256:"2e9a857ae57677c7079cf215380c459a83808c11dee1410281fa7a1b22ff0173", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5b/bd2d9e5a7cbb8a708b90fea9ab4986b1b8f612
meta: {size:1591, lines:0, sha256:"5e7020a6decdfb9dbf3fbe92c3f2464261995edfd6a8bacfce5f88c6846c81bf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5b/d54a39d5ed5f67771d6e2597f4a80b92a77be9
meta: {size:978, lines:0, sha256:"567c0015a04d7be8387f52ef09adb3d432f504f9c79a0168614ce505bd22fc10", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5b/ea65364eb38636c6d5d4ccd68025e665c57053
meta: {size:102, lines:0, sha256:"44a68bb2d5301192374600bf6bdcbf303de6e18d5c6e859e16e493bfeb468f78", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5b/f1ef7af8eb5c47957264e4adcbf7fb5aff76bf
meta: {size:95, lines:0, sha256:"4f2077bc3457cd77a01724c0d5a6a63a886ded0d0a49b4e633de70ab44767c21", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

