---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/cd
part_index: 0
files_included: 8
size_bytes_sum: 8088
created_at: 2025-08-31T21:08:15.648715+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/cd/4d71a2abba0692d90663cf8f834b8d45c88716
meta: {size:751, lines:0, sha256:"dbec5698ee8f8d122f7fb52dd4132ea522647ba69f584ffca7e14e74644e7f8b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cd/69688786f6f95f233dba86b287db4ee0da86b7
meta: {size:637, lines:0, sha256:"f94802d30bd9d62ee3aa0e8cea1d10191eea21d2154e62565c310dfa045742bc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cd/7c43c49c443078ea5d91c19688c00af1a4c8af
meta: {size:154, lines:0, sha256:"9b58db1c63856dca4949bc2e6635cc389f614ff173cac8b85ea178b07d4ba3b9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cd/a4f115ccc054fb606dccc2cab55e30e4c3bf83
meta: {size:3552, lines:0, sha256:"1d2f8d0cf5f71a3cb16f3980a66c59c696a2dbf9f41bc57c06c02fcb193d5f60", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cd/afb0bc231e318545c4c98b4cef5423bff56460
meta: {size:1192, lines:0, sha256:"3bb17ec606dd518319054faad050e0a01115b4190bdc7c5da126daf5c275b873", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cd/c858ff3a2057258a52195530f88b1e4d145ddb
meta: {size:679, lines:0, sha256:"38b74e4a87a0d118a206b5a0902f8e32bb8dac2524d7b940f688e9c5039269e2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cd/ce2c4ca1d08fc6752902d4ecf0f3188a85f656
meta: {size:591, lines:0, sha256:"32b9ccfb6d983b43a3dfd2026a21569bf1abf782bfb460852468684857695629", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/cd/da8d4ef4edc6c1e4fb484b4f8f691c508f10ff
meta: {size:532, lines:0, sha256:"8d798979eb693f832fc81d2b52e87ce941f999b91f02b191c3b51141eeb074f4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

