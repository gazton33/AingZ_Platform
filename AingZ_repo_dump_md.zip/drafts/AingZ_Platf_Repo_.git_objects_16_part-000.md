---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/16
part_index: 0
files_included: 11
size_bytes_sum: 55829
created_at: 2025-08-31T21:08:15.568153+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/16/023b251a285e1e15f95242bdb265ddd9cc6cd1
meta: {size:348, lines:0, sha256:"3c74fb7031a88c84018a43a57734893277b92eb67a017ee65bc0feed27bfc704", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/16/423301461012d1693978bacb257a4af958b722
meta: {size:971, lines:0, sha256:"2afbd7c12a1c1b46053c353c84fb12a42d3d3420d5c0d3f1e1c873469a11e23f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/16/43857075e5afb5617af6f67a443f28748bdbe6
meta: {size:41111, lines:0, sha256:"98f2664af4efeca68d60dbe19c923fddd3d0b9a49ed6777b051fb370b23d23bd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/16/58758f6baf326f13963e124af51ba812cbced3
meta: {size:1203, lines:0, sha256:"5a948b3be6f20ddcb82e026fcb48c8c3fdfff7095746be3be4fad8207f9bc924", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/16/653551da0a06b4dc9cbfd209da0efa33d5f438
meta: {size:7686, lines:0, sha256:"f90bdd9f76ece43dd9f6c34d3a7c6077bddc5f5a230e00c042ab205c0bcf5822", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/16/74d6bced9ea2abd5fc6dcea460d782812905d3
meta: {size:1842, lines:0, sha256:"3103e41c358309e2e60781d4cc1cafee2776bb3ae5c630791d55d442df2de37d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/16/90d6ff180ca93da4818e342a3eca109bfb544d
meta: {size:845, lines:0, sha256:"57dd18722925ad74b7590c85ba3d9fad887f20992b0638f4053424152389ae3c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/16/c57908a6771580a2972e30dcfe3b9cebede52b
meta: {size:58, lines:0, sha256:"cb33b5f8abad21c5ec51bfd5edb2ea97dfd34739c83609cfd6f478719293351d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/16/d22cdcc7934c23f7bdde3a4f48b95f5e6dc9dc
meta: {size:482, lines:0, sha256:"a82a8e6ef383a4edf50931ea05c58e48a83bdf6ff01684882ae54c809aba1bbc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/16/ec54e6c053be11dabd2c5d1cf29711cdbd8e7c
meta: {size:801, lines:0, sha256:"d5bce233c3922686cf3db73fd4a2c30a870c22ffe713cb3ead2cdba6c96ececd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/16/f920b49ee745dd7374a7eadbb90d6425dd3152
meta: {size:482, lines:0, sha256:"c6fc9309b8ffe24c78d637b1e2fe8bc07d1d3f495f6bc42bcc42cd8a7b62aa11", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

