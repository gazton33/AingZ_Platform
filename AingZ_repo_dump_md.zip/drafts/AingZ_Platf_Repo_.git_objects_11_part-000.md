---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/11
part_index: 0
files_included: 8
size_bytes_sum: 7042
created_at: 2025-08-31T21:08:15.567789+00:00
integrity:
  sha256_concat: c38b4ab1af3fd7ad7bd218ef8b70d5e314dcdcb41d120aa09a77ea3aeb22c974
---

## AingZ_Platf_Repo/.git/objects/11/01d1c6fae708f3af710d6580f7e996f8fdf14c
meta: {size:591, lines:0, sha256:"afafebd0c6caf8f9fe8678e91e746c3e02490771279a238d6761559af1c1682b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/11/1c3540479c646871809e16ec300885d675fcd0
meta: {size:1517, lines:0, sha256:"34856128443f81040ab191856fbbef416b56028d21379ef14f74529739235024", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/11/4a390534027883788b903d06b12cd3c431df94
meta: {size:1327, lines:0, sha256:"e355d2a44ccc9ddc349347027e1cc7fe2fdfd614002f301ee8616d00d9d9bac3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/11/6ea784af303c78a58355996ba95e98736c8302
meta: {size:157, lines:0, sha256:"ecda0e3c4ca3628408b292610f464460bdff2e5dcfec60114e6035aa7dcfcf42", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/11/c6dbe10af791fb3211e878e1bbb741625ca5c5
meta: {size:702, lines:3, sha256:"eaafd2bd23a068a06951d4282dccf1d57b436f2201794a7d98ed4de3aa779ee9", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÕUÍnÓ@æì§©"%N¤´¢¢J+qÆëÁÙÖÞ1»ëT>ð¼§>Bß'a¼IêhQÄJ½ãovæ$ç^¼~µýl&iç-CJpfñëS8cym¯0×¨ôõm¥üï_¾åºÐfõótwÒÝwï{p´¡Zô`¸5|ÙßÚîÏ£¨ßïGÑÆ·¢Ì¬k¾kãÛÖ$¢µAX4ó`J¶Àã"£4ÂfÇÇæØyGj±#pU «%Ø¼®¯¬V,¡2ð`$(-Í5ÇpA±W`­'	ðY´P Ä4© ð²\$çO9>Ä··¤fËUÃÈªó*9+ñ_¢½j8dßØúåªa×MFRGv.XØHZuTËµ«»kåûêjww÷Z¸säà^µV(ñß*?üË¢L¥åsRÞöÐãhl²SV"Q9:7u
M\.ÚÕ0>Ø?Ü?í°Óª$)b9'ëBÊÐ&¨Õ¡¨[Am'TH§DGÄds&¥®f¤.r)ÑæüßA(°,µÉ:ñïOA§TtPývóH7èå¦7¸HNèþ%eM-á¥éºþ,=%Ìn@QX¦kI¬ËI~Æ0>o¸AHæúÐ«^c.½^÷vÅcï#z#jMºÏe
	/Ú8Nè?eU%mÆ¯8úvÆpÄ21 a+o48N¬«{ÐÎápªác%ý9´«T{s4^g:IØ1ª-ùl¬Àõ|"áæXhïVæfpGÑþ<Q
```

## AingZ_Platf_Repo/.git/objects/11/d0fd8e6680ee1e494b0cead616684116c2ebec
meta: {size:853, lines:0, sha256:"a9c9fa463d922d2da91aa60cb6a8a96402e1b8352537b1ac45a539ad472ca00f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/11/db64cb941dbed19bb1be9dcab2d735aec1bf31
meta: {size:940, lines:0, sha256:"ad07678739b5c23b28a5853bc75024c1b47740a1ece5d283ad622adb5ed1a453", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/11/e141fad1c00954a14ce0748d304c66f4e2b25a
meta: {size:955, lines:0, sha256:"719692bd8cfa2edd2510ab24bb50954b2efb00247b9bb24a2afce34958ff58fb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

