---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/5a
part_index: 0
files_included: 13
size_bytes_sum: 8271
created_at: 2025-08-31T21:08:15.620416+00:00
integrity:
  sha256_concat: 05eb04e7bc2184161f142a63a8a2c9a043b1d4e3fa376c4ab0d6e841e01c168c
---

## AingZ_Platf_Repo/.git/objects/5a/1cf3ab821d6b18cf4437eb41e6ff57eab7f777
meta: {size:98, lines:0, sha256:"44f83974f7e94c6f8c7761806efa0211c2d35811d461f95a89bb175011dbdc35", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5a/23356335dab6dd2baa3405048c72960a8eac72
meta: {size:224, lines:0, sha256:"c16306848b4193261a34408cedeb80b1b91abcd0d3a41e5cc6785922f817d801", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5a/2649bbdac90d6d2bdd09d0612f7d27659a0dfb
meta: {size:1670, lines:0, sha256:"fa5324c2052eb2119517afc5173de1da252615fe05c50712a3ca8b6c715ac80c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5a/3a725dc29c3b2d989b1c7f66f5bd0234170eaa
meta: {size:116, lines:1, sha256:"d7b7104f00c36765244f734cfb788117848a60d11d2fbd04c972724289cfaee2", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU040a040031QrutñuÕËMaèÞþyâqÛ9^³tÇ¿W½³s'TQQjbJnj|r~Qj|JbIb|IjnANbIj|Qy|R|Y¼q¼Èâ"Ü¾ü\'ðQûã2Ê[l5*0t,,
```

## AingZ_Platf_Repo/.git/objects/5a/3afcb4a0af944fef678c0c6d68497117c2b820
meta: {size:1215, lines:0, sha256:"32960cd3735de7955c719c2a92a37c966dc59b8e9dd0bc9285b9776eacb3ae01", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5a/579f71ccd3cf15597a01eba1fdd0231c17a5b9
meta: {size:83, lines:0, sha256:"67fbdbf99a59902f53bc1c6e7d533137a8b99fc31d0439f104d1ae34e3737b0c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5a/705103597bfda79068c7bdeee9ae503197eea0
meta: {size:203, lines:0, sha256:"57a1e0538ac0aadc97f3145bd8469c3d929ed9bb4365ea443e7e6ca32241812d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5a/70b1ecbf618ec14cee8123de8f46fe214a25e8
meta: {size:297, lines:0, sha256:"6831e48d56a5d7d24dc8487dca8ba2fbb840144e0744f7bf0addd2e84964d248", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5a/7872bcdcc28e62572568d09661742bb97e4302
meta: {size:810, lines:0, sha256:"460b14e92549b76d5787878916360b61e287373b0006323637e47b4d4e9f674c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5a/9b77b510bf60d2bbc7f40f01c4da7c133961f6
meta: {size:979, lines:0, sha256:"ac3b90c806bca817b161e8455c1b457f87d5907b0724c7a6bc1fc2662c43e833", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5a/cbfa3045ae6f9a6f68e4c790e770889fdff7cd
meta: {size:1551, lines:0, sha256:"ec20d36e9382d0d2536a210595481f26cc83e4ad8c125ac4fe0065a243748d30", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5a/f7c8b5fd38991755c0190563f77069d0b49b0e
meta: {size:727, lines:0, sha256:"d575b2a44b11ea553d259ecc334f0686cd6fb5b1d716d760be54d879d11be891", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5a/fa0b112565682850c200feca9eb9b4dbc113a0
meta: {size:298, lines:2, sha256:"33d8af356dc097d59d7b00979d75cf324892b733efc54fa164005b5fab833274", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xu1OÃ0ó+ÞÖÉ­eI$&6cUEIzUéÙäÎ¥øñØNZDeß{÷Ýó5½kp¿¼½ázO%Z·¥£ij¡Þ2¶£ö½(àté¡æXë}my}_ôHôQñæIµ!°ùñ]Ld!45¾ÖØ-EÉgoÂIðºUëXyJôá°Ìâ¤ã¼"x<´s<ÕpåÒàÏÀ§Õ)nbÆøYa4H¤ÝÍ³+ÞÖ}-yâ-qkI.Ø¯Ä×å
ØÖ0;¤o³íUæzTlVÐÞzØ©¥þèVØÙ«^ã1íçbÜá!ÿ}9Eó²v°^e«òNª³±:,«ìûSñ9«÷
```

