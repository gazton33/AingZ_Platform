---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/be
part_index: 1
files_included: 1
size_bytes_sum: 35219506
created_at: 2025-08-31T21:08:15.367629+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/be/db8a885e9a91d0475fc29be371c4b502a39d4c
meta: {size:35219506, lines:0, sha256:"c9c4a50a6814ac44471f85e67a72d95c908233a97fc279704b9a99b6d09cfb26", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

