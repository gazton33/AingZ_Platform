---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/9a
part_index: 0
files_included: 4
size_bytes_sum: 5959
created_at: 2025-08-31T21:08:15.628200+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/9a/2e63270409f98eac0b5ddf1199d2627ca40ba8
meta: {size:4563, lines:0, sha256:"bcb69a496144418827a3ea2321af1f4322eaaa2dc199180599716cd44112a878", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9a/44e85477f998d3bb8e12bc21ddc1a5a036666c
meta: {size:77, lines:0, sha256:"14339073f93901af93ff745f80a2ba3b6529f014a0fe5e0a48576662c74c3bad", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9a/a866f7faa97eda74be119ef896c2451039bddc
meta: {size:1251, lines:0, sha256:"ac2198e8a91f4689bc1b63578f88b314ec90ec59df95e0a5b2f39355cf09226a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9a/c81ace409a54e0f187f943bad7625e6f9ba2f8
meta: {size:68, lines:0, sha256:"f37f454c025520a6daf2654032615ffb6bf153c75adc986d69d40d458ac7a71c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

