---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/e7
part_index: 0
files_included: 5
size_bytes_sum: 3323
created_at: 2025-08-31T21:08:15.650950+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/e7/19f114626c52656d2ea2b0f835858707a0c72f
meta: {size:152, lines:0, sha256:"4f3229bdca10a08311b2760d1eb372898d23244aef2a5452c4c0b9d21283521c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e7/4d7548071ee6587f937725ee2db4339e09b05c
meta: {size:2399, lines:0, sha256:"cd97a83cab921102d0ba192e1e503d2d1b820e38ebeee97e5afad3a10e192f08", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e7/a3b75e89c4ed27c7f520eec63109d0a0301b22
meta: {size:253, lines:0, sha256:"53c230ce3c655ebf1a131c33d2a3665f7bc2f6229cb8f31a4f2275bf192498be", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e7/ae894d10bf1d4b0e71f08661813f07db3cb650
meta: {size:75, lines:0, sha256:"f25ad9eb3a121c866321bebfabe4f4e4debbf44dacdb8924b9392e93e61e7b42", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e7/d7782675fab27063d415ac71ce05df293ce87c
meta: {size:444, lines:0, sha256:"d608935034372e73c3e134e330babc8a1d3fee02bd5ce2ffa4d29aaa44a85a0d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

