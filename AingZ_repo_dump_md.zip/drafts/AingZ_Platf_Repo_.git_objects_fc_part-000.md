---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/fc
part_index: 0
files_included: 7
size_bytes_sum: 6096
created_at: 2025-08-31T21:08:15.652784+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/fc/12fa9fcb0ae5b9f8fcf10d6c8372448172c6d3
meta: {size:186, lines:0, sha256:"7f260165692a81eba75209653c49fbecf05c4bdd82f52594b9bb6750232babc9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fc/4fce7f320d645da1a5a82de6c699f7e78d5b9d
meta: {size:1160, lines:0, sha256:"a0434be69209851a2ce0a75c22829b25a344684bb6f271dfc6e443a45fd18d1a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fc/5212f41624a709fd8429669ceb227264423688
meta: {size:275, lines:0, sha256:"ae59873a68cf20a44ab8094c65e6ee126ee04edee2d0da5df3ccd702aca56b21", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fc/550968ec3eb501e37ab78b5feb07213241ee1a
meta: {size:124, lines:0, sha256:"f105813d75507ac5a5afe81fd9c29e1c5020cd2ee175da33bfcc8d9fe24f1f9a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fc/63324c6cccf1c143ac4203cc95b7d8dada82f8
meta: {size:414, lines:0, sha256:"83f1c2274fa1ea7d0719ff8d391ded7d15d074dce24477562777f8cdd13c36de", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fc/7fb7423091879234bb5712285200bf7b34d156
meta: {size:2779, lines:0, sha256:"fa68e5dc533d767501d36952358f4be7c1a3bf556edfd94bd35e8078c76f5ca6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fc/de0bd55b17e933192260b2ab3db551b209acad
meta: {size:1158, lines:0, sha256:"e34b7a3dc93b21d247ab1d0765b2a9f295fc810e39417f96a9a00c53a9dd97f3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

