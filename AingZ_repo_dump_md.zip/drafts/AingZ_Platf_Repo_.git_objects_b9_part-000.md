---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/b9
part_index: 0
files_included: 9
size_bytes_sum: 4616
created_at: 2025-08-31T21:08:15.630007+00:00
integrity:
  sha256_concat: 31903cef5dd8e48e65d04ead17c5dc8aa90f88134e2e034e6df7ebba8b3a5bd8
---

## AingZ_Platf_Repo/.git/objects/b9/1042565460a518e0f85a6cb19ff862b0a5cf81
meta: {size:119, lines:0, sha256:"602233d57b094dc4b9324882e1462b9b2cd64a49eb734c1b60f312b4e3eb5bb4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b9/1dcec70301f753b4a9ce5f9b1d428faf269ef1
meta: {size:442, lines:0, sha256:"00d08b75fa714b553dfa2e8f357483b44abd1da71b338c646e8cf84759b02c75", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b9/22541e9470acb29054796bc33e816522229638
meta: {size:1600, lines:0, sha256:"de5d87bac2dbc027551f640251c7aca0f5e5b8a7f86cc82df6e724e078847369", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b9/302b514af3091a3ecdcfee7ff9f8cb9d911a7c
meta: {size:75, lines:0, sha256:"999a5130959dcabf668fc4f1489ebe857715ca781e7b031cc824e9798a9ad85f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b9/77c255c1bc40dd9f39dcd754761304ef0eb719
meta: {size:278, lines:5, sha256:"c6667c31846d567b77a4b64a6f3f5cd5b81bd7b58c33f78f01bd4652321a47e3", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x]RAnÄ ìy_í¹[UýÞÄ
ÁÈ8ÝVý{!à:ÌxfGÏãðþöñò}ë<|DÏrýT6|-S¦7	Aì\?¤ÔÎY 6¤ìâ),µÐB¸CªÞtb
é©
°&Gá¢eÄ|úËaBï{Mw@þiëÁÿ¯¥¸FXXÆò9µ½2¶Bp9GÕ&Nòæ"*&:RtkêÌË
²4`ïÁP¶=üÏv_Kév£GK6åõ¨×xçæ]6AwsnAëõ$O®Û$lØÚ,èìò%E°â8"¸£<ëéq=¥rgô¶æì8?;.?¿±Ñð
```

## AingZ_Platf_Repo/.git/objects/b9/90b6272f9a3afb5c7617bd9fd8242dcba99230
meta: {size:137, lines:0, sha256:"0960da2722377d7481ed53f705cff54aae58e6f97ecba61d1271cf3c898d024b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b9/a3a0495dc6cf08ffffe221c3ec48a2c6e8556e
meta: {size:270, lines:0, sha256:"58c12b41ab324c46d145a3f0c3707a423ff1719cbbbdcad88b4f35e5e78a6daa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b9/a433b3fd1fd9e36569fa6624642aa1f36b2384
meta: {size:845, lines:0, sha256:"d555698390f82fe6b96e55a4cf4f7d56cb6ef21c3fec9a154f00e79c50ecf0b6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b9/c61b17405d217e69adef1d58ec0531f76f97d2
meta: {size:850, lines:0, sha256:"7b81c1eb6af814771633ecdaebb08132827130d05d8974d8589669ef8dad66b8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

