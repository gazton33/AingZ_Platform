---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/4c
part_index: 0
files_included: 6
size_bytes_sum: 3822
created_at: 2025-08-31T21:08:15.619166+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/4c/2662d8d52b1728f0e0d34c9fe02d9c048709e9
meta: {size:1976, lines:0, sha256:"7fba6c17c26caf1819d2a4fb4aede44cb48144711780fc01031f4a011c446cde", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4c/657c0dd4e13f0276080dc69bea569e93b6b36e
meta: {size:114, lines:0, sha256:"876aae0511726d397ca4abf472495e45a2118e2e0af27bbbdec4458c1a3df2c4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4c/6b925b385de692dfa010ea2763274035482463
meta: {size:1337, lines:0, sha256:"381c50355867a5497f4c665c120ce1e8352ebff45e6a09c6668d173b2d4e6584", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4c/bc5da1bd8d0cfb30696c9025ae6a9659d29e9b
meta: {size:51, lines:0, sha256:"4156499d3780c5e75cc84e7072b5dadf85ac2b8bafecacde8ddd3e85a27adfcd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4c/e12b604f0e73d6d78bde5da3b116e51f8082be
meta: {size:265, lines:0, sha256:"804aeccbc78c7178c75abb2019eea28c2cfebc842be31954b01a8622237442af", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4c/f6f77c5a12450700b26b349502a6834ec5c363
meta: {size:79, lines:0, sha256:"9abcc556cfa213588a7edf306af80c197d02ad5c5be986677b03fe8bc6cbeeb4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

