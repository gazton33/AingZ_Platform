---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/ruleset/develop
part_index: 0
files_included: 3
size_bytes_sum: 980
created_at: 2025-08-31T21:08:15.670612+00:00
integrity:
  sha256_concat: db96909dff53fefe7ee685cf558ad79f95cb732766062448327d65a4bf12fdc2
---

## AingZ_Platf_Repo/ruleset/develop/.gitkeep
meta: {size:0, lines:0, sha256:"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```

```

## AingZ_Platf_Repo/ruleset/develop/ruleset_chatgpt_v_1.md
meta: {size:556, lines:17, sha256:"73cbf66b9dacbf2a0faa2d4384244e482b1079e3864a9baa1c9a4ea939bed436", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
file: ruleset/develop/ruleset_chatgpt_v_1.md code: RSCGP name: RulesetChatGPT version: v1.0.0 date: 2025-08-24 owner: "AingZ_Platform · RwB" status: draft
---

# Ruleset ChatGPT Platform (incluye ChatGPT-5 y AgentMode)

## Guidelines
- Aplica el Glosario y Ruleset V5.
- Compatible con todos los modelos ChatGPT, incluidos ChatGPT-5 y AgentMode.
- Cada interacción debe registrar ruta exacta y OutputTemplate.
- Respeta la literalidad (LSWP) y contratos ≤120 caracteres.

## Output Template
```markdown
# Respuesta
<contenido>
```
```

## AingZ_Platf_Repo/ruleset/develop/ruleset_codex_v_1.md
meta: {size:424, lines:16, sha256:"a81a8d29678679a7a66084dfb917ca50e5237b1e9bead8d2dd1649c24b262625", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
file: ruleset/develop/ruleset_codex_v_1.md code: RSCDX name: RulesetCodex version: v1.0.0 date: 2025-08-24 owner: "AingZ_Platform · RwB" status: draft
---

# Ruleset Codex Platform

## Guidelines
- Usa naming PascalCase con CODE ≤5.
- Las acciones deben ser reproducibles y trazables.
- Mantén la sincronización con los templates `V5/`.

## Output Template
```markdown
# Código
<instrucciones>
```
```

