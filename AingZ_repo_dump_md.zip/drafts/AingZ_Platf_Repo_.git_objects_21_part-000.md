---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/21
part_index: 0
files_included: 9
size_bytes_sum: 4960
created_at: 2025-08-31T21:08:15.569312+00:00
integrity:
  sha256_concat: f0ec3bb9ae5dd7b7a08af61eaeecc21994cfcf8e120e700f213830184f54caab
---

## AingZ_Platf_Repo/.git/objects/21/2089ab6091e0c94551337e5a9a4c6cc8ec366d
meta: {size:193, lines:0, sha256:"d848769ef2b34b1444f81fa0c2a4374beb7652d35962c8a58a54e5f517f46f97", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/21/2bd95b0993242cc9825f3a502c97768de3a521
meta: {size:557, lines:0, sha256:"586d7281ba74cf9202d25c6c273d1817c3b73e2f9000e14c8fe8fb222062f52d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/21/67d59361742653a4f1b2d4e98d5630ddc91275
meta: {size:398, lines:0, sha256:"f2414ede584078327352097c3f462a46f066d08781e66583f0e0ac7a59eb6514", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/21/98c8ede34aafa622ad0888f269e21048c4cf26
meta: {size:214, lines:3, sha256:"bd82fc43a0ca1ee1e4e6597a4ed85a371ab5b2f8befb1cd7d9ce2b943d36a399", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xµ±NÄ0D©ý[:]'ëdNQ¬7K$G¶àËèù2r¢¥ef4	ó<e¨ÑÝä¨
½+­µÌ*,¥ïú©%mDÉ[$Ö£.YP»¡&ß×Úª\¹¸tzÔ·<)?±ä),éÅü
g´ÔQEÕñöaKS±¨ëÛgñKæ{°­CruÛ88»Ìîg²þóýÖ-^ôö®Ó&x®àûBQSõôæKs¸
```

## AingZ_Platf_Repo/.git/objects/21/a88b05aff5c0a84f74fc08e9bbc7bf456e98d7
meta: {size:329, lines:0, sha256:"dafff5b3b2c1d410a6ade362a273f31c2636d2ae6894fea9e78fa6ec156e6b97", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/21/c39dc751ca967f762605da6de4cae8af8642b9
meta: {size:1882, lines:0, sha256:"1ce61df06ef5c5e5dc55420fd8b1ec04330141eb6ece3f027a43f69fcd2ae77c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/21/d05d6713dcb216574e21c9e3672b40051be9a2
meta: {size:673, lines:0, sha256:"5a2273df06b4a2ee493531f9dff12f82e912111120fad1fec3c0a43889a92c4a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/21/d2521cb130e79f1f203dc94649ec34b07b9d52
meta: {size:601, lines:0, sha256:"b91f712b58ab186e6979af1af6c1d8d83e7f78b2c2a859e5e9c71634f22ccf32", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/21/f00392c9a3ff096c3f7661a04baacc0dc56b10
meta: {size:113, lines:0, sha256:"7c3a6ef827ce0043f7dd1e1c24b985e0abe5263c75396086274e97a4b0259565", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

