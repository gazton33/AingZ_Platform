---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/13
part_index: 0
files_included: 8
size_bytes_sum: 4224
created_at: 2025-08-31T21:08:15.567933+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/13/064d8e42f8ef8358214da3ae2e8730b5563a3a
meta: {size:868, lines:0, sha256:"e55902a95e6cd296e9ef33b55f08d1ebe8fc69245e9352a3d94247e7f57889a8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/13/6de0970de86e353abc09ef1cf6f1798c18b724
meta: {size:99, lines:0, sha256:"97900b0415772f47e6e552f87ee29aae5793df3991d9b43d3567886f121ab287", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/13/c3dd70953c4737f9f46bbfd110dd1e372fd2b4
meta: {size:634, lines:0, sha256:"40a02174a3562a8298d3613f6bf183b9456f00db38ebaac776541e011bad2b10", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/13/c5e171e1822f8b5cceda731e25102bd4bebd71
meta: {size:633, lines:0, sha256:"458e7ee380777d02e0d0d1ebcd78f886c7b8f6d7742448aaf50443c851565bc2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/13/c9943e57e87f0c5cd93eb81e3341d9a62c0716
meta: {size:950, lines:0, sha256:"8db786b12a990abb96be288d786b56cc0d3e8a1601e60f7b0c087de83ab9e616", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/13/e7bc8cc7ee207d6417b05af1ea4e8c3af62210
meta: {size:776, lines:0, sha256:"19424a5d51550a459033fb8d501c253ccd7b4f192d6f3e992a4025d1d981091e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/13/edaa1bdfec90d001b1015ca383df6224dbfd29
meta: {size:192, lines:0, sha256:"f84e3320eac561c76479028397c23741e68bf4b570a88b8b8f5c913f620881c7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/13/fc97f38722fe4a25ad7bd98bdc8c2738d74c6e
meta: {size:72, lines:0, sha256:"6e6ab61e00f0279a22d2ed7f22d684adb15ba3a3891a8a1b72c0edcf7ec19b9d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

