---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/54
part_index: 0
files_included: 5
size_bytes_sum: 5381
created_at: 2025-08-31T21:08:15.619895+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/54/0d8c33fcd56cee126624187ee029ed887a0ddd
meta: {size:1826, lines:0, sha256:"86f758eb5cbd1e511a5eca222d7fcc14339868dd7591eb40f1c16ee2e95810a5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/54/495a9272e09cf42f09b3412ec951120da75c8a
meta: {size:422, lines:0, sha256:"c2ec485a4df8437bf6bf4cfb49372c807a46f52d028dce24cf70982d2eaeb4e0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/54/517079ff0cdfca02e05f8b52fc1a131b41585b
meta: {size:2124, lines:0, sha256:"07ef23ee835871b742175d7873f90942fdba3f75e7e1164f3c9eb87025a536ff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/54/717b815e7668b2661add83a03042bba74d21cd
meta: {size:155, lines:0, sha256:"11a93fc9dbe0cbc7fb9fd5a211d460b619a735ed14d01cacb9e52857b31137e4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/54/eb23a52a8354d6e427ab82b3ae1c72787927e5
meta: {size:854, lines:0, sha256:"670791e781fd8918ceae3a3b8b04e57d04ed32746d26139db54e2d56ed3ae549", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

