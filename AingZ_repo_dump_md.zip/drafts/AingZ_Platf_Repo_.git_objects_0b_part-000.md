---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/0b
part_index: 0
files_included: 3
size_bytes_sum: 509
created_at: 2025-08-31T21:08:15.567402+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/0b/716ec8995161ab5562e3f9ffb1286367c2337d
meta: {size:156, lines:0, sha256:"79f4c03bc68064d3f4d5dcb671a1fc98832b74e3f36a636d04f140c75a37e8aa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0b/e7a3b09a44acaa735619d36371bbc4256bd204
meta: {size:144, lines:0, sha256:"7864647a5b76a1032b621d34f6ab116bf8fb5f8941fd425c240059d550f63e4f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0b/f5a4b4a35de683e63cce62459229f2b6db55e6
meta: {size:209, lines:0, sha256:"85abc7c305b96ac32c19a64964ccc6e93c17ac9988f51d5a9c338384f33b5ab1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

