---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/35
part_index: 0
files_included: 9
size_bytes_sum: 5841
created_at: 2025-08-31T21:08:15.571713+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/35/00551832579b05dba4ea64cb9623ab2b239319
meta: {size:433, lines:0, sha256:"93f07a0ce1d100953256f1743c4ca55b8182f24f9024c6d262e49adebd756794", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/35/08297ade62ed5fa377804d9116ddc02725bbe8
meta: {size:195, lines:0, sha256:"2767cae1269a83eb9a88da6515ce7d508138076c195eb4b3fa42ed10d017e770", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/35/359a032c301fa9a2bde239c70d277cb250996c
meta: {size:75, lines:0, sha256:"d2914f177937e10de2ce2eeb99a756dbd0e379ca67e17c06d3db9522f7f3367a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/35/4f4ce63d2e5795877e01278656b597874efffd
meta: {size:591, lines:0, sha256:"ff3d5c3a156bdbcc0255673d811e657205fcbf396351772a0ab38f4551f80bc5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/35/8159fccb6989ea7e36af2703d2694d7d935c88
meta: {size:1220, lines:0, sha256:"9b540058e0ef856ebcc6b0a37303f79e84f2a6fc1e71251bc93dd631a44bb3b0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/35/91394e0aac8154996d56283ff3bc2e7783769f
meta: {size:1692, lines:0, sha256:"278b55b82f1c6b71f110627181f27889b30b5e1f2ca47320acf89e624851a643", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/35/9b6586abdf2181d778fdc1574dbb7eb5b2e163
meta: {size:611, lines:0, sha256:"84e80b8eae68841dafceb2373f648f42f46fc33caf7c9d42e2a7ab626e23ea2b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/35/9be9d8a63c981dd173aa2fabcfe136f8553b4c
meta: {size:111, lines:0, sha256:"3da442cfb420652b8799894ecd3569c8f0c1720cb147584f51367a27151eddc1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/35/e2f7e881a8eb58847ed28620ab3fcf4a462848
meta: {size:913, lines:0, sha256:"613a818c17d35ecbb5fb919f4cdf1922ae7b9ed9c5510994bea6d8cae9f3d698", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

