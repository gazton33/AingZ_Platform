---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/c6
part_index: 0
files_included: 8
size_bytes_sum: 7696
created_at: 2025-08-31T21:08:15.631086+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/c6/06ab7a3da6947e94c995a602c96f7d0b850dd2
meta: {size:777, lines:0, sha256:"84620cec0c3357c5dc55060093dc40c8769254097d6b232cf397fa340a14b666", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c6/337a8caebf87a6e664c5dd3d23f20b26e3b595
meta: {size:1888, lines:0, sha256:"fc2e13aebdbcc1e07cf3dcdc7c9883fe821f7304e8db70e044bac8cf9256cb62", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c6/4ab3dd201d6cf67226a4357d4506cea241c9b1
meta: {size:85, lines:0, sha256:"fb437f1d7965ce56c4b135ef73ebebaa9282f2dfeb3601f09cecd44d6309a0c0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c6/531225fe6f7ff192b74e5df59edfde06eeedc3
meta: {size:199, lines:0, sha256:"01cae5226b5c5040b4bdb18c9d16d7850e0c2a10f4f79f7cbc3ecabdd246c0d1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c6/719c70128d66bed8a2c73396bf6b1c4cf7fcfc
meta: {size:971, lines:0, sha256:"2cfc03d667cb759bb74df92a9b459be9f5c8ef1237c422d4b80178ef66fa5e33", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c6/f6c513b3bbcefa71e1e0e4cac05592490e6200
meta: {size:1767, lines:0, sha256:"afde5436b1cb5816ad7f4f7248fa12eac10f8701bb42676277666c594312d8e9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c6/f6fced31a8ac2626791391525630efd1013f5d
meta: {size:1889, lines:0, sha256:"5a0dfbec92f7d5356fae6e8cde978779a82fe06ca99967ddc00ced0e8b122666", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c6/f7cdea2e33420d75de904a1fb8f7cd38d7c010
meta: {size:120, lines:0, sha256:"0a2620707b6485faffd8a7977ac844dee0295450bfcf6660ae2a9cd2575c9ca4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

