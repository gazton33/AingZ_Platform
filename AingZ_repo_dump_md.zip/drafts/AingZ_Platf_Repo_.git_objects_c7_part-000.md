---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/c7
part_index: 0
files_included: 11
size_bytes_sum: 10585
created_at: 2025-08-31T21:08:15.631143+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/c7/1fa553de34a159a971a85ae765787aae241b19
meta: {size:1955, lines:0, sha256:"67307f9934907d0b1b59ee9b8d5c0cfd0fcd618b99d081ad3e140063bbbfb07a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c7/3ed17b684b4d1fbbb84ca597884f7dcbd3eca6
meta: {size:138, lines:0, sha256:"a68f7798bdbcaece6de9fd893face09065263401d5aec13ae214a2e333835e7c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c7/4dcc346b47b6c1ec4a46c34687877de5725281
meta: {size:718, lines:0, sha256:"b320a88a54f6eec98235faf998bf0145c336c1634115520db2bb5f0bc4593adc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c7/5d7b5b10f6d9a6ec42bc9e073c77801d17f9ec
meta: {size:429, lines:0, sha256:"eaaab898eb5ab1a63874c6e9c01a7d441d1be37c0b6cb7762c3c896b4112c26a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c7/5e06d5d0f1186bd812cac88dffd46fb0a9c095
meta: {size:693, lines:0, sha256:"00fd01a695db0ac4dd7dc31b3fafb091cd72cda627c42310ef3ee20bcc2e55ff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c7/a5d4d9e29eea94fa34fc49c044e44138d23c43
meta: {size:894, lines:0, sha256:"1bc3cf1bc7633b30e4726462fcf75738ea541502061d8892d35acb2e5d31622b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c7/b9fa32bb46222a3fc1644090c6ef7052049ec0
meta: {size:849, lines:0, sha256:"a9163e8a7b384a6868aa3a5674613de849c1f2627cbc205bf30da3f4a8ad1872", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c7/c375b6bd59c431e2fb54ea1f002ee2e46427b5
meta: {size:840, lines:0, sha256:"5e984d688a95aadca66f18226a0da1db11c3d6cc1b7ce89b4773616102709d22", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c7/c43d218b2e02817d3d684b7d269fd10f4b6e5e
meta: {size:898, lines:0, sha256:"0c825d070237c1d41ed67b2dad8166e83843278e32121be62d1eb09e244311c4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c7/d25b03a41086be352560448290379b53c47d75
meta: {size:1955, lines:0, sha256:"dbc5cadacf5ff0dd3b3fc8626d33f63540444446bc367a4a06eb4c261bff4df1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c7/eb87ada294151b4ec0c131fa11268d9ca57cf8
meta: {size:1216, lines:0, sha256:"d48b07f0d4b303d9c1fc1346aa3929e28c306168f5cd3d1dd83237d422bc7102", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

