---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/main/data_base/core_actv/data/out_template/mtx/validation
part_index: 0
files_included: 1
size_bytes_sum: 0
created_at: 2025-08-31T21:08:15.669230+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/main/data_base/core_actv/data/out_template/mtx/validation/.gitkeep
meta: {size:0, lines:0, sha256:"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```

```

