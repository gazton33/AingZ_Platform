---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/db
part_index: 0
files_included: 8
size_bytes_sum: 2487
created_at: 2025-08-31T21:08:15.649725+00:00
integrity:
  sha256_concat: 86a49eac63e7bfbe3c2ef054dccc7cb78dd20249c44df27c39cf51f07e795c2d
---

## AingZ_Platf_Repo/.git/objects/db/0faacd89fd3a3def3cccb3e9e890b3fc4b9bbf
meta: {size:518, lines:0, sha256:"3223b2f0e4c9efcf881e551dfff8acdc5b820ca25e3879a11eff211c5b633da7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/db/2b8d894922db53c5c09b16132c353cb4e2aa81
meta: {size:206, lines:0, sha256:"871bd7fe78f87ac2c3e4ff35949213b7687e186c4bf05d4bf44e033613b5ba85", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/db/38a880106706192a953c3d93e57ca07c8b6d3b
meta: {size:460, lines:0, sha256:"b51e5fd8781ef19899e6fb6293011bd5e63356dfe47d42ca339e6c9be991e1a1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/db/4afc38437419243fa3485ccebf8e9d7dfac8fa
meta: {size:116, lines:0, sha256:"63f2c6eb621f0191700989268180c52daefe19e67d95e223b7ca41edcae7dcda", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/db/9ef21195579ff679d3014542aadd6a54da1a1d
meta: {size:342, lines:0, sha256:"795a622bc41227e752ef8cffb884c0d75b710ec4d6deaaa1945488c9e7f1c7d9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/db/bfb8d08046a7052f6c3f828a95d3334c7b2bc0
meta: {size:152, lines:0, sha256:"e0984a4289834da4eb2a339927ad83ff5a5390c2b5d6d8e25443cca4352cfb5f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/db/d5b35d67cf91db2aa12d9d29f7237460b32455
meta: {size:545, lines:0, sha256:"d2df77012c1f8fc6da6a49a2380b36076af0fddcdadb19bdf312266801c48177", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/db/fc8abb6ed027199d81dfdd25632adee1a33f47
meta: {size:148, lines:3, sha256:"dd7ab1e5b54fe9134f9138760689bb5cfe976e5b31647c6d7e8d9005e140d846", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xMLÍ
Ã Þ9O!ìVX¥{ÝvCª¦V°hÆðí{½äË÷kYu¦ËU=ÂNÕ³ñJ»²ÑG0&77»Ñ0¹½D~üYÕñ;3Ó§ýÄäSXáP4øX¹c·¸/t.%
U,èïÙbÜ2¹4µÄ$kÃÈ[îWtúÍðgGñ
```

