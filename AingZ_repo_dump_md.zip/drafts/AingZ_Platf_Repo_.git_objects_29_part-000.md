---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/29
part_index: 0
files_included: 3
size_bytes_sum: 903
created_at: 2025-08-31T21:08:15.570269+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/29/7ca2e257da427e6e071741750b5ef4070e9df5
meta: {size:191, lines:0, sha256:"08133a28d74fa41298c63c9b5cc5cd12de5bc2eb15ced1ebb2cf3f4216a55aad", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/29/a420423bc7d6a0365bef608e36d2f52a9e6c30
meta: {size:534, lines:0, sha256:"670498a9a10e323e5364d1ba2cbdc98a2cef8b7b89e048406322b6488d804871", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/29/db5b7da69512b1a2bb069755098d1914c21ba4
meta: {size:178, lines:0, sha256:"ddb7999939abc4c1ff7e9c52969fba1c6f7984018c3b5ed2d7b867802cb80d21", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

