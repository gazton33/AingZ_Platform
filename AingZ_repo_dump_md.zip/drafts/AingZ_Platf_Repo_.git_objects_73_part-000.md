---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/73
part_index: 0
files_included: 6
size_bytes_sum: 3614
created_at: 2025-08-31T21:08:15.623996+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/73/3069cdd3d0f6bd94019344d0fdfcac4c700311
meta: {size:718, lines:0, sha256:"b948d58fbed8db4907cd49cf9533b8c2fe0985ee111ae04b97f37a8c849de27e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/73/36831fe7d0aae540608d60201a530adc453f9f
meta: {size:134, lines:0, sha256:"8f7f7f83fb1f706a8ebdf92a6732deb64b71a9cbc9832aa7ff334279adc09731", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/73/3f269952b1106cb57b811ebb456b6e7cf82804
meta: {size:1229, lines:0, sha256:"f3849ecf18b0161daae0d71fe7bd89868b2252ac2b381be64d559d2c9f3d73a2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/73/6da0a09108c94d4ecbd8676e3a49a21ddfdd26
meta: {size:590, lines:0, sha256:"07c7664703724f6aee969549a3ece9a43d3c551614c5bb4dc81f584f99368b34", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/73/91f318ec35560459d62cfd0be69b3ad7f3cede
meta: {size:293, lines:0, sha256:"845e29fa8e1373ae4ed45da28c3a392fcf51992f95184252d8992b1a88540b09", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/73/ee5323a6f8a8ad5c3c2b1b517e8a7387daa67a
meta: {size:650, lines:0, sha256:"eaab2d7dff59fc27a8983f66d76ff3d3b42058ee4f06a1611c17157b6de1df68", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

