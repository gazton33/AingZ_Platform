---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/f3
part_index: 0
files_included: 6
size_bytes_sum: 1169
created_at: 2025-08-31T21:08:15.652131+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/f3/348922820debe9359c1b1e59b15c45667edd10
meta: {size:91, lines:0, sha256:"1752b78e13aed36ae326d9e2ac41e376b3cc255197f6a8b2f4a3541603afa949", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f3/678d83696bd66151ff01e95e8ad0c3f9cdcd05
meta: {size:173, lines:0, sha256:"f7d0e860a0b1820f248bd29842767123cb012d1c2cd1443d0b6be92e3fd69abe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f3/8a1dc4e23b2203dc17ef862df7158a7bf21fe3
meta: {size:80, lines:0, sha256:"abaf3ce642b7cef13a64fc6215d6e921f8612a52bde47bbf90668192597a0b8c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f3/8c6a7d3840933eabb149a6c2355687f9bc45e7
meta: {size:368, lines:0, sha256:"e95e7dcfda4c95570af68a338ff22fbeb37576cb7ed7da3ac43800fab0f01856", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f3/9294a5b6f90bbc2cc4fd1d0716c961e9f3b730
meta: {size:155, lines:0, sha256:"1f5702d2558d0d6fbe98381068408f7c7bd44be82dbc9ae4e8c605437bc1c792", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f3/955b13a63f0ef690a5361985dab9fd46c8636e
meta: {size:302, lines:0, sha256:"048054194a17a6fb7618ead9c34f2d84449a671354a693227a43c4587ccfd015", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

