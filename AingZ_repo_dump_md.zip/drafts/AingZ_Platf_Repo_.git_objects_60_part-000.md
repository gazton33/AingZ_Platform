---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/60
part_index: 0
files_included: 8
size_bytes_sum: 6126
created_at: 2025-08-31T21:08:15.621751+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/60/10898658b82868c97bc1bd86e0003effce4108
meta: {size:568, lines:0, sha256:"59fc4021ce094b4aa1ef7386ebbf1f52d4e5c335cb7ca6dcc5e82fe1dffc18c1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/60/1d3108db4ce82b77a95103dacdd68cd5920c6d
meta: {size:252, lines:0, sha256:"900fa18af33cf24c9e4cb720c7c4b4c0491d8816af78237b63be4dc84feb05e4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/60/35f2f913947decda627ab2596aa64dc6fa3373
meta: {size:1548, lines:0, sha256:"11114c1e6e87d1107ca6bd1c46bfa40f147c0996f548632c7145b8396af5dd30", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/60/368cd51a53eca36817b1e47a942278ac7a3228
meta: {size:473, lines:0, sha256:"c13c46d137b7615b202f5b77a4e18d4914bca370d90df227d73b81c7137e469b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/60/87e2306bbc0467cca8fd73e6b1a59742afd10f
meta: {size:440, lines:0, sha256:"702040c0bcc7254c980b78fc7bfc448439b8581746a126b84d6939ab88df9973", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/60/c44772d94145a2aa5044d27443606f36816fb8
meta: {size:300, lines:0, sha256:"04e64cd37698e771f3524fed3ec2a1c605bbf2dea83b9e71c33241e261fac494", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/60/d45d52406f9e8f366bcdfbfb919d74b325814b
meta: {size:1524, lines:0, sha256:"4a475c450a2d5e50fbe0428b1e79e7f0a45032581cfba54c998dba57474c6dea", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/60/fdda716f896437cd699cf46816dbbdf93231b9
meta: {size:1021, lines:0, sha256:"a9b88a4c33bee49ac51a8db9cebc31c876a6116409d59a8f77efa6ba1b21fbf7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

