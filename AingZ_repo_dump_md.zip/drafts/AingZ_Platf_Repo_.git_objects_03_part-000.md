---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/03
part_index: 0
files_included: 3
size_bytes_sum: 2447
created_at: 2025-08-31T21:08:15.565892+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/03/399656d2f0e36c2ccf57d6c7122728915cebb6
meta: {size:52, lines:0, sha256:"346ee7845e0d9293c47d8bf63ece7f2026df87d714b4b70da6c991ea0268c400", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/03/65e5ffec5ff81c677cbee51504b9559e713834
meta: {size:369, lines:0, sha256:"54f3e96428e986528518227161f6195352acd4be79b61187833d427b5606b426", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/03/9dd7753f781c679a3356b3f24b0e4934aec429
meta: {size:2026, lines:0, sha256:"aab298c515101d8179abb5a45ab27709ad24f3b32e42e7872b90be3c4cab8626", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

