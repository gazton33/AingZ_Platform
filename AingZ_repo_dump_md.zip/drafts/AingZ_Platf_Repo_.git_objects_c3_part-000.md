---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/c3
part_index: 0
files_included: 5
size_bytes_sum: 1255
created_at: 2025-08-31T21:08:15.630897+00:00
integrity:
  sha256_concat: 5d79cf286a997faa24d1ae6af442e86c15c0ccd3fc7a56ed0db29f0de6237752
---

## AingZ_Platf_Repo/.git/objects/c3/3d06153c53c3b4ea67336e9a1bdd244dbbfffc
meta: {size:80, lines:0, sha256:"c4b7ab4b69f28fd82c6c70b63a2484f012a3ba7ea5353744cb3e1829847d9aaf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c3/4e3a7feb7a7422835198aa38045f2490b15d19
meta: {size:153, lines:3, sha256:"896ac9eb8407a18f79f27e8dbdfb890b3a1fe8913392a13737dc41d712e6d2cd", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎQ
0á=÷½À¤ica]%kSÔé6ðôó{ýá?ÕuõÀ¶«ÚpÊsì{bAÊà¤HH¡l^²ëvBGFñ½:a EN¥gå°Qy·©îv£ÕÑÞÆîÐEÓT¿º?ÆUæ¥Ku½[`
4 ´WÎ³MÿÂæÌÒ#C
```

## AingZ_Platf_Repo/.git/objects/c3/4f04a77f8dbfe866e77b3480d13e562f7d9b0d
meta: {size:765, lines:0, sha256:"66b1ac12dc4f3c2254d0a6180ae321469fb7b33f6f06a8415e26d66a6ef4af0c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c3/5a56c7cfba0ec3a3bbbee48e4e533fd112e047
meta: {size:119, lines:0, sha256:"6c8e43f8d6c0bb3593bad7935c3d60ca4c536579873016b7040a3f6f6780f796", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/c3/9f1ad058e1e4549e4e4f1c3b91880d62a6d8ff
meta: {size:138, lines:0, sha256:"8cd10a2726696753b33bb5dc135f9edd0873cb88060463642222e3945282e2b9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

