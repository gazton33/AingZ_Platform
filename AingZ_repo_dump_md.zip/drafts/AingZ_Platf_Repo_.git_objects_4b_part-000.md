---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/4b
part_index: 0
files_included: 7
size_bytes_sum: 2654
created_at: 2025-08-31T21:08:15.619054+00:00
integrity:
  sha256_concat: b441fcacbac2b0607c10a7d19972006b7cad2c57a4c0968901dca783082d531c
---

## AingZ_Platf_Repo/.git/objects/4b/2353494c083814886824c17f49ad84bdfd0af8
meta: {size:841, lines:0, sha256:"2d1b1aaad2a53518c5015048b45468c2f028b2f57aa9f9ce3db483f53d95fa44", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4b/29be2157fdca2df3eb1226801952d28dba3ad9
meta: {size:39, lines:0, sha256:"70b189f2db3e2fc1afad02d92264ab50037fb3b2b2e2958b3c63f76e622a0bbf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4b/93482875365c43cb9d2049b29ec4ae279b34d5
meta: {size:591, lines:0, sha256:"b80378ed73ddfa6024d1b8c2cbec394cce8f66c2ab874e09fc50eee4192a35f0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4b/b09990622c37b3e611cf603dab898e00dd5a55
meta: {size:867, lines:0, sha256:"2cbb1a71e2141994b810126608d2b2feaa86567eed6d52891c3b9ed2455b5257", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4b/babe511a453ab1cca21c4af16225cb682f6a46
meta: {size:154, lines:3, sha256:"ddece8838556ae6262be15f650f5c230ee865b9b2946d72baee8b74b53741757", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎ[
Ã @Ñ~»
7Ð0¾¢B)ÝÊ8I Æ"BVß¬¡¿.\jµnCjn£3KoU	6eR ­x.LAääÍl]I¼±ó1dR/Çl¬õfCÚa´g(ÙäAàg¬­ËÏÑcäcNÞÖöåþZ*nûD­>¥òÎFíwò@\z-þ+vRâ_DÙ
```

## AingZ_Platf_Repo/.git/objects/4b/d5f92ccaf5a6b4725208123a43f0bfb5904468
meta: {size:121, lines:0, sha256:"b16e74fa66d315a3a9c77e5d443033b8c25cf6cfee79e7b303cc59bc5ba3eeb8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4b/e796930b138486378ed536558e1109ef148421
meta: {size:41, lines:0, sha256:"0899740342f9528f5b1bcd0048d69ff898699546614b149a2ad2c2f6c5b7a794", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

