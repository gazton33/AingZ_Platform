---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/d1
part_index: 0
files_included: 10
size_bytes_sum: 6906
created_at: 2025-08-31T21:08:15.649032+00:00
integrity:
  sha256_concat: a5dce4d45ce67e2282656cee1bcd4c876641bae65c8d1f6b1f0f6c80b279bdf3
---

## AingZ_Platf_Repo/.git/objects/d1/188513b1a249bdfb5ce7e61bce265f5d638b22
meta: {size:137, lines:0, sha256:"2eaccb102abb10e04daa0f259a2e294352a72768c587791f40613e899e62dee3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d1/3dd304c5854afccb91ea2b52e2101cc314849e
meta: {size:157, lines:0, sha256:"544b77ac9ecee2e6dea40caef6a455cfaaffd89a2274f68f2bf925a50f229e19", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d1/5f28e3579cae4e2465e1833dfaaec206c0c02e
meta: {size:75, lines:0, sha256:"ba776c30a5563484ad8165b36416402c7b10c0fb379ec78bb643941d561f5922", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d1/6297db46e2ead843b18b58691d3add2315830f
meta: {size:422, lines:0, sha256:"a3e2acae88f18ecc9bd7a6da26b4c7b3e6be5f9157cef4ed8209bebd3776d370", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d1/675fd49ee8fc8c4782012ffc1bdf37a043f59f
meta: {size:853, lines:0, sha256:"3c6ead49637393effb3a4ac6a1a01b480515c4773a7876b27e4309b5a5c07571", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d1/6acbf866315b565e6e3d4a65b2e421d22f78b2
meta: {size:3085, lines:0, sha256:"aca8fa4b102daa040654f68e7462cd9a6f72e86f229e99a3da431fc49892cb6f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d1/7bc04ad86edbd3226651b267d8cd8cf8b43ff5
meta: {size:153, lines:2, sha256:"f3f87da9a677b45194cfadf9a4196e4419f9f5ab08559876fe37d548f0dd621c", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎÛ	Ã0@Ñ~{
/Ð Û±@)]E$q1.LßÌÐß®}_õo­ªZ b @pr1èÒ4 v0ô.ñæMUfsà4ÀGâ,Q$*zÌ=ú´¥T;ÓÙÊ}ÌÝ©ÊR¾Z_óNëÖIÙÖ¥Ø»>&ì¹êµØô/lù;aE
```

## AingZ_Platf_Repo/.git/objects/d1/9b575ee6c1f364eb641194b136f64a7f3d0e87
meta: {size:534, lines:0, sha256:"6eb558967a54153c5562d445560b624654e82e6971826edf3547be49d5cf6b24", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d1/c1c711aab8240cd9dfa878e6ce6948b1148c15
meta: {size:634, lines:0, sha256:"1fc2c13154559795cc2e583af76d6399e75686f5f281757f4c67762c5bece7e1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d1/c667cbc4c3e15a26edebe5d7cd342a26d92681
meta: {size:856, lines:0, sha256:"54fae6db69a3bee4fbe21db089230efe447d05c87a36fc11ae1b6eb0486fae54", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

