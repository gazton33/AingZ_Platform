---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/a7
part_index: 0
files_included: 10
size_bytes_sum: 4353
created_at: 2025-08-31T21:08:15.629012+00:00
integrity:
  sha256_concat: 20dbad0ce9bb948cee2f90e05b9e018346402be82fb68a975a7b79aa526aeb9b
---

## AingZ_Platf_Repo/.git/objects/a7/0553fa8b1a4ecd0f2fe8dfa9ef1cea7b48fe33
meta: {size:288, lines:0, sha256:"0c077e64d521c592d8ce71c5fc2b81ff7234ae192b03bdeb9360585eb0257a6f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a7/28e9b9eab4f019b79c9f3e5cff2116e1f3441e
meta: {size:261, lines:0, sha256:"1caa70391f8f6ede4dfb58fd0022dd350303a0ab1dfdf3760e740a85c463e326", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a7/441ede2d842f610474682a0ac0c4bcb58dc95d
meta: {size:234, lines:0, sha256:"ce2c15a437a3b0477a5cf81dffce06a7891c0f42ee40ba93fe0752df71ebcc37", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a7/58b20598d69d6e9164bc2495673b44897a52b9
meta: {size:632, lines:0, sha256:"b932711c21ed4eeb0a3354e36aedab15894d8204fbe0cb9585f7078146284338", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a7/6b48343eb0e150f64a6fbc180a42d8867272b1
meta: {size:128, lines:0, sha256:"ce82cbe8b275920aaf25778b66c1253ab100301cd1cc90f62adee5137be23a2e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a7/79a949d4ced6ce148dcce97621254d2270b17a
meta: {size:224, lines:0, sha256:"e91494b23feeb4fd77c6ef5b1fcef98c35ad6e318a8cd0397d4d308b36a491e7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a7/85ba124014ddc692a7609dfacb0600b03d7ef0
meta: {size:88, lines:2, sha256:"4928d6e77cf0128ff3ab58449efa835e403e15abda7ab7856236fd3a4cbf7db4", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÉ1
0PçâÑÉ;¸´´"¶¦õüº¾LcÇÌK;«U¼ëÕÄSöäþ%Ê¦®Êqá¨Mí=÷R÷±ò¼ÑADÕ
```

## AingZ_Platf_Repo/.git/objects/a7/94e70b07fa8f279f413b69e79a974c3fdff837
meta: {size:884, lines:0, sha256:"f80f082099e37c17b1b5fa108ad39aa640c13ebefd297220e23b381614c5b89d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a7/98338835a828fa7e478321a6885f5e30f6f3d4
meta: {size:765, lines:0, sha256:"11df344aa4f82218442d603d7918b97d282a92867865391acad8a2849c2da9c9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a7/a959e5bbc2c904fc8d6a256c77335a58ec520d
meta: {size:849, lines:0, sha256:"f43285037c085de7ab285fabbfeaacf4e866e628771da81725f8e0d3758425a1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

