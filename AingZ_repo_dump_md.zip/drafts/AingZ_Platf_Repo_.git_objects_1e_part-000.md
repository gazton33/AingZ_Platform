---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/1e
part_index: 0
files_included: 10
size_bytes_sum: 4888
created_at: 2025-08-31T21:08:15.569015+00:00
integrity:
  sha256_concat: de5a1fb97d2255066e9954e350e45818447c1608564b8f10a83a5b6602bb515b
---

## AingZ_Platf_Repo/.git/objects/1e/4ce4d4162773b546e047e058a8b32fad39b1ae
meta: {size:369, lines:0, sha256:"2e72dd082efe59c73ed435135b403e2a49fe9cdb53f0ad689a3c49df64c819f6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1e/4e80cb7049b21c619a43c7c75172bdfe9950d7
meta: {size:644, lines:0, sha256:"0fde514f4dfdfd6083b5c1beb7646b18ba938a51056057ed7b8766cee6850edc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1e/513a6b5a0fe619e9bb45e50fd7b612adc1e681
meta: {size:51, lines:0, sha256:"6662e385bf89c5a2915833c81ad4342eb36473881b1b5d0650819c72e57e9c8c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1e/6c634600dd12a05ddc093521775c67ae214bb9
meta: {size:759, lines:0, sha256:"bb0f756c415323cfd2778037d2aaecc0cf2c619d1fa4c4f6928462b18507355e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1e/75ff06f2a3b5a75e4825b299c6b4a391a4d4c7
meta: {size:178, lines:0, sha256:"43a7a60e3fc00651642a64d3c92ab682a81f4f67e303b351d043758a15adafd8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1e/8c7060e77d5405189bdef70b7b8de95b37624e
meta: {size:136, lines:0, sha256:"a8b5e1a1f49f488c5c21f3e942507d7210b2317d00bcd23ab04dfbb54baef4df", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1e/8e8143bab1eeeb4294c02ce8cf088c5b2e6d39
meta: {size:656, lines:0, sha256:"d7a7a5d87b4df83309c900cc4ada5e2e53b31de535cf0cf7c2e17b1703e6be5a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1e/93ee3c5178fd3eb0c9b48d74941197fe61c7fa
meta: {size:852, lines:3, sha256:"8fa1a824c1822cc2d1fa2850a58c2e853de877d2a0f3da94f0f2060a1744aa98", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xu[¢H÷_ÑÉ¾ìÌÐ\7³Añ"â4Mr³Qý:ó<S'©ÊÉùª
·u]@ºøÇÀ)±.iXHO¤\Ìr=×E¤HYTÆag
×%4 (,Ëâ<Ï BB¦B(C¤8Ñ\åq(Z²¡ð~}à¢ûNë¤¬¾â¶þHU4(!U_> ÷Q?ÂÀ²1ß®z}§åPéoÚhGû/?jn-W.ð8¬®që§ÎL½ç1_?÷×mÀå"XÆQÊ0wØûåF6ÝÙãÇÃ«h\õëU80»,a«FÍ+QhË§HÈ¢9þõû}@nì¦ðÌî>mÅÊN[Ï¬©v,6:¼®µ]tKwc¸7ÉUù^BÃ¼²ª¬}Ç+)«ÌÛ%YëþQgr@ÀËÍ:ÁkKuç wdÚp.ÈÁÄÇ¿;ièò\uSïg·@ÕMSyïzå@cÌmmÚn¬Û9»GÓÎl¹}¯Ðµ"vZ$¬$«pbSæá³¾Ðö¥ÇþXiW«ìLé¥»åÁÑá* KOayüt^Sz.æ½[ÒÖºbQtÛná×«0VVð-;´ÝEÈz÷ÑÁ¶ÞT	'Q	w¾0emø^F³êØÜcª¯p(íÏ°ÕxÙ@ÜÔ,eâ`õ¸xÁ¹÷OÍsív>xíiËr7w´)VCh¶/ì{5á	y¨Ñop`4xÆHÐ/Ùx¯¥èèüð¸ÝçÎðÚ¬übü`9½õñØ½#U$UjÅ5,)¶"§tqÚØÒxmgR*ÑÙZ®GðÔ¤½ù[õçkë3	óÙP~ä0D÷nIá"è$ùöVSËèíÕ¶[ñV'WZ:{©%¿}ët{°x¼!û{;·'ÅrÃ­ß÷ØD§(KÖï«¼äÀ¿·EôAýs÷-×üõEpä	Zö¨KÊáóTeC@V&´iû²=fe7¿þô¿9îÀVÀ
```

## AingZ_Platf_Repo/.git/objects/1e/a0599989a53812a98acab3bdcb4d83bc5494f0
meta: {size:1089, lines:0, sha256:"5cbf036b183649b8dc52eea18094a50c2700e282730c5f34738d10e3b0420e02", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/1e/c2a00b67adfe163495d1faf73472e8d878bf97
meta: {size:154, lines:2, sha256:"24b72a867ec477503fb639eadf2322d595a737ff4cc844884fd4faf90eded9ae", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xQ
Â0ýÎ)rËfÓm² âUÍ¶Z#%"ôôæþÍx0R÷ýÙ,ºxijÌ)³ÇE8"Í> pS,Ú:óN¾!2As*³óÀäNd%`w&}ÚZ»¤³Õ÷ö¶§n*kýêñXöôÜ©ûÝº@ãÈÓh¯àL·=±é_gSt3?OCm
```

