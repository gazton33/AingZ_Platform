---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/legacy/templates
part_index: 0
files_included: 8
size_bytes_sum: 35933
created_at: 2025-08-31T21:08:15.667276+00:00
integrity:
  sha256_concat: 0959ab68cd626c1fa5df399b4d644eb85e31e9ba2fc99b1acf73d644cf8efaad
---

## AingZ_Platf_Repo/legacy/templates/buckets_assets_entidades_baseline_v_1_full.md
meta: {size:12311, lines:127, sha256:"d3c23cb06b09e0f04c1e0a38ae56de3fe5ff74dbfd0394113a2407b224d804cd", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: core/doc/workbench/AINGZ\_V5\_Buckets\_Assets\_Entidades\_Baseline\_v1\_full.md code: BAMBL name: BucketsAssetsEntidadesBaselineV1 version: v1.0.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: locked referencias:

- source\_snapshot: core/doc/workbench/AINGZ\_V5\_Buckets\_Assets\_Entidades\_Map\_v1.md
- tree\_baseline: BL-2025-08-18-DirTree-v1.4.2 triggers: [TRG\_BASELINE\_LOCK] cambios:
- 2025-08-18: Congelado el mapa maestro real con crossref/wikilinks. checks:
- Enlaces `[[DIR::<CODE>]]` válidos
- Tablas completas y consistentes
- Tipos normalizados {bucket|asset|entity}

---

# Baseline Lock — Buckets / Assets / Entidades v1.0.0 (FULL)

**Baseline-ID**: BL-2025-08-18-BucketsMap-v1.0.0\
**Árbol**: BL-2025-08-18-DirTree-v1.4.2\
**Origen**: `AINGZ_V5_Buckets_Assets_Entidades_Map_v1.md` (snapshot 2025-08-18)

> Estado congelado. Cambios futuros en *working copy* y nuevo lock.

---

## 1) Tabla maestra por nodo principal

| CODE  | Nodo (wikilink) | Tipo                   | Función operativa | Entradas                                  | Salidas               | R (owner) / A (aprob)     | Calidad/QMS                |                          |
| ----- | --------------- | ---------------------- | ----------------- | ----------------------------------------- | --------------------- | ------------------------- | -------------------------- | ------------------------ |
| ROOT  | [[DIR::ROOT     | AingZ\_Platform]]      | bucket            | Monorepo raíz. Política, CI/CD, paquetes. | Repos, normas         | Releases, docs            | R: Platform-Ops · A: QMS   | [[CHG::]] [[QMS::]]      |
| MAIN  | [[DIR::MAIN     | main]]                 | bucket            | Código y datos activos.                   | Issues, PRs           | Builds, artefactos        | R: Core Dev Lead · A: Arch | [[VALG::]] [[RULESET::]] |
| DB    | [[DIR::DB       | data\_base]]           | bucket            | Knowledge base de plataforma.             | Ingesta docs/datasets | Conocimiento versionado   | R: Data Stewards · A: Arch | [[VALD::]]               |
| CACT  | [[DIR::CACT     | core\_actv]]           | bucket            | Activos nucleares de operación.           | Specs, plantillas     | Guías, datasets           | R: Core Ops · A: QMS       | [[CHG::]]                |
| DOCS  | [[DIR::DOCS     | docs]]                 | asset             | Medios y documentación evidencia.         | AUD/IMG/VID/LIB       | Evidencia validación      | R: Tech Writers · A: QMS   | [[VALG::]]               |
| DATA  | [[DIR::DATA     | data]]                 | bucket            | Datos estructurados y metadatos.          | CSV/JSON/Parquet      | Tablas, catálogos         | R: Data Eng · A: Arch      | [[VALD::]]               |
| SEM   | [[DIR::SEM      | semantics]]            | entity            | Vocabulario controlado y reglas.          | Términos, reglas      | IDs, contratos            | R: Ontology Lead · A: Arch | [[RULESET::]]            |
| AILE  | [[DIR::AILE     | ai\_learn]]            | bucket            | Entrenamiento, evaluación y feedback IA.  | Datasets, prompts     | Evals, insights           | R: MLE · A: Arch           | [[VALG::]]               |
| DEVP  | [[DIR::DEVP     | develop]]              | bucket            | Config, setup, orquestación desacoplada.  | Config, specs         | Entornos y conectores     | R: DevOps · A: Arch        | [[QMS::]]                |
| OTPL  | [[DIR::OTPL     | out\_template]]        | asset             | Plantillas de salida estándar.            | Reqs, lineamientos    | Documentos estandarizados | R: QMS · A: Arch           | [[VALD::]]               |
| GUID  | [[DIR::GUID     | guides]]               | asset             | Guías operativas y playbooks humanos.     | Procedimientos        | SOPs                      | R: QMS · A: Arch           | [[QMS::]]                |
| WF    | [[DIR::WF       | wf\_playbooks]]        | asset             | Workflows ejecutables.                    | Inputs, triggers      | Runs, logs                | R: Platform-Ops · A: Arch  | [[VALG::]]               |
| KCTX  | [[DIR::KCTX     | kns\_ctx\_vivo]]       | asset             | Contexto vivo y snapshots.                | Snapshots             | Estados reproducibles     | R: Platform-Ops · A: QMS   | [[CHG::]]                |
| CDEV  | [[DIR::CDEV     | core\_dev]]            | bucket            | Desarrollo núcleo.                        | Issues, spikes        | Módulos core              | R: Core Dev Lead · A: Arch | [[VALG::]]               |
| CARC  | [[DIR::CARC     | core\_arch\_platform]] | bucket            | Arquitectura de plataforma.               | ADRs, blueprints      | Artefactos de arq         | R: Architect · A: CTO      | [[ADR::]]                |
| LOG   | [[DIR::LOG      | log]]                  | bucket            | Registros de cambios y validaciones.      | Commits, runs         | CHG, VALG                 | R: QMS · A: Arch           | [[QMS::]]                |
| GIT   | [[DIR::GIT      | .github]]              | asset             | CI/CD y automatizaciones.                 | Workflows             | Checks, deployments       | R: DevOps · A: Arch        | [[QMS::]]                |
| PKG   | [[DIR::PKG      | packages]]             | bucket            | Paquetes y módulos compartidos.           | Código                | Librerías                 | R: Core Dev · A: Arch      | [[VALG::]]               |
| RULE  | [[DIR::RULE     | ruleset]]              | entity            | Políticas y reglas del repo.              | Normas                | Enforcement               | R: QMS · A: Arch           | [[RULESET::]]            |
| SCRIP | [[DIR::SCRIP    | scripts]]              | asset             | Utilidades de mantenimiento.              | Tareas                | Scripts ejecutables       | R: DevOps · A: Arch        | [[VALG::]]               |

---

## 2) Semantics (SEM)

| CODE | Nodo        | Tipo              | Función | Entradas                                   | Salidas       | Crossref          |                   |
| ---- | ----------- | ----------------- | ------- | ------------------------------------------ | ------------- | ----------------- | ----------------- |
| GLOS | [[DIR::GLOS | glossary]]        | entity  | Definir términos y definiciones canónicas. | PRs, términos | IDs, definiciones | [[GLOS::MAIN]]    |
| DICT | [[DIR::DICT | dicts]]           | entity  | Diccionarios operativos de términos.       | CSV/MD        | Diccionarios      | [[RULESET::DICT]] |
| CDCT | [[DIR::CDCT | code\_dict]]      | entity  | Mapeos de código a significado/acción.     | Matrices      | Code→Sem          | [[TPL::CODEMAP]]  |
| TDCT | [[DIR::TDCT | trigger\_dict]]   | entity  | Catálogo de triggers y contratos.          | Triggers      | Firmas y rutas    | [[WF::INDEX]]     |
| ADCT | [[DIR::ADCT | app\_dict]]       | entity  | Alias y metadatos de aplicaciones.         | Apps          | Aliases           | [[RULESET::APPS]] |
| PDCT | [[DIR::PDCT | prompt\_dict]]    | entity  | Prompts estandarizados y roles.            | Prompts       | Catálogo          | [[TPL::PROMPTS]]  |
| INGP | [[DIR::INGP | ingest\_prompts]] | asset   | Prompts para ingesta y parsing.            | Docs          | Extractos         | [[WF::INGEST]]    |
| VOC  | [[DIR::VOC  | vocabulary]]      | entity  | Vocabulario controlado y sinónimos.        | Términos      | Lexicón           | [[GLOS::VOC]]     |
| RSET | [[DIR::RSET | ruleset]]         | entity  | Reglas de negocio/técnicas.                | Normas        | Reglas            | [[RULESET::MAIN]] |

---

## 3) AI Learn (AILE)

| CODE  | Nodo         | Tipo           | Función | Entradas                                | Salidas     | Crossref         |                   |
| ----- | ------------ | -------------- | ------- | --------------------------------------- | ----------- | ---------------- | ----------------- |
| LEARN | [[DIR::LEARN | learning]]     | asset   | Currícula y objetivos de entrenamiento. | Datasets    | Plan de training | [[WF::TRAIN]]     |
| EVAL  | [[DIR::EVAL  | evaluation]]   | asset   | Evals, métricas y suites.               | Suites      | Reportes         | [[VALG::EVALS]]   |
| INSI  | [[DIR::INSI  | insights]]     | asset   | Hallazgos y análisis.                   | Logs, evals | Insights         | [[CHG::INSIGHTS]] |
| FTUN  | [[DIR::FTUN  | fine\_tuning]] | asset   | Ajuste fino de modelos.                 | Datasets    | Modelos          | [[WF::FT]]        |
| FSHT  | [[DIR::FSHT  | few\_shot]]    | asset   | Ejemplos canónicos.                     | Casos       | Ejemplos         | [[TPL::FS]]       |
| RELV  | [[DIR::RELV  | relevance]]    | asset   | Ranking y recall.                       | Queries     | Scores           | [[WF::RAG]]       |
| TRNG  | [[DIR::TRNG  | training]]     | asset   | Sesiones de entrenamiento.              | Config      | Modelos          | [[WF::TRAIN]]     |
| FDBK  | [[DIR::FDBK  | feedback]]     | asset   | Retroalimentación y bucles.             | Feedback    | Cambios plan     | [[WF::FB]]        |

---

## 4) Out Templates (OTPL)

| CODE  | Nodo         | Tipo             | Función | Entradas                      | Salidas      | Crossref   |                  |
| ----- | ------------ | ---------------- | ------- | ----------------------------- | ------------ | ---------- | ---------------- |
| MTX   | [[DIR::MTX   | mtx]]            | asset   | Matrices comparativas.        | Criterios    | Scores     | [[TPL::MTX]]     |
| MATR  | [[DIR::MATR  | matrix]]         | asset   | Scoring reproducible.         | Pesos        | Puntajes   | [[TPL::MTX]]     |
| TBLS  | [[DIR::TBLS  | table]]          | asset   | Tablas estándar.              | Datos        | Tablas     | [[TPL::TABLE]]   |
| RCSH  | [[DIR::RCSH  | record\_sheet]]  | asset   | Planillas registrables.       | Datos        | Planillas  | [[TPL::RCSH]]    |
| MAPP  | [[DIR::MAPP  | mapping]]        | asset   | Mapeos de origen-destino.     | Campos       | Mapas      | [[TPL::MAP]]     |
| RELN  | [[DIR::RELN  | relation]]       | asset   | Relaciones entre entidades.   | Entidades    | Relaciones | [[TPL::REL]]     |
| VALD  | [[DIR::VALD  | validation]]     | asset   | Validaciones y checks.        | Reglas       | Logs       | [[QMS::VAL]]     |
| COMP  | [[DIR::COMP  | comparison]]     | asset   | Comparativas de alternativas. | Alternativas | Reportes   | [[TPL::COMP]]    |
| OTPD  | [[DIR::OTPD  | docs]]           | asset   | Documentos de salida.         | Reqs         | Docs       | [[TPL::DOC]]     |
| WSPC  | [[DIR::WSPC  | workspaces]]     | asset   | Espacios de trabajo.          | Config       | Entornos   | [[RULESET::ENV]] |
| PARCH | [[DIR::PARCH | platform\_arch]] | asset   | Artefactos de arquitectura.   | ADR, BP      | Blueprints | [[ADR::0001]]    |
| ATOOL | [[DIR::ATOOL | ai\_tools]]      | asset   | Herramientas IA empaquetadas. | Specs        | Tools      | [[WF::TOOLS]]    |

---

## 5) Guides (GUID)

| CODE | Nodo        | Tipo               | Función | Entradas                 | Salidas | Crossref   |                |
| ---- | ----------- | ------------------ | ------- | ------------------------ | ------- | ---------- | -------------- |
| PLIN | [[DIR::PLIN | planin]]           | asset   | Planeamiento y gobierno. | Reqs    | Planes     | [[TPL::PLAN]]  |
| MPLN | [[DIR::MPLN | mpln]]             | asset   | Master plan.             | Insumos | MPlan      | [[ADR::0001]]  |
| BCRT | [[DIR::BCRT | brainstorm\_crtv]] | asset   | Ideación estructurada.   | Ideas   | Backlog    | [[TPL::BRAIN]] |
| RCTL | [[DIR::RCTL | run\_control]]     | asset   | Control de ejecución/QA. | Reglas  | Checks     | [[QMS::RUN]]   |
| PIPE | [[DIR::PIPE | pipeline]]         | asset   | Flujos/ETL.              | Fuentes | Artefactos | [[WF::PIPE]]   |

---

## OutputTemplate

```yaml
output_example:
  status: BASELINE_LOCKED
  baseline_id: BL-2025-08-18-BucketsMap-v1.0.0
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - files_frozen: [core/doc/workbench/AINGZ_V5_Buckets_Assets_Entidades_Baseline_v1_full.md]
  log:
    - step1: qa_pass
    - step2: checkpoint
    - step3: freeze
```

```

## AingZ_Platf_Repo/legacy/templates/dir_tree_v_1_4_baseline_locked.md
meta: {size:8024, lines:111, sha256:"fbac6dcebb4d65106fe3946fbb85c804f16574fafc26a407ea1e34a0f54d907e", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: core/doc/workbench/dir_tree_v_1_4_baseline_locked.md code: ARBBL name: DirTreeV14BaselineLocked version: v1.4.2 date: 2025-08-18 owner: AingZ\_Platform · RwB status: locked referencias: [DirTreeV14Aligned, aing\_z\_v\_5\_dir\_tree\_v\_1.md] triggers: [TRG\_BASELINE\_LOCK] cambios:

- 2025-08-18: Freeze de la vista alineada con notas y códigos. checks:
- Vista ASCII con columnas fijas
- Índice de códigos presente
- Descripciones breves coherentes

---

# Baseline Lock — Árbol de Directorios v1.4.2

**Baseline-ID**: BL-2025-08-18-DirTree-v1.4.2\
**Origen**: DirTreeV14Aligned (v1.4.2)\
**Alcance**: Estructura visual con [CODE] y descripción alineados.

> Estado congelado. Cualquier cambio futuro debe realizarse en un *working copy* y proponer nuevo lock.

## Árbol congelado

```text
AingZ_Platform                                        [ROOT]  — raíz del repositorio
├── main                                              [MAIN]  — código y datos activos
│   ├── data_base                                     [DB]    — base de conocimiento
│   │   ├── core_actv                                 [CACT]  — activos nucleares
│   │   │   ├── docs                                  [DOCS]  — media y documentación
│   │   │   │   ├── audio                             [AUD]   — insumos de audio
│   │   │   │   ├── image                             [IMG]   — insumos de imagen
│   │   │   │   ├── video                             [VID]   — insumos de video
│   │   │   │   ├── library                           [LIB]   — papers y libros
│   │   │   │   └── onboard                           [ONB]   — materiales de onboarding
│   │   │   ├── data                                  [DATA]  — datasets y metadatos
│   │   │   │   ├── semantics                         [SEM]   — semántica de plataforma
│   │   │   │   │   ├── glossary                      [GLOS]  — glosarios
│   │   │   │   │   ├── dicts                         [DICT]  — diccionarios
│   │   │   │   │   ├── code_dict                     [CDCT]  — mapeos de código
│   │   │   │   │   ├── trigger_dict                  [TDCT]  — dicc. de triggers
│   │   │   │   │   ├── app_dict                      [ADCT]  — apps y aliases
│   │   │   │   │   ├── prompt_dict                   [PDCT]  — prompts estándar
│   │   │   │   │   ├── ingest_prompts                [INGP]  — prompts de ingesta
│   │   │   │   │   ├── vocabulary                    [VOC]   — vocabulario controlado
│   │   │   │   │   └── ruleset                        [RSET]  — reglas y políticas
│   │   │   │   ├── ai_learn                          [AILE]  — aprendizaje de la IA
│   │   │   │   │   ├── learning                      [LEARN] — currícula
│   │   │   │   │   ├── evaluation                    [EVAL]  — evals y métricas
│   │   │   │   │   ├── insights                      [INSI]  — hallazgos
│   │   │   │   │   ├── fine_tuning                   [FTUN]  — ajustes finos
│   │   │   │   │   ├── few_shot                      [FSHT]  — ejemplos canónicos
│   │   │   │   │   ├── relevance                     [RELV]  — ranking/recall
│   │   │   │   │   ├── training                      [TRNG]  — sesiones de training
│   │   │   │   │   └── feedback                      [FDBK]  — retroalimentación
│   │   │   │   ├── develop                           [DEVP]  — desarrollo de plataforma
│   │   │   │   │   ├── ruleset                       [RDEV]  — reglas de dev
│   │   │   │   │   ├── config                        [CNFG]  — configuración
│   │   │   │   │   ├── setup                         [SETUP] — instalación
│   │   │   │   │   ├── customization                 [CSTM]  — personalización
│   │   │   │   │   ├── specs                         [SPECS] — especificaciones
│   │   │   │   │   ├── preferences                   [PREF]  — preferencias
│   │   │   │   │   ├── connectors                    [CNTR]  — puertos/adaptadores
│   │   │   │   │   └── orchestrator                  [ORCH]  — orquestador/wf
│   │   │   │   ├── out_template                      [OTPL]  — plantillas de salida
│   │   │   │   │   ├── mtx                           [MTX]   — matrices comparativas
│   │   │   │   │   │   ├── matrix                    [MATR]  — scoring
│   │   │   │   │   │   ├── table                     [TBLS]  — tablas
│   │   │   │   │   │   ├── record_sheet              [RCSH]  — planillas
│   │   │   │   │   │   ├── mapping                   [MAPP]  — mapeos
│   │   │   │   │   │   ├── relation                  [RELN]  — relaciones
│   │   │   │   │   │   ├── validation                [VALD]  — validaciones
│   │   │   │   │   │   └── comparison                [COMP]  — comparativas
│   │   │   │   │   ├── docs                          [OTPD]  — docs para outputs
│   │   │   │   │   ├── workspaces                    [WSPC]  — espacios de trabajo
│   │   │   │   │   ├── platform_arch                 [PARCH] — arq de plataforma
│   │   │   │   │   └── ai_tools                      [ATOOL] — herramientas IA
│   │   │   │   └── guides                            [GUID]  — guías operativas
│   │   │   │       ├── planin                        [PLIN]  — planeamiento
│   │   │   │       │   ├── mpln                      [MPLN]  — master plan
│   │   │   │       │   └── brainstorm_crtv           [BCRT]  — ideación
│   │   │   │       ├── run_control                   [RCTL]  — ejecución/QA
│   │   │   │       └── pipeline                      [PIPE]  — flujos/ETL
│   │   │   ├── wf_playbooks                          [WF]    — playbooks de workflows
│   │   │   └── kns_ctx_vivo                          [KCTX]  — contexto vivo
│   │   ├── core_dev                                  [CDEV]  — desarrollo núcleo
│   │   └── core_arch_platform                         [CARC]  — arq. de plataforma
├── log                                               [LOG]   — cambios y calidad
│   ├── changelog                                     [CHG]   — registro de cambios
│   ├── validation                                    [VALG]  — logs de validación
│   └── qms                                           [QMS]   — calidad y normas
├── .github                                           [GIT]   — CI/CD y workflows
├── packages                                          [PKG]   — paquetes y módulos
├── ruleset                                           [RULE]  — políticas del repo
└── scripts                                           [SCRIP] — utilidades y tareas
```

---

## OutputTemplate

```yaml
output_example:
  status: BASELINE_LOCKED
  baseline_id: BL-2025-08-18-DirTree-v1.4.2
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - files_frozen: [core/doc/workbench/dir_tree_v_1_4_baseline_locked.md]
  log:
    - step1: qa_pass
    - step2: checkpoint
    - step3: freeze
```

```

## AingZ_Platf_Repo/legacy/templates/glossary_real_v_1.md
meta: {size:4463, lines:64, sha256:"ae5f09271cae24140ed50c2df45436c544547f686e82a0b9e9e0929ceafe6317", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: core/doc/workbench/AINGZ\_V5\_Glossary\_Real\_v1.md code: GREAL name: GlossaryRealV1 version: v1.0.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: draft (real) referencias:

- BL-2025-08-18-DirTree-v1.4.2
- BL-2025-08-18-BucketsMap-v1.0.0
- PCTRL (PlatformControlPrinciplesV1)
- GTPL (Glossary\_Template\_v1) triggers: [TRG\_GLOSSARY\_REAL, TRG\_XREF\_GRAPH] cambios:
- 2025-08-18: Primera versión real del glosario con refs a DIR::. checks:
- IDs únicos prefijo GLOS::
- Refs sólo a buckets DIR::
- Sin rutas de archivos ni anclas

---

# Glosario — Real v1

**Contrato**: Término → Definición breve → Referencias a buckets `DIR::`. Sin enlaces a archivos.

## Tabla

| ID (GLOS::)    | Término             | Definición breve                                          | Refs (DIR::)                                 | Sinónimos           | Tags            |
| -------------- | ------------------- | --------------------------------------------------------- | -------------------------------------------- | ------------------- | --------------- |
| GLOS::MAIN     | Glosario principal  | Conjunto de términos canónicos del monorepo.              | [[DIR::SEM]], [[DIR::ROOT]]                  | vocabulario         | #glosario       |
| GLOS::BUCKET   | Bucket              | Agrupador lógico de carpetas y assets para un dominio.    | [[DIR::ROOT]], [[DIR::DB]]                   | carpeta lógica      | #estructura     |
| GLOS::ASSET    | Asset               | Artefacto tangible y versionable bajo control QMS.        | [[DIR::DOCS]], [[DIR::OTPL]], [[DIR::SCRIP]] | artefacto           | #artefacto      |
| GLOS::ENTITY   | Entidad             | Contrato semántico aplicable a datos o procesos.          | [[DIR::SEM]]                                 | concepto            | #semantica      |
| GLOS::RULESET  | Ruleset             | Conjunto de reglas con router por plataforma/app/api.     | [[DIR::RULE]]                                | políticas           | #gobierno       |
| GLOS::PIPE     | Pipeline            | Orquestación declarativa disparada por triggers.          | [[DIR::PIPE]], [[DIR::WF]]                   | flujo               | #orquestacion   |
| GLOS::WFTRIG   | Trigger de workflow | Evento que inicia una ejecución o cambio de estado.       | [[DIR::WF]]                                  | disparador          | #workflow       |
| GLOS::BASELOCK | Baseline lock       | Estado congelado e inmutable de un artefacto.             | [[DIR::LOG]]                                 | freeze              | #qms            |
| GLOS::VREVIEW  | Version review      | Evaluación de deltas, riesgos y recomendación de versión. | [[DIR::OTPD]]                                | revisión de versión | #qms            |
| GLOS::QMS      | QMS                 | Sistema de gestión de calidad, validaciones y normas.     | [[DIR::QMS]]                                 | calidad             | #qms            |
| GLOS::KCTX     | Contexto vivo       | Estado operativo actual para continuidad de procesos.     | [[DIR::KCTX]]                                | estado activo       | #operacion      |
| GLOS::AILE     | AI Learn            | Área de aprendizaje, evaluación y feedback de IA.         | [[DIR::AILE]]                                | mlops               | #ia             |
| GLOS::DEVP     | Develop             | Configuración, conectores y orquestación desacoplada.     | [[DIR::DEVP]]                                | devops              | #plataforma     |
| GLOS::OTPL     | Out Templates       | Plantillas de salida estandarizadas para entregables.     | [[DIR::OTPL]]                                | templates           | #documentacion  |
| GLOS::GUID     | Guides              | Guías operativas y SOPs de la plataforma.                 | [[DIR::GUID]]                                | manuales            | #procedimientos |

---

## Reglas mínimas

- Mantener sólo namespaces aprobados: `DIR::, GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::`.
- El alias visible de un nodo puede cambiar; el `DIR::<CODE>` es estable.
- Añadir términos nuevos con impacto → crear ADR.

## OutputTemplate

```yaml
output_example:
  status: GLOSSARY_REAL_READY
  created_at: 2025-08-18T00:00:00-03:00
  params:
    - namespaces: [DIR::, GLOS::]
  result:
    - terms_defined: 15
    - file_refs_detected: 0
  log:
    - step1: author
    - step2: link_dirs
    - step3: validate
```

```

## AingZ_Platf_Repo/legacy/templates/glossary_template_v_1.md
meta: {size:1501, lines:53, sha256:"c2c7350f008b731e9b7e256dd3e97371eff6668d6cccc60297d9c209d0151f5d", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: templates/glossary/Glossary\_Template\_v1\_1\_linked.md code: GTPL11 name: GlossaryTemplateV1\_1Linked version: v1.1.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: template referencias: [DTT11] triggers: [TRG\_GLOSSARY] cambios:

- 2025-08-18: Añade namespaces, política anti-archivo y formato de IDs. checks:
- IDs únicos `GLOS::<ID>` (3–8 alfanum mayúscula)
- Refs sólo a `DIR::`
- Sin rutas de archivos ni anclas

---

# Glosario — Plantilla v1.1 enlazada

**Contrato**: Término → Definición → Refs a buckets `DIR::`. Sin enlaces a archivos.

## Namespaces y políticas

```yaml
namespaces: { dir: "DIR::", glos: "GLOS::" }
policies: { no_file_refs: true }
```

## Tabla (rellenar)

| ID (GLOS::) | Término    | Definición breve      | Refs (DIR::)         | Sinónimos | Tags      |
| ----------- | ---------- | --------------------- | -------------------- | --------- | --------- |
| GLOS::      | \<término> | \<definición concisa> | [[DIR::]], [[DIR::]] |           | #glosario |

## Reglas mínimas

1. `ID` estable y único. No reutilizar.
2. Definición ≤ 25 palabras. Sin dependencias tecnológicas.
3. Refs sólo a buckets `DIR::`. Cero rutas absolutas/relativas.
4. Términos con impacto crean ADR.

## Checklist

-

## OutputTemplate

```yaml
output_example:
  status: GLOSSARY_TEMPLATE_READY
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - terms_defined: <n>
  log:
    - step1: author
    - step2: link_dirs
    - step3: validate
```

```

## AingZ_Platf_Repo/legacy/templates/platform_control_principles_v_1.md
meta: {size:2723, lines:79, sha256:"e3d21da87fe9c8f1aa8f8f7067d585d7b00d1ddc5c044e48f19ac8df1a7b2627", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: core/doc/workbench/AINGZ\_V5\_Platform\_Control\_Principles\_v1.md code: PCTRL name: PlatformControlPrinciplesV1 version: v1.0.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: draft referencias:

- BL-2025-08-18-DirTree-v1.4.2
- BL-2025-08-18-BucketsMap-v1.0.0
- DTTPL (DirTree\_Generic\_Template\_v1)
- DTT11 (DirTree\_Generic\_Template\_v1\_1\_linked)
- BATPL (Buckets\_Assets\_Entidades\_Template\_v1)
- BAT11 (Buckets\_Assets\_Entidades\_Template\_v1\_1\_router)
- RMTPL (README\_Main\_Template\_v1)
- RSTPL (Ruleset\_Router\_Template\_v1)
- GTPL (Glossary\_Template\_v1)
- PIPLT (Pipelines\_Template\_v1) triggers: [TRG\_PLATFORM\_CTRL] cambios:
- 2025-08-18: Creación del marco de control y operación. checks:
- Sin referencias a archivos concretos
- Sólo namespaces aprobados

---

# Principios de control de la plataforma

## 1) Flujo de control (router)

- **README main** `[[DIR::MAIN]]` → delega a **Ruleset** `[[DIR::RULE]]`.
- **Ruleset (router)** resuelve destino por `kind/name` y redirige a la sección aplicable (bucket bajo `DIR::RULE`).
- **PIPE** `[[DIR::PIPE]]` orquesta la ejecución con triggers `WF::` y entradas/salidas en buckets `DIR::`.

## 2) Política anti‑archivo

- Prohibido enlazar a `*.md`, `*.py`, `*.yml` o anclas `#...`.
- Sólo `[[DIR::<CODE>|Alias]]` y prefijos: `DIR::, GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::`.

## 3) Namespaces

```yaml
namespaces: { dir: "DIR::", glos: "GLOS::", ruleset: "RULESET::", wf: "WF::", tpl: "TPL::", qms: "QMS::", chg: "CHG::" }
```

## 4) Jerarquía y cobertura

- Fuente de verdad de códigos: **DirTree Template** (`tree_export.codes`).
- **Buckets Template** debe cubrir 100% de `codes` (coverage=100).
- Cambios estructurales requieren versión nueva y ADR.

## 5) Gobierno de cambios

- **Baselines** quedan `locked`. Ediciones sólo vía *working copy* + `VersionReview` + `BaselineLock`.
- **ADR‑0001+** registra decisiones y efectos.
- **QMS** valida: `VALD/VALG` y registra `CHG`.

## 6) Pipelines (hub)

- Registro en `PIPLT`. Campos mínimos: `PIPE_CODE`, `Trigger WF::`, `Entradas DIR::`, `Salidas DIR::`, `R/A`.
- `PIPE` no guarda lógica de negocio; sólo orquesta buckets.

## 7) KPIs iniciales

- **Coverage** Buckets vs DirTree ≥ 100%.
- **Broken links** (wikilinks/crossref) = 0.
- **Tiempo de lock** ≤ 1 día hábil por cambio mayor.

## OutputTemplate

```yaml
output_example:
  status: PLATFORM_CTRL_READY
  created_at: 2025-08-18T00:00:00-03:00
  params:
    - namespaces: [DIR::, GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::]
    - coverage_required: 100
  result:
    - router_chain: [README->RULESET->PIPE]
    - anti_file_refs: true
  log:
    - step1: author
    - step2: validate
```

```

## AingZ_Platf_Repo/legacy/templates/readme_main_real_v_1.md
meta: {size:1112, lines:41, sha256:"969b487df42ea5d30b247e9319fed79fa171c4f11ab34e5a64eb52c6cbefafd2", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: core/doc/workbench/AINGZ\_V5\_README\_Main\_Real\_v1.md code: RMREAL name: README\_Main\_Real\_V1 version: v1.0.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: draft (real) referencias: [BL-2025-08-18-DirTree-v1.4.2, RMTPL, RST11, PIPLT, PCTRL] triggers: [TRG\_README\_ENTRY] cambios:

- 2025-08-18: Entrypoint real declarativo hacia Ruleset y Pipelines. checks:
- No contiene instrucciones operativas
- Enlaces sólo a buckets `DIR::`

---

# README — Entrypoint de la Plataforma (real v1)

**Rol**: landing único. Deriva a `Ruleset` y `Pipelines`. Sin pasos operativos.

## Navegación

- Reglas y políticas → [[DIR::RULE|Ruleset]]
- Orquestación y ejecución → [[DIR::PIPE|Pipelines]]
- Árbol del monorepo → [[DIR::ROOT|Monorepo]]

## Garantías

```yaml
no_instructions_here: true
links_only_to_buckets: true
router_chain: [README->RULESET->PIPE]
```

## OutputTemplate

```yaml
output_example:
  status: README_REAL_READY
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - delegates_to: [DIR::RULE, DIR::PIPE]
  log:
    - step1: author
    - step2: validate_links
```

```

## AingZ_Platf_Repo/legacy/templates/ruleset_real_v_1.md
meta: {size:4404, lines:135, sha256:"2504e3d0875fde98b9e17de2dadf4eac373bcb0fd2ec2454abd5d7ff9cf54c4d", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: core/doc/workbench/AINGZ\_V5\_Ruleset\_Real\_v1.md code: RREAL name: RulesetRealV1 version: v1.0.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: draft (real) referencias:

- BL-2025-08-18-DirTree-v1.4.2
- BL-2025-08-18-BucketsMap-v1.0.0
- DTT11 (DirTreeGenericTemplateV1\_1Linked)
- BAT11 (BucketsAssetsEntidadesTemplateV1\_1Router)
- RSTPL (Ruleset\_Router\_Template\_v1)
- PCTRL (PlatformControlPrinciplesV1)
- GTPL11 (Glossary\_Template\_v1\_1\_linked)
- PIPLT (Pipelines\_Template\_v1) triggers: [TRG\_RULESET\_REAL, TRG\_ROUTER] cambios:
- 2025-08-18: Primera versión real con router y secciones global/platform/app/api. checks:
- goto sólo a `DIR::` (sin rutas a archivos)
- política `no_file_refs: true`
- rutas cubren plataformas/apps/apis declaradas

---

# Ruleset — Real v1

**Rol**: router normativo. Centraliza reglas y deriva a secciones aplicables. Enlaces sólo a buckets `DIR::`. Sin archivos.

## 1) Entrypoint

- **README main** → delega a **Ruleset**: [[DIR::RULE|Ruleset]]
- **Ruleset** → deriva a sección aplicable bajo [[DIR::RULE]].
- **PIPE** [[DIR::PIPE]] ejecuta orquestaciones según reglas activas.

## 2) Router declarativo (real)

```yaml
ruleset_router:
  targets:
    global:   [[DIR::RULE]]   # políticas transversales
    platform: [[DIR::RULE]]   # reglas por plataforma
    app:      [[DIR::RULE]]   # reglas por aplicación
    api:      [[DIR::RULE]]   # contratos de API
  routes:
    # Plataformas soportadas
    - match: { kind: platform, name: aws }
      goto: [[DIR::RULE]]
      section: platform/aws
    - match: { kind: platform, name: gcp }
      goto: [[DIR::RULE]]
      section: platform/gcp
    - match: { kind: platform, name: azure }
      goto: [[DIR::RULE]]
      section: platform/azure
    - match: { kind: platform, name: local }
      goto: [[DIR::RULE]]
      section: platform/local

    # Aplicaciones internas
    - match: { kind: app, name: console }
      goto: [[DIR::RULE]]
      section: app/console
    - match: { kind: app, name: etl }
      goto: [[DIR::RULE]]
      section: app/etl
    - match: { kind: app, name: ui }
      goto: [[DIR::RULE]]
      section: app/ui

    # Tipos de API
    - match: { kind: api, name: rest }
      goto: [[DIR::RULE]]
      section: api/rest
    - match: { kind: api, name: graphql }
      goto: [[DIR::RULE]]
      section: api/graphql
    - match: { kind: api, name: sdk }
      goto: [[DIR::RULE]]
      section: api/sdk
```

> `section` es informativa y no es un link a archivo. Indica sub‑sección lógica dentro del bucket [[DIR::RULE]].

## 3) Sección Global (normas transversales)

- **Anti‑archivo**: prohibido enlazar `*.md`, `*.py`, `*.yml`, anclas `#...`.
- **Namespaces válidos**: `DIR::, GLOS::, RULESET::, WF::, TPL::, QMS::, CHG::`.
- **Roles R/A**: usar catálogo de QMS. Registrar excepciones en `CHG::`.
- **ADR**: cambios con impacto → ADR‑0001+ en [[DIR::CARC]].

## 4) Sección Platform (ejemplos de reglas)

- **aws**: cifrado en reposo y tránsito, tagging obligatorio, límites de costo.
- **gcp**: VPC Service Controls para datos sensibles, CMEK requerido.
- **azure**: Azure Policy para conformidad, RBAC mínimo necesario.
- **local**: secretos fuera del repo, backups verificados.

## 5) Sección App (ejemplos de reglas)

- **console**: autenticación SSO, auditoría de comandos.
- **etl**: idempotencia en jobs, catálogos en [[DIR::DATA]].
- **ui**: accesibilidad AA, telemetría sin PII.

## 6) Sección API (contratos)

- **rest**: versionado semántico, límites y *retry‑after* definidos.
- **graphql**: esquemas *typed*, *persisted queries* para producción.
- **sdk**: soporte mínimo para 3 runtimes, *deprecation policy* clara.

## 7) Integración con Pipelines

- Las reglas activas habilitan rutas de ejecución en [[DIR::PIPE]].
- Triggers `WF::` definidos en PIPLT disparan pipelines con entradas/salidas `DIR::`.

## 8) Validación y QMS

- `VALD` valida conformidad de reglas declaradas.
- `VALG` valida su aplicación en ejecuciones.
- `CHG` registra excepciones y desvíos aprobados.

## 9) Checklist

-

## OutputTemplate

```yaml
output_example:
  status: RULESET_REAL_READY
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - router_defined: true
    - kinds: [global, platform, app, api]
    - file_refs_detected: 0
  log:
    - step1: author
    - step2: routes_fill
    - step3: validate
```

```

## AingZ_Platf_Repo/legacy/templates/ruleset_template_v_1.md
meta: {size:1395, lines:57, sha256:"98e5cdf26d9c218bffabe244bc8571c6b03ae72346464de5ff5a4ba5eaaa54d5", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---

file: templates/ruleset/Ruleset\_Template\_v1\_1\_router.md code: RST11 name: RulesetTemplateV1\_1Router version: v1.1.0 date: 2025-08-18 owner: AingZ\_Platform · RwB status: template referencias: [DTT11, BAT11, GTPL11, PIPLT] triggers: [TRG\_RULESET\_ROUTER] cambios:

- 2025-08-18: Versión refinada con políticas anti‑archivo y router vacío. checks:
- goto sólo `DIR::`
- Sin rutas de archivo ni anclas
- `routes` cubre {global, platform, app, api} cuando se complete

---

# Ruleset — Plantilla v1.1 (router)

**Rol**: router normativo. Sin instrucciones operativas. Sólo deriva a buckets.

## Políticas

```yaml
policies: { no_file_refs: true }
namespaces: { dir: "DIR::", ruleset: "RULESET::", wf: "WF::", qms: "QMS::" }
```

## Router (completar)

```yaml
ruleset_router:
  targets:
    global:   [[DIR::RULE]]
    platform: [[DIR::RULE]]
    app:      [[DIR::RULE]]
    api:      [[DIR::RULE]]
  routes: []   # agregar items {match: {kind, name}, goto: [[DIR::RULE]], section: <hint>}
```

## Secciones sugeridas

- Global · Platform · App · API (todas bajo [[DIR::RULE]]).

## Checklist

-

## OutputTemplate

```yaml
output_example:
  status: RULESET_TEMPLATE_READY
  created_at: 2025-08-18T00:00:00-03:00
  result:
    - targets: [global, platform, app, api]
    - routes_defined: <n>
  log:
    - step1: author
    - step2: define_routes
    - step3: validate
```

```

