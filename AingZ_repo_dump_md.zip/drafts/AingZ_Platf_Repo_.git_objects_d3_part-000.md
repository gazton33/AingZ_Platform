---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/d3
part_index: 0
files_included: 14
size_bytes_sum: 8893
created_at: 2025-08-31T21:08:15.649188+00:00
integrity:
  sha256_concat: 6892b29642ad27466d91566710514869e8b087014d0c32092ddf4485c3e9b0f1
---

## AingZ_Platf_Repo/.git/objects/d3/01d68aec01e016c35f1308086d6efaa5b177d4
meta: {size:83, lines:1, sha256:"a1a580790dc25abc4f46a62c88438f62b09bff36b6234ad61c9b32bcae818044", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x+)JMU07b040031Q(JMLÉMOÎ/JÏÎ+OÌÏIM,ÊEåñIñeñÆñFz¹)6ê>36­u_eµ³ÿö~±æè/Z;7
```

## AingZ_Platf_Repo/.git/objects/d3/099e4b3112d23ebd01daed40c40d90bb3b6c49
meta: {size:739, lines:0, sha256:"210e8a70c9ccd6fd0d184e4df7b6dcf30000db406e1ee94f76bf3dec9119c193", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d3/22975ae1f2607e201a0acf2c14ef96a945a071
meta: {size:591, lines:0, sha256:"ad235d17728cc108db8831473fcf081fca48d1332e61bdf8129ae7063bfb6e3a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d3/2a829051f9251c80683719d838e58d07b73852
meta: {size:212, lines:0, sha256:"6be82715257d86aa48194a3773d20b18301d077d1cc30df04cb98e5ded013864", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d3/2fd705a6b03bf1753e1e85ca0cae36bdb68ac2
meta: {size:850, lines:0, sha256:"505e9dec02ac5173b8bab37e58cf018a13ba8a338dc380f5ea96633ded67d31d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d3/3fde1dc191bb03c8b11b751edde6ec0ec330aa
meta: {size:163, lines:0, sha256:"9c8a3be8bf0435463d180e836fede8e5559b02d941a800fee02cea6e709c7854", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d3/4441780d795b7d4c9eb47e7cca45a8691b0b4f
meta: {size:367, lines:0, sha256:"b9072e8cd0e684966687ba118a0991067d690f572e307f0d0de4b475ad42df2d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d3/65ef821eac71bd9d98679d538a649df3871ed5
meta: {size:290, lines:0, sha256:"f04b92955af98f56b878b9bb7e85cecd3ac321c7649d6c0b5a68fbc8fde2b8a5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d3/73a1afc3cc573e1198ccb0263d9a1049ac5751
meta: {size:94, lines:0, sha256:"c4d8e4cdbba9f75e7ef0ea10db0c6fe28e04cfa705623b59f9b10f60b4da1e10", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d3/8dfaf6450dc22c7a4dbd376d5a1d7f561356ea
meta: {size:3239, lines:0, sha256:"7279a4794e722e4487712ae64358ec59eb7af75027f85debeb367cb55c4b96b4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d3/9b7e7856c0770d007c769838d86896c2ba8c33
meta: {size:762, lines:0, sha256:"717e49890e1ba408c7e507f636fc620c1e29c5bfda8aad8a063128bf9415bcf1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d3/a3223cdbc2c9fc0348e785950f82f974957fa7
meta: {size:265, lines:0, sha256:"368bc953825ad79d4d87597cc4ba21e1024d1436216af29df5ae9cd463a59a2d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d3/c6377c3e900f68faea78eab64f06fde23b8b76
meta: {size:81, lines:0, sha256:"2fe67a28e5b1e64cfc192b58dcea06b22fab0b31a7a4d82d057a988b249de8c4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d3/edb4c7751e820c6e708622d828c94873015698
meta: {size:1157, lines:0, sha256:"766328e779b90eb56299d2c28cb2991463cf11dd1e5c46fd086f8765b598104f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

