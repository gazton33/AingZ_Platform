---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/4d
part_index: 0
files_included: 9
size_bytes_sum: 7040
created_at: 2025-08-31T21:08:15.619255+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/4d/054d7a5aee97f6598881de1b8381fc369914f7
meta: {size:442, lines:0, sha256:"c6397e17608f6b4d785bf4e0eedf81da11cc13212592a6ccab863007c06998af", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4d/0e69c48066e43e3da26bc2ea794f0b6e05588e
meta: {size:496, lines:0, sha256:"85cd465f7d6a672da8e50b5e5513c2e2789b2dcff19e639c441d3fb3b1665a47", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4d/56b99cb45503f198c5bb0f9e0ef3d1cae22d93
meta: {size:227, lines:0, sha256:"50a6ba5aa5303c96d552f72aa6987551e0d588f58e6f55d83483e38c3705be43", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4d/65c9075bc028241928d89e88b09442c36bed69
meta: {size:856, lines:0, sha256:"17bb324d1be4a441920c5782c3613545bfcba8dea446edaf94afd605b90d9ff9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4d/6e9d60bcbc8eb5732916f5412c9fc47206990c
meta: {size:56, lines:0, sha256:"ca092065df2fb0fba856f04261872117b24bf5ddf5517591614d6fa7fbf66038", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4d/8156c254044e2fd5f2c3f3f4156ed37bb728a4
meta: {size:1177, lines:0, sha256:"b1abb17b6f7aa7e36b67ccd2973e3a2bd8f7fc6f0ea2564ca102b9adbda39c0a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4d/a113220a50a94efb3f89cc28b1ce5841a7828c
meta: {size:2181, lines:0, sha256:"729b7c3e031066616ebc13551c19ba1602ab5666f9fc3d606cf8ef3839f1ca7b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4d/d1f4e6b82c71c8a9d6bc68b91c426e3eef21cb
meta: {size:1331, lines:0, sha256:"9a86a7e98cbdd77e662d85e50671e4b0617b01940066e1325c90ba22bc57be58", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4d/f08c14523b2442e53ac8c256cb6723b18516b6
meta: {size:274, lines:0, sha256:"a033510df28a4c498ebb4bec51f70fbfb6ca4b2ee0f34ca6959b4d74f104cf31", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

