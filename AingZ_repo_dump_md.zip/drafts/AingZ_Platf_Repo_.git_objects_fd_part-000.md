---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/fd
part_index: 0
files_included: 6
size_bytes_sum: 2082
created_at: 2025-08-31T21:08:15.652854+00:00
integrity:
  sha256_concat: ba0836cfd17763af0a93ec94473b706074f23090c7423eee877c2da6790c5b49
---

## AingZ_Platf_Repo/.git/objects/fd/80f6f3d17559548829fe8c043713c48300387f
meta: {size:820, lines:0, sha256:"a7a7146a2313e2afe8fb5c4bbd5b0dc1cb0ade727a5a35a6e6aa7f5795bc4e38", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fd/955d7ff71b2ef2a53366245dba06f7cfeae9f7
meta: {size:163, lines:0, sha256:"2360b511d8726129806a0594350ac9485e7a3b304c39703e2634bbddb54719e9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fd/b7ae17992bc68d50c998e3ac403afc4ea79085
meta: {size:400, lines:0, sha256:"8d595376d38739674175a3c16071ac129d2b751bcdfc8e43270e24e39ffed389", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fd/ba6b326c0a6024013c1fea75b5b0d1adb405e9
meta: {size:72, lines:0, sha256:"e80339dcffcc2aa40a58de87dfd25f3c78b55339b47b674d79dba3ff7acf8f10", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fd/fbc6a5a0e93e324f2e55b8be02f2a132e20cab
meta: {size:156, lines:0, sha256:"ce1a5ffebaee24591985bf43ba51f26f77361f0c71d91c1eb2bb714e3d6c610a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fd/fc38b64d24f1a3add40b120793c3f2ae25c3a0
meta: {size:471, lines:1, sha256:"bdd00552c268b1f9e5dc991bb7a6c6daf5658a9475212a4c56516f4178628c8e", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xUÝnÚ@{í§©7)ªÙ´RS©w°eLÓ!¯tËz×ÙHó6}^åx±®M©Ò[{Î7çÙRê®>¾õ2Ê	)J8,%A!3ºn`è­Ó5Üd°öûOâNGQ¯?È½f¹²$4êS¯ËmJC{ªI9Ó@s|¶Âéó«6h[´Ùm¥>ta',]Ù¢`£A1`·iþåzÞ²y2\äãâ-æI'ß26ÉM>(Æé%_;VÖÏ¹8>+hÈX­P'¬0ð£h³ÙDËÄr#Êàüñ7.ÄKn¨;É[à^T¨*Jõ¤¶ðîÃå%ðPwdÈÒx@ÿ­í|¬ºµ!sæø«&gKÜSç)q%tQ×ÚÔØuÚ»Æ;¸ø<ñ¦#v7NÞØ^CoôØHÁ±ÛÐJªùÕ¨<Jþt´¶Á¡âmÜ*´×.§èxja[BçCÕE¿ÏvJ$U÷XíÀ©*4±>Ï­ùwt÷[¯×¯«ÖÝrhôößU;`¥¹eüô'®±!Añé	ÙNýæ¦ì¿
```

