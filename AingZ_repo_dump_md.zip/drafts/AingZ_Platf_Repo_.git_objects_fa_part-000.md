---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/fa
part_index: 0
files_included: 4
size_bytes_sum: 7286
created_at: 2025-08-31T21:08:15.652524+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/fa/09676a20bdd8d8aaaee414eaeb5ca6a2c0f3b6
meta: {size:1950, lines:0, sha256:"b03426e2acef507c751c1685f143bbec3216d4e03868fe068fb8bf2ac56dca98", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fa/11d3b07cbb7a5e97e9cb834f245c4485c7eeed
meta: {size:3241, lines:0, sha256:"7f80d27db1ac106ed6014e661af0b0a6b3756f3811efbef236cbeae1e0217ab6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fa/7762caa2ec65e3e7583e21a312882bbfb1b329
meta: {size:1139, lines:0, sha256:"bac8f7c42f00f192430b3fb7cfb4ff1fb27de6fd28187cf2f54bacb6d972a235", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/fa/a589328f6c046405a0088bac4650b6ec3ee4a0
meta: {size:956, lines:0, sha256:"ab2369b8dd2170325d23cdbba1256c05d758f4a589789f7c99384fb362cf659f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

