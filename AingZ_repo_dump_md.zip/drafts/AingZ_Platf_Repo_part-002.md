---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo
part_index: 2
files_included: 3
size_bytes_sum: 4524
created_at: 2025-08-31T21:08:15.653372+00:00
integrity:
  sha256_concat: b8c0ad095b7e970fa67527078d213b05d2b6559ee94fc07b29890da40e4de4a2
---

## AingZ_Platf_Repo/README.md
meta: {size:1174, lines:26, sha256:"678aeb618aa3240e1d577726d8d00ebf1c8d390e06404ca01c967e2d4a3d4561", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
file: README.md code: RDMN name: ReadmeMain version: v5.0.0 date: 2025-08-24 owner: "AingZ_Platform · RwB" status: wip
---

# AingZ Platform – Arquitectura V5

Repositorio base para la implementación de la arquitectura V5. Mantiene los baselines bloqueados y las plantillas operativas para el desarrollo sostenible.

## Estructura principal
- `main/` – contiene la base de datos operativa (glosario, ruleset, dir tree) y artefactos core.
- `V5/` – plantillas y minipacks oficiales para generar artefactos.
- `legacy/` – material heredado pendiente de migración o archivado.
- `ruleset/` – bucket central con el ruleset maestro y sus referencias.

## Reglas generales
1. Los baselines bloqueados residen en `core/doc/workbench` y son la fuente de verdad.
2. Toda nueva documentación debe incluir front‑matter válido y un OutputTemplate explícito.
3. `wf_playbooks` reemplaza a `wf_template` en la estructura V5.

Para obtener lineamientos unificados de todas las plataformas (ChatGPT, Codex, VSCode, GitHub, Obsidian, Excalidraw), consultar el [Ruleset maestro](ruleset/ruleset_master_v_1.md).

## Output Template
```markdown
# Título
Contenido...
```
```

## AingZ_Platf_Repo/SWEEP_PLAN.yaml
meta: {size:242, lines:12, sha256:"283644a0b0a8756026234b41fcb53bf2727c385d69cb79bcd49d4abd0b79e96a", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```yaml
remove:
  - V5
  - core
  - core/doc
  - core/doc/workbench
  - legacy
  - legacy/data oficial
  - legacy/data oficial/Docs_OpenAi
  - legacy/data oficial/Help_OpenAi
  - ruleset/legacy
  - legacy/templates
  - legacy/templates/3
```

## AingZ_Platf_Repo/TREE_PLAN.yaml
meta: {size:3108, lines:68, sha256:"353b8c413688213eb6b6c7a78be0876bc01a1233183b9ccefbd0c604426528d8", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```yaml
create:
  - main
  - main/data_base
  - main/data_base/core_actv
  - main/data_base/core_actv/docs
  - main/data_base/core_actv/docs/audio
  - main/data_base/core_actv/docs/image
  - main/data_base/core_actv/docs/video
  - main/data_base/core_actv/docs/library
  - main/data_base/core_actv/docs/onboard
  - main/data_base/core_actv/data
  - main/data_base/core_actv/data/semantics
  - main/data_base/core_actv/data/semantics/glossary
  - main/data_base/core_actv/data/semantics/dicts
  - main/data_base/core_actv/data/semantics/code_dict
  - main/data_base/core_actv/data/semantics/trigger_dict
  - main/data_base/core_actv/data/semantics/app_dict
  - main/data_base/core_actv/data/semantics/prompt_dict
  - main/data_base/core_actv/data/semantics/ingest_prompts
  - main/data_base/core_actv/data/semantics/vocabulary
  - main/data_base/core_actv/data/semantics/ruleset
  - main/data_base/core_actv/data/ai_learn
  - main/data_base/core_actv/data/ai_learn/learning
  - main/data_base/core_actv/data/ai_learn/evaluation
  - main/data_base/core_actv/data/ai_learn/insights
  - main/data_base/core_actv/data/ai_learn/fine_tuning
  - main/data_base/core_actv/data/ai_learn/few_shot
  - main/data_base/core_actv/data/ai_learn/relevance
  - main/data_base/core_actv/data/ai_learn/training
  - main/data_base/core_actv/data/ai_learn/feedback
  - main/data_base/core_actv/data/develop
  - main/data_base/core_actv/data/develop/config
  - main/data_base/core_actv/data/develop/setup
  - main/data_base/core_actv/data/develop/customization
  - main/data_base/core_actv/data/develop/specs
  - main/data_base/core_actv/data/develop/preferences
  - main/data_base/core_actv/data/develop/connectors
  - main/data_base/core_actv/data/develop/orchestrator
  - main/data_base/core_actv/data/out_template
  - main/data_base/core_actv/data/out_template/mtx
  - main/data_base/core_actv/data/out_template/mtx/matrix
  - main/data_base/core_actv/data/out_template/mtx/table
  - main/data_base/core_actv/data/out_template/mtx/record_sheet
  - main/data_base/core_actv/data/out_template/mtx/mapping
  - main/data_base/core_actv/data/out_template/mtx/relation
  - main/data_base/core_actv/data/out_template/mtx/validation
  - main/data_base/core_actv/data/out_template/mtx/comparison
  - main/data_base/core_actv/data/out_template/docs
  - main/data_base/core_actv/data/out_template/workspaces
  - main/data_base/core_actv/data/out_template/platform_arch
  - main/data_base/core_actv/data/out_template/ai_tools
  - main/data_base/core_actv/data/guides
  - main/data_base/core_actv/data/guides/planin
  - main/data_base/core_actv/data/guides/planin/mpln
  - main/data_base/core_actv/data/guides/planin/brainstorm_crtv
  - main/data_base/core_actv/data/guides/run_control
  - main/data_base/core_actv/data/guides/pipeline
  - main/data_base/core_actv/wf_playbooks
  - main/data_base/core_actv/kns_ctx_vivo
  - main/data_base/core_dev
  - main/data_base/core_arch_platform
  - log
  - log/changelog
  - log/validation
  - log/qms
  - packages
  - ruleset
  - scripts
```

