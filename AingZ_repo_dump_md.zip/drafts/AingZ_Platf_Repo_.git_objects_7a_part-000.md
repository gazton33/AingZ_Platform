---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/7a
part_index: 0
files_included: 12
size_bytes_sum: 22548
created_at: 2025-08-31T21:08:15.624659+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/7a/10fab4dfc3a76483ce1461424e1552caa2440c
meta: {size:128, lines:0, sha256:"5a1f60199eab9d846cff3ead794548b86c0b236f48213f297bd23f9853154b90", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7a/18ab205ff04c583f5c2716b487b2ec7b9fbef6
meta: {size:736, lines:0, sha256:"18e0b945f3d45d5e9595a925d1e31f757be2ba84baf62602eab216de5b49e6fb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7a/1ff45e495a74f3ea8d5ffe665aaeeb0b688dc5
meta: {size:749, lines:0, sha256:"35e914c4fdc2aa93b4a2ceed7609641c8a8391aecd1eb95856cc0992c7e10dad", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7a/5af325a496603cb1841dcc3d937ca266c79939
meta: {size:412, lines:0, sha256:"0e740b12dcef33f545ed273004388d076c2216a9a370a000f9c2b3b4e444af71", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7a/5e5eba4109209913111f266ed8b26e56bb35ea
meta: {size:4403, lines:0, sha256:"09e3ec1066457c38279d0ecebbc5ecce4fcde1f53623db13cf0af25b3e18d732", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7a/739d486d3c9355837e2b1e00a6dd44230d9150
meta: {size:835, lines:0, sha256:"8606bcf904e476968a5dc5fb89078d04bea1e11974b1dfa3bc540470acecc615", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7a/a9a83965deca9bb10fad727908bc05830b44b0
meta: {size:53, lines:0, sha256:"f738fc653e0a1257dd2caaa88262a23538e3257dab97cecbe085cac9918054fd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7a/a9bc8c07d57645ead670ff55a9b92acb2e00d5
meta: {size:713, lines:0, sha256:"55fd563e0c3f9bb8aea54306696e498fdb4ec58e6a21931e30e8c392f0763ecd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7a/b88ebd12446b36ac4a85591711ee94db8be2ce
meta: {size:2652, lines:0, sha256:"67faa9c7b4ecb7eceafd27abea50f7f2cd4b0e3d6b7188a6ee5b7959422dd190", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7a/c63df71cc78f53950df7dc84a455ee67519625
meta: {size:10348, lines:0, sha256:"1dc566d1b40ed4ecafa2f6dc04d765d85acc1a021b6e32fb06a6514e0f2f5d17", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7a/dfe90d08d0f5563610351820579b7ede46e8d8
meta: {size:680, lines:0, sha256:"38fbb761b4c32aa71d1faef574a4b07e7c008f5df65d3e6a336e8cdd56b5fba6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/7a/f6e859464be566e7e63f9bea825748c35c2dd9
meta: {size:839, lines:0, sha256:"4c907f3ad365319a5c75bb8b29eb4a2850abaa2467fd059c2f4ccb6f8670535c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

