---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ea
part_index: 0
files_included: 9
size_bytes_sum: 26633
created_at: 2025-08-31T21:08:15.651115+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/ea/2ed276cded45a183cdd81d2caca87b27969a0d
meta: {size:1956, lines:0, sha256:"6c0bd01d1137537b79fc83fbd73ca819dc62f32ed41c680a96deca9ad5a7ab5b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ea/342268711e7780dcd4e8ffd61fb75309946655
meta: {size:1797, lines:0, sha256:"7be184a96976f2f86591782b0cfcb25c99e077262b4afccc039050f1c8d2bbd0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ea/3c6dcde300fc6d50f39b6174b397befd92c59f
meta: {size:954, lines:0, sha256:"ce3557d10fb52e1aa7fb84fc1ee1aa6ff5d97bfa690d0260141aeea57804e50d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ea/3f9e33cb57b53a2bc38b65c77e9a6008c2f18d
meta: {size:1660, lines:0, sha256:"bae45228e18db2e53ea0b84b38f85ce3a70a92384c2a3f8aca94a9615a1ec2da", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ea/674624141686508716b8c2d6f2b946dd9afdc9
meta: {size:79, lines:0, sha256:"b4161eff308c20d4cee51c37b86e1a4c9236031adbbb2290e029efef2b332670", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ea/893a77f0471adf977228d6b88a125d6b143d21
meta: {size:130, lines:0, sha256:"0af94b887abeca45e31f7c499aaf26a739228e14820b362a925ddebfd0428ed9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ea/93855333f640d735aa5f93cfadbb170f3d3e9b
meta: {size:65, lines:0, sha256:"424cf0f4997c2c8a638c3eaa0720a465e33a311ca429970eb8af700d6fadb4da", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ea/98749179566d67abbd5397481d7d807f482d82
meta: {size:58, lines:0, sha256:"6c1736fa793a2e7a59ccc99c845f738db38bc14dc9e42403f69542acb9751d69", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ea/e84c75da0b24ca48f5128d54342604f6d21947
meta: {size:19934, lines:0, sha256:"12a398e78d1630e3adb4a7970b47bcbe8f46c373be3659a6cdd76d54808bbec4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

