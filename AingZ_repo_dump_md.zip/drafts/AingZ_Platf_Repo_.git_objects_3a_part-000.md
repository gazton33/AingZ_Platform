---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/3a
part_index: 0
files_included: 8
size_bytes_sum: 8404
created_at: 2025-08-31T21:08:15.572075+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/3a/2a956d01ed7361cb1e68b1b280f078713a67b6
meta: {size:54, lines:0, sha256:"615ffdf1179b5a81109e69310a303d046d7fd0bb3d1ef413ea24f8dfcf3009aa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3a/434ff407dbea382b6aa3e8e47e9c230ced09e9
meta: {size:934, lines:0, sha256:"f4548984306a4d13fd15443d10180338cdd149479ae65ba1ed6eb46afe390d7e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3a/4b2db6d7a05b815d1f0dd8c2225078ee98fd97
meta: {size:83, lines:0, sha256:"ca772a74a1ee11b7f8c4a7ebc25281dcd8c295654363bb4a00b029b81381bab8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3a/990958e56acc91bc3c54bc0ac729e9eabcaf5f
meta: {size:1671, lines:0, sha256:"8212bc3a7624831c07db0123fe60c0d5dc2edd6fae7bb05f9810f33393d79c8c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3a/aaa5d22c4b98ffe8642c1c44c1411db8bd8821
meta: {size:46, lines:0, sha256:"493a2c2ea834e09546b220a99f54441c23fffae699b696eec08cf63466405229", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3a/ce9c308d5215a760122035e4ddbc8ae9ab58ad
meta: {size:157, lines:0, sha256:"011884a4674bd10abef9b192e5879cc173697e0951272089d2dd523d718f49f0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3a/d126dc698dedf4f21b5f15cf76899b7b640df9
meta: {size:5405, lines:0, sha256:"610ff95ff7bf3f413dfe100cbfc3ad303b3ddadb7bc643777a7f695628fa13df", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/3a/da1ee4e585a4b2664b66ace385ea172f9e769e
meta: {size:54, lines:0, sha256:"2203c0c6009feb86ab65bf998ab126f6a230b8f2f28e247611a8391249bae5c1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

