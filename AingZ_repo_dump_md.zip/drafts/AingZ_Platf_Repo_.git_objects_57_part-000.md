---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/57
part_index: 0
files_included: 4
size_bytes_sum: 1755
created_at: 2025-08-31T21:08:15.620137+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/57/4351676ac61ed0bca5358538882d89187e657c
meta: {size:442, lines:0, sha256:"03f121d9bee73b5c01c738cc90f73e45d4b86a290642516f26062bf121600abd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/57/48e6afb59b7caae5a2c7b73eb2c03c6a413df1
meta: {size:217, lines:0, sha256:"23bf0f5a81715b0203f5998ff41099f490d2d35a13865dd84a166d5005090fdd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/57/51a0b0d55d5ebd2018d09f369522aa6bc7a78c
meta: {size:941, lines:0, sha256:"556327c3ba6bcec33a00873dc1bd2ab6f87a71676831a07a26865f6604b8744a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/57/8a94a2237b894fdac5dc6135945364a6b12029
meta: {size:155, lines:0, sha256:"a95677a8299c8e1c7c642a9bb42b90714b85ac527c063c9599e400435bd44479", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

