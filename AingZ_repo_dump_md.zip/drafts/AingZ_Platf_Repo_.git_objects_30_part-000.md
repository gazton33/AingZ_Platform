---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/30
part_index: 0
files_included: 10
size_bytes_sum: 12482
created_at: 2025-08-31T21:08:15.570735+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/30/0d8ae1b955e25e1fc445c5ef2452bc8b9120b5
meta: {size:715, lines:0, sha256:"08775775e029b76792d7749ceb05d5982f322c35984d2acd0654b7135143375e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/30/7826a410cf26551832bebb7cb261265f45f909
meta: {size:715, lines:0, sha256:"3df5e3b9ba483ce7a7fb7416fb5162fe93f6870a13ea34524e2df895ffa08304", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/30/7fc1c92f00329a7df13e66f966f36a49a5ca27
meta: {size:1463, lines:0, sha256:"f9094bb56d0b7ed3ac23e228518a22dd734923e3c6dc648077ece88c31a0994a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/30/82bd26eb91c31fd072b9b71a8a0d32551e398b
meta: {size:612, lines:0, sha256:"0dc69741b30b6fb13b9b4aed4a504f9ad1151eabd9ebc9e1ddbd5bc77d2ac06b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/30/865adc0cbe6993126c8db7e03a0dd5806fdedb
meta: {size:3517, lines:0, sha256:"9755c25f6f061fe79ee65ee0f71ef71fdeb6523c2bbb6047fe300330200a6934", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/30/9c240f7c758adcea28ff161159784045ac0cf5
meta: {size:944, lines:0, sha256:"76f9e40ca4befb542bcd96ac3cf453f89264742e727d67bc0121fab08e72365f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/30/a4c390d6b2ade743b0abb64843892825a86b65
meta: {size:112, lines:0, sha256:"2d5b8328f918d80d5295e62b1a0713e787572d6e27ce0501ae3f266df9655b84", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/30/e7897f5286cdaafcd84184e9bb1475c4df4c2f
meta: {size:1701, lines:0, sha256:"1f3e67ddc86c7843cc1bdc4be3970071acc4414a824e4147cf9ea544591cf917", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/30/ecc6d05a0e78208bbe37234f51c14c90c9b7db
meta: {size:995, lines:0, sha256:"76d128f685dcde861842f557d22062a04ccc9b7b928934bd3ac99d1ff320567f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/30/fbc44455762caf8739271ef8940dceb9d0b083
meta: {size:1708, lines:0, sha256:"037ef86b05bd17506f7ef828486bf5bbd31d833c978991a2a31b263378d7c4ea", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

