---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/d2
part_index: 0
files_included: 7
size_bytes_sum: 2964
created_at: 2025-08-31T21:08:15.649109+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/d2/001b26b63cb296a0b814e8b941fff651e416f9
meta: {size:217, lines:0, sha256:"1b6f1ba47468dfa42e4500758256b580f108f6639c194bfc8114d1d6be4289e8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d2/22da135d55868b60cf800a3006fb488d36ad70
meta: {size:883, lines:0, sha256:"6d1c0ce125f2271126249b67e5d1bae3b81ad3571050a50e55eb04b68d3b6cae", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d2/380ee1875a5094fd86f179287ea420a3ba03f6
meta: {size:559, lines:0, sha256:"10956a982002b311d9002feac829f8f3a90bf6806092eb5590ba4e3f44577316", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d2/39f4431d7f79d7fd783d1979b13b6a9ac97894
meta: {size:806, lines:0, sha256:"355a87a56fef5dd17f7dec0f76ea2b16844cfbd621485bbaa993d5891d2fda8e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d2/790263315db2f1420165c7d7d5590e9f7841eb
meta: {size:139, lines:0, sha256:"3022ce09536b09da79e307aaad8819a4b2d0429f89c00f9c24cb29e89c1f4f3d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d2/bce38a402036da4705ef89659cf7126462e7f8
meta: {size:269, lines:0, sha256:"08809c17acc7fab1cf8d6c8c71ef7dc714d5311f46782b2579d4dcc913e533e1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d2/e21df92406a30e5621f1efbf6004c699f00ae4
meta: {size:91, lines:0, sha256:"d266be8ee014f7aa836b1ac8007cfd232ad9afe07dfeed10d01557b976d68e7a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

