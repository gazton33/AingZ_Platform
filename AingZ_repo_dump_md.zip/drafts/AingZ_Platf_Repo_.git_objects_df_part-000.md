---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/df
part_index: 0
files_included: 10
size_bytes_sum: 9747
created_at: 2025-08-31T21:08:15.650011+00:00
integrity:
  sha256_concat: 5cc5a270c2d47991387c8de4e9eaa6fe4784fb41f4b0a5e162254cdf3ac8770e
---

## AingZ_Platf_Repo/.git/objects/df/456e40b166f49979766a3eb88c98f6375dd795
meta: {size:276, lines:1, sha256:"5ef38dc6f0cc206ba21c0616ab2c0f6cac1675c06ae5cac440d662eb11555488", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xMANÃ@EYÏ),e´DE¬QnØªã¦#¦ãb'8«¡Ã	mÕY7ÿ?ÿ:rùâ.åÎ§"·Põ)$êcåÜµA;ñà¿ûÓ/DV@¿¯M¡HO)4¤}©cIl¶,{ß1 pâx:¶BÁ\8e¼%Ú·$¡aWUËáÝ^¾^ç«|>õÜÀ%0	j¡le<')&ßD|Nµñjr^>äóÇ¼¼7JHíÇBþ1/YoÎäÚ×MB[<^Y{¥âW^y¯	Y,W(àð+Zac#Í:uãwa0ØX>¾áIpQ+xhuvõë¬p¶%
```

## AingZ_Platf_Repo/.git/objects/df/5f66ce3c1d790639c5d843273e1cf7496f8fa4
meta: {size:5524, lines:0, sha256:"ef27f1622d979c5e15fb5a9ac0d0927c0d51dad85d089388cc8aa6ea937c4c18", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/df/69974c671b921a2819ee767972bea0b3a795d3
meta: {size:1944, lines:0, sha256:"9f1f4529fbd8e7fa694e2345ca6370da5667c8105152034b9076e7f6e2ebc207", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/df/9304179b02a42d32a61d220421780a2e9484d7
meta: {size:172, lines:0, sha256:"5b98ca9dd241b77f31805772d29a1351453a2c3fecc9e55eca46b2ff46216a69", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/df/9dd9a8c254bc5d5e83a7c248efd79828c2d90b
meta: {size:626, lines:0, sha256:"15b77a03cd200667cd7ed9ee878c9dca18816299445c7cd0dcc852100c3a6b99", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/df/a732c66717e759eccc595efa5185885633d143
meta: {size:51, lines:0, sha256:"bb73b90a99fd8d72dcd4a025da513c404d0eab31f0bdd4cec8582b07ba437dcb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/df/df20bf6e0e591fa5dc027d6efa20f460d9dd89
meta: {size:912, lines:0, sha256:"14012625a8ce15ab63cef492a8a8ca6eebbb22551e7c224194af68d741d8194a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/df/e0770424b2a19faf507a501ebfc23be8f54e7b
meta: {size:76, lines:0, sha256:"bc2765c7012275e921f22fb94d53158122c693d0cf6426406d6aaf19848a43d7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/df/fddc325b6c13e268f71aeeae327ee06f62574c
meta: {size:78, lines:0, sha256:"d7a612866ea63bd3f1ad68a26aca8007838a2e4a397d157957fef15a601c7c8b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/df/ff86b14701097990bb6c984c3857fe548158c3
meta: {size:88, lines:0, sha256:"ffcd3867e520bf78c5a6d5751ff978707b94dc869bb23454502c02cac3a14667", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

