---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/47
part_index: 0
files_included: 7
size_bytes_sum: 8170
created_at: 2025-08-31T21:08:15.573664+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/47/044b2e4fdee955a0a6f513987433d1fb772667
meta: {size:2863, lines:0, sha256:"215ad6877350a16163dfe09887740ee29669111959f54c9c9295299de341026c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/47/06406056444099bac16befaa07415d7f096c7c
meta: {size:855, lines:0, sha256:"eec17e1dce60a34894e3a21fa882ffefddc46e6e8bd14d88e91ae6320ae11100", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/47/430a24f200e043db1c7f5a73ccdbd18e40218f
meta: {size:2333, lines:0, sha256:"79078543d5401673804b499ca472cba99da878106f5034e5d63dcd0251be8ed0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/47/4fa29c3896de68fe7b7c8e39e42f58b5977291
meta: {size:977, lines:0, sha256:"aed7b7472b538f69729e1851247cec2f9c1607684ef82e64148001e0fa17ca37", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/47/5fc0f208337d0a10d8ab0574909603facf2448
meta: {size:737, lines:0, sha256:"99107ef14ddb1288dc242188c3f2f0177ae5bb8587faac0be2ca7148812a43ff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/47/70f6bde8630d91ac85c92b6cc7643de7300d34
meta: {size:212, lines:0, sha256:"7f8554cf52a83c19480bba06953305b47278fbdb46df3bb1d22bc990fae29a64", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/47/b1478317fc9817f20c097667da0ff2cc50173e
meta: {size:193, lines:0, sha256:"894dd504aaade139a9e124ecb6d61789c2f3fd7f4b9fd84af338fdd723b2e2a8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

