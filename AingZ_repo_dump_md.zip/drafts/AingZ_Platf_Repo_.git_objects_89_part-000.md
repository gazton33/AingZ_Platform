---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/89
part_index: 0
files_included: 9
size_bytes_sum: 15250
created_at: 2025-08-31T21:08:15.626628+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/89/0bcd37c8c49d425c9dd6d6d5805844df05fd16
meta: {size:853, lines:0, sha256:"0c765d7c497d4aa91f7feaeda62127bbde1c4e95dc0232c6243951ba6f35e62c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/89/0c4ce6f9f06f646e6517b2cff742037363e8be
meta: {size:7757, lines:0, sha256:"ec799e3d077afdadfad46e98f5ec82b4e69f684c7d13414af55b2e66186b5f9a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/89/2198f8bc784e7fb674acd8ea3827355b32014e
meta: {size:264, lines:0, sha256:"8d952b2a1a82e5841d19d195eb0b14539f9cd9ed7eb1c1a62aa8ea9d74b605cd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/89/226000572afb0e2d22abd16d6917b85bc508ed
meta: {size:799, lines:0, sha256:"761e7a572138710f1d3e32a4914af2961a65b937886207177ebd5cb8c4c4a928", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/89/47e9e54c2922e8adf0c888a319ad0137512f0f
meta: {size:1477, lines:0, sha256:"2fa17b8a0b82892142b768eff0d8ecde812ce1bb1b3deb46f2501f5f2b676ef9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/89/50ff0255de728e311d8337c9b8bd1e8fa5623f
meta: {size:496, lines:0, sha256:"a793106e81eba227d1319f564cba780c137c5b490e5b0dab7bbfc611be59b571", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/89/d2753247e65c4dcfd57e14bd4ba89d68ef7bb6
meta: {size:772, lines:0, sha256:"fa29700ec419924d72aaab3c17132993367fe171794e4189886f37d01d806e1e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/89/e98168b0c52b9ad504a331d72dd729263af5c9
meta: {size:2630, lines:0, sha256:"2fb2af251cb678705a8558fcac7589a2abc25dd481bd9822cc3418ada95e6e56", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/89/ebf8f668e18f6b0b1d3aa2a8505964029ff623
meta: {size:202, lines:0, sha256:"7e6645de1acc56c244f1a9522941d3b22f3aa3600b61d977fd5c2439680c3d50", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

