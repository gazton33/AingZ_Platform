---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/9d
part_index: 0
files_included: 8
size_bytes_sum: 3679
created_at: 2025-08-31T21:08:15.628364+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/9d/0cc1ff363b95abdf07c0d30b71a8922e390d66
meta: {size:858, lines:0, sha256:"fc897ed7b2e635ff833ed6c7c4f1632622b7095ad940119e0fdbfd4bfc17e09d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9d/25cfe32ac13f544eabd9ef182db2171efc1916
meta: {size:218, lines:0, sha256:"a2f20386c37e17717e259eed10d8be6a5207926031c884b29223830ef80748e5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9d/81819385c41427d76685a8edbaaf3463b0b49a
meta: {size:611, lines:0, sha256:"fcc595b6a45b62bcb4eea622f015c34b0b0bee89c60fde25c82214e21a5e004c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9d/869fede1fc859b7b56cd07eaa9d5098712a2fb
meta: {size:1121, lines:0, sha256:"fca6e012fe64085843bfff4c8331528d4a1705b35ddc39b8bffbfc1eba074b7e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9d/ce34a6753ad31d60f0a8f28b2f2b3b19c20036
meta: {size:482, lines:0, sha256:"2720c0ce00b5a4ac4a40cffb8067dda40e983b5313cb85f1701455f4687e6f32", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9d/da5efc605ff7e3368414b69275a8b4e86ada38
meta: {size:197, lines:0, sha256:"2cdcb6b56feef8d841f064db54ade7d7f791a3d8d2d7e8869b2bb927c5b39903", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9d/e12c4a69a8db6c5ebb6f2c06c816ce879091bf
meta: {size:128, lines:0, sha256:"f0d52dec4a4db5df2db3e9880ae780d4d25b6772228e664e77e210725af6a911", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9d/e5d954cedd78a8a18fdc763deb4971f73f9118
meta: {size:64, lines:0, sha256:"47be167798b6ba3bd90651248209c7bc835e1099921cdf3bad9df93d3a1501e9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

