---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/77
part_index: 0
files_included: 13
size_bytes_sum: 6658
created_at: 2025-08-31T21:08:15.624291+00:00
integrity:
  sha256_concat: 1b38ae43c11308d1c2af9793d7d8829c60b7358a0e273b93696d22c99d8f9b47
---

## AingZ_Platf_Repo/.git/objects/77/04798c0d1a1bf676b52b202c03c67a5c9bb9f5
meta: {size:459, lines:0, sha256:"901060818e650c6bdeb2c8b9d8873c94eaf58afb0a0220502a1c3614961742fa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/77/12a81712133dfdb6e97fbb897c65cc9e1aabbf
meta: {size:998, lines:0, sha256:"fed2c8867cad769c38e58d44386817912b67496dc179d42486001584a3a5c668", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/77/2f50e30545f47e454376d265ffff32560a894f
meta: {size:232, lines:0, sha256:"87fa4623ba17be5cc14fc1d905b00b0287fb17c7890f12b27386ccf2f2cfcc23", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/77/325d5016ff3c6e5826ebd391a41a537ad81855
meta: {size:124, lines:0, sha256:"a84ec8a43aa6ca627d91880cfb5c22b56fb108cf2ca8505a1c2e4002979ce967", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/77/453725ad72c3bc9018fe35404f25e710a54fb7
meta: {size:164, lines:0, sha256:"6e556acce34d5974232468a52c4990919d3ba923cd8cf925d501d734b0ddef87", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/77/504fb0f139faf47bc04f9b6f6d1eb4cfb02b49
meta: {size:129, lines:0, sha256:"0ea213b7b37e57ae13f6c0c578014a5e699bd3e8b9901e6d04d57d9a7d70ac1e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/77/6ea5dac416358346d0b55c3f54a6fe1fb8d3ef
meta: {size:534, lines:0, sha256:"d6daee8c8fe1d73f01fd0377f827bf7c8899d362d9686256fad6719f4c29cc7a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/77/a2f21641f31197f3053a5d45223859cc47aa9b
meta: {size:893, lines:0, sha256:"90643d2bb51e49ce579b87d6a2fde863a20504fc0652c2693281fd08df7a55c8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/77/d164e6a00dc727e33c8852df1de18cfa4b422e
meta: {size:2209, lines:0, sha256:"18543696ba52e3ec73a4781564d5e848db0ae083787fc355258225b17cf3afe9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/77/e3a877708098358ec9c903523d510524239cd2
meta: {size:87, lines:0, sha256:"e0d0f9ff63d179436775a0001a539bcc14b997b3a2777ab44bcb969ea1e1ed3a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/77/f817cd95dda6e210f3658f807416beb561ac98
meta: {size:145, lines:0, sha256:"7aac561a8ecf2614ec093055fcdfd6fcf12bbf9c8f1a9627505d6978753475d5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/77/fed6c5081ad8ba9cf1d0f661efe8776a1200ca
meta: {size:155, lines:5, sha256:"055004b184e355ef6900f8bfd203395cdb76ad4a3dfac2599412a9ac9efed230", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎI
Ã0@Ñ®}
] A<JéU<($q1.¾9C·ü\÷}í@¤o½@
Ú
¬'ÌI¶H	É«wlrtðfæÌì8úB>XNÄ8ï(ëâYÅO_j9½ÌðS6ÉKýJ{Í{\·!×ý	Ú[äÌÈpGFTW½»üUlyT?&ßD
```

## AingZ_Platf_Repo/.git/objects/77/fee832632e8134fd4caca4f5ce419bd86decf2
meta: {size:529, lines:0, sha256:"fc9f0f10d5c73a8944ea1109d0240bbabdf9a6f8817461a1a2ec87b19de2228a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

