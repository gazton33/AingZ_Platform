---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/4f
part_index: 0
files_included: 9
size_bytes_sum: 2187
created_at: 2025-08-31T21:08:15.619453+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/4f/0731876fb3651c0fdd087de7e6d588f152c34b
meta: {size:853, lines:0, sha256:"905be2472eca4477ae32c0152baf8923268b7d44c9cd2bbc187f226a55d18541", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4f/09b7a6f695ee26b8e54b35bb8c3baffdce7b60
meta: {size:51, lines:0, sha256:"5cb27cefe97ee47ed2e3822a4296dddd6715af74fa0264184f3eff3a54bac07c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4f/397bbfe447a2d19a4816078a69c49e19ee17f1
meta: {size:95, lines:0, sha256:"f1f5e4bcac3887a0d09471d5d90ab9efa1dc89fe3cb6eaaba40949ddb26c5b1e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4f/5e6d4966c57c2d5d8521ed872048e14767f297
meta: {size:81, lines:0, sha256:"5b063de8314fb7989fb44b12e26d0cedbbf37b5328b62204d39d80c25dc969bf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4f/809124e1bf408a9046d4647a09976ea549fd68
meta: {size:133, lines:0, sha256:"4d498cdcb42af5ce757a55077103c6a44a1a2df6d6f80d3bcd7de321bb458bd8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4f/8a795a089538c6797054047ef9364c9e595a2f
meta: {size:86, lines:0, sha256:"2704a78dcf95ba4b72ee2440d3658087f7502aa83f942f071f2b09c90ce1a9f4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4f/989fdd65227b979d557a86c61bc2786bac2993
meta: {size:297, lines:0, sha256:"1f71be7f611e0818be14b46a41f55881e25d8e985a71e1822c1f7ad37ca55572", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4f/bcb2758fff534e8a099f3cac5b05effe90d05b
meta: {size:415, lines:0, sha256:"09845f21d711d44adda65bf48a2a4753fc2b5adddb1524d848b0e288bb336ed3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/4f/bdcab2df412d5bc1cb46b64f3d8007636df864
meta: {size:176, lines:0, sha256:"70a519334e83efe20333580bfb7afe91c541b8439bce28a38774d6aeb430bd4d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

