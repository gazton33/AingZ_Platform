---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/79
part_index: 0
files_included: 8
size_bytes_sum: 8199
created_at: 2025-08-31T21:08:15.624492+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/79/0315224b0cbaf6f4bc4c7be0e8df9c5b5b6993
meta: {size:155, lines:0, sha256:"e8853ef363a70aa3df491b3dfd1032730c68422ae57ab089aba5a88f9ad443f6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/79/5ba6da34c9b6edc801d4d7707208fbd5a990fb
meta: {size:1462, lines:0, sha256:"c3be0035a37ee0aa3165127bd05097fccfec81340057af186ce478660832be7d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/79/772b54242b6ce00f2e58abf8aa423e09c8c964
meta: {size:797, lines:0, sha256:"2ac03aeb02a624cfd69619dcd334539df8c02c28615ad87c9f3c595e50d29448", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/79/95a196fa2edbe9b7b60527ccf97f4c2310f124
meta: {size:800, lines:0, sha256:"ea51fdcc463aa04e004f8e30729581b62a66bef99a6919762f5b6f31514fdb0a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/79/a2b2e474e3c3021c1d36b1b53e6efef1037c0d
meta: {size:399, lines:0, sha256:"ee51c2aa71ba5c000643a1552fb5f54f09443cbc11532899cc86f296b070483a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/79/a45fe1e46433410484c4d280d00677182c5822
meta: {size:2975, lines:0, sha256:"f3f3dd974e44abf91badaabbbe1d3920b19471c289a1f964ef8d67d6249eb1f6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/79/a5b7558492f9b7684b8c63263b9920188e5c95
meta: {size:368, lines:0, sha256:"15c880c2aa6b36a53e8ad6392cf82354b17386815b79fa774b0ede1d9d9dd5d3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/79/f95098322ef6802bbdfd329edb24129da6d4b2
meta: {size:1243, lines:0, sha256:"21d6c2086191ccc32a1d754420a9d6f4113c864ce26dc444bfa9404bb3f78911", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

