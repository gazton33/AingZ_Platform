---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/48
part_index: 0
files_included: 9
size_bytes_sum: 7735
created_at: 2025-08-31T21:08:15.618192+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/48/18af97e037d5b26be90e050b1628069587ed4a
meta: {size:204, lines:0, sha256:"7d81aef3169d1e3278bd19c29b0f9e12bf4308de866378345174e5f7edad4f2d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/48/25cf8f62e27340380a16968531147ee92979fe
meta: {size:1008, lines:0, sha256:"743c96d3e24bd5eefd3a19fb0ed2f6dd8e382316eba03ab6e17a7fbc51350ada", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/48/2d3c61fb2553278e8219c1a1de22a452e3ef1b
meta: {size:1166, lines:0, sha256:"d5e32db31a120d9362215001fe23e131b36c730a89238513e2038a5931c3cc67", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/48/67dc6a8358bdacc61228493ebf7c143609fa61
meta: {size:800, lines:0, sha256:"b8e18918d83e96f63d8d51c73a63252435d46f1094fdd31a803ee256808fae10", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/48/77142c9d565bffa2105f9cb37738200ce1c128
meta: {size:1119, lines:0, sha256:"e369bfbd6489ab5e155d234a03b2a01e75184cd16fd70583c00f7920f997cfbe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/48/8fa69786d5b19b866bcef20690e1264bb29c2b
meta: {size:133, lines:0, sha256:"03e4b12b7c93b13482e80604c228a4a1d5e3b1b5e4a97478c3fa9c2b04491e08", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/48/9da192a49d05d1e7f0d244a81ad29febcbce43
meta: {size:959, lines:0, sha256:"4c2f8a4170d9cdc01c4ee84bbabadd866abd703d2d57f8ac862bf37880827783", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/48/de7e76f5c3c48711b58273e02c05665d0eb329
meta: {size:1105, lines:0, sha256:"eb70a1796f6afb37829f54f7d6f01b69bbed049343139bc11231df88fd8d96ee", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/48/f9920e1bf08c4770057d96edde369b349a6b03
meta: {size:1241, lines:0, sha256:"0bab9086b7786f28dff50b2c58fdfb675086c06df6bb3eaa946bd4e59971fefd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

