---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ee
part_index: 0
files_included: 9
size_bytes_sum: 18131
created_at: 2025-08-31T21:08:15.651602+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/ee/089e12e1e5fb918af6d2a17a97a18c5f8dd7dd
meta: {size:10410, lines:0, sha256:"2e6f5dff9a2960937540e70f7008a537caba3f0c8b6599318c35fb7629563abd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ee/1d1085e531a2abdda88f0a822b23e97cc1846e
meta: {size:485, lines:0, sha256:"467d5d9d18e716fa8ed9122cc6f93714b68acdd3efe03a6bd5e093225df5b65e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ee/47fadd734e64b06089538da9b7b533a34ade54
meta: {size:65, lines:0, sha256:"a3fb9dd4a5a4ab1056f6f3b4ed51da86613a75a1ee1f2c9bec4258109a25d44e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ee/6e569ab7d6cf46a897333be73b995eefa2d604
meta: {size:701, lines:0, sha256:"18756616ab2b11cbf24fcc35905a9ed106dd33ba9b1613ad3c5f0af337093252", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ee/993141bf59cb2cdab91c817fb87dfeb4aa04d9
meta: {size:75, lines:0, sha256:"b49da3dd68d31bea80be00500c2de813f5059965f6c67acc79587a97c18028a4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ee/b6164c23bde55cacef0645678e271fd435154b
meta: {size:1306, lines:0, sha256:"21e56f854ebdc7bc794d7acb6a0ec9fc849691029c36b91441456f8f5e558ac6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ee/b95cda4a67ccc103977d6eb8ead4c07d2f85e1
meta: {size:828, lines:0, sha256:"2ffca72d9d37fc25cd3089280de4adba15e965340aa67443ccc6d7c66d91965f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ee/c2c1f952520bf65daf26ea40d24b3665f82f12
meta: {size:3289, lines:0, sha256:"49b24a7f8a130ff72cfcd3e0afe72bf91a2195f1661d0ab16b0c245c2693dfc2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ee/d843153187ba3a141a4a01f2cf7084da16b60c
meta: {size:972, lines:0, sha256:"db63a4236bd9bc8aa99cd92345aecac61a9f23680c23694f97ac6f5fac4c311f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

