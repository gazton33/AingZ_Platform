---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/b5
part_index: 0
files_included: 10
size_bytes_sum: 8110
created_at: 2025-08-31T21:08:15.629825+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/b5/15e9eb02feddd59a70ed61f2f1900b58d379d8
meta: {size:591, lines:0, sha256:"4d99c26c5ab6d424aecd3260fb1aea3b9d54f3b2322d48b2b5bb26ba71e57f19", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b5/2d6fedad835215e2de0112918747377a4fbbce
meta: {size:760, lines:0, sha256:"8c20ab8a664565892a5c27d61a38cf7b7d14945e99b640bb2cbeb13ef1931b89", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b5/326992ea673d6b87d3fbd5a8ef1f0837fd1d25
meta: {size:1403, lines:0, sha256:"e53718e504589ddfe2b840d571e5d94c69de6fa77c84112b90112955ceb08fb4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b5/514c3a9aa968eeb58da3fc1949109d51769270
meta: {size:87, lines:0, sha256:"e27e18eab7631a4ff234f94a6a0e2ed88bfb5130602adc581d815d44f963f404", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b5/87a0a6b0ecc38aa1b66749e0f9188087928a85
meta: {size:1887, lines:0, sha256:"61174c1a74c0681bdbea222345531c1c05773d21362c08b36fc44df9bfdef92e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b5/9d0d1bd36845be661eeed85aa5fca19158d1ff
meta: {size:2148, lines:0, sha256:"cf29101922df2ec465f844503106e52c2b817414fb4b08e9f814ecfba4ef207d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b5/a1a0819e0ec3584735608e243b78f06e8d01a1
meta: {size:280, lines:0, sha256:"8341dc4a25b999da9a8445be8615d5ff17b33fd11e15f53d1ba52878231d9457", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b5/c6cc77e5203c729b34189781b50d7d5ca250ff
meta: {size:99, lines:0, sha256:"d8e1164e40e7663a95929292cb459bf234edd14153203fb26ddb9097d0a5d3a2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b5/d6e369de324b210d32130f64652d41a1bfe345
meta: {size:51, lines:0, sha256:"eb0d154e53f48c64d99911e20488423321bdd3c61364af17e1127277633c4918", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b5/dec94e8956ba4c3ebf3d35923a106af3035392
meta: {size:804, lines:0, sha256:"5390c22d85e5772eff079c7e4bea73812ff2134c1522d672a10d77aba8f3b206", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

