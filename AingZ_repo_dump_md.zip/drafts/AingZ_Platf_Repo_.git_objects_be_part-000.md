---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/be
part_index: 0
files_included: 15
size_bytes_sum: 69821
created_at: 2025-08-31T21:08:15.364550+00:00
integrity:
  sha256_concat: 1b2519806e8f2f2dd27478b37776549cfea4b2953deec0c801aa044023bc1a6f
---

## AingZ_Platf_Repo/.git/objects/be/1571fa1fe4d95e10dca24d9e9a294d74b99edf
meta: {size:70, lines:0, sha256:"b0540831806a17ed0f9d0735ee5f91654366f135a9bb7238dfae16362510215c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/16df9aa4cd225b2427fc0623e06915b89adad2
meta: {size:849, lines:0, sha256:"1bf6e7f4b562483af9d325638210bd6987193cdb9db86e228d001711c4ff2c43", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/2facaa8aa2b0770b728ebf453069f1f6a06bb9
meta: {size:58, lines:0, sha256:"f8a16f0f3ee02d516bbff7723e186ed27de5086c9be7e551acb204bcbf3a5ba0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/3bdbd648b9403e22f03054736937b68380bd01
meta: {size:262, lines:2, sha256:"ac0d854b39605624ceca22fbcbb1ddf0720bc39515bc9cc723e8b6a130cb229f", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xM1N1E©s_d¥ABÔHè"ÄfíÙ0wf5¶9à´{1¼èÜÌ{ï{È6àöîþêÙ2P:4­läñ]ý1Pa¼~<`&'PKRÍoÂõÎmkÀOs¦ÊOý\,àEG'.Õ[¬Íéf»Ùc¤£y÷Î8!3_Tm	M¹2XM+öøÀ±UgÌg#ÿïH\)gJÂûåG©@ôìÒ%lZ!M}X§ü5(M¢û®èÜÈI&á>¿tþ(*ÉÊvóXfv[ÝÖêÜjëcùFY©c)¯ØåKùúUE6IG¢©ç5
í/FP
```

## AingZ_Platf_Repo/.git/objects/be/42d6050bc1a42b4f5613c99a8f4b23976fe637
meta: {size:610, lines:0, sha256:"256abd4669f237a84b946d1cbb734ecea8f6fe7e43cf493a97e8884895bc3de3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/494871275bb2fa10d9b7dabe8e04f19056b940
meta: {size:321, lines:0, sha256:"fc509bc173a0795f810f207e1dced51a6612e28f3522c7040e0620103ab36c52", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/562c11b34fbec9e76f06d893d04c277314123d
meta: {size:914, lines:0, sha256:"0571bf9ec6257facd93f4082a3433ee9c55c87ce7e43b5daafc5ea2a4c030a1c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/731995e0fad9e1803c89eb28d91a5722ae964c
meta: {size:274, lines:0, sha256:"43d480159dfeb6685e1a538c11dc2776afa673a9b4c1bf2c3bb728fa7579de9c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/97eb2d0964db800c24e24a2ea63ac116571419
meta: {size:526, lines:0, sha256:"3a04243be1db45b081b4e2bce2956702d13c53fc3b0b11d6bb52fa9e8a5df343", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/b1f40e2b0b4eb4463f9b3980dd64074f6e239d
meta: {size:228, lines:0, sha256:"a72e3bf074fb13efe5759577c44c593b9f57c35c12cfde728fe01529fdf1bed4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/b5026ff3cd5b31d3832e6c8ef818d4d3dcf4e2
meta: {size:843, lines:0, sha256:"2546e8cc3929a1981d57ee84d5418782086f0fdb8875e49539e0afee9453df9b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/b85a63bc303fac9cd60a230de15d5614740182
meta: {size:54924, lines:0, sha256:"d6bba9b72cc575950e06c2e77565eedf0852eb11b0d3339a6cf4f354bd232147", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/bd7023910351c868089ed6b78801605e4b3324
meta: {size:218, lines:0, sha256:"f570aeb0c06e84fd07fe16cf568386a601a003e047f21d09c81fdcac8ee3ee0e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/c56b2cc580c5e6ab1030a977ba3d6c924d449c
meta: {size:246, lines:0, sha256:"44ab966c6a541aa82a99c7e8b1c892b730739372d213b33594b0db56ed2beb58", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/be/cdc62b99bbe89027034acb4e891d80bfc9b104
meta: {size:9478, lines:0, sha256:"7be246da383a0c51c9b4416a3a853bd10ce969e9c86799cfb4abb859346f8c63", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

