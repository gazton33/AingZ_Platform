---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/a6
part_index: 0
files_included: 7
size_bytes_sum: 6285
created_at: 2025-08-31T21:08:15.628946+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/a6/393a5b17e06a4a620985631acc72158f229968
meta: {size:78, lines:0, sha256:"e418e66be46c6d874e9cedb336ec8abb6f60aba4005cb64a0783830a073112f9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a6/4263559027464c7ecdaed39392f76c2dba8a91
meta: {size:1326, lines:0, sha256:"ad73be3b8e649dec5aa0bb97cdda5468ed8a3acb4981d0bbfc90159b8fdc611c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a6/a2ba3fede863fbb6630e9cc039ab4fa2a7da33
meta: {size:442, lines:0, sha256:"3f38f26112b53a61779ca37a93884b2412ca494be4171e2edcefe56d2ff16235", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a6/b7db8eedc755bc15af6593174377b727d8941e
meta: {size:682, lines:0, sha256:"38207928476785ca395a8d33e2e110ba4daed0c03f5320fd30e315ded9994883", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a6/c355589fb3b9b27949b7eb0857f9126c97aa7d
meta: {size:119, lines:0, sha256:"5eb958bd9ae8584e35c34bdfa243b6f45066484474e0fc0f517117420a7aef93", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a6/c54b022e5d3ae1d49750aa0b146978a8299bd2
meta: {size:2680, lines:0, sha256:"984927e6b5e1958f07e64cbd6f3a404fdd726feeae6f4d22ae49edb1e0489ab2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/a6/d51974cf86fb3e64ef41426fa5e01eb4eb16a0
meta: {size:958, lines:0, sha256:"fbc50ab10af4756024acd85c10817a9a8bdaba4b547574f8ae8e5cf3a9dec732", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

