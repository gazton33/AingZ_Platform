---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/10
part_index: 0
files_included: 9
size_bytes_sum: 5091
created_at: 2025-08-31T21:08:15.567735+00:00
integrity:
  sha256_concat: 6f05b09e2fc2e240f3726a56ab76b014e249c03b02ab260abb3a4d2257d74cb9
---

## AingZ_Platf_Repo/.git/objects/10/123d375b5dec6707a492c2311d8509abeaced5
meta: {size:1002, lines:0, sha256:"8a3365ecd4ad69f75b409b7885f684f4b3b5367b1d108e6fd594cc033e475af0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/10/19622e7208176b391356fd08a25a5b33d2f16f
meta: {size:525, lines:0, sha256:"24c5442e836b9ce5ed3e63176b105cb8f66f3ec96ca59f31dd850df37f9c88d1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/10/2855a40f6c1f2a18a6da2badabea40834f8f2d
meta: {size:49, lines:0, sha256:"defcb51be4f600b1feb888e02ab453690489ba0974b659c716fd4df2b78a9e50", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/10/5d60f1cec635f8ecece0f69ce644dfeb493b66
meta: {size:1036, lines:0, sha256:"dc9469f5c936c838157d7f905c9296bce6cd76ad0695055da62681b8c38135cc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/10/62a002b064ce1bd44c04a822afccc13c43d475
meta: {size:808, lines:0, sha256:"8c007a20c5ca5e14e48f329ba30b75734ef1fc1c121d200f70c300cf3c73e4f3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/10/786a461abcef0108f7143bde7fe54b6235a3a9
meta: {size:646, lines:0, sha256:"906c44003114143673df56ae77b8a8e0802697f14c238bc13fc670bc4d793ea0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/10/7c5abca36b0d3b9b3b3cae7ca6d4a5bb3ab731
meta: {size:163, lines:3, sha256:"9a1d8be126f26e4dab96206f9919082b3012d3f896edf822a9ea29e2b8b60f99", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xMÍ±
Â0aç<Å!S;XDpêâ$ôBÚÜÖ@{n"Ø··µý|;ÇÃi§µnFÛÑ3©3ú ¸77Å ÙóP©ëK83¢xÎ	¥dezû*µpJ)G=&ë¹(±¿àÎ
Ë¾ÏBÿdÄ¿öÖjÂ@Lb39Ìu¹¾1l'2umÌê£7x©¬C4
```

## AingZ_Platf_Repo/.git/objects/10/aa0816e19aa9890a63ad250a733b5f9e119085
meta: {size:629, lines:0, sha256:"2f20a2b724b6d15f1c9b1485073d55dd01b48ea0176eebd5072c89c9841ebe9c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/10/bb3f6284a77afc8932b3bcc038151a62391485
meta: {size:233, lines:1, sha256:"a04751e4f7ebda8650a4501e2fa756130cbb296606b7c9f649ebc310babca44b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuÍJ1]ÏS\pS;ÝwíØÊÐ".Ê0ÜÉÜ8iàø¾CÓX\®ÏÇùÎiiáöfrq	ÛÙ´\¾p6­jøÒïíàÖh­Ôû,C?Ñi!ÐÒé@wyÛ¢`õ/ÄÂ@ù2Â!±º¿Jàl=ù µðe¥0¢?s¢2ÄÂdÃâTõ(êïK¶æ«çñÍ>Å¡û.Ôðf<ãÒR\A)zÇø IO^Ìã¦EÑ¶AêëôW|¾ª6óç¨ìQ>nu
```

