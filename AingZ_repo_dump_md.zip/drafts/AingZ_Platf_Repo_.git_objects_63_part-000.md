---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/63
part_index: 0
files_included: 8
size_bytes_sum: 4132
created_at: 2025-08-31T21:08:15.622244+00:00
integrity:
  sha256_concat: fd8e4307d8311e8ac7ed3ca93bb5be41879e1798fea7743b495b1f02ea9f2cbf
---

## AingZ_Platf_Repo/.git/objects/63/29fbb6755fb9f4e59032d4dd72df47245ea69b
meta: {size:246, lines:0, sha256:"3248514c356f208ed452aac902b864e69b9b16a419ab89fae8e12e50a83670df", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/63/31b5f0e840c20dcaaf866d8470222b180e6e7c
meta: {size:159, lines:2, sha256:"7071a1b86e747f9419ef73c226d02ba817a5e55c35b12b6db0005a2a7d7ed776", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎQ
Â0a{\À6í:AÄ«¤iºÜ*³*ìôî¾þðÁ/uYæÎõ§¶©B½'Ñ±à@.,¢lbq1³yò¦k½ÓP¨%DCÔjyÛsdêÙð»Mu÷VW"¸Ý®©~u»ÏNêrEï	ÎHæ¨ÇbÓ¿ð¡×°´Xó¾Gç
```

## AingZ_Platf_Repo/.git/objects/63/384f8ab569ed4c5f78f5f9e7f1a91e72253eb0
meta: {size:1457, lines:0, sha256:"be6ee05771b19f947b9268ff44d1841a1143071d67fe36ea1b24012d77f65d64", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/63/70192cc30728e35d8233fd2d744dde8d57b507
meta: {size:442, lines:0, sha256:"5e2e863bf53b0fc72240ec3eddb5f5cdc35cb010162b1d9505c94830fc8e3ff0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/63/82164b1a5a122a8492fb2d9270cda3e484cb1a
meta: {size:796, lines:0, sha256:"317de7cf1e80477deb0534a5ec77fbdd35f8d69f4120b9df731a3a3e1c72afe3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/63/b7ab6efd96b560a876ddca4c0416ec3849a201
meta: {size:800, lines:0, sha256:"f1efd23f263b67749379ececc9d1d5790efe110db6c31f5dab20f942b97a252f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/63/da82b5c88d32749e425cdd8c7a569811b0c0ad
meta: {size:60, lines:0, sha256:"3f0962d3458775298d8d5818a8b2c0181ff34b767a9cc82233787aa0da9ef663", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/63/efb48d622180dd7cb2580a212e30bd85f07ade
meta: {size:172, lines:2, sha256:"ef944efea23e6ccbf80f2113f2561bb4c09b575c60048d4e4804acb64d2c0d19", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x[
Â0Eýî*fJó<DD·á_23­¶)1"¸z»ïá.ehã­r¬51Æ6ÏÌblÈÇº-UY û¢W&h1¤dÐ&É:UäªÄ~ð]z·g©pÖññôYèY>Roã¦ùDe¹òhw5{Ó÷Ý¾îÿüove{¡Ê\(5¹/x¯¼vðBÿL
```

