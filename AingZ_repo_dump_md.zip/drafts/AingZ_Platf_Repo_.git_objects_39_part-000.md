---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/39
part_index: 0
files_included: 5
size_bytes_sum: 2410
created_at: 2025-08-31T21:08:15.572018+00:00
integrity:
  sha256_concat: d1660abc6e023f0e02a8e29b7f1ba0def8da789e5e9f405bd4f631645eca26e6
---

## AingZ_Platf_Repo/.git/objects/39/302636524422145370cd47d324ddfd32e2b491
meta: {size:839, lines:0, sha256:"3e897a0c5511df6d33588ce4d9fc5f5dd63f203e93973aea785a21c670d9d26d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/39/71865e78e21897e7e350928e589424839fee9f
meta: {size:845, lines:0, sha256:"320c8f893b5e17125cc2d7dfe377c94d00e1c30cd0322bcc7ed947f7823a2934", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/39/7c338b1c2c3491900fb08408c296658223db42
meta: {size:301, lines:0, sha256:"cd153623ddb5bf95adc95cf717259d7c5332e7e1c7bf876f88262939857e667f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/39/b041ec4a02f5ae797606b6e76a1d4c31e8c65f
meta: {size:243, lines:0, sha256:"626457662b6faae9393877b419dbec55aa18ef6a2350ec2b0b4f9cb39a22adaa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/39/fb3da8aaf7799c33a334c8427e6e1004207cef
meta: {size:182, lines:2, sha256:"f86e3661bc6cc71ffb640e3a982a34690f300cc311e2cb5d2a1c31c6f0bce292", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xMjÃ0»ö)tIÑo(%=E¡»ç§OÀ¬ÚÓ×Wèv`á¶memâÛè@Ù$bF
jN)ÂÏ9z¶D<É²ÔQW1+evlµ³.ielðÒd¯óDÏqo]|º|÷åü|o/ôÛ²QYÏÜ¶¡¼5ÊFg¬8ÉÓA¿ÿÓQï¸}ôÂC|Úk?µºþjBåýðR)
```

