---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ec
part_index: 0
files_included: 10
size_bytes_sum: 16718
created_at: 2025-08-31T21:08:15.651237+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/ec/1ec27b4a93749db1d70e2759c28bd255156ab2
meta: {size:1859, lines:0, sha256:"f2307f0b4839015a918acbae992e1641374a6e110f770044edf258e04044ce92", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ec/65793b5d6d5b7ddaf3a43af6aa6a4553d19379
meta: {size:8810, lines:0, sha256:"8ada540e034222dfbb236eef5e75240174b219e9bb2428b22b743db68a8beb6d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ec/762abfecde11c3b8c2187a46d6edb2643b329b
meta: {size:2439, lines:0, sha256:"80214b261fc089e9baf734ac65e66c1c18991bb7a38588cf233cfad276cd636e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ec/929865a0af08f41d5e195bb3863720bd9629c4
meta: {size:716, lines:0, sha256:"5c524317e6fd1f542fd27cb7402917395b9cc0f4acfb51ff179faa977809c326", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ec/96306fdd72b4d505a059c06e425a993eefc070
meta: {size:484, lines:0, sha256:"ad25c8036d48e66b74b6905c53f4c3bc17f1154acf8a598f06ce048c4e5417d1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ec/a1c97a3aca80e3f3721817ca678c11543073ba
meta: {size:394, lines:0, sha256:"35d6aa11b2f22d725d01e280c7216caf274f0e2a891bc50ca43a99b047b5a3aa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ec/a694159d8f5278c330f864937dc20443fc4cb9
meta: {size:694, lines:0, sha256:"99b86b3e77975047e8c1a939a79e1975d29368309fddcae2781a75ec271016f2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ec/b9e50109b56b037d7d8ac176f60187cc1b5433
meta: {size:152, lines:0, sha256:"35ea2cee1384bf0fd2a7547a8514e0845d59bf02819a6a353dde527ad21ccc51", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ec/ce93a09209dc014d23c03d99d4542f18bc3634
meta: {size:369, lines:0, sha256:"f8c241cd25a32569aa407016f4b3f906467a6245b9dd7f7fa0ebf98812950d34", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ec/da66b14ee7d7ad9f6f20b4eca04314140c976d
meta: {size:801, lines:0, sha256:"a672fb3f533230d8724be0e7a96b4b552ea0b10c752a580adf93f550de9b6425", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

