---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/ab
part_index: 0
files_included: 13
size_bytes_sum: 8754
created_at: 2025-08-31T21:08:15.629253+00:00
integrity:
  sha256_concat: 4b4e1d52080f8abb42a40433a14a5c48e910b72899171ddced9fdecb64256114
---

## AingZ_Platf_Repo/.git/objects/ab/1cbe0636c7c8ed1da4a772c7c70522e4ff45f4
meta: {size:531, lines:0, sha256:"2165d5484471c81eeffe98753bfb524b3675f6f2025ac02e6abae659161fffcd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ab/6228b60804754b882202fdcf8ff19d8da762fc
meta: {size:1237, lines:6, sha256:"dec7276f9493f9e0be4b8d9a84e2d07aa61eb6739fe88e41f8654249a9b17c70", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x¥WÝN#7îuÂÚ½H!aª*½b[uJK[X.ªHÇsXÌØSÛ W[Ë¾B¯ö¢R/Ëð$ý<ÒÉD+Øç;>>>_ì¾ýb0ôz¯_³ÊhÌ¤±4L^{áÑñïðÃ	'eJðZÍ©Á÷åþL¸pR©	÷h/O¡*Â£_ÞMøÑÙyø÷Ó"ÇZTsQãî(¶$ëÑc¶Üß;`©ð~3zs8}5Øÿ+M*Ã 2ágÆæìß¿ÙÏ?1ç/ÝeF^RÊvR²jIé.³4Ã²3¥c+EöyÖ:&¼ÈJ¸?+µô0Û¯ÇMxmÇçTëzçqÂ*ãöçBé!B$&<9C¤_V«CG¹Ð^I7P`oïONÏ§|~÷áä¤Nß(¡'DêÕý61¨Y¿Ýÿ¥I8ô÷ûlçáîÏ»ø°»[üÝÕ¿vY!¬VEìFô3r{ìLi& [H£kOÚ	÷5s÷2HX¬K¡ï?i%Û{¬óÌ.ÙÃÇ;ö­²¬®P;5ì$Ôân¯×ïÐéTaàteàY¦´'SªD(l?Z<e÷ÿd^A¢«÷n§Áo¯t©R²j?z½étêay¯ª¾UñõVU	ÁÏ[Æ¢ *?«æ~ÈZ´ûM)\H·V )&ÊTrpyNä*¥.ú2XÔWÆÇ3£#lºVòyÈÖ
4]ÕwlïAg@ª¤o{S}èw<@:ë÷VÍçd·¢ØPX~;:,9Ïkh÷,Iµ×BµX¶D ¶Åºg$¬îÞJtÐRd¥­¼3Di§æ-ªÝ¸/õ6vÍè»iR³-ïRhÙvÉoñt±)æmF&B^¶D*&.%<¦hlÚ²¹$òè×3Õ=Ë¨¶²»1²tÞäê÷íÊÂÔÚ±PÈbØ¢îWNkÞØÍ2cå·Ú
 ZÓfJÏ=åÆ¬îuûëÕµÛMçs6¸-È$ÛlTó KxlS\$jm7ëm,.ãå]fÒ¡	aôØó+Ñç1"º-Ú×Á¢iX ®ÛTi(0£sÚÛXÑtzoLÖVÙQt1­åÖ`{6Áô¸ÿ5£núòïaÂsiýrÃañ®ÙRó0vZm@Äs
UTTl­xT{5E71ëµ]jÇ¥¿9Z¾ø¢®jRE+q`ÔP²Èr8±Ê9#63Oí9®ÉÀ±ngÍ§ü?¢½¹ò2y¶ê¼Älû\èé5J´ªÀ¾×ô÷´ôEéÏc¿7"ÏzèXçt-P
4î±Ï<ý?T
Úe¼"~`Ãü æÂÐÀ[ÑESÜPXªäÃ=ÆÕg0z/*wáXÆvEa+&bþÄËÑòÚ©VDµÁS¡«Ì|TX;lTWHNÜvý10Ô®Ü×À»F
```

## AingZ_Platf_Repo/.git/objects/ab/88be143ea9ebb2199d30885ec88ef3fcc69011
meta: {size:105, lines:0, sha256:"c9d6117f99ff8bd5514361f8edaf339fe0666ce3ba52eb9e85128281329b9c3e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ab/8d7c33b43fdfacdb4b93db2f008ad3c854e7d4
meta: {size:72, lines:0, sha256:"cdf0009693c9a9e1853630e72e56a7842d42f05eac0080672f2333a72821f1aa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ab/9f21c4734a5142badf1b53ae3a84e4c5203d8c
meta: {size:651, lines:6, sha256:"6408043e403910b71e95fac61b47334b322dbfcb12391dad50db63da91a7b9c9", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xT½nÛ0îÌ§8 KÔ²âºIª-±ÑÀCs¦ÎHJ}îm§¢C§Ýë7éôz.A
twßw9-ìö÷ûÏ:é2PÖQ÷Êøîdt<29¯­É é'i
0Ô>TA7$Â¢b#ÌKöÚËàXù;yZ`YWÂ¯0¹>uc <^Ú{ÙI:éPÎzïh	iQSå´	$Iw-§rkìKº	dr[Idz$ÓX$À¼`&tlûµÂG;:m¥²91G¯E¦½W;;ðçó·/½Ãïà±×åsx(°hy#ìõ÷µû	:[-ï½VjÌ5Ìe¬Ò¥&,4º±Ï·pÏTÁéùç
9APñ¤0
9 oÑä6Òxí¹eÅ´ÊåWv)LÚì½F>¸ZÚ¡¸ºÂÉ+§+¥÷îØÅm²¹}ójY:ÓeÛqåâ@oñÖÁr
Î`¹F¥.VÈMp®ºIZBuyUEøàÔUeyi±-¬s[þÀÇÕ^]CÂMX=Ø²8É¸qnÔ¯â7 ×ë%Âàípµaá9Å*Pç^NjWUFÀæ<7gcù­S<D°<×IJâU(!ãå÷øÍ¥/,jT,{Zn6#ZEW«æß¸WbUmÈ£@^$0æ°îÛ&7j8yûû§ëü|÷OÆçúwzM/UÊGÆùîvm}óqhOÒÅÅÅËBØ:TuÊ(m¾&Ã±<ë?ýa"ñI:A
```

## AingZ_Platf_Repo/.git/objects/ab/a282e56b154d41349339ca4fc084d0952e2e40
meta: {size:1290, lines:0, sha256:"5616bc3be922009fddba7de4853f844fa24f446f145c048e7bc8b31daf851b0d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ab/adf024337bd024fcc9a52c908d75f2c494cf4c
meta: {size:430, lines:0, sha256:"f12d1ef7c9d4b733dd1d0b260ff2d20727086a5ccd02c3f970cdb1b57a4a1f01", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ab/d5a425f08823b907c357d75d6a2e113fa83713
meta: {size:153, lines:0, sha256:"0b9b701e9f05d71ff685d5591af58d66ae596f8317f3dfebbf6eae2a9ab09dad", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ab/e2d5a93904eb5d9e6b10c92c2dc33a1a224fb9
meta: {size:792, lines:0, sha256:"e985c1a64cf4f810c320a869400fe950adcb247fa5c1ad13bbc27139427fb405", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ab/ec0aafcc0da811b1de91167b72342c42250765
meta: {size:344, lines:0, sha256:"c1d43f75b928098285fc8269144aad1288fa1ed676680e5104a24f93e18296f3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ab/ec6c9b0b748dfabc8f82c4652b65099eaeedf1
meta: {size:902, lines:0, sha256:"7ce64532150b87fbab1d6ac145920b2d3345437bbf0eb362de706126aa328ca0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ab/ef930cf40ee57d0f92a5bf9d26db9f8025c115
meta: {size:1446, lines:0, sha256:"a6ff730445a0e442f256ba70b6a5ce4dc8b4cb9240f76934e8165c027fb83090", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/ab/f8f1915f328ca03e7eb71ea98b03ccbe95b7ad
meta: {size:801, lines:0, sha256:"f8f13450a40ef54c5669a00db48723f05c75ba811fc1293f8546a02ffbe91d40", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

