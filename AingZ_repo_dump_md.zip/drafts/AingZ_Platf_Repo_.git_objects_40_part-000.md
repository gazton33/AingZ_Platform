---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/40
part_index: 0
files_included: 9
size_bytes_sum: 8835
created_at: 2025-08-31T21:08:15.572876+00:00
integrity:
  sha256_concat: cd10495ef79d4bb658f56e50e69d64716307520e7cb2ec637e01f1d026e0c9e6
---

## AingZ_Platf_Repo/.git/objects/40/07d2b4a5144ced103b072fabc5793e9c69aa18
meta: {size:310, lines:0, sha256:"c56bfe908b3c03d71bfa7a2420c7f0c9a013408a54227bf3a6fad10542c6dfac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/40/20f4c1bc1f45d0ccd764251fdaaa91156ef930
meta: {size:321, lines:0, sha256:"a6a96204f35747f788aab583208cbe91a18bdba33fe166016c9967d45e0701c2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/40/24878ec190df1d6f0c6e67ecf278a332e4dac3
meta: {size:240, lines:0, sha256:"1f1ca3aac85b2d38c8ac7625f903b3ebfd012b512c1d137f07bba098a15b28c6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/40/75aee6a79ec7eaf0daff637de515359cb129c9
meta: {size:1937, lines:6, sha256:"38355cf9a047c07bed5d775693dff75748f6a4580154f4a0fe7ebbc4d975f78b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x½XínÛÈío>Å®$¯$ÆÎ$,+Y#²­µl[¯a¨±46Åa¤?R/Ðèäò«ÿú×oÒ'é¹3$EÉF±5Póyî½sgæzLovwvþ°E]£ÄÈKúE«hJI{Yp-ÓþóRuýå|ôR9ÝìP}÷ÕîÖ«?µ^ï4<ï=õ¿er.HÞÍD¤êFó$UJ$ìàÇ=Ís¥FÒØ!ù:HPlFÄ"ID"§ÑDÓüñëDjÄ1V¡I²x"RI*JR¥_#©ô<©Ê»¡ÑL#æ
 0"U±¦ãq¢&JDMJ£bx+²T'UfCoTP}züWäÿÔiÓÎ«W$ÔERÀ&A'·{ß·=¯ÕjyÞÖí´iàìW!è.Üv·Æðm´½=ÒÿLë$£PM¨p"Ç2¢DàFêFàfÛÞnRE aÂ $u£&p@&mÀtý¼÷"Æ$ô:û=¦ÒàJ,¨~(Í\(ÄûPë¾!¸¥©ÇÈ4£ðê.0¦0Ð¸R8¤Cíg&ÊÈ ÕFi°±·Ú\_úÃ«Xrð7´D§bv¤cDkûì°rªÍã7±b)ÕFS1ex*¥#.°rªøW, NfÙ\D°ìÉ+ÉTIÝ60XÊ<Ý=ï!ßcTþ=ÐI¹aùàAT­ç4IáûIhÙË÷éDb×EÒÇo±ÍÞÅÆÎW÷ÈÓê&¨Ëßê[­´#ö{;Ý¿ø'¢©	6´>çuet8ð`í¨ÚÜ2|üVÎì:»WkK#}"o8zÖ¤îñIoiÀ³-k!W­®@.YUa°&íuº>WÍ|®e-äªÕÎªßî7rÄa5©¼Û²åÉ Z¹jtióûÈª'SÆlnY¹b2V%¶Þêßu>ïØOGC¿ßë+ú1k!yêôdÎÒ¤Qø²SòbÈýÎ¨SÅ,»ùÏMüÂÀ»'UD6ÏÌßrÿ¸»²¸"°}ÙÜ²v-þ°øÿð²{|tÔëOò,z n\&a³r}ñéÓÈØÁÁ ×?8êY÷Ü*¯õÒNT	ãfÈqKÀ/\5º
Y\öl§U¦sù·Wy­Ã£Î`øãñhøËywôgS»ã{éµdsËZÈ£'Õù@û2õýâ"ùm_^YÉ×íÅý]r®îPÝ]éíù¤Âp@Ä/..æ9Aó¶ètïs÷SotfI|Ióïï¸çZÊñv{NÛmÿÌÒÓE
ûp]|qÞïz'þÖÄÀÚÝ|M\¥@ÛïGGÇyïÒàIÚ^P(>B½ð¬ùH9ôü¶Om#"Ó°¶³+ø7ÊH°8#
ZyîÜÁhëGÛ_¤ù.nb|f*1yÏ¹2Õl6Û`Éd¹Ô(ðMf°¬S4Ý,L©.¯ÞÒÅé©=ÏÎ.Ý´~µx|ÁA´Ë,ù¡],&åQX.qA`Û>UÀ5ÏEëtÞ¡L­&4Df÷ò­G¸Ñ7rÙ¶m.ÜÏ,±e°Vþ-i=7`VÐ3Ej[ÑTÄ:ñÜÁäáÿ¤Vï¥.ÂíßÉåB0&¥Ñ>£ì¾gvh«ðµe"¶¯-sümÿ°5ö,uªTuú}ÛLÅv)Ê yäÚðMVgZÙr:h²¤zú¾c¹väuühU!Ð|)41+43Tòã¿#züjÆ:D>YqlÔ52 ~M(R\½X,³}qQªBb'9+±]Ba¼UcHC	òU¨k!öËS
[ÁË"!7Ø.VR¯,%<rwîÓ4{}¬ùaáJ7ÞÚõmµ§æ,ÕH'Þ¥ÑsÀ¤³P)¯ èyn'éÚe©Å"¸SÔTûùÿÃ?X¨üã#Àlð2þbmóÏ4³ÖtSº,à÷ËWQZ)É»jI(;CüùÇ¤8Ùi7&·ðåÎßò(âByòUø¤Â×¯¹:úÓ8ýáiodÓX?­ð£ç\o¯Áwæy£N[õk­VÃów§gýý.:D{ºý¹[dµïÿ~ÀKÏÃ«Wñr¢"Ê3E²¹`pÎÕ](e}{~ó¿g~É»Éð´ ïTëk[t}Ñ#OµrOÖí[£Ry"êEÐÛüú&Òçkg1:êF£rÚ¼Ç£ÒZîåïÊw7Ê½>ñKÞ¾6nÿ>¬Ôn8ÄbðwÀÙán3Ü)wöÅ£ØÙÿ&ª«_
```

## AingZ_Platf_Repo/.git/objects/40/899c419f263e75a48c8ee0ea448f72d50a0c01
meta: {size:1940, lines:0, sha256:"3f4ba4fc8f4c7dcc1c7ab5d11e01999de7bb2a4f0c30f9e50840a607d261c2b2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/40/8bb06d90452633d60dc7985c77f1db6a7f6e06
meta: {size:518, lines:0, sha256:"cf069f5f3123dc6cb61fa17929ddbcfd4ce534c1e313ce0d24403b9f86460bc2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/40/c16ba91c1b7f95a5632e90b5713f3c2458f081
meta: {size:763, lines:0, sha256:"a070565a9480efcb5588e64dbe30f1183352c38500f48dc4c688c16e68ba6937", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/40/d234a17d0b3cbf9840febbba124bea284d8c6b
meta: {size:1769, lines:0, sha256:"2d24813a158fa3c260fe90c5654d2f48dddee090705c88cb9e597559a446d9e4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/40/f3b4b3fe9557b2231bc35ca2c274236f78a256
meta: {size:1037, lines:0, sha256:"81840af268c4d9581e3b4a9e9c41e597f61741b8cdcb2984ca6a545f73647c05", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

