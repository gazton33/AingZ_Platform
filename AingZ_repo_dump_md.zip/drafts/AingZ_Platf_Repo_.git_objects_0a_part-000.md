---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/0a
part_index: 0
files_included: 4
size_bytes_sum: 2222
created_at: 2025-08-31T21:08:15.567156+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/0a/180bf995e09cef17a347b2ab66c923085477a1
meta: {size:1256, lines:0, sha256:"cebfc80e31c8b39312e1416d35087a231aeb8164a1d588f1fdff74d8ff1d1fd7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0a/278e2c2bf484af5d66a3f49644800e4840d2ff
meta: {size:74, lines:0, sha256:"91a8f3fdb557d52b04582641a515d30ed9baf7933b7ba41d5046f934d2c6bde0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0a/ab0a06276f15daa9617f8ac62cb1c363417bf0
meta: {size:801, lines:0, sha256:"6b0e6e1aef291a8f1404754d9d1ad964aeb784b9f119cc9d4e380e99f69c494f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0a/cfab2c8a3efafb80a675d54f76742455a7d3a9
meta: {size:91, lines:0, sha256:"49c8a6f224e0bd6c4213329cbaad4cf1842a84c7baffb393c261a621d0feebe8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

