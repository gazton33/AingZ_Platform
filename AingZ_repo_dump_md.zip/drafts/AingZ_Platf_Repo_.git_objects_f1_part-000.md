---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/f1
part_index: 0
files_included: 11
size_bytes_sum: 7233
created_at: 2025-08-31T21:08:15.651937+00:00
integrity:
  sha256_concat: 678dcf6d9fee7bd84e251d7106898bc5a224e2453b12978ea99f3f3799e0c4f9
---

## AingZ_Platf_Repo/.git/objects/f1/0662cdacfe088b934f9b3bb4dce8225dddaac4
meta: {size:276, lines:0, sha256:"a5a35b6b41f9bc174dc42e16b0ecc23dfeb2db8fc120c4f57a217ce2bbb7fff9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f1/0e89f8ebe6c7de4ed227d2174fa5a759ecf41c
meta: {size:400, lines:3, sha256:"b8b121271e9668672c5223981e673494d47a4368c423a731fff5fb1f50f4bfc6", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÍT]kÂ0ÝsÅ=øÔµ:ÝÄÓ"BÕáÇö0Fíí¤M¹Ûýø]?îaZ1!MBÉ¹çääræÚÌ¡zÛ¸¹¸ÎBf¯¨Í«ã2Í5fVJ¥m9.ÔüZÝõ«<àri5^¢4^¥1ÿ¹'	ÄXD¤r«L&hSÖq\×å	fy,-Æ)
âã*qÐî®Ñzs1×KÌIeV¼ºÀY¬b#¾!ü¦ðoÖ|îh`´4zÓÜ+.)$E¹Ù)RJÂcòÂãOÊ8Eæ¿Õ3ðè°¬WþíñJÂ8¶í½­s»ý9:X^fIKþÎQNMòzN÷¯îeÛx¢3êö=^a¿=ìâ±¾K³Èz´ÔZïÐYîþuº~Çî7ï§ãhÏºý©HfÕç(3P{¡b-`Ù`bEYC«Tö¡cÑp2
ûÝö48ég£|áäéáû¬açË0V¯
```

## AingZ_Platf_Repo/.git/objects/f1/353543f209b15f9e6a8bd81c1ba19f1eb7c4d5
meta: {size:1005, lines:0, sha256:"6832da9f00d4d7e67cb972a94af1320163eddf7787f37d48f88993a6642669e0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f1/4bc77621340bc3a7577e8d548ccbfe015b9a9f
meta: {size:111, lines:0, sha256:"7a69e09ad38916afaa54a08fd6c5182488cf884586aba0f084e798115ac543d8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f1/5ac8dca6131860bf96858feb7c74790fa8c7af
meta: {size:65, lines:0, sha256:"6c41c2eb6b8ea32a939f3fd3ca9da7448756c2a9461df3c364a2cc9436a241e7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f1/6f7425ba482bf37495edb07969e0cd23dd4ad5
meta: {size:800, lines:0, sha256:"c8f9765ba105c2a24c71158bbd902530c0b09ecc1faa33c72620cc4315845ede", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f1/8eafa4ae19ca612d8e03b9ff430834759b325f
meta: {size:1544, lines:0, sha256:"4a825b50f5b6f475d975cc783b58415c6c5b53aac0b56f3edd6e9010d9e958a7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f1/9d38eec2065dac47c9caa192a6f7c383f70974
meta: {size:1486, lines:0, sha256:"c892067240c40b13c5e11b4e62853777a28d9c11409f9c21883ec3ff8e2fe9ac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f1/b6120195bb707b9b9f63bfc7d72cd5fdfc0449
meta: {size:909, lines:0, sha256:"258ffc307e959b6a65c78c02a327aa539938660c2bf27b1a2995e61444046a77", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f1/dd92162847b0900dfe86eb172ec071bc9be8a3
meta: {size:534, lines:0, sha256:"385a5fa0d18b4728336d151c7358a883d3ab382a4be36cf94717b27e6a6a2062", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f1/e92a0e086811a8ff05b7a692a9cac4bcf0a86c
meta: {size:103, lines:0, sha256:"9672ccece52096017014a949ba8adece79c48763b8811343d2ad06d4615ae2db", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

