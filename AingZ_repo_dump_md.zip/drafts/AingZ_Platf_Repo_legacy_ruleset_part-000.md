---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/legacy/ruleset
part_index: 0
files_included: 3
size_bytes_sum: 8250
created_at: 2025-08-31T21:08:15.666824+00:00
integrity:
  sha256_concat: 12308828c5fd0002b023c4aeb29034a8d30a39dc20ed99ba3b3deb591a5daf85
---

## AingZ_Platf_Repo/legacy/ruleset/readme_core_data_ruleset_rw_b_v_3_2.md
meta: {size:3017, lines:80, sha256:"64546a436cebca1773ad7e9a2dbecf7dff9df5633ea77753d269064e294fca80", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
CODE: CORE
ID: readme_core_data_ruleset_rw_b_v_3_2_v4
VERSION: v4.0-2025-08-10
ROUTE: /home/runner/work/AingZ_Platform/AingZ_Platform/legacy/ruleset/readme_core_data_ruleset_rw_b_v_3_2.md
CROSSREF:
  - lifecycle/temp/rw_b_blueprint_v_4_extendido_2025_08_06.md
  - lifecycle/temp/rw_b_master_plan_v_4_extendido_2025_08_06.md
  - lifecycle/temp/prompt_codex_baseline_v_4_check.md
  - legacy/ruleset/RULE_CODING_COMPLIANCE_V4.md
AUTHOR: AingZ_Platform
DATE: 2025-08-10
---
# 🔧 legacy/ruleset/ — Rulesets, Normas y Políticas Universales (v3.2)

## 1. Descripción, función, objetivos y contexto

La carpeta `legacy/ruleset/` centraliza **todos los rulesets, normas, políticas y marcos regulatorios** que rigen la plataforma AingZ/RwB.

### Funciones principales:

- Almacenar reglas universales, políticas de integración, naming, versionado y compliance aplicables a todos los assets y workflows.
- Servir de referencia normativa para la validación, auditoría y automatización de procesos.
- Garantizar la trazabilidad y actualización de todas las políticas críticas, reflejando cambios en blueprint y master plan.

### Integraciones y sistemas relacionados:

- Referencia constante en workflows de `wf/` y validaciones cross-bucket.
- Base normativa para la generación de templates, onboarding y pipelines automáticos desde `ops/`.
- Crossref explícito en todos los assets principales del core y buckets hijos.

## 2. Estructura interna

| Subcarpeta / Archivo         | Propósito                          | Estado |
| ---------------------------- | ---------------------------------- | ------ |
| ruleset\_rw\_b\_universal.md | Ruleset principal y versión viva   | Activo |
| naming\_politicas.md         | Políticas de naming/versionado     | Activo |
| compliance\_policies.md      | Políticas y normas de compliance   | Activo |
| ...                          | Otras normas y reglas de operación | Activo |

## 3. Metadatos y compliance

- **Versión:** v3.2 — 2025-08-06
- **Owner/Responsable:** AingZ\_Platform · RwB
- **Crossref obligatoria:** Blueprint, master plan, checklist, template universal README (ops/templates/)
- **Naming/Versionado:** Cumplimiento estricto de políticas RwB v3.2
- **Estado:** Activo

## 4. Ciclo de vida y flujos

```mermaid
graph TD;
  A[Ingreso/update de ruleset] --> B[Validación compliance y naming]
  B --> C[Crossref en assets, checklist, workflows]
  C --> D[Auditoría, lessons y mejora continua]
```

## 5. Changelog local

- 2025-08-06: Versión v3.2, integración de compliance ruleset y políticas universales.

## 6. Observaciones / Lessons learned

- Todo cambio en ruleset o políticas debe reflejarse en blueprint, checklist y changelog global.
- No mantener políticas legacy fuera de compliance y sin versión activa registrada.

---

**FIN README legacy/ruleset/ v3.2**

## OutputTemplate
```yaml
CODE:
ID:
VERSION:
ROUTE:
CROSSREF:
AUTHOR:
DATE:
```
```

## AingZ_Platf_Repo/legacy/ruleset/RULE_CODING_COMPLIANCE_V4.md
meta: {size:3106, lines:75, sha256:"2df70381684de1f650cde31c0bba4a2c51f5148f5f22a9475ade89027d75ec8b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
file: legacy/ruleset/RULE_CODING_COMPLIANCE_V4.md
code: RULE
name: RuleCodingComplianceV4
version: v4.0
date: 2025-08-11
owner: AingZ_Platform · RwB
status: active
xrf:
  blueprint: RwB_Blueprint_V4
  mplan: RwB_MasterPlan_V4
  glossary: CODE_Glossary_v2
  dictionary: CODE_Triggers_v2
triggers: [TRG_CONSOLIDATE_TL, TRG_AUDIT_TL]
chg: CHG_main.md#2025-08-11-rule-coding-v4
chk: CHK_root.md#2025-08-11-rule-coding-v4
---

# Rule — Coding Compliance V4

> **Propósito**: estandarizar el contrato de cumplimiento para todo asset V4 (naming, ruta, WF, OutputTemplate, crossref) y habilitar su verificación **Pre**/**Post** en cualquier plataforma (Chat/Actions/Bot/Notion).

## 1) Alcance
- Aplica a **todos** los archivos versionados (MD, YAML, scripts) que formen parte del árbol V4.
- Compatible con CI (GitHub Actions) y orquestación Notion.

## 2) PreCheck (obligatorio)
- **CODE**: coincide con `^[A-Z]{1,5}$` y existe en **Glosario** (CODE_Glossary_v2).
- **Ruta**: válida según **Blueprint V4**; el campo `file:` del front‑matter **coincide** con la ruta real.
- **Metadatos**: front‑matter completo (`file, code, name, version, date, owner, status, xrf, triggers, chg, chk`).
- **XRF**: referencias presentes a `blueprint`, `mplan`, `glossary`, `dictionary`.
- **Triggers**: lista contiene al menos `TRG_CONSOLIDATE_TL` (y los que correspondan por ciclo).
- **WF**: pasos explícitos o referencia clara a WF aplicable.
- **OutputTemplate**: bloque YAML integrado (estructura mínima validable).

## 3) PostCheck (obligatorio)
- `OutputTemplate.status == OK` y `created_at` en ISO8601.
- `CHG/CHK/CHKP/LESSONS` actualizados (fecha actual) y enlazados.
- Evidencias publicadas: artefacto CI / commit en ruta / snapshot Notion.

## 4) Gates de error
- `BAD_CODE_FORMAT` → `code:` no cumple regex o no existe en Glosario.
- `UNKNOWN_CODE` → CODE no registrado en Glosario.
- `ROUTE_OUT_OF_BLUEPRINT` → ruta fuera del árbol permitido.
- `MISMATCH_FILE_ROUTE` → `file:` no coincide con la ruta efectiva.
- `MISSING_XRF` → faltan refs a blueprint/mplan/glossary/dictionary.
- `MISSING_TRIGGERS` → no declara triggers mínimos.
- `NO_OUTPUTTEMPLATE` → falta bloque OutputTemplate.

## 5) Notas de precedencia
- En conflicto de semántica o triggers, **prevalecen** `CODE_Glossary_v2` y `CODE_Triggers_v2` (máxima jerarquía).

## 6) Checklist rápido
- [ ] CODE ≤5 (`SCREAMING_SNAKE`) y válido en Glosario.
- [ ] `file:` = ruta real; ubicación válida (Blueprint).
- [ ] XRF completo a Blueprint/MPlan/Glosario/Diccionario.
- [ ] Triggers declarados (`TRG_CONSOLIDATE_TL` mínimo).
- [ ] WF explícito y **OutputTemplate** integrado.
- [ ] CHG/CHK/CHKP/LESSONS actualizados.

---
# OutputTemplate (obligatorio)
rule_coding_compliance_v4:
  status: OK
  id_asset: RULE_CODING_V4_2025-08-11T00:00:00Z
  generated_by: ai
  created_at: 2025-08-11T00:00:00Z
  checks:
    precheck: required
    postcheck: required
  log:
    - step1: declare_rules
    - step2: enforce_pre
    - step3: enforce_post

```

## AingZ_Platf_Repo/legacy/ruleset/RULE_NAMING_METADATA_CROSSREF_V1.md
meta: {size:2127, lines:80, sha256:"e6baf6cc932a7f1889c1bdddb7ea0792fc2ae0bbb66795c17895b094484b5900", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```md
---
CODE: DOC
ID: RULE_NAMING_METADATA_CROSSREF_V1
VERSION: v1.0-2025-08-10
ROUTE: /home/runner/work/AingZ_Platform/AingZ_Platform/legacy/ruleset/RULE_NAMING_METADATA_CROSSREF_V1.md
CROSSREF:
  - legacy/ruleset/RULE_CODING_COMPLIANCE_V4.md
  - README.md
AUTHOR: AingZ_Platform
DATE: 2025-08-10
---
# RULE_NAMING_METADATA_CROSSREF_V1

Políticas globales para convenciones de naming, metadatos YAML y mantenimiento de referencias cruzadas.

## 1. Naming
- Idioma: inglés o español claro.
- Formato recomendado: *snake_case* (`[a-z0-9_]+`).
- Usar `_` como separador y mayúsculas solo para acrónimos clave (`RULE`, `README`).
- Prohibidos espacios, caracteres especiales o nombres genéricos (`final.md`, `temp.txt`).
- Incluir sufijo de versión al final (`_v1`, `_v2_20250810`).

**Conforme**
- `core/data/readme_core_data_rw_b_v_3_2.md`
- `ops/scripts/deploy_pipeline_v1.sh`

**No Conforme**
- `core/data/ReadMeCoreData.md`
- `ops/scripts/deploy pipeline.sh`

## 2. Metadatos YAML
- Todo archivo de documentación inicia con bloque YAML con campos obligatorios:
  `CODE`, `ID`, `VERSION`, `ROUTE`, `CROSSREF`, `AUTHOR`, `DATE`.
- `ROUTE` debe ser absoluta; `CROSSREF` una lista de rutas relativas existentes.
- `DATE` en formato ISO (`YYYY-MM-DD`).

**Conforme**
```yaml
---
CODE: READM
ID: ejemplo_readme
VERSION: v1.0-2025-08-10
ROUTE: /abs/path/ejemplo_readme.md
CROSSREF:
  - ruleset/legacy/RULE_NAMING_METADATA_CROSSREF_V1.md
AUTHOR: AingZ_Platform
DATE: 2025-08-10
---
```

**No Conforme**
```yaml
CODE: ejemplo
VERSION: 1.0
ROUTE: relative/path.md
---
```

## 3. Crossref
- Al mover o renombrar archivos citados, actualizar rutas en `CROSSREF` y en el cuerpo del documento.
- Las rutas deben ser relativas al repo y resolver a archivos existentes.
- Evitar URLs externas o rutas rotas.

**Conforme**
- `CROSSREF: [README.md, legacy/ruleset/RULE_CODING_COMPLIANCE_V4.md]`

**No Conforme**
- `CROSSREF: [docs/old_readme.md, http://externo.com/doc.md]`

---
## OutputTemplate
```yaml
CODE:
ID:
VERSION:
ROUTE:
CROSSREF:
AUTHOR:
DATE:
```
```

