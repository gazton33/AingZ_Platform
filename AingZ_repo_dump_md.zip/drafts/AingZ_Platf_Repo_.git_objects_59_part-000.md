---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/59
part_index: 0
files_included: 10
size_bytes_sum: 4925
created_at: 2025-08-31T21:08:15.620325+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/59/0435808b3007b953aa7232c4ee9924528f71f2
meta: {size:165, lines:0, sha256:"ee10339e31bb110c66b2b5475de9f9a94888fc79cb6a0aabb0439b2ef9ab4bfe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/59/08757bad2f5af75f39cf904ae63416bfa75c27
meta: {size:845, lines:0, sha256:"463d4543380a711f5c1b4ec82836cc2a8605df35292f29a8b6344edbf599cf41", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/59/19e6a5fa9b794db0248b523c0dd612d78030f0
meta: {size:852, lines:0, sha256:"2b4dd0426594c2a20468039840bca1fcb129da16253adc5b42ca3345cee4e3ff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/59/94040bde65806e8b8b71312f99b2ef810ac33f
meta: {size:723, lines:0, sha256:"04a0cbd5f0b67a13c2ce1d2320c62fad5b6dfa305b53d4b001e8d5b17f313319", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/59/9e76cc1bceb817ab54113cdde5f637a9cf33ce
meta: {size:585, lines:0, sha256:"4d67ca3242f8ed3d3a01f827916449c82320153f2b79425cb5ab4b88b595bd7a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/59/ad7efe5ac7a79e82982d838ed1fc89108c9e1f
meta: {size:944, lines:0, sha256:"aa30d1c96b3ab66d126b28b8a060da9520a163988fdb3e2bf365c6ac06809b15", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/59/c05378b3f22e2f9bfd645c53c7f75aa967ee93
meta: {size:442, lines:0, sha256:"685e2a6d5fa44c17cde2d3246414f0979c7e83230d8e79cec7c0a3c43857b868", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/59/c18aa72fa8cbcac55926511d2c8e7c96e60518
meta: {size:133, lines:0, sha256:"aa5451a3dbe1804e15063e87df45d145054ca7c7fe8ebbb638058eafbefebaad", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/59/c51f551c9a3e4c30f6268da427551aee40cc0d
meta: {size:81, lines:0, sha256:"84e384889885dc6dcac93d0f7476cf3ad2a7cec0d36126707a8a6e4f976acd5f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/59/e4d2262de3881319516e2db4ce0312687572b0
meta: {size:155, lines:0, sha256:"5a951acb76d90f551cccf62525e520205784fa013a6a4f0d36c0b4b1ac6302f3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

