---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/d4
part_index: 0
files_included: 9
size_bytes_sum: 4013
created_at: 2025-08-31T21:08:15.649275+00:00
integrity:
  sha256_concat: 193420adde6fe564a498c8479c6f6c5e14f097f2264e28c0976330ea081fc8ec
---

## AingZ_Platf_Repo/.git/objects/d4/30df98d47911ef99f7f696b047939e20b6c109
meta: {size:155, lines:0, sha256:"fc67617dea3881afc07ba536218442f713d4569d6866a57226f4f1456be85727", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d4/3f89fa82644108f08ff7d1a8d07bbe054f0481
meta: {size:84, lines:0, sha256:"95efe61c3304b080c5f0002f370dd97b3e2dd19ef1f79b069e358e202b267a6a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d4/5aa2228934303116c430b13eae89f4bf3ebeac
meta: {size:367, lines:0, sha256:"35a0fce3b113828bcdd55a7919daf177bc77a73f0ed214e74b37f5a687bf0e71", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d4/95462a12eb0a7527f6febe302acca97456cbcd
meta: {size:1602, lines:0, sha256:"9808eab45d3ebe546fb3104658bc8adba23b48e8de1ef1f05332ada640356074", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d4/a2f9202e2f2f7721164be810f541ddd95db20c
meta: {size:518, lines:0, sha256:"099be977c1cc35614d95acefdfad094777c3e309c83ca380ae65c21d62c42835", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d4/b4d53a506aacb1b01c4a43cf356f1c7793527a
meta: {size:232, lines:2, sha256:"46edb43d17110129826c79242e3f3710b464e25aa5705d86f3b44a02c120ce95", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x½nÃ0;û)´ej¬¿NEQ´Ý»dìål ¶UA<}Ý!/ÐeYæ&Æ§VE²Z' 	Ö{I("$HiW!è±Û¨òÚDL
@¬ÐDç1ëwÀèQ[¯yRÇÆ`x¥Ú`R|dCÖ)ßÑµM¥L÷VVcÄk>ÞùÂq*7®ïy¡ùreyÊU¥ñ,Ýîîÿ«Ü}qÍ,JkÄaÇ¬QZÛ~^ú>Ïmºäþ1­?Ý>Ï'ÞÊùc^ów÷µf
```

## AingZ_Platf_Repo/.git/objects/d4/d115713e21b16ec68173075dafe279f674dc1f
meta: {size:84, lines:0, sha256:"1e75629f1291c4b9a956479c9b62538f7a342e7fdf1ec7efbea80b9e71a837cf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d4/e0054e5e031f3c20139c5da433298feea0f636
meta: {size:128, lines:0, sha256:"c7c2494b3afc5dde17735e870075234ec59f6686b17023bb35a801b172abfaac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d4/e41a500b0b50d9aede58084ab2663ff1929301
meta: {size:843, lines:0, sha256:"881782a17c0fccffbe43de9997fa9536e6c5f2c8fea1e4ee73306e56f69dd005", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

