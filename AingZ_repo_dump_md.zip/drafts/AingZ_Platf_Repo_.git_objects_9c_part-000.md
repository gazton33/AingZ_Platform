---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/9c
part_index: 0
files_included: 9
size_bytes_sum: 10624
created_at: 2025-08-31T21:08:15.628291+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/9c/3b448e1af3c3c434e9ae8c83fe886ad6675757
meta: {size:51, lines:0, sha256:"1aba587a256f30f129c69d47140720675d776f55a39db7df34421c8d369ae406", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9c/4fed4a0da7ead4122c03ea3eb9617e08d537d6
meta: {size:1241, lines:0, sha256:"366c66d729d76701a62f65ab6914853dab882eaf4695b93d6c92799c2bdcf7f6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9c/617b8430609d371abe438bd4870c397928749c
meta: {size:241, lines:0, sha256:"fc912d6639722f3ac9a7370f9544257f24d8817ac77ad5fdc8be66a82c746cfd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9c/8020a5cf56dca318dabc44936cf7a137f13199
meta: {size:742, lines:0, sha256:"e39cfa218d7904aea5695c06d6da9d045a25bd22e47ac07116f6ac126381c88a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9c/958e84b7945c31b7b5d3d1cceb5e1a0f9d9dca
meta: {size:92, lines:0, sha256:"577ee3a906cc35494f0193b873990bb3ab6506da7acd50fdeb28b2f410ab0e90", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9c/9b5e45103d7b536bc640aafa35e32d0e9e5c3d
meta: {size:96, lines:0, sha256:"0e7bb3b26692ed539be4e68a6983c97bf985e063f389a4afc442257d858b82fa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9c/a2bfc59479dc15e588f24c0856b4cae4addf75
meta: {size:977, lines:0, sha256:"902e343bcbd79134b2920a7e933cf0a8c42e0c841e9b3384ed3b372b54e36d99", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9c/a55c06a580564e7bf263da73cbf44e9883c5f5
meta: {size:2234, lines:0, sha256:"d4d826f823aee10e3e2bc6563f1d3815c557b3b2a273a11847710622fcccf130", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9c/f910a76f36ec06bf2778b5943df5f4b85fcc42
meta: {size:4950, lines:0, sha256:"e1820b5f00bab4d00060fcdd42b03a99769373a1dfb6e18cad2c3ef01d3707f4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

