---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/e8
part_index: 0
files_included: 7
size_bytes_sum: 4560
created_at: 2025-08-31T21:08:15.651016+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/e8/32c9e75cd79fcc40212f2b43948a69d25ac0d2
meta: {size:107, lines:0, sha256:"5feb919589e4c4e9c72f57d0fb7baa4adcb7403586ea5713388f5768496c36fd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e8/6086f3a54d49837dd75c6e08229019a8d23946
meta: {size:1479, lines:0, sha256:"f47b938476fc7c80368a770e254b77160923be6cefd87156a896c571e483220a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e8/78a13c5782e768e7f3d897b64ffcc9abffda4b
meta: {size:1005, lines:0, sha256:"70453f57158d109adcac9f6c28c1e19faea9e13bfe2ef7f34d8b49e3d5108713", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e8/78d98112ebe5927ece456b214db6275a121552
meta: {size:288, lines:0, sha256:"986d59e5d6a1e0c55a2ca2714349beab9cc5e324f7266a319f3fb00a3f466361", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e8/8f4dacced81bdd9e7bf97c5e8aacbaa0def8f0
meta: {size:630, lines:0, sha256:"902f7b69d26cddb84cb01d9f5c0e83ddba91b5ab6cbdc1642aa59549a77a3abe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e8/93a6167e58f280e73fbf44724cd5c5deacadbc
meta: {size:196, lines:0, sha256:"770fa8aa36ea63bad521c18f3fd2ae489da375014d93ffd9634511ac4492c729", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e8/e020343afcc4fcadebd7c649baa2cd876af300
meta: {size:855, lines:0, sha256:"2743c25d6b94dfb875aff8616aa14907418b2cd7e35dabf6943d6e659fc4c14b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

