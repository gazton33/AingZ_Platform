---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/b7
part_index: 0
files_included: 5
size_bytes_sum: 1329
created_at: 2025-08-31T21:08:15.629916+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/b7/3acb6401ebb2ab4154e2af61a677b3c0157b40
meta: {size:139, lines:0, sha256:"77420a31ba8cf49a68bbf1da71d199250556d79467b5c92ee6f0347721d42c0c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b7/66270172ca60f8200d00998f172f86ab299196
meta: {size:103, lines:0, sha256:"bcecaf7abe640d776e1979bc7301015fcaa0ab00fcb0c745b4985b4f1e977b14", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b7/a9e79eef15c78c11f48c96fb742b6278323197
meta: {size:302, lines:0, sha256:"f59758cede6b258f2894377c9d4dcee8eccede2246db258083381f3332725f33", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b7/ba44349ebdaa0f08327fdccec0e0131bac27da
meta: {size:633, lines:0, sha256:"08d7301953b90a8f8c6f3a00b7ae8e0f544db71ddaebd76619ff5d597a9c35aa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/b7/f647e3d6baf3893f4daf7b585141a5435815ae
meta: {size:152, lines:0, sha256:"d2f5f6d41ea22f601d5b064611637f9f07f1780af29a1eb5d419eb9f12cf520e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

