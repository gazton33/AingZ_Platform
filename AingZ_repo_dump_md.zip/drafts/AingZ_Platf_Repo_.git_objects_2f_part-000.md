---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/2f
part_index: 0
files_included: 5
size_bytes_sum: 8539
created_at: 2025-08-31T21:08:15.570692+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/2f/069087e7028c865354fa506bdbeb3da2569a96
meta: {size:1507, lines:0, sha256:"1de6e4e4c455047c401ca7f077322e4451fea7a597f16f0ed739b86bca5e84ca", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2f/305588332b8893984ee8eea46a04451d751488
meta: {size:1349, lines:0, sha256:"dd372e1781c29e3dea5a8ee86ebe6c41fcf3ad7601237cddb203b990d2348a98", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2f/537e22ac6936b9aeb78e71b8a38014f032c6da
meta: {size:76, lines:0, sha256:"321e01f056b5f7331fe7f9978a6fa0753b6535406527d48f0cebd1fbbe21cba9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2f/7729ac57b770ec4fc2d6af9a0344d5c39d5c95
meta: {size:1599, lines:0, sha256:"302c312d74eba07fee456edc5a750f84c4e1f5b8b72ff9bf9f7aded9149eeee9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2f/d220f0aa8f94050b4c188fa9561c37eab2bfff
meta: {size:4008, lines:0, sha256:"968fcda9f2621b363c2aece5b46b6287c7d48743ceeb99fac933739092e1ddcc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

