---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/53
part_index: 0
files_included: 6
size_bytes_sum: 3354
created_at: 2025-08-31T21:08:15.619816+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/53/0b776348465ddd139020bb3fcc768cdebe5ee8
meta: {size:444, lines:0, sha256:"1f843f73cd00fe9ac25a6743929f7a0c1f7b78b2b382c3c4c7b44874c457dc33", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/53/1b1927a78b1f28c9a178bac0a6b65607c68b0b
meta: {size:442, lines:0, sha256:"2d78be136d14a60972f4e77bc80b33c944167ea2c787f84a4d6563f4e9d169d4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/53/4cd4ff7938da965f93b049ba9316a1b5a0b68d
meta: {size:374, lines:0, sha256:"788dbd5af01e847dbe0ef8232800d74fb34e9b3dd79175c15a2b4cb452a5bf78", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/53/5fe7db03eb0086daac1f7934923bf07ffad574
meta: {size:958, lines:0, sha256:"698a6752358ff3fd1d636ba1d024b750593e0c7d0f858c7df05bd8102c5d1f15", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/53/b56857a82593c018264801d023170500dfe96f
meta: {size:80, lines:0, sha256:"dd515178e27a94031256fc2142a86ded77ad1d60c1b5b4c8c7c8ed92c9f7778f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/53/ce1f31816711497366b0e5fd46126dfff5324b
meta: {size:1056, lines:0, sha256:"c24e66445719990af3899eff3a0b9e7d97582ed5eef59abbb057d1725bfe4955", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

