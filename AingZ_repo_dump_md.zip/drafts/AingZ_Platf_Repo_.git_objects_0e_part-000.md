---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/0e
part_index: 0
files_included: 5
size_bytes_sum: 9046
created_at: 2025-08-31T21:08:15.567643+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/0e/4e64a3620669793c62755841e9eff6ea124074
meta: {size:69, lines:0, sha256:"62cf84d60f20b74ea81eee1129b5c13e1dcad077db9e5901c49b8dea3d3c57e0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0e/a57a48ea0e6c8b29315babb5ef8f8fa3546380
meta: {size:7237, lines:0, sha256:"cc5c38c9ec85d07f8cfe6095698043b84c85483c897feaa9dd2e47a6407bb8be", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0e/b028c21236bcf410d3aa07baa42c70b25469a4
meta: {size:923, lines:0, sha256:"19963557c033183f4eeb0fa0f24c2e3f0488db551aa7d4e31340e285a31f41eb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0e/b5969d45ce50e4e97aa9777f4a1175d62dc3d2
meta: {size:52, lines:0, sha256:"019589e1dd4b01c4fa8a67edc9ddc7c75f61f8ab36a0ca20dfafc8551c47751a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/0e/c68b237d6e93e18348576c3626a30650312bfd
meta: {size:765, lines:0, sha256:"8eac7d8f7c811f27465ae28bb749a9e954e68788b38e9067c2d8fba727f6d8e0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

