---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/75
part_index: 1
files_included: 1
size_bytes_sum: 4316153
created_at: 2025-08-31T21:08:15.071590+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/75/06dcd029ca54f294ef067d91ff44bcdfe59660
meta: {size:4316153, lines:0, sha256:"f51b5e8135760c64ba7ce6a79c03683501708367e216bc24e0afaa63e9c0fa3d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

