---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/d7
part_index: 0
files_included: 8
size_bytes_sum: 3519
created_at: 2025-08-31T21:08:15.649518+00:00
integrity:
  sha256_concat: 17f428959eae4add74bd3ba95d4f252c96d6ee929fd41054e8ca7b9f27868405
---

## AingZ_Platf_Repo/.git/objects/d7/2303b4228b278ab59545dc4244cae3096785ae
meta: {size:346, lines:2, sha256:"5a53e2ee087dafbc66da35658ea72f8adf581b05bb8f3e7ccd124f8978c00729", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xuQËNÃ0äÜ¯r¦UWCoHUn²M,\;¬ÊCýwÖN_A"$;3»¯¤^y]ü ,µ¼50^iÃY°æÒÀ¥ãp,Â°¯½}äµ!Äb·×6·ÍuÔ©¿<)£åTÊPÛ=¶WiG7ô£q\£îÚáLOÜð²n÷ïàóÛrÛÌæBÕÏËÉíZãf¹áBÆmâÅ~ÝÄq*ÙA@5Ö+¤Ó±¤Ø7îü×½_}*GÏ0­äîüSnÏ9¢ÞPöWp×I+Z)|î¦tñ=¤¼§P
õuô@ð'1ºÀEPµu·M2VLY§ÅÕ4JXìFhA©Xï};G½Ö×ÂX®J qÖkMÉ¥«£IERäY³åIöIImïãí~â7»Ù
```

## AingZ_Platf_Repo/.git/objects/d7/2e8961f56f736d92b2577942aa2a6803ed58f8
meta: {size:242, lines:0, sha256:"a5a5fce471b68474608f360112da351e4e60dd84a2975d0bbc62d6f67005e470", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d7/571fa94ea2f1233694122f06f7f81479e3e2bb
meta: {size:291, lines:0, sha256:"e0f6a93306f2f7d9e895782ec2b6d7b3584195a99082f3ee8a81b6bf5715562e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d7/77ff7ecd24b77926adc113530774a5782c23a9
meta: {size:181, lines:0, sha256:"ffdfac6cbd36ec66e94317547ea6846fd549cca05104a7da27f3e017f747f0e2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d7/ac363fceb0ea93f095a15f6224b309e395f369
meta: {size:218, lines:0, sha256:"a3d7d6d4e8bbe20643f9ce58a9f3fa32517c787e132885f7f25be2d5cbed65ff", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d7/c3c67185d6ced22a2159e246b9498db7cc8ae1
meta: {size:178, lines:0, sha256:"8b1245be2c1ee30d7fa49471912d8e3bf41840611af3f87ff18324439bf57682", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d7/ddbdbdf8bfb41dc6dc5d43fc0a7ba80639853c
meta: {size:801, lines:0, sha256:"dec65aaf557a54390b1c4e6a10d39f8d12beb89a805c37dc364ced2672b196dd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/d7/ed4e31875acbd9d888e9aab7ee1f687f0ddc08
meta: {size:1262, lines:0, sha256:"9538bb32c8c35823c6d7a2e35dcf0f32a6363f259db46c22413aa35649fabf8d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

