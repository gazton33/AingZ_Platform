---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/82
part_index: 0
files_included: 5
size_bytes_sum: 4712
created_at: 2025-08-31T21:08:15.625606+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/82/1d8a1be1564d420f97604ec9511a14e2aafee3
meta: {size:656, lines:0, sha256:"294bd6899d366223a37684438c371d22598005c4f0741beb21f6052423100000", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/82/53909ce35ef42ca02592b0a63f8113f24ff865
meta: {size:126, lines:0, sha256:"4b7da04496aac1c4edb26f7cf084261f4d554d22c20d70a3e56cb6f4c7b51992", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/82/8b5da641314449a7190094a7fd808ea084b8f7
meta: {size:508, lines:0, sha256:"ecd1343b03174f51a538d183cc451387dd1b6337ce0afa3b56b5f9e2ff394ff4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/82/9681959947be1672c477fd0a7855fbad8392df
meta: {size:2416, lines:0, sha256:"92998d56bc8534bbc1ba6811ca794844fe019bfad66d6038718d3997618f86e7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/82/fc37ed99749cc7fc1ba506d75067120a27fe39
meta: {size:1006, lines:0, sha256:"3361864daf169dc29c5dd6a6c5d93474f8b6fd9f6fcbce74b41e5409605b55b6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

