---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/f6
part_index: 0
files_included: 8
size_bytes_sum: 10059
created_at: 2025-08-31T21:08:15.652312+00:00
integrity:
  sha256_concat: 9d54a901d78f2fc4413efd3aecf968457ce1d2e1948c3ff2ed96b1361d25aba2
---

## AingZ_Platf_Repo/.git/objects/f6/1be54c7c7b2a0d4d35d84e5338ad3edc106724
meta: {size:5629, lines:0, sha256:"77f6671164bc0a2cf95d314fe53617d842a8de1d171f1722888897c07b010400", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f6/1e715776ef48491e4be00f3834b7b1ca60f3ec
meta: {size:1601, lines:0, sha256:"e280a8ed0b12fdccd4cfde70377484a55315b5ca253e8a3db8943eb10b0228cc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f6/943face66c67090047e7e765b45b8d2a388f7f
meta: {size:908, lines:0, sha256:"626110749e9e08174bc90b782b5c41b0a570bc4ba8e59ee6667e5cb0c5ff7d99", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f6/9b6d7f35ea6de16f2b4cb110cef2ac87758a16
meta: {size:179, lines:0, sha256:"aa0962129c9ba22666a1187961bab122ba1cc2212e81267dd96969106bc37a78", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f6/9c3fee2034a3ce9c4a514c7be30be9b170c790
meta: {size:1378, lines:0, sha256:"8cd12db86a45ef7285e154c6bf46359e3d54308353d9287704cf5b1ebc037b46", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f6/c39657f2242f28ffea87936bd34f66c71c9aa9
meta: {size:119, lines:0, sha256:"a066acf2f64a4c79220eadec1d42b113aa8b2dd61d0679a0b94c9e973c169708", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f6/f67290c4e183fc629ed7b0f03920c201aec943
meta: {size:72, lines:0, sha256:"258711b0e0d0f86c02b1d0f8ed1d24f07e6dc8b56dccb8ae2ba912b8a57b116b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f6/fd12cc80cb9d67beba4cf55b30b36b34ad8e85
meta: {size:173, lines:3, sha256:"4d67ac40d338f6c9555ea13b3b2f6978dfad8049699b3248e3aa942193552309", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xÎQjÃ0á=û¾À,Ùqeì=,Ëi·&®K¡§_Ï°×>ø¥mÛuX¤ùctU!
F¤ @jÉ±T	 I=!¥ÊÑRÍÁ]÷açìw]uu®GNÑUKÄ\Ïè9¹lø1.­Û_£íDö´N/½©\ÚSû÷ºñõ6IÛ¾¬ÁC
´Dû	`Þõ½8ô_ØÂCí³õßûÁ¢ÓÏ½íæK
```

