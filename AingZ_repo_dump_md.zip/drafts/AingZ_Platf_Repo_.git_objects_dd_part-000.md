---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/dd
part_index: 0
files_included: 5
size_bytes_sum: 2998
created_at: 2025-08-31T21:08:15.649864+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/dd/2443b8a6fba09936325d27f2a7f76767457acf
meta: {size:611, lines:0, sha256:"5b0009473cfa1794279973e0b34f1855aa2ef7911a36cb93515057a0621a67ab", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dd/901cf2e5d68f1bdccf404c5122cc4eb5e9dbba
meta: {size:167, lines:0, sha256:"a21fabccafe0811322e02b691769677386ecb63a2af30d20fa5a6089dc48d7a6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dd/bab77e25ddf70051a087aaa5d8c469154160b8
meta: {size:73, lines:0, sha256:"3a3282a94d36ab75bfdf9084c58b975a74bc9a5359337d6b0c93312be79ba0f6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dd/bf572652c91ad255440220146e5f6135dd082d
meta: {size:1911, lines:0, sha256:"d44c30936431a1b651d7876a6705aa885b57509f5508010eb3a14dc2f3caf1f3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/dd/d3cdc2f8d44faae3fe7643cf9bcbf9a681af93
meta: {size:236, lines:0, sha256:"de596afb843b75cb9db8c4b0d5fe3320421f772c77573a0b77f055afc9ae97f0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

