---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/5c
part_index: 0
files_included: 6
size_bytes_sum: 3386
created_at: 2025-08-31T21:08:15.620948+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/5c/3e45050072f5a8925f30ffbec1327c2b351066
meta: {size:717, lines:0, sha256:"39a7d6ac18c6f1465adbbe68b2d35555296ad3b5c9aa031d0411a0dcd25b60b3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5c/483cebe879ee6e71adf19fbf64f871c5ba69a0
meta: {size:209, lines:0, sha256:"a355a1d4a02c65d04127b02acecda58b20b389eba9ac4db14fc7c2713affbec6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5c/579533465f9a8751ca93b775da6e84b697f1dc
meta: {size:115, lines:0, sha256:"3d774ed0a41ef23d87d611ab3cca1eb7a84415cbd3691c21f3afe3bdc3a7ede3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5c/580230764a3cb534316b415db54553c4bce404
meta: {size:852, lines:0, sha256:"e2c96da8e7d11cdfbf7f079ef14c5bcfa9e19213e7447fe414fd4aa191808052", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5c/9eb6853660261fba27e45b0f65c8c67a1d60b4
meta: {size:1415, lines:0, sha256:"d2302ee51e67a5a70fa7247b50089272d0aab6536a347a67e0bb8d3cf83e1fac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/5c/cef7374eaa5d17d51e90879fb10abcdf740ce0
meta: {size:78, lines:0, sha256:"e48fdfcd97dd6e5eef81368b2a3d0dd0e79ff1b1dbbddd80dd55ecc64c2efc6d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

