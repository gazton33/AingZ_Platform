---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/pack
part_index: 1
files_included: 9
size_bytes_sum: 429996
created_at: 2025-08-31T21:08:15.444187+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/pack/pack-7eb9a10774ada95159dfac1c1cf971c28bc609d2.pack
meta: {size:205529, lines:0, sha256:"d8ae3cfce6b49463031b8d083ea840910b393eedd681d85f6511b21f79b2fc23", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-7eb9a10774ada95159dfac1c1cf971c28bc609d2.rev
meta: {size:976, lines:0, sha256:"72d5436b4269fe13c8ff514254421017205326bf1c17c2c3bcf8c5000a8ec31a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-87a7f407582f13029d54169585499ac1ff0b8fdc.idx
meta: {size:7176, lines:0, sha256:"df0a3e71bb3bd242a9db2e7432cd8e7fd547b995fd8eb3dca54be334f4d85b9c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-87a7f407582f13029d54169585499ac1ff0b8fdc.pack
meta: {size:18067, lines:0, sha256:"5f39521801b99b6eefe131c530dfd6bbe380260a21f112f841147d8c1ddde293", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-87a7f407582f13029d54169585499ac1ff0b8fdc.rev
meta: {size:924, lines:0, sha256:"84d80f2cd16c9263c7bc9d6c34d4dbda9e3d7a2666cef9d0c425811a0d487691", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-a89dd5a91fc0edf61c2ef1881dd43e23813ca0a9.idx
meta: {size:6084, lines:0, sha256:"897d88f159722a8172dfa0daecffcb7333b0ee6b9d5079169987a189dd0949af", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-a89dd5a91fc0edf61c2ef1881dd43e23813ca0a9.pack
meta: {size:185340, lines:0, sha256:"eaa5a259cd7ff0442c96c800d3c16e900c567a164171db90cbda9f9d3abfc07c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-a89dd5a91fc0edf61c2ef1881dd43e23813ca0a9.rev
meta: {size:768, lines:0, sha256:"8daf65183a00c803e4e9f57bc9d0bb058a7ea3de2013e1aae90ad2c553ad2261", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-c35a64df7612cdcd167fbf1deaf0f6e1e7c64737.idx
meta: {size:5132, lines:0, sha256:"fc99a91e29193818fc36c8b8c217057841436defd62197ca6a4038a8565c4363", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

