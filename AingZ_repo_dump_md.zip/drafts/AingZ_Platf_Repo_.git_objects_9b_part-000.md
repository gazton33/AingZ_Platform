---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/9b
part_index: 0
files_included: 9
size_bytes_sum: 2835
created_at: 2025-08-31T21:08:15.628247+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/9b/1239ac2365dcf25a8edade42c4ffcfe039e3a9
meta: {size:299, lines:0, sha256:"df076c29e4a8863769dc56c43fb2a22044ecdb7b65b2cb1e135a2b8a20e20643", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9b/39d786297233b6a1402f091a06d14cbc89b92a
meta: {size:231, lines:0, sha256:"574657b8793e23fe450dc672197e8a28a0b29e53ccbb4a9a80c5b15ad77d2fc2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9b/7d324f1e9294e84ead44e7915bdb8ab1aa2408
meta: {size:485, lines:0, sha256:"374c527aa5ee1980114a70fa0219a286329a4851ac5a0f7966b05f217846213b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9b/86d7b2629ab290445d343188fe31b3f4995a57
meta: {size:436, lines:0, sha256:"ecff11997d68e36232a3a2452efa94db7c48e73f613297e222d898e7c5297c1b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9b/8f16451c1e0fdd73eb78e0ebf39ae89eaa9bd7
meta: {size:124, lines:0, sha256:"cad5321839563b68dbce653c36db6e3c282c463e5cfe82eab7952f5dca43e14a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9b/941496b307f1298c9dc7a178ebd741c641ccb0
meta: {size:590, lines:0, sha256:"ef2a44c96863fcb5c664679230e600b4ea1b4acc7300c55c3a15a082fc0c1876", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9b/a340b07727008a53dc39b94937d05db62199ec
meta: {size:169, lines:0, sha256:"e0d0becf3828b368e3fe6be620e16806b589154e9919e2bedfa2f82f18ef6369", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9b/c57bc020ca166b4aae8c68672af123ae681183
meta: {size:136, lines:0, sha256:"655ef1ddad6b143f5e026d2d40ef9c89093c39ebbd2f3b20fc355cd09619d4bb", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/9b/c7f4a08f46ad25481180dc41cc27124c28abbe
meta: {size:365, lines:0, sha256:"9adc639624979b2086a3e4e10806ec2676ecc6441cdff0e1fcc2b37dce5f9c02", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

