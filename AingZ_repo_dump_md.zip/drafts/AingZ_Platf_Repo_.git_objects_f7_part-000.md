---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/f7
part_index: 0
files_included: 5
size_bytes_sum: 3746
created_at: 2025-08-31T21:08:15.652368+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/f7/3005194d4ff7bb59d4b1df8ea22e170fbc374c
meta: {size:136, lines:0, sha256:"1822411fe10aacd57d5540a83370829b6dc636e12db7d9401ab286cc53e308c9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f7/74718946b94bb11438aebf78a3d2cb2c2d069f
meta: {size:993, lines:0, sha256:"824b3bbbf37d5aea4fbffb367857673b7ca4472c6668167ddfe5b99f44980037", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f7/8dd66faedf07c461ce8e8bd18d5eb22b891944
meta: {size:1930, lines:0, sha256:"a6cc26a00b6fbb3b52e0529a7903d23b76f1646df981000dabd2972faf3c1957", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f7/97409b57935374848d9eaa4d23ad9415951791
meta: {size:582, lines:0, sha256:"96eb2cadd3935675acf89380863f99fab0e2a876cd68060b44227c16522c8220", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/f7/a4c3136b156206c2bbe13caef2b9291b415c3f
meta: {size:105, lines:0, sha256:"553b7c5410ac475b655203656f1ba1e539e927b4d0ba7a9c2b51ee23f601b15d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

