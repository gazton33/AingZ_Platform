---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/69
part_index: 0
files_included: 11
size_bytes_sum: 16415
created_at: 2025-08-31T21:08:15.623002+00:00
integrity:
  sha256_concat: 222eedd4763c90eadd96171cdb9fbd75f1630483ad88d5cac883818fae8f35ea
---

## AingZ_Platf_Repo/.git/objects/69/0b0b1e99de7ec6210040d5fe26ec1fab330884
meta: {size:485, lines:0, sha256:"aaa49bf4a3ead09457301dc7a3d7d298ea76b828abc012e1aa75e6baf2b7c2f3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/69/0c23c5b183e52c7d9aa227b67085cc02b120ff
meta: {size:497, lines:0, sha256:"99a075106b51b887b49123cc466fc3024160e3db8757655af0f9bf9ac925f626", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/69/2cb473158820135b19f9ea08c7b8a1d6a70b1b
meta: {size:10368, lines:0, sha256:"ce1c4c4a25a42f02a42274bfc903a43566389e02f91b9f4b23196b4616056d00", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/69/525e649bf675247cfe407a3dfbe8176c0ddd8e
meta: {size:187, lines:0, sha256:"a32d36d847322fceae6f305c41034921bc55811ae07a3954956c0c9da0528305", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/69/82011036fb810dee4e577eff8b27e5018494f1
meta: {size:942, lines:0, sha256:"24a9dfb027b838cb23c2b75df952ecf8ec1e1651b47a86e7a7570f0ff8d9ce90", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/69/ad991d8a61d36c26e3734d441fb67c7406a73b
meta: {size:1654, lines:0, sha256:"8b1fc5044d6404a44ae2e5219ef1049c62ee0217f955efa554b095d0321fdc7d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/69/b19d33b146c2a9dab82ea692ee4641c7339b9a
meta: {size:47, lines:0, sha256:"3da4d15934e61079ce11dfadd909bdcaed9905566ded43b78a0630b71eceb210", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/69/c898f745c8cf3be7c08ecd10c22c935a21d93d
meta: {size:591, lines:0, sha256:"4c1062ec2420d52aef632f0fa8e3fff6f953240ef6c34678b24aed0ecfc26649", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/69/dfbbe2d2de1bc51d43bdb5b35450e31f38c7e8
meta: {size:152, lines:2, sha256:"4f5acc6b2d06424ccced0c517e0b468af398b17507f654d8b2c2c89aa78918c5", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
x[
Ã ûí*Ü@z}B)ÝÊÕ< E,¬¾YCR÷}íÒèxëDÑD#?ÅLÙ0ëbMàTòèÈ9¶Q¼¹áè>eÆ«¨!c1å ÷&C"Zð§/µÉÏ^"ùÊR¿h¯yçuJÝR«Lä|wEJ^ÉbÄ&~åD
```

## AingZ_Platf_Repo/.git/objects/69/ec7c57c97b4d0de28434d8ebfa8d5bf561b6ed
meta: {size:847, lines:0, sha256:"fe7b39ebdaa22a72f26d9cc56a96fb03029e39201f8686e1b71ba6de5be1aefe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/69/f3295adb9e5e62f85dd0ad8f1716b1e626e3c4
meta: {size:645, lines:0, sha256:"ca5751db85fa6653b7e00ce768fe80aa5180130974ffb1b92a8f2d3fc152ffb0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

