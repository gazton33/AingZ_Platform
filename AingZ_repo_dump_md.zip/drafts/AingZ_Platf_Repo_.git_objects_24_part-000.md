---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/24
part_index: 0
files_included: 7
size_bytes_sum: 12613
created_at: 2025-08-31T21:08:15.569712+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/24/31faa8a9ffa9b35c244fe3ff2a866bbaf253a0
meta: {size:889, lines:0, sha256:"30338d28b43d2f1c7809473e82c43be898dd5a4625e7652fdcb1d40a483af18c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/24/37d15ab184af9f2d3d892f8faa6aa03e7416eb
meta: {size:193, lines:0, sha256:"33fddd3f5e47a6dd7942855008b4b3bdc07f3f28b9ec29f9b6b8b26c12761889", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/24/3f8ef5ea2802e990d1bb3174b731b846bffc7f
meta: {size:838, lines:0, sha256:"52700dbe7b5008d885890f384d1af8b3fc7554ee89e4bdb02913a554f57e22cc", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/24/907a3f060bff473aa621b890a612bb0a0de312
meta: {size:129, lines:0, sha256:"562435f9890efe4ce6d49777963d73833caf44e63b2c2d0d30295254a226549b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/24/a8efc3e46b9a520c173defab8f3451671c8a05
meta: {size:8909, lines:0, sha256:"3f5003eda94b950884636a5841684c596b312accbedd05b443703b2044f00b25", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/24/b5b0f27d39bc5802b9acd0b19d7f54f9fec954
meta: {size:286, lines:0, sha256:"9ebcc5061f451d719cac2290e2feb021abb47f6ec603677b895a516b163a77d3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/24/ba55056fbc426ef91eb65a8bb42cf548f1b022
meta: {size:1369, lines:0, sha256:"86fd9c99c5c6a337d3dfa706f294f04d90d6a114b22872194038270b5523e651", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

