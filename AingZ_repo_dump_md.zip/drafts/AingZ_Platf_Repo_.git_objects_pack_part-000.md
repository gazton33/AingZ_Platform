---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/pack
part_index: 0
files_included: 16
size_bytes_sum: 319553
created_at: 2025-08-31T21:08:15.441485+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/pack/pack-41c00e8ea50ed90054e4c665ed25544f3ccac254.idx
meta: {size:14932, lines:0, sha256:"6939a8fe5f257ce5c1b96a257b4b3299fecccbaa1decfa9ef6d3a506f558f24d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-41c00e8ea50ed90054e4c665ed25544f3ccac254.pack
meta: {size:44165, lines:0, sha256:"d9302bdafff415c4e86dfe42408b0949b31f8ab66a01b2c494d287fdd40b1171", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-41c00e8ea50ed90054e4c665ed25544f3ccac254.rev
meta: {size:2032, lines:0, sha256:"60ed886380f0d694348a0ca728595dafbcca42bc0a8a0a65bb0f4099d351d7e7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-45e31679c552b7a516c29455d4ae6bbddc67e7d4.idx
meta: {size:4824, lines:0, sha256:"3cf8d949c055a3913ef0d7f1ee18dd76fbe3f548ba64498c3b1fbe8c312ce79b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-45e31679c552b7a516c29455d4ae6bbddc67e7d4.pack
meta: {size:67184, lines:0, sha256:"22b73480a1b1f3bda7dafbba1cac47f33d9e2527bd6eef0ef3a732c1f56a97dd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-45e31679c552b7a516c29455d4ae6bbddc67e7d4.rev
meta: {size:588, lines:0, sha256:"588ffb1856bb9290b0de59ffc96c51cce02cd4dfd99491fded91721360f8799f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-4a8dd7481b199a8de21a0e643f18a57e1f7374b9.idx
meta: {size:5020, lines:0, sha256:"0939b8e03a1f5f6749aada84b36c5ffde673b96af74ede5be5317f4e14b6bb0d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-4a8dd7481b199a8de21a0e643f18a57e1f7374b9.pack
meta: {size:38471, lines:0, sha256:"cda2fb1cdc3cf800f0c7ed4d9c987235397b4a3044c817a14aa53e142c68d5c9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-4a8dd7481b199a8de21a0e643f18a57e1f7374b9.rev
meta: {size:616, lines:0, sha256:"6f99dde5ace86d2ea9a734dbef3ddf6c5cc4e52aaefef36a01edcf7359719757", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-4c02e6c90365c4724f6d434eb62184cdc59fad5b.idx
meta: {size:4768, lines:0, sha256:"062eded10f971eb50f27bc9f2ece57922817baa8fc9cb8c6588df4a076bb2ccf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-4c02e6c90365c4724f6d434eb62184cdc59fad5b.pack
meta: {size:79927, lines:0, sha256:"2f43287bb68a5381ea61d53725a3e03b24c792eeb4aee1e83f26addca6ba5143", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-4c02e6c90365c4724f6d434eb62184cdc59fad5b.rev
meta: {size:580, lines:0, sha256:"b372cce45ea18da1264157b8f2350b933d39580396c7b078e15d281344160cb2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-6458f57264d9e7791f772a4f4a521d8ad262f8d5.idx
meta: {size:8520, lines:0, sha256:"3b698dfb26a3f323cac927904f5953552001920c4150dc5ca8b00bbecd555fbf", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-6458f57264d9e7791f772a4f4a521d8ad262f8d5.pack
meta: {size:39270, lines:0, sha256:"71676c2ad250f81ad89592892f266b846561d337a87e603d623605c2ec3c82d2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-6458f57264d9e7791f772a4f4a521d8ad262f8d5.rev
meta: {size:1116, lines:0, sha256:"543e778161dae930d108c66ba0e355d3d7daa470c6475a2c825eed56a5c4d14e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/pack/pack-7eb9a10774ada95159dfac1c1cf971c28bc609d2.idx
meta: {size:7540, lines:0, sha256:"2c1ad216a5e102ee7215523805e9265ca4bb00f105980e366fdabdcf27111424", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

