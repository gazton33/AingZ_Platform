---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/info
part_index: 0
files_included: 1
size_bytes_sum: 240
created_at: 2025-08-31T21:08:15.564803+00:00
integrity:
  sha256_concat: 6671fe83b7a07c8932ee89164d1f2793b2318058eb8b98dc5c06ee0a5a3b0ec1
---

## AingZ_Platf_Repo/.git/info/exclude
meta: {size:240, lines:6, sha256:"6671fe83b7a07c8932ee89164d1f2793b2318058eb8b98dc5c06ee0a5a3b0ec1", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
# git ls-files --others --exclude-from=.git/info/exclude
# Lines that start with '#' are comments.
# For a project mostly in C, the following would be a good set of
# exclude patterns (uncomment them if you want to use them):
# *.[oa]
# *~
```

