---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/e3
part_index: 0
files_included: 6
size_bytes_sum: 6715
created_at: 2025-08-31T21:08:15.650482+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/e3/226995623c328a478a9e2e2b589c3c3677a03b
meta: {size:957, lines:0, sha256:"e23fba7bd001546e163107abe581c43d8b79e63ba8e1f850a85f1491d224f856", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e3/3f622e8914bc052b26ead0121383c5e85f2848
meta: {size:721, lines:0, sha256:"afd10cfa3043ab19b062bda5cca4c55be3702cbb78fbc39c12a5775d8d3662e6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e3/5d798529fbde48be20ab895223dfd36def9a44
meta: {size:2001, lines:0, sha256:"9da565ea2fbbcc0c1e51b0d434d57136b9e54bca58c9d6dd9700e0aa9b676416", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e3/5da9519045adf9c4ec7833d3be28ee6df76f27
meta: {size:54, lines:0, sha256:"bf14537763a82bfe0eff1983bf01f18e085de3cb8c8f2f180cb7e1d52d2b93f5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e3/7445f15da214fb5bb71864622764e456491e5a
meta: {size:2714, lines:0, sha256:"20b225a1b0cf985e83931bf81b89106280bb4e799cd0f1875759edb2220f3b7c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/e3/95fd6cb2d0625d85fed5279183152c694b065c
meta: {size:268, lines:0, sha256:"089e3b94a88645fe4fae5e47f7c818c1d8b3e3fb920a92d2d1c14de837d493f3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

