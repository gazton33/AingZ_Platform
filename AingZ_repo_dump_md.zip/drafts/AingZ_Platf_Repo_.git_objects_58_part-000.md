---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/58
part_index: 0
files_included: 13
size_bytes_sum: 9290
created_at: 2025-08-31T21:08:15.620210+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/58/03099d9a3f497e1b41b9efb02e3f21fda0c424
meta: {size:145, lines:0, sha256:"b6d2be4a1741ad9f410855c507b0aa689b6b6be91dd7846b0739d79e54732591", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/58/03235eb88200e1f212f945070dc200a8239f48
meta: {size:80, lines:0, sha256:"c3223c363053a41501d17784a84ec3699a67567bf89270ae566ea79df92a75e9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/58/0a20e35906d7c2ca276e6e8620bd5648f449c9
meta: {size:631, lines:0, sha256:"dbfe55d394d66f37abeda06772c246145adc95272393856e601e02665da7c63a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/58/1e52150796895874aea8be78c8da14d6e38fe3
meta: {size:1551, lines:0, sha256:"38afdec5e87131d953a313210a4afc1a89cafe5dc262e7758c368cdd1812a463", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/58/2eec146f839021f06f7adb00dfa132bbc63e44
meta: {size:47, lines:0, sha256:"cfc2e810497d1d9e3b716a875b04f990fcc0bb7d45e4f87db0b38a69349a5e54", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/58/396efed42dfc324db14819f96e0575b15e5dc6
meta: {size:849, lines:0, sha256:"ee84344f40d2fd1cd00e822d1e7648e9f059839dee2863515f423312e3c8ef46", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/58/3b4ee2bdedbba605d7285eb31b0101d01eea49
meta: {size:1047, lines:0, sha256:"dd6f912f408361c457e08c38c746e7d944230341531408408aa1b37c87056928", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/58/6122f45f159210a3d5923ff7e6708f41fd662d
meta: {size:156, lines:0, sha256:"2c8279bf8adfe2025a290554b68bc308aba5cff8d8b2a9c030bd7e7f6bd9dd33", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/58/710177277d89953aeac2674b89ee8242421e5a
meta: {size:1671, lines:0, sha256:"2660d20a46fe2e9894b45a10748472f02249dd1fe062d7c5fff266de703c961e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/58/8f3789509bde833f9f9b1f80060d27935e61bb
meta: {size:399, lines:0, sha256:"ea1a7985cda8f7ece3d2952d8cf681d7cfc076133630d8c0123d2803bc58ba5a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/58/a3a1ee66fbba14d7d7d58233f37d362893d517
meta: {size:99, lines:0, sha256:"a7c52bd1006802f016fc98c250ec6c60293cce66250931b2e6e7d19c4a0f6337", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/58/c0da40ce203138754605d8e57a759ba2da0386
meta: {size:214, lines:0, sha256:"8110ac6870a772a1e55485916b920ce7af3c57dcf55e4cb9b3c7e9aa877a6ed6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/58/c10e97c04d1534c8ba7f6c3b4ea648922eb885
meta: {size:2401, lines:0, sha256:"c72b7df6020434162cb6a37db017d0784c2fc9c2cafaf8e4508d50401fee5699", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

