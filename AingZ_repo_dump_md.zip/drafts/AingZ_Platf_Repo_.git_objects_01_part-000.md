---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/01
part_index: 0
files_included: 15
size_bytes_sum: 13084
created_at: 2025-08-31T21:08:15.565714+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/01/03df3e29ecae1b8a54a0bfffcb323d7770c2ea
meta: {size:812, lines:0, sha256:"7a91595d598027575b7db9d5064f037679209cc3b435c6e40755e4fe761ce53b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/03e54c2fc9bf1d0041a88421563eacdd5c5df3
meta: {size:1497, lines:0, sha256:"2b8a18b901e94db95b7178a3bac614321cea9c6ce1b921ac3fcb49191ae55a92", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/239e6260f8685c56a21aaf136266e462cfde5c
meta: {size:139, lines:0, sha256:"be03dc7cd482281dd0bab51483b13e04846ee5a4c6ec503014cca9598ed80881", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/3580159de07fc5deb33429712a9310f27fd600
meta: {size:953, lines:0, sha256:"a4e613d86633d9c8503173fd4eb03125a93d5ed2911f8d03a2273be991920ec2", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/5432967caa1966883ccafed633842ebcb3b698
meta: {size:122, lines:0, sha256:"49f8afd433efb4e4161f512d6ae95619e59417541095a81fd474d45d1faee034", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/6358eeed89637808ffa28bcff1ebdbbfd0fc67
meta: {size:2502, lines:0, sha256:"7fd1e06e2dbf175401805672ffc131638e1c32de1c8bf1aee323a61abae814a6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/63e5828adf832bfef4eadb3b35b5338fd3672f
meta: {size:706, lines:0, sha256:"2345b49f977a24358ec7cac16c88514078090d085e9126de55f31655b68d49ab", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/6999ad963db01c0a3f8abe646ce40326cf0eca
meta: {size:1936, lines:0, sha256:"d5130fd0deaf1fe68585fdae59ced2121bd6e3920c9532e0cb123c84179e6861", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/7476c4725792ae08c1121dff6ae4b358054bff
meta: {size:140, lines:0, sha256:"ec716fa6cfbcef71efbae81d89d242f15f56f9792acbc8f4e46e74128ed2963c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/b1ed1fbf6dda6d2e802d4f1e58f39fea3985f0
meta: {size:569, lines:0, sha256:"bf5a284a9c262c92241745610f65e63495104c4fc562fee36e0bc84de8f8ac95", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/d47fa6a0f0136b7267acfee2a1ae768af61fe9
meta: {size:490, lines:0, sha256:"d05f2d9b24bccb8c1a3e0f3c4e8480eb79fce798763fc3d31707426f6b13e9ed", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/d5a1e35231ed8bc1167b588002ada3d3025669
meta: {size:1274, lines:0, sha256:"5611d72d84a07c8566f39a7283c0cd0bbde12d87fe479369342ca48dffa3bf83", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/e2e5ec9084a3d909f1d0ab7c1258c6a37256a9
meta: {size:105, lines:0, sha256:"04221f199c3ff157f37204dc337a99a52861e8a8b0f40bd09857469d010fe9a1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/f613f9d035e02ce41ffd6f85f546b1e13ab4e6
meta: {size:282, lines:0, sha256:"eb7cdcc46a3681b8148e83c4a861889545a328454f0cc9f4d2e8ab7424d7f53c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/01/fb214e8b9a097e2af617c1b55b471b9bba5a33
meta: {size:1557, lines:0, sha256:"958ccc46467848c0f465a1450849ba975885dd10dc9f75242ff00ee1e731c589", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

