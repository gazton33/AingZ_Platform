---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/2d
part_index: 0
files_included: 8
size_bytes_sum: 6860
created_at: 2025-08-31T21:08:15.570551+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/2d/2b8da2f9d47736646dd483163f57ad27116aeb
meta: {size:634, lines:0, sha256:"26bb8e96bd231d76286d9228d41cfbd8947414453cb4775c5776ab1334bcc347", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2d/2d6d90a2d9c841c00eb76c73f0e3736b54d798
meta: {size:151, lines:0, sha256:"6d60f47ee9f4098f8847c371464191273985337c1678cea22b763db9ad5ef30f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2d/4502c7e555361376f5e92e53a02e6a5bc0752d
meta: {size:84, lines:0, sha256:"d137f807886385d831f8a21c818468e22d7560dbe73cd5351e5ca5c8e63247ad", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2d/8197750748a561c875887ee02a0eaf7013c80b
meta: {size:51, lines:0, sha256:"5754198a165ac74cc736dd86b9d6e99cadb8d50699fbb9e6f575e85fd1b25417", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2d/83468749447b26a0f7b7186fb2a956a6195fd4
meta: {size:1512, lines:0, sha256:"e300d58bcd30988f3cdf6345c223c771314bb5bf3120f7ef79d7ffa4e5a1d116", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2d/d159cf83cb69c99644b39c98b715af68c33cb3
meta: {size:731, lines:0, sha256:"1ea8c793e510a812c3d2bd0bf9428c9407bf91181f73d3d057e98ed073be568e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2d/d7442d163734184e97749159baf920002fee5e
meta: {size:3087, lines:0, sha256:"f1054751657adffdb519e194aa4f7661b0c33a37b3af586aabc3974e104641ae", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2d/e935936fea0cf043776b12cdb5fd842caa83d1
meta: {size:610, lines:0, sha256:"724c1bef3cb72f38bc1387bf8703e86c41260ca9e56df8ea8f077bd0ebc279ac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

