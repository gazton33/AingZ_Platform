---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/2b
part_index: 0
files_included: 11
size_bytes_sum: 18749
created_at: 2025-08-31T21:08:15.570428+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/2b/0670666060d2a0991b6ab4cc1a570393dfabd7
meta: {size:631, lines:0, sha256:"33c1f5364abda54c5b4a42e33f8456da7cb2de98f5a478c4eab843f47ac59325", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2b/0ca0373915387aa5b57fd4c2015adad0619f61
meta: {size:46, lines:0, sha256:"e51c504e7a6d102aa3ccddbd9407a7ec6da29e2b274ffe7a481a928aa94fefe3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2b/205633983519e91f9425a5f0258910a5c3edc0
meta: {size:15179, lines:0, sha256:"e6da8895ae566045bee45541a8e54a7821a3354934d38cee2175ea8961e61f96", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2b/233b46dc4018a538df5ced409dfa38a547cb49
meta: {size:590, lines:0, sha256:"d2db56fcb6052846608cf711be3a436cef821394d4711f3b8567d2c5d1696ae8", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2b/3f72e7c2b5ca3862a12a1bf7be27dd57edd465
meta: {size:372, lines:0, sha256:"0d7060efb142a9d02fee8090d8c419e77af3f63aea682e359bbbdb0929c9095d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2b/69ecb57a810140ed81159c4a1f40950f1ce805
meta: {size:51, lines:0, sha256:"6273d63b895399a3481d423c93386338f818802a071480ebee8851612212baa3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2b/a6ba6b02ef9075ecea5e8aa3cbf4a1880bd830
meta: {size:859, lines:0, sha256:"441281eaecadb0050771c3d1dcf7f52a9d5a622c42cf79d8950f2115419e7646", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2b/aee90c22358571ba8b653ec8ca4c6141760150
meta: {size:414, lines:0, sha256:"23c6f1e71107a45d8c4349a5b53ab0faf2688810a774d0516844039bdf68f4ae", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2b/c27d06b0e03e9b8f9780288d0abde9b9e89808
meta: {size:164, lines:0, sha256:"3b9cd5cfab725e1bc8cd5a36e9213fc81000d6a1a39cc7e029643d21753eadcd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2b/df4cc3a72309ebb908198f5d1551f251a051aa
meta: {size:289, lines:0, sha256:"0704e4e5cf6516df00f3d112a6f3911a01d6c373e8670254f5c47c7e95d4dbbe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2b/f614f269253d0a0fae9a178a6f25cff154c245
meta: {size:154, lines:0, sha256:"e874f06ecb049fe93174a68571c57b8a19d7842bd4342d1370d2e0316258fca4", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

