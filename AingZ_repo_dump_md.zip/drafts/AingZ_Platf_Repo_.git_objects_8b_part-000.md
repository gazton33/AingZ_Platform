---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/8b
part_index: 0
files_included: 14
size_bytes_sum: 10720
created_at: 2025-08-31T21:08:15.626901+00:00
integrity:
  sha256_concat: 039266237792c438ebd3451bad9fa898cf79c9fb8d198b4523080ac558e84704
---

## AingZ_Platf_Repo/.git/objects/8b/2e3283a8fdd8f73017a35a25dae3a897af5973
meta: {size:505, lines:4, sha256:"23c615ba42122e48eac42c68cc9449eedd8c9f1007617f298c86c17098cf48a1", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xíVÑn0Ý3_q¥=t{`Ð4­*&1@M*
¶i²¾¬HÆ¶³%Ò>~¦é²tZfIòñ=>¾>_={	¶­à­iÅZV´*ÉkµJ¨¦ÐeÃÄLm÷Ô\ðd¡ï-ªføª¡æËUcÛRÕR×¨ÝOnY¶mä)J´­2Ãkiä×Ãõ,È-QªkòL	®4rZSALøsâ^÷¢g¿VWX®KÆF:ãÁ#4E«QÉ
~ð=dlsmÐÄ?#§G Q?­KÞ·y#á=mro£ÜCÿOs¤$OQ&>ßç¡iQÉazÿTÁoKó$"Á<gW¦¹¾IbDäíôÁÍJ¡ÐQKÖ¢vúÆìïÐv/ÍelwÂô³ôøyg$K *5Sý)ÅL>ÁL@»,ï ól
h­°ÔB­=8ÙÅæ³Ûy~éññÛw7¬§Îý_¯íþêõkùö¶ügÕöàEeQù)¼?Èr??4Ïü.[[ýøØþIAß{&z8o¬¡«ïO%½üë¦ÓwÎzxK%©I)(®Êü1/³¾êVã
```

## AingZ_Platf_Repo/.git/objects/8b/377bfcd66043fd793fc4ae9ed1f10791962f52
meta: {size:154, lines:0, sha256:"5994cd80e8346dd1c8817c4066ef4b28c9fe3d6aa4c7ef9de5edf44364421fe6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8b/38f152799701c55a94a2a574ff2852355483a8
meta: {size:609, lines:0, sha256:"760b1a1bbb064f801be39fdc43dd62f1a77ecc15e8e302f1ff9f4d4e212995ac", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8b/45ad0593e9966c5062b83105ba2bac78220cbc
meta: {size:73, lines:0, sha256:"41f73decfe9050aba579ff1d0b2717c3f540a239896bab3c970b5e4fe026f36f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8b/7be335dceb67984fc64a188a7d0dcc1d6f0fe0
meta: {size:51, lines:0, sha256:"b010ff1d235d43a860d424dff59309d618a6d66bd0d3ab4689569ff062374329", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8b/905efea61784998c014ffaaae068ccc053c118
meta: {size:53, lines:0, sha256:"68c79c354ce2e253ef94ed7b0e6992a938aac31d5d9215f650cee824a0481ba6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8b/9b9d6998bd0a49012e40d2da163e4c9b2bbc2b
meta: {size:1399, lines:0, sha256:"1b3ee8e327d687ab72614008061cf5878a3f40c6b622df3a445a4070434d15e1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8b/b7f391c73d9c4a9a2ce75fef27eb5bb989b249
meta: {size:429, lines:0, sha256:"eea480411f7c2f21111616ac92ee266b62da3899b32854cef38ec295777bf3d6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8b/cc07b8a8742f4f7291e7e061bbd5d6f45fc9e5
meta: {size:1875, lines:0, sha256:"26d4660dd1d9f5922136266e5c9920b4055860bc7df1f1a12b81d7bbb1e88554", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8b/e0070217758288210d18da617a003ca6cf4fc6
meta: {size:3040, lines:0, sha256:"161763c22a06048cff566c93d00e032efb5c326c7f68ba61914aac28811e1a6f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8b/e385b5b979e02dae9914071e287b736004a92c
meta: {size:718, lines:0, sha256:"597c6c1f8355e3f8fe02ba1c3b83d215c91ec6e2e6d641bb2e33ef34ba505dc0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8b/e42b26699b608ccb37c34b93bc977e8a99c634
meta: {size:880, lines:0, sha256:"07a4c518669e18467b3d7bfdc9cb3cd7a2688a89f7fce0f55cfbd8420dd1e73e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8b/f31d71e3eadcc3ead0e425690fcc9565dd043c
meta: {size:80, lines:0, sha256:"98037b5908f6bd7d98c11c3ea0b974da35e672eba4022747a8534314fde81add", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/8b/fc7fcc89107fe08fc53b75267f443dc52122fb
meta: {size:854, lines:0, sha256:"5ed119e75535c1989407454105d51e6ccc56685532fbf1e8b90e3923566e0dfe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

