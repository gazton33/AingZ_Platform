---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/80
part_index: 0
files_included: 13
size_bytes_sum: 7917
created_at: 2025-08-31T21:08:15.625376+00:00
integrity:
  sha256_concat: f41f1faf34df77f5b8219116f355d9dc162a34fd7e695b401f75e857785e078d
---

## AingZ_Platf_Repo/.git/objects/80/006ff66f49a3a49fd69057ae878c27a218d22d
meta: {size:698, lines:5, sha256:"20b6ee1f1c967b3d67a83ce21cff742c294285a10e268f7830a81714c8bde792", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xíW[oÓ0æ¹¿âH<ºv74úµÑ¨Ú©KAå&§[4'6¶³­?ãÞHwI²¢= ¥µÛøóù\¾cOÀÁÁÑûW¯!@cdfhä:Ã¸ÑðoyªfVÏ`*uÊm§Ñýöþa³½GüÅíeËÊÖ4¸ÆôÏNp
1H'Ê&291WÞh4Mú±¹Å"-Ñ´<É`ä{½O>éè¾a69*d]³C·³8%#óG¬}ÌÚï½æÉ£Y$°e1U­úÂ5¤ÜXÔL	m¥¦ø#`¤2-ú0<Nì°½à£rX5·üXðjxl{Ï-ç/ÑõaÖtÉóyTÈyÒø=Yïz°Àm£qà³î°×Òðé,è{®Ï>.Ù,[:m«l-e¿cÂfû¢Ýµ	£Sæ{ýL9Q3êw_ëLÂþH0yt	³AjzÖ¢èNîpp>ú=/ô·³´© Ò^pþålý8±JÝÿýµ¥¿î¶ïÎºÿéÚxÓóC¿z#ø
^7{AÿýCÏekðÖ±ÕêPüþhM`^PëïO]|uMÒ)«³ÜJËTYÉo|S6Ë(Qd-
pU[E¸É[XÚTPiï¹å~ÐÎ±êºX±nP$ë³î%FWd1b;GK¡²ÝÇ°®µ¢â¸àoâæë;y]|Y;+®N:"±7ÌÜ ª]5£Nõg1yâÒÄ7®Oýóîd@i¼¦¹Ð<#rw÷íL\s¸[KÑrð*i×Ý-ÒàÑhüSßaµ
s«rÒ=B*0Ôéc¿×^È
```

## AingZ_Platf_Repo/.git/objects/80/13f0e5d7098658332eaf2cd0bb434ac0c3c443
meta: {size:1246, lines:0, sha256:"221639f00b6dafc6ae450b015e13ddb06ff86c2906c797a0e4d6c7ea6eb9dcd9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/80/3303f7f6aa63c76bb53de572aca5b50aee364f
meta: {size:83, lines:0, sha256:"9bf5bd3c278e80b083b3ed1a1c3c5cb9655db470cfb5a02c83c740e4eac421ad", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/80/3f467e2d212b211d9413b41d394b99bcf2074f
meta: {size:910, lines:0, sha256:"ab7bf544464217776b9bb35e6dbdf7011a0b886aa4210febe0dab10c95cb68b7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/80/41d0d28db267ea042f648db3df0f4b465091e3
meta: {size:51, lines:0, sha256:"5e0433b53de5a2e3b5f06202d88639a87e1fe4ea8230ab74a7f21eb95d3dae69", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/80/4a50391fe32773fef6fa45a373eec0a2054010
meta: {size:1385, lines:0, sha256:"0b88e1eeafa030aed8faa890e2fd1ea442d6355e4af9f9ddbc61c2fad1230301", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/80/6c4f7fcf05775d9bc61cea2b327dd972c3351d
meta: {size:902, lines:0, sha256:"37185224f54801a57fcfc0255da6701633875ba6389efda418de257cb736f266", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/80/72ee947566786d1e9f4fc9c0cf8e6a27877523
meta: {size:178, lines:2, sha256:"90bc5edb73dafdea3cc3bb5baaa42302087abeb4014472c5007eeaafc70e795b", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xM@E[û+Äu¤IµÌ"¨íÃy4_cÑ/$ZET«»¹ç.á¸ÃIÜ»:®ë3 ¼Am*iá`kQ²)pÁx 7u=^í^(Gß¢Ðþpÿ%emÑæ¥üG÷-Þ	µQB[ a¤¬W;+= =¾õÔo¶y
ÉjG,×y6+vÑs*¾ixÖÿØunÎ¹°T
```

## AingZ_Platf_Repo/.git/objects/80/7fa03590115c044c81d9db387cef6baaaeac43
meta: {size:104, lines:0, sha256:"1210681ab530081875ec8d002c90eb83300c1b1ee358c6af3369752803ff3e78", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/80/afc4d85b783801617d86518043ca0354dfdf9e
meta: {size:289, lines:0, sha256:"9cd559697201c963e57e873f8b5ab8dba64534e102d40c72b566f3225224f78c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/80/b2a9042bceb783e6654e2b0382d527dc1c62e0
meta: {size:765, lines:0, sha256:"0c46b1676284290d4732bcfc981da5e07549703e574d5d2d661c634520212f2a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/80/e20cfcdfd269b3cff7e1e9016aca817618669b
meta: {size:1227, lines:0, sha256:"d3bf3d29ac3dc37154b21c983fe6d99f0cba7d3dcaccffe0415e72a8abb69d24", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/80/f09e0792d8b614f68c3127360b986e844a4484
meta: {size:79, lines:0, sha256:"04e15ad121c0840f521d705d014f9631ab075f4c72a60a71b8cc87622af60c70", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

