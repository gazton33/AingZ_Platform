---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/bb
part_index: 0
files_included: 8
size_bytes_sum: 11046
created_at: 2025-08-31T21:08:15.630267+00:00
integrity:
  sha256_concat: d4e022c51f31f081e6ad0177df1963874ef097e8af800acbe63225595542d7c4
---

## AingZ_Platf_Repo/.git/objects/bb/1c8ed9fb4d7ad74980608ee3e35c28f9a6a781
meta: {size:895, lines:0, sha256:"6c4dfa754815b27e8e71946532eb09436e6cab176f62be67bacd23704da9a3ec", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bb/43ae98bc4736c4187f6c88fa9d09b4e1a2eab1
meta: {size:1328, lines:0, sha256:"3323dc801dba13c0c48d83b0848ee174ecbeb455b5fe3fdf3ff96c20baa575c6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bb/5a781c9416f832f2ca76c40702321bb4bebb36
meta: {size:711, lines:5, sha256:"8825906bdda262331f219056aae1e68a9ac851c72832d0ef6fe262d1c96591d5", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xSMNÛ@î:§x°CÒÔì¥E*mh  ±±&ãçñ53vHV=D/Ð%®zÜ¤'é;AbÑU$gf¾ÿ©2Sèõý7{0Y&£ïnÉùÕxrs\Ü%î¯ãÛûär|sÞOúGýÁÑIç)üýñFeJÞØõoè¼-¥/­P°?ÁÂX Joòõ/OÒÀÅ]÷úî Ó¢¨ÓÙÛ^WÖë?èJ£=>zÓÙy2Eö2ÔhEjAÀIKýÍÁd¾H²U¢ÇÕª¦D½AÒ{z±ttÙÁiQ¸¹ñ"¸¥;gf~!,2lü¡@K³õeþPã?.(Þ¢T¤PQ%âgýNµÄ\y&­À¡Bé©2|5]ç:K_©FYíÛð1X
Î®oùêaR³Ð5OìH#åB/ëb4rsNGÊÃÊç2°ßÉÇÕ<å¤ÈCóUc)³A;ÊE>%ÃThÁ¬P{¶HrBØ. Lpµ$ÁßËH³ðë'©I
¶¼¹o£ßÞÆp6Gù Cf6t±8hkÒRRëù~E®*Y¶!UËÆ¾nÝÄØæÊ·_$üç¹!?·,A6
[;^UTPØÿ ¡}	3!Àöe¤ÙA»µðßUí6E­¹xIÑ³tàx/¨MÖ°Ûe½á#b:òá:g´ã_a5¦\mBL"½]ënòd¹
BAhÙù¶u³3ìÔhv\Þ¹Ò¼cg³ýZ¶re¸2ÂòÃî¦_¡6gÌÖ5Y0õêÓ9æ¡[¡P°ÅmL9Ãq]Ò¡Âiõth¸
```

## AingZ_Platf_Repo/.git/objects/bb/8c5c4d89e57d318b46a46059677cab60cef9f2
meta: {size:1790, lines:0, sha256:"4a52bdc5477b7aaafc13bf4f7b6aca9ad48d8cf21fdc76683746062570cc2820", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bb/b592beebf410ae0124b5a4a7c43b6ea923bdb6
meta: {size:373, lines:0, sha256:"470e3bb4ab0d7924901eaf171fa8fa564e0458c8ec7cbadbe68140abff2a86d9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bb/b81c5c94395458a3afad8991b381f2011fe7a2
meta: {size:1668, lines:0, sha256:"fe77c27a2005fdf897886f80fdf23aefcb8844c633fd442a03fd457066e96b4d", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bb/be55de13a00044b71468c075e0f4cd905eaf2c
meta: {size:3344, lines:0, sha256:"22e040760306e4e4d57ee2aa4569b05e72d6f772fa9cea6bfbdc4a9e0d461d91", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/bb/c4b1c62f99c9f4a956c97541f2a725741238c4
meta: {size:937, lines:0, sha256:"f4e16b485b65efdb0e26d1bdc5f2a7f80091a4caba364ad6686f3fa7c6051bc9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

