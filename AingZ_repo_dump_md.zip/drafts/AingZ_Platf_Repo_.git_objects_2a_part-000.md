---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/2a
part_index: 0
files_included: 9
size_bytes_sum: 5992
created_at: 2025-08-31T21:08:15.570323+00:00
integrity:
  sha256_concat: f98dc767a80aa7eeaa9ca5a18125a93979a5be3d4008947b271231f098451564
---

## AingZ_Platf_Repo/.git/objects/2a/27f4914aaec4ceda2f9d24ad4b247d96e843d1
meta: {size:763, lines:0, sha256:"8ab796d265a702ca9ed989bd509b53d2695c54bfb499d79a55068d91cb6330fa", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2a/2fd8033df65bc3693469037159908b22424b1a
meta: {size:2025, lines:0, sha256:"4c4713b76bcb7310a462e4be370ed2bee4b61ea8e6dff1a6ed50a37cefbdaab9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2a/43f6ea63d92f855246198ddbb2aa80e65deebb
meta: {size:178, lines:0, sha256:"5b4a785e9b6fd08ffd451b3b4faa10784f9a226ad5e2f62252f4cb9c24fad958", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2a/856ebe8d255adef778897564e9fca135b13400
meta: {size:1213, lines:0, sha256:"3ac0f46e16015b5b5bdfb64355c4a50e2e6334b184d4d335bea5dc030ea6ec26", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2a/b07ac4c42f4e84fbd29c44fb95918440c9dbad
meta: {size:74, lines:0, sha256:"ad139565010a96b0e0184fac093996aaa292cf248e8324ba072eb3705369d96f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2a/b749085a248643ba7dc73462677966b20c182e
meta: {size:168, lines:3, sha256:"6c656249ac895aeb0f37f43719987f39042097a621c7c0f25a268de56e5e3f66", mime:"text/plain", triage:"B"}
map_targets: [SPEC]

```
xEË
0E»ÎW\²Ò¸*ø]tbÉLþ}£¶tV3pîÓ»Ð£iÚÖúI,1DÈLØ¼¯ØÛªyolañÂUfcXñ
ªivÓËº(É+¥!¹×äÓD=+ÍJÌv¢¢¼+äÉ­Ï!¹{äàá;-e¦ë_Q¢ë óÃÂ/~Òê¸oMê
```

## AingZ_Platf_Repo/.git/objects/2a/d7bbd89836693bed20b722c0b7fe159d4d32af
meta: {size:133, lines:0, sha256:"ab05d06651e415d16e71d65d0fa81325164cf49d6c1b8d1043c45221c2b3da03", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2a/eb78e57e6e6c537bfa5b274c1a54166e4ccd04
meta: {size:846, lines:0, sha256:"3021e8c39f454d82564bf8a32b37e22ee38f2a5d12258262ec2e55a43aca8ffd", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2a/f1cb6a8371a9fba5f335c211f31dc9e8dac92b
meta: {size:592, lines:0, sha256:"ac6e3d6720967bc7acd4c7eebb7536a9fd19fe2fb5e8692e776b292adc6d9ed7", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

