---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/56
part_index: 0
files_included: 10
size_bytes_sum: 11164
created_at: 2025-08-31T21:08:15.620046+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/56/102be82cdba644d00da6258f649125ccd8245f
meta: {size:857, lines:0, sha256:"67577d3a89a10ace96241e7cb000ba0250afb25655fb25ca4d9c568f1f8030f0", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/56/166994e1dee6446dce089421c7cf8f13d0e907
meta: {size:967, lines:0, sha256:"48a0b76a1b8136d765c362ae611054ff7e243f9c4a25fac7fdbe4bcf2120a9b5", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/56/20de087d2867affa23ce45552b86cc052161ff
meta: {size:1918, lines:0, sha256:"2b35538e7c75108234bfbaed76d0b619aa8566c22064b7e83b5436a24916cf2f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/56/47bccfca89c828b76f1e247bf4da3ea40c70d1
meta: {size:1315, lines:0, sha256:"31c4e0935ac6622c02a4dfffaf37a2d370c4ce8bb5a0c36a09994b1b1a7b8e80", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/56/5409bd0031cb7c9f0292f3ea055b1679f0476d
meta: {size:99, lines:0, sha256:"df63c17f98a8734f44a2e464f614ffde9094943e66cd7a5b9feab58570601e6c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/56/99a0a533d1a3ed747c6922c0a3318de03e6b59
meta: {size:1628, lines:0, sha256:"d39b8a5bf908c929af8ebe6299924ec167930c9186cfa0eb38f6cb61e5643137", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/56/a7821b841ffc39c604363c26dc96b608a38360
meta: {size:848, lines:0, sha256:"6d33f0de45a9ba89f426552644605e8b79ade99095d17043052433189211bdf6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/56/b08112663b7e812d67a1570db33d8d83c3365f
meta: {size:861, lines:0, sha256:"5c27dea76c79490abe9d32716b3d2f528a9dffbecfac32578183e2c8c83edfc3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/56/b7f2c0d3da791377879b3c975fc8236b15dc18
meta: {size:749, lines:0, sha256:"71d2345831ea55d6de13e49c588de1dce4beb60f0639fa697a74a644a7494b96", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/56/f9f3b4a62f4cf3601bdf5aaf42de4c9e138ac7
meta: {size:1922, lines:0, sha256:"de8e9f15b086e5c51b9c5ff32566ffa55e4d392d4c64e5270ce88578f9a25c44", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

