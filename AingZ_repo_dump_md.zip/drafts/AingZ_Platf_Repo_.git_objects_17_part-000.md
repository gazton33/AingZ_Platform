---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/17
part_index: 0
files_included: 13
size_bytes_sum: 14141
created_at: 2025-08-31T21:08:15.568264+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/17/14336c5be51bce1784aaffb85a27d005c94496
meta: {size:193, lines:0, sha256:"d80fccead9f355fe9a050401314401cdea38b0f1a896ff0895815846ab1f3c83", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/17/244a5120ac5d2be225018d4aa44b46ece22510
meta: {size:3229, lines:0, sha256:"2447844e20661575bd965cbc5e54aadf71c3c443c2ad055c63fa21b03b7dff21", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/17/45a00bdc7f1a8ecd4eb910d6264ed0b6bc8585
meta: {size:150, lines:0, sha256:"dd464ed5e67b9a78e0aeaa6654913d2b451bc35645e7776f790e7d7e32c6af1b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/17/76a98195298999326d089ba4b361b070b2341d
meta: {size:801, lines:0, sha256:"4e380ac5449daa4f18d01e268a928dab888b60271f2adca364ffacf54b3ec46e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/17/83ade8e77ffeffaa65da95fab38c702272bc4c
meta: {size:1665, lines:0, sha256:"9f251e3108d63a357d6f60f3b0e006ce860e8a9c73d60a42afb05ec318103555", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/17/8e4fd4be14bbb87a0c2f892954fa9484195b9b
meta: {size:232, lines:0, sha256:"b3ac10a6235033b37796322b7829e8f6abd391eeb864120fc42f9fcb8712833e", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/17/9284f2ce7e16f208739966b76151563fbed4cd
meta: {size:2352, lines:0, sha256:"e5bdd0bf004795f900a6b98c7b9696bdef2ba293eaa5daf03d7ea549679f578f", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/17/97c0032b34fff1cc97754924d1b275f0d35c3e
meta: {size:1594, lines:0, sha256:"7c0be896bdc728d1789902acba5106a25e1988a88b6bc7d6e920079c25ea52e6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/17/97fb25990bcfd12b157bdc64cd6a0c77352ada
meta: {size:51, lines:0, sha256:"656e20b0b336b730ccde467d30b4f37d435261c54f6d0ef866ddad6120768535", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/17/a361f489777aa883ed7b04186cb28369b69dfc
meta: {size:547, lines:0, sha256:"0970730ba1f940320ae020efaa1d1faea7fdd1ab649c6d387124b3c22081242a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/17/c83d0288639825586f731d504124ba580e2eb5
meta: {size:1669, lines:0, sha256:"036e1d485a08f52ea177395b0956f056761491d0269528f2215ccf4d729f1efe", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/17/d854cbe517e76d25593f39d12d417c86bbe750
meta: {size:685, lines:0, sha256:"dfb4dd54c4f9f1eede59a2b8c4deda40b3ab75f103593ed1affa6a4a8eb8597c", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/17/db66f85c7b5aaedc6b12f296f3953e8b60e2f6
meta: {size:973, lines:0, sha256:"10cb37a838ef905b0550ddcf0388febf169765ad41ca3e984383bedba37c5214", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

