---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/2c
part_index: 0
files_included: 7
size_bytes_sum: 5412
created_at: 2025-08-31T21:08:15.570504+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/2c/27ce0fed93060cdbbf7a02d34e447ecff13b5d
meta: {size:844, lines:0, sha256:"410420c4df26763cf45a3b4fba218f8759a2ff9ff9c81359f87c899ee39eebb9", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2c/556a50eefd800882929c5fbf36edcf84dcf990
meta: {size:46, lines:0, sha256:"7b4dae73618b4be391ed90adf043d77fd79ce0f3e91d68e264b1559b8cd22627", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2c/5f61abffe0747d501075e66849448fbe501122
meta: {size:917, lines:0, sha256:"70b8084cc97aa0daea00c81f650866681faf1162853671bc0dc79c00afdf4ea3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2c/79f7895c16e6eb7789fe3e4e8d5d542498ba2d
meta: {size:1903, lines:0, sha256:"f7f1efdcafb096c3bbd6ef5b9512e1c63195288f7d52153f225e1e853c7b46c1", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2c/84bf935f0bcc2e3b0980e2a9ce0147dcb25f08
meta: {size:844, lines:0, sha256:"03750b661914687a8a10186ba29b91497a3d4603f52c4926a8f5f6a746094800", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2c/dfacbc8553d8d06cbd1ee9e77fba738da5119d
meta: {size:57, lines:0, sha256:"8723e626f8ed349b781f00e230a50354ae62026bc20b3b430c5998b675f0d58b", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/2c/e9e9ab59e98e8f9fa8151b6de75d4bc710de8e
meta: {size:801, lines:0, sha256:"abc3591c49c337eae945062c658bef9ce9e4daabbbf3a332d586ecd996456bed", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

