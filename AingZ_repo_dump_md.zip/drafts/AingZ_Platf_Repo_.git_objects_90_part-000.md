---
source_zip: AingZ_Platf_Repo.zip
source_path_prefix: AingZ_Platf_Repo/.git/objects/90
part_index: 0
files_included: 4
size_bytes_sum: 1986
created_at: 2025-08-31T21:08:15.627496+00:00
integrity:
  sha256_concat: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
---

## AingZ_Platf_Repo/.git/objects/90/61758fd7856fcaaa20adbd0ae883817f0385b8
meta: {size:855, lines:0, sha256:"992234fd47866ecd5d77158f43b222f07b4a223046623db2415641a15d50e578", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/90/9ec9d3ce06cff83a625d2573919ab0481ddd74
meta: {size:592, lines:0, sha256:"3ca69293bc6384f36487204e6704489730ec200b4d7d474c59dc808240f4769a", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/90/c510e02759fd33fd7a376266c92837910368ef
meta: {size:306, lines:0, sha256:"51d1b4407eb13d753ac5fadacb203b1436915e98fdd49b4b47a524fd32d7acd3", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

## AingZ_Platf_Repo/.git/objects/90/ce5a1ed897649e4568a6df4289758fd5af0287
meta: {size:233, lines:0, sha256:"de1c86eb0ad9b02fec4545bb4838d5373f5c3b3cd0026042459bf8dcda2d29a6", mime:"application/octet-stream", triage:"B"}
map_targets: [SPEC]

(binario/sensible — sólo metadatos)

